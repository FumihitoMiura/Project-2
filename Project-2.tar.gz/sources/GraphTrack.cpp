#include "GraphTrack.h"

#ifdef Q_OS_WIN32
#include <io.h>
#include <fcntl.h>
#endif

using namespace DesktopTrack;

GraphTrack::GraphTrack(void){}

bool GraphTrack::printTrackLayer(void){

	if(CGIParam.layer==""){
		return printTrackList();
	}
	else if(CGIParam.layer=="description"){
		return printTrackDescription();
	}

	//�u���E�U�[���C���[
	else if(CGIParam.layer=="image"){
		return printImage();
	}
	else if(CGIParam.layer=="index"){
		return printIndexImage();
	}
	else if(CGIParam.layer=="operation"){
		printOperation();
	}
	else if(CGIParam.layer=="index_operation"){
		printIndexOperation();
	}

	return true;

}

bool GraphTrack::printTrackList(void){

	QStringList filters;
	filters << GraphFileNameFilter;

	#ifdef Q_OS_WIN32
	_setmode( _fileno( stdout ), _O_BINARY );
	#endif
	QFile file;
	file.open(stdout, QIODevice::WriteOnly);
	QTextStream out(&file);

	QDomDocument doc("track_list");
	QDomElement root = doc.createElement("track_list");
	doc.appendChild(root);

	QDir revisionDir(QApplication::applicationDirPath());
	if(!revisionDir.exists(RevisionsDirName)){
		return false;
	}
	if(!revisionDir.cd(RevisionsDirName)){
		return false;
	}
	QStringList speciesList;
	if(CGIParam.species.size()!=0){
		speciesList.push_back(CGIParam.species);
	}
	else{
		speciesList=revisionDir.entryList(QDir::Dirs|QDir::NoDotAndDotDot, QDir::Name);
	}
	for(int i=0; i<speciesList.size(); i++){
		QDir speciesDir(revisionDir);
		QString& species=speciesList[i];
		if(!speciesDir.exists(species)){
			continue;
		}
		if(!speciesDir.cd(species)){
			continue;
		}
		QStringList revisionsList;
		if(CGIParam.revision.size()!=0){
			revisionsList.push_back(CGIParam.revision);
		}
		else{
			revisionsList=speciesDir.entryList(QDir::Dirs|QDir::NoDotAndDotDot, QDir::Name);
		}
		for(int j=0; j<revisionsList.size(); j++){
			QDir revisionsDir(speciesDir);
			QString& revision=revisionsList[j];
			if(!revisionsDir.exists(revision)){
				continue;
			}
			if(!revisionsDir.cd(revision)){
				continue;
			}
			if(!revisionsDir.exists(GraphTrackDirName)){
				continue;
			}
			if(!revisionsDir.cd(GraphTrackDirName)){
				continue;
			}
			QFileInfoList entryInfoList=revisionsDir.entryInfoList(filters, QDir::Files, QDir::Name);


			for(int k=0; k<entryInfoList.size(); k++){

				GraphFile::FileReader r;
				if(!r.setFile(entryInfoList[k].absoluteFilePath())){
					continue;
				}
				GraphFile::Header header=r.getBasicTrackInfo();
				if(header.species!=species){
					continue;
				}
				if(header.revision!=revision){
					continue;
				}
				if(header.trackName!=entryInfoList[k].baseName()){
					continue;
				}
				QDomElement track_tag = doc.createElement(TrackTag);
				track_tag.setAttribute(SpeciesAttr, species);
				track_tag.setAttribute(RevisionAttr, revision);
				track_tag.setAttribute(NameAttr, entryInfoList[k].baseName());
				track_tag.setAttribute(ProgramAttr, CGIParam.address);
				root.appendChild(track_tag);

			}
		}
	}

	if(CGIParam.is_cgi){
		out << "Content-type: text/xml\n"
			<< "Pragma: no-cache\n\n";
		out.flush();
	}

	out << doc.toString();

	return true;
}


bool GraphTrack::printTrackDescription(void){

	//�g���b�N�f�[�^�̃f�B���N�g���ֈړ�����
	QDir graphFileDir(QApplication::applicationDirPath());
	if(!graphFileDir.exists(RevisionsDirName)){
		return false;
	}
	if(!graphFileDir.cd(RevisionsDirName)){
		return false;
	}
	//species directory
	if(!graphFileDir.exists(CGIParam.species)){
		return false;
	}
	if(!graphFileDir.cd(CGIParam.species)){
		return false;
	}
	//revision directory
	if(!graphFileDir.exists(CGIParam.revision)){
		return false;
	}
	if(!graphFileDir.cd(CGIParam.revision)){
		return false;
	}
	//graph track dir
	if(!graphFileDir.exists(GraphTrackDirName)){
		return false;
	}
	if(!graphFileDir.cd(GraphTrackDirName)){
		return false;
	}
	//graphfile�����݂��邱�Ƃ��m�F
	QString graphFileName=GraphFileNameTemplate.arg(CGIParam.track_name);
	if(!graphFileDir.exists(graphFileName)){
		return false;
	}

	//graphfile���I�[�v��
	GraphFile::FileReader r;
	if(!r.setFile(graphFileDir.filePath(graphFileName))){
		return false;
	}
	const GraphFile::Header& header=r.getBasicTrackInfo();

	//�p�����[�^�`�F�b�N
	if(header.species!=CGIParam.species){
		return false;
	}
	if(header.revision!=CGIParam.revision){
		return false;
	}
	if(header.trackName!=CGIParam.track_name){
		return false;
	}

	#ifdef Q_OS_WIN32
	_setmode( _fileno( stdout ), _O_BINARY );
	#endif
	QFile file;
	file.open(stdout, QIODevice::WriteOnly);
	QTextStream out(&file);
	if(CGIParam.is_cgi){
		out << "Content-type: text/javascript\n"
			<< "Pragma: no-cache\n\n";
		out.flush();
	}
	
	//�g���b�N�R���t�B�O���[�V�����y�[���̓��\�[�X���Ɋi�[���Ă���
	QFile resource(":/browser/GraphTrackConfigurationPane.js");
	resource.open(QIODevice::ReadOnly);
	//�I���W�i����JavaScript��S���ǂݏo��
	QString document(QString::fromUtf8(resource.readAll().data()));

	QString anotherParams;
	for(int i=0; i<CGIParam.anotherParam.size(); i++){
		anotherParams
			.append(",\n\t\t'")
			.append(CGIParam.anotherParam[i].first)
			.append("':'")
			.append(CGIParam.anotherParam[i].second)
			.append("'");
	}

	out << document
		.replace(QString("TRACK_NAME"), header.trackName)
		.replace(QString("SPECIES"), header.species)
		.replace(QString("REVISION"), header.revision)
		.replace(QString("TRACK_URL"), CGIParam.address)
		.replace(QString("FG_COLOR"), header.fgColor.name())
		.replace(QString("BG_COLOR"), header.bgColor.name())
		.replace(QString("AN_COLOR"), header.anColor.name())
		//.replace(QString("MARKER_COLOR"), header.markerColor.name())
		.replace(QString("ROW_HEIGHT"), QString("%1").arg(header.rowHeight))
		.replace(QString("VERSION"), QString("%1").arg(header.version))
		.replace(QString("ANOTHER_PARAM"), anotherParams);

	out.flush();				

	return true;
}

bool GraphTrack::drawGrad(
	const quint32& highest,
	QImage& image,
	QPainter& painter,
	quint32& strand,
	quint32& dataType,
	bool showLine)
{

	qint64 imageHeight = image.height();
	const qint64 pixelPerGradMax = 20;
	const qint64 pixelPerGradMin = 10;

	if(strand==0||strand==-2){
		imageHeight=imageHeight/2-1;
	}
	else{
		imageHeight=imageHeight-1;
	}
	
	//variables
	qint64 gradMinValue=0;
	qint64 valuePerGrad = 1;
	qint64 gradMaxValue = highest-highest%valuePerGrad;
	qint64 numOfGrad = gradMaxValue/valuePerGrad;
	qint64 pixelPerGrad = imageHeight/numOfGrad;

	if(valuePerGrad<highest){

		while(1){
		
			gradMaxValue = highest-highest%valuePerGrad;
			numOfGrad = gradMaxValue/valuePerGrad;
			pixelPerGrad = imageHeight/numOfGrad;

			if(pixelPerGrad>=pixelPerGradMin&&pixelPerGrad<=pixelPerGradMax){
				break;
			}
			if(highest<=valuePerGrad*2){
				break;
			}

			valuePerGrad = valuePerGrad*2;
		
			gradMaxValue = highest-highest%valuePerGrad;
			numOfGrad = gradMaxValue/valuePerGrad;
			pixelPerGrad = imageHeight/numOfGrad;

			if(pixelPerGrad>=pixelPerGradMin&&pixelPerGrad<=pixelPerGradMax){
				break;
			}
			if(highest<=valuePerGrad*5/2){
				break;
			}

			valuePerGrad = valuePerGrad*5/2;

			gradMaxValue = highest-highest%valuePerGrad;
			numOfGrad = gradMaxValue/valuePerGrad;
			pixelPerGrad = imageHeight/numOfGrad;

			if(pixelPerGrad>=pixelPerGradMin&&pixelPerGrad<=pixelPerGradMax){
				break;
			}
			if(highest<=valuePerGrad*2){
				break;
			}

			valuePerGrad = valuePerGrad*2;

		}
	}

	QPen pen(Qt::NoBrush, 1, Qt::DashLine);
	pen.setColor(CGIParam.foreground_color);
	painter.setPen(pen);

	if(showLine==true){
		if(strand==0||strand==-2){
			for(qint64 gradValue=valuePerGrad; gradValue<gradMaxValue; gradValue+=valuePerGrad){
				int vPos=gradValue*imageHeight/gradMaxValue;
				painter.drawLine(0, imageHeight-vPos-1, image.width(), imageHeight-vPos-1);
				painter.drawLine(0, imageHeight+vPos+1, image.width(), imageHeight+vPos+1);
			}
		}
		else{
			for(qint64 gradValue=valuePerGrad; gradValue<gradMaxValue; gradValue+=valuePerGrad){
				int vPos=gradValue*imageHeight/gradMaxValue;
				painter.drawLine(0, imageHeight-vPos-1, image.width(), imageHeight-vPos-1);
			}
		}
	}
	return true;
	
}


bool GraphTrack::drawIndexGrad(
	const  quint32& highest,
	QImage& image,
	QFont& font,
	QPainter& painter,
	bool changeScale,
	quint32& strand,
	quint32& dataType,
	bool showLine)
{

	qint64 imageHeight = image.height();
	const qint64 pixelPerGradMax = 20;
	const qint64 pixelPerGradMin = 10;

	if(strand==0||strand==-2){
		imageHeight=imageHeight/2-1;
	}
	else{
		imageHeight=imageHeight-1;
	}
	
	//variables
	qint64 gradMinValue=0;
	qint64 valuePerGrad = 1;
	qint64 gradMaxValue = highest-highest%valuePerGrad;
	qint64 numOfGrad = gradMaxValue/valuePerGrad;
	qint64 pixelPerGrad = imageHeight/numOfGrad;

	if(valuePerGrad>=highest){
		return true;
	}

	//�t�H���g�̏���
	painter.setFont(font);
	QFontMetrics fm(font);
	int fontHeight=fm.height();
	int fontWidth=fm.averageCharWidth();

	if(valuePerGrad<highest){

		while(1){
			//
			gradMaxValue = highest-highest%valuePerGrad;
			numOfGrad = gradMaxValue/valuePerGrad;
			pixelPerGrad = imageHeight/numOfGrad;

			if(pixelPerGrad>=pixelPerGradMin&&pixelPerGrad<=pixelPerGradMax){
				break;
			}
			if(highest<=valuePerGrad*2){
				break;
			}

			valuePerGrad = valuePerGrad*2;
		
			gradMaxValue = highest-highest%valuePerGrad;
			numOfGrad = gradMaxValue/valuePerGrad;
			pixelPerGrad = imageHeight/numOfGrad;

			if(pixelPerGrad>=pixelPerGradMin&&pixelPerGrad<=pixelPerGradMax){
				break;
			}
			if(highest<=valuePerGrad*5/2){
				break;
			}

			valuePerGrad = valuePerGrad*5/2;

			gradMaxValue = highest-highest%valuePerGrad;
			numOfGrad = gradMaxValue/valuePerGrad;
			pixelPerGrad = imageHeight/numOfGrad;

			if(pixelPerGrad>=pixelPerGradMin&&pixelPerGrad<=pixelPerGradMax){
				break;
			}
			if(highest<=valuePerGrad*2){
				break;
			}

			valuePerGrad = valuePerGrad*2;

		}

	}

	QPen pen(Qt::NoBrush, 1, Qt::DashLine);
	pen.setColor(CGIParam.foreground_color);
	painter.setPen(pen);
	
	//Separate strand
	if(strand==0||strand==-2){
		if(changeScale==false){
			if(dataType==0){
				for(int gradValue=valuePerGrad; gradValue<gradMaxValue; gradValue+=valuePerGrad){
					int vPos=imageHeight-gradValue*imageHeight/gradMaxValue;
					int vPos_rv=imageHeight+gradValue*imageHeight/gradMaxValue;
					int hPos=image.width()-fontWidth;
					painter.drawLine(hPos, vPos-1, image.width(), vPos-1);
					painter.drawLine(hPos, vPos_rv+1, image.width(), vPos_rv+1);
					vPos=vPos-fontHeight/2;
					vPos_rv=vPos_rv-fontHeight/2;
					QString text=QString::number(gradValue);
					hPos=hPos-fm.width(text)-fontWidth;
					QRect rect(hPos, vPos, fm.width(text), fontHeight);
					QRect rect_rv(hPos, vPos_rv, fm.width(text), fontHeight);
					painter.drawText(rect, Qt::AlignRight, text);
					painter.drawText(rect_rv, Qt::AlignRight, text);
				}
			}
			else if(dataType==1){
				for(float gradValue=valuePerGrad; gradValue<gradMaxValue; gradValue+=valuePerGrad){
					int vPos=imageHeight-gradValue*imageHeight/gradMaxValue;
					int vPos_rv=imageHeight+gradValue*imageHeight/gradMaxValue;
					int hPos=image.width()-fontWidth;
					painter.drawLine(hPos, vPos-1, image.width(), vPos-1);
					painter.drawLine(hPos, vPos_rv+1, image.width(), vPos_rv+1);
					vPos=vPos-fontHeight/2;
					vPos_rv=vPos_rv-fontHeight/2;
					QString text=QString::number(gradValue,'f');
					hPos=hPos-fm.width(text)-fontWidth;
					QRect rect(hPos, vPos, fm.width(text), fontHeight);
					QRect rect_rv(hPos, vPos_rv, fm.width(text), fontHeight);
					painter.drawText(rect, Qt::AlignRight, text);
					painter.drawText(rect_rv, Qt::AlignRight, text);
				}
			}
		}
		if(changeScale==true){
			if(dataType==0){
				for(int i=0;i<CGIParam.anotherParam.size(); i++){
					if(CGIParam.anotherParam[i].first == "scale_log"&&CGIParam.anotherParam[i].second!="undefined"){
						for(qint64 gradValue=valuePerGrad; gradValue<gradMaxValue; gradValue+=valuePerGrad){
							int vPos=imageHeight-gradValue*imageHeight/gradMaxValue;
							int vPos_rv=imageHeight+gradValue*imageHeight/gradMaxValue;
							int hPos=image.width()-fontWidth;
							painter.drawLine(hPos, vPos-1, image.width(), vPos-1);
							painter.drawLine(hPos, vPos_rv+1, image.width(), vPos_rv+1);
							vPos=vPos-fontHeight/2;
							vPos_rv=vPos_rv-fontHeight/2;
							float gradValue2 = qPow(2.0, gradValue);
							QString text=QString::number(gradValue2);
							hPos=hPos-fm.width(text)-fontWidth;
							QRect rect(hPos, vPos, fm.width(text), fontHeight);
							QRect rect_rv(hPos, vPos_rv, fm.width(text), fontHeight);
							painter.drawText(rect, Qt::AlignRight, text);
							painter.drawText(rect_rv, Qt::AlignRight, text);
						}
					}
					else if(CGIParam.anotherParam[i].first == "scale_real"&&CGIParam.anotherParam[i].second!="undefined"){
						for(qint64 gradValue=valuePerGrad; gradValue<gradMaxValue; gradValue+=valuePerGrad){
							int vPos=imageHeight-gradValue*imageHeight/gradMaxValue;
							int vPos_rv=imageHeight+gradValue*imageHeight/gradMaxValue;
							int hPos=image.width()-fontWidth;
							painter.drawLine(hPos, vPos-1, image.width(), vPos-1);
							painter.drawLine(hPos, vPos_rv+1, image.width(), vPos_rv+1);
							vPos=vPos-fontHeight/2;
							vPos_rv=vPos_rv-fontHeight/2;
							QString text=QString::number(gradValue);
							hPos=hPos-fm.width(text)-fontWidth;
							QRect rect(hPos, vPos, fm.width(text), fontHeight);
							QRect rect_rv(hPos, vPos_rv, fm.width(text), fontHeight);
							painter.drawText(rect, Qt::AlignRight, text);
							painter.drawText(rect_rv, Qt::AlignRight, text);
						}
					}
				}
			}
			if(dataType==1){
				for(int i=0;i<CGIParam.anotherParam.size(); i++){
					if(CGIParam.anotherParam[i].first == "scale_log"&&CGIParam.anotherParam[i].second!="undefined"){
						for(float gradValue=valuePerGrad; gradValue<gradMaxValue; gradValue+=valuePerGrad){
							int vPos=imageHeight-gradValue*imageHeight/gradMaxValue;
							int vPos_rv=imageHeight+gradValue*imageHeight/gradMaxValue;
							int hPos=image.width()-fontWidth;
							painter.drawLine(hPos, vPos-1, image.width(), vPos-1);
							painter.drawLine(hPos, vPos_rv+1, image.width(), vPos_rv+1);
							vPos=vPos-fontHeight/2;
							vPos_rv=vPos_rv-fontHeight/2;
							float gradValue2 = qPow(2.0, gradValue);
							QString text=QString::number(gradValue2,'f');
							hPos=hPos-fm.width(text)-fontWidth;
							QRect rect(hPos, vPos, fm.width(text), fontHeight);
							QRect rect_rv(hPos, vPos_rv, fm.width(text), fontHeight);
							painter.drawText(rect, Qt::AlignRight, text);
							painter.drawText(rect_rv, Qt::AlignRight, text);
						}
					}
					else if(CGIParam.anotherParam[i].first == "scale_real"&&CGIParam.anotherParam[i].second!="undefined"){
						for(float gradValue=valuePerGrad; gradValue<gradMaxValue; gradValue+=valuePerGrad){
							int vPos=imageHeight-gradValue*imageHeight/gradMaxValue;
							int vPos_rv=imageHeight+gradValue*imageHeight/gradMaxValue;
							int hPos=image.width()-fontWidth;
							painter.drawLine(hPos, vPos-1, image.width(), vPos-1);
							painter.drawLine(hPos, vPos_rv+1, image.width(), vPos_rv+1);
							vPos=vPos-fontHeight/2;
							vPos_rv=vPos_rv-fontHeight/2;
							QString text=QString::number(gradValue,'f');
							hPos=hPos-fm.width(text)-fontWidth;
							QRect rect(hPos, vPos, fm.width(text), fontHeight);
							QRect rect_rv(hPos, vPos_rv, fm.width(text), fontHeight);
							painter.drawText(rect, Qt::AlignRight, text);
							painter.drawText(rect_rv, Qt::AlignRight, text);
						}
					}
				}
			}
		}
	}
	//Unify strand
	else{
		if(changeScale==false){
			for(int gradValue=valuePerGrad; gradValue<gradMaxValue; gradValue+=valuePerGrad){
				int vPos=imageHeight-gradValue*imageHeight/gradMaxValue;
				int hPos=image.width()-fontWidth;
				painter.drawLine(hPos, vPos-1, image.width(), vPos-1);
				vPos=vPos-fontHeight/2;
				QString text=QString::number(gradValue);
				hPos=hPos-fm.width(text)-fontWidth;
				QRect rect(hPos, vPos, fm.width(text), fontHeight);
				painter.drawText(rect, Qt::AlignRight, text);
			}
		}
		if(changeScale==true){
			   for(int i=0;i<CGIParam.anotherParam.size(); i++){
				   if(CGIParam.anotherParam[i].first == "scale_log"&&CGIParam.anotherParam[i].second!="undefined"){
					  for(int gradValue=valuePerGrad; gradValue<gradMaxValue; gradValue+=valuePerGrad){
						  int vPos=imageHeight-gradValue*imageHeight/gradMaxValue;
						  int hPos=image.width()-fontWidth;
						  painter.drawLine(hPos, vPos-1, image.width(), vPos-1);
						  vPos=vPos-fontHeight/2;
						  float gradValue2 = qPow(2.0, gradValue);
						  QString text=QString::number(gradValue2);
						  hPos=hPos-fm.width(text)-fontWidth;
						  QRect rect(hPos, vPos, fm.width(text), fontHeight);
						  painter.drawText(rect, Qt::AlignRight, text);
					  }
				   }
				   else if(CGIParam.anotherParam[i].first == "scale_real"&&CGIParam.anotherParam[i].second!="undefined"){
					  for(int gradValue=valuePerGrad; gradValue<gradMaxValue; gradValue+=valuePerGrad){
						  int vPos=imageHeight-gradValue*imageHeight/gradMaxValue;
						  int hPos=image.width()-fontWidth;
						  painter.drawLine(hPos, vPos-1, image.width(), vPos-1);
						  vPos=vPos-fontHeight/2;
						  QString text=QString::number(gradValue);
						  hPos=hPos-fm.width(text)-fontWidth;
						  QRect rect(hPos, vPos, fm.width(text), fontHeight);
						  painter.drawText(rect, Qt::AlignRight, text);
					  }
				   }
			   }
		}
	}

	

	return true;
}


bool GraphTrack::printImage(void){

	//�g���b�N�f�[�^�̃f�B���N�g���ֈړ�����
	QDir graphFileDir(QApplication::applicationDirPath());
	if(!graphFileDir.exists(RevisionsDirName)){
		return false;
	}
	if(!graphFileDir.cd(RevisionsDirName)){
		return false;
	}
	//species directory
	if(!graphFileDir.exists(CGIParam.species)){
		return false;
	}
	if(!graphFileDir.cd(CGIParam.species)){
		return false;
	}
	//revision directory
	if(!graphFileDir.exists(CGIParam.revision)){
		return false;
	}
	if(!graphFileDir.cd(CGIParam.revision)){
		return false;
	}
	//graph track dir
	if(!graphFileDir.exists(GraphTrackDirName)){
		return false;
	}
	if(!graphFileDir.cd(GraphTrackDirName)){
		return false;
	}
	//graphfile�����݂��邱�Ƃ��m�F
	QString graphFileName=GraphFileNameTemplate.arg(CGIParam.track_name);
	if(!graphFileDir.exists(graphFileName)){
		return false;
	}

	//graphfile���I�[�v��
	GraphFile::FileReader r;
	if(!r.setFile(graphFileDir.filePath(graphFileName))){
		return false;
	}
	//const GraphFile::Header& header=r.getBasicTrackInfo();
	GraphFile::Header header=r.getBasicTrackInfo();

	//
	bool changeScale=false;
	quint32 maxScaleI=0;
	float maxScaleF=0;
	bool showMaximum=true;
	bool logScale=false;
	bool showLine=true;
	

	if(header.version==1){
		if(header.dataType==Integer){
			maxScaleI=100;
		}
		else if(header.dataType==Float){
			maxScaleF=100;
		}
  	}
	else if(header.version>=2){
		if(header.dataType==Integer){
			if(header.maxValue==0|header.maxValue>100){
				maxScaleI=100;
			}
			else{
				maxScaleI=header.maxValue;
			}
		}
		else if(header.dataType==Float){
			quint32* p=&(header.maxValue);
			maxScaleF=*(float*)p;	//����C���̕K�v����
			if(maxScaleF==0|header.maxValue>100){
				maxScaleF=100.0;
			}
			else{
				maxScaleF=maxScaleF;
			}
			
		}
	}

	for(int i=0;i<CGIParam.anotherParam.size(); i++){
		//�O�ʐF�ύX�̗v���ɑ΂��铮��
		if(CGIParam.anotherParam[i].first=="foreground_color"){
		QByteArray colorArray=CGIParam.anotherParam[i].second.toLatin1();
		QString colorString=QUrl::fromPercentEncoding(colorArray);
		  #if QT_VERSION >= 0x040700
		      if(QColor::isValidColor(colorString)){
			  header.fgColor.setNamedColor(colorString);
		      }
		  #else
		      header.fgColor.setNamedColor(colorString);
		  #endif
	   }
		//��ʐF�ύX�̗v���ɑ΂��铮��
	   if(CGIParam.anotherParam[i].first=="background_color"){
	   QByteArray colorArray=CGIParam.anotherParam[i].second.toLatin1();
	   QString colorString=QUrl::fromPercentEncoding(colorArray);
		  #if QT_VERSION >= 0x040700
		      if(QColor::isValidColor(colorString)){
			  header.bgColor.setNamedColor(colorString);
		      }
		  #else
		      header.bgColor.setNamedColor(colorString);
		  #endif
	   }
	   //annotation�̐F�ύX�̗v���ɑ΂��铮��
	   if(CGIParam.anotherParam[i].first=="annotation_color"){
	   QByteArray colorArray=CGIParam.anotherParam[i].second.toLatin1();
	   QString colorString=QUrl::fromPercentEncoding(colorArray);
		  #if QT_VERSION >= 0x040700
		      if(QColor::isValidColor(colorString)){
			  //header.markerColor.setNamedColor(colorString);
			  header.anColor.setNamedColor(colorString);
		      }
		  #else
		      //header.markerColor.setNamedColor(colorString);
	          header.anColor.setNamedColor(colorString);
		  #endif
	   }


	   //�r���̗L�閳���ɑ΂��铮��
	   if(CGIParam.anotherParam[i].first=="line"){
		   if(CGIParam.anotherParam[i].second=="true"){
			   showLine=true;
		   }
		   else if(CGIParam.anotherParam[i].second=="false"){
			   showLine=false;
		   }
	   }

	   //�摜�����ύX�v���ɑ΂��铮��
		if(CGIParam.anotherParam[i].first=="row_height"){
			if(CGIParam.anotherParam[i].second!="undefined"){
				header.rowHeight = CGIParam.anotherParam[i].second.toInt();
			}
		}
		//�\���X�P�[���ύX�ɑ΂��铮��(real number)
		if(CGIParam.anotherParam[i].first == "scale_real"){		
			changeScale=true;
			if(header.dataType==Integer){
				if(CGIParam.anotherParam[i].second!="undefined"){
					logScale=false;
					maxScaleI = CGIParam.anotherParam[i].second.toInt();
					if(maxScaleI==0){
						maxScaleI=1;
					}
				}
			}
			else if(header.dataType==Float){
				if(CGIParam.anotherParam[i].second!="undefined"){
					logScale=false;
					maxScaleF = CGIParam.anotherParam[i].second.toFloat();
					if(maxScaleF==0){
						maxScaleF=1;
					}
				}
			}
		}
		//�\���X�P�[���ύX�ɑ΂��铮��(logarithm)
		if(CGIParam.anotherParam[i].first == "scale_log"){
			changeScale=true;
			if(header.dataType==Integer){
				if(CGIParam.anotherParam[i].second!="undefined"){
					logScale=true;
					maxScaleI = CGIParam.anotherParam[i].second.toInt();
					if(maxScaleI==0){
						maxScaleI=1;
					}
				}
			}
			else if(header.dataType==Float){
				if(CGIParam.anotherParam[i].second!="undefined"){
                    logScale=true;
					maxScaleF = CGIParam.anotherParam[i].second.toFloat();
					if(maxScaleF==0){
						maxScaleF=1;
					}
				}
			}
		}
		//�\�����[�h�ύX�v���ɑ΂��铮��
		if(CGIParam.anotherParam[i].first=="display"){
			if(CGIParam.anotherParam[i].second=="maximum"){
				showMaximum=true;
			}
			else{
				showMaximum=false;
			}
		}
	}

	quint32 strand;
	quint32 bpLower, bpUpper;
	quint32 dataType;

	if(header.dataType==0){
		dataType=0;
	}
	else{
		dataType=1;
	}

	if(header.strandSpecificity==1){  //unify strand
		if(CGIParam.start<CGIParam.end){
			strand=1;  //����
			bpLower=CGIParam.start;
			bpUpper=CGIParam.end;
		}
		else{
			strand=-1;  //�t��
			bpLower=CGIParam.end;
			bpUpper=CGIParam.start;
		}
	}
	else if(header.strandSpecificity==0){  //separate strand
		if(CGIParam.start<CGIParam.end){
			strand=0;  //����
			bpLower=CGIParam.start;
			bpUpper=CGIParam.end;
		}
		else{
			strand=-2;  //�t��
			bpLower=CGIParam.end;
			bpUpper=CGIParam.start;
		}
	}
	quint64 bpWidth=bpUpper-bpLower+1;



////��������int��float�ŏꍇ����////
	if(header.dataType==Integer){
		
		//unify//
		if(header.strandSpecificity==1){
			
			QVector<quint32> data;
			if(!r.getData(CGIParam.target, bpLower, bpUpper, strand, data)){
				return false;
			}
			if(data.size()!=bpWidth){
				return false;
			}
			if(CGIParam.width==0){
				return false;
			}
			
			quint32 i, j;
			quint64 pixelWidth=CGIParam.width;


		/*------------------------------------------------------------
		     ��������version3(�A�m�e�[�V��������g���b�N)��p�R�[�h
		------------------------------------------------------------*/
		    QBitArray annotation;
		    QBitArray pixelAnnotationList;
			
			if(header.version==3){
				
				if(!r.getAnnotation(CGIParam.target, bpLower, bpUpper, strand, annotation)){
					return false;
				}
				if(annotation.size()!=bpWidth){
					return false;
				}
				pixelAnnotationList.resize(CGIParam.width);
				pixelAnnotationList.fill(false);
				
				for(i=bpLower; i<=bpUpper; i++){
					int bpOffset=i-bpLower;
					quint64 bpOffset64=bpOffset;
					int pos1=(int)(bpOffset64*pixelWidth/bpWidth);
					int pos2=(int)(++bpOffset64*pixelWidth/bpWidth);
					
					if(pos2>pos1+1){
						for(j=pos1; j<pos2; j++){
							pixelAnnotationList[j]=annotation[bpOffset];
						}
					}
					else{
					//�s�N�Z������1�ł�true������΁A���̃s�N�Z����true
					//�܂�A�s�N�Z������bool�l��OR�����΂悢
					    pixelAnnotationList[pos1]=pixelAnnotationList[pos1]|annotation[bpOffset];
					}
				}
			}
		    /*------------------------------------------------------------
		        �����܂�version3(�A�m�e�[�V��������g���b�N)��p�R�[�h
		     ------------------------------------------------------------*/

		    QVector<quint32> countListF(CGIParam.width, 0);
			QVector<quint32> maxValueListF(CGIParam.width, 0);
			QVector<quint32> minValueListF(CGIParam.width, 0);
			QVector<quint64> averageValueListF(CGIParam.width, 0);
			
			
			for(i=bpLower; i<=bpUpper; i++){
				int bpOffset=i-bpLower;
				quint64 bpOffset64=bpOffset;
				int pos1=(int)(bpOffset64*pixelWidth/bpWidth);
				int pos2=(int)(++bpOffset64*pixelWidth/bpWidth);
				
				if(pos2>pos1+1){
					if(countListF[pos1]==0){
						for(j=pos1; j<pos2; j++){
							maxValueListF[j]=data[bpOffset];
							minValueListF[j]=data[bpOffset];
							averageValueListF[j]=data[bpOffset];
							countListF[j]++;
						}
					}
					
					else{
						for(j=pos1; j<pos2; j++){
							maxValueListF[j]=qMax(maxValueListF[j], data[bpOffset]);
							minValueListF[j]=qMin(minValueListF[j], data[bpOffset]);
							averageValueListF[j]+=data[bpOffset];
							countListF[j]++;
						}
					}
				}
				else{
					if(countListF[pos1]==0){
						maxValueListF[pos1]=data[bpOffset];
						minValueListF[pos1]=data[bpOffset];
						averageValueListF[pos1]=data[bpOffset];
						countListF[pos1]++;
					}
					else{
						maxValueListF[pos1]=qMax(maxValueListF[pos1], data[bpOffset]);
						minValueListF[pos1]=qMin(minValueListF[pos1], data[bpOffset]);
						averageValueListF[pos1]+=data[bpOffset];
						countListF[pos1]++;
					}
				}
			}

		    //���ϒl�v�Z
		    for(i=0; i<CGIParam.width; i++){
				if(countListF[i]!=0){
					averageValueListF[i]=averageValueListF[i]/countListF[i];
				}
			}

		    //�}�̍쐬
		    QImage image(CGIParam.width, header.rowHeight+1, QImage::Format_ARGB32);
		    QPainter painter(&image);
		    painter.setPen(Qt::NoPen);
		    painter.setBrush(header.bgColor);
		    painter.drawRect(image.rect());

		    /*------------------------------------------------------------
		         ��������version3(�A�m�e�[�V��������g���b�N)��p�R�[�h
		     ------------------------------------------------------------*/
		    if(header.version==3){
			    //�A�m�e�[�V�����������݁i�o�b�N�O���E���h�j
			    painter.setPen(header.anColor);
			    painter.setBrush(Qt::NoBrush);
				
				for(i=0; i<CGIParam.width; i++){
					if(pixelAnnotationList[i]){
						painter.drawLine(i, header.rowHeight-1, i, 0);
					}
				}
			}
		    /*------------------------------------------------------------
		         �����܂�version3(�A�m�e�[�V��������g���b�N)��p�R�[�h
		      ------------------------------------------------------------*/


		    drawGrad(maxScaleI, image, painter, strand, dataType, showLine);
		    painter.setBrush(Qt::NoBrush);
		    painter.setPen(header.fgColor);


		    int F_v_pos;
			float F_v_pos_f;
			
			if(logScale==true){
				for(i=0; i<CGIParam.width; i++){
					if(showMaximum){
						if(maxValueListF[i]==0){
							F_v_pos_f=0;
						}
						else{
							F_v_pos_f=(float)(((log((float)(maxValueListF[i]))/log(2.0))*header.rowHeight)/maxScaleI);
						}
					}
					else{
						if(averageValueListF[i]==0){
							F_v_pos_f=0;
						}
						else{
							F_v_pos_f=(float)(((log((float)(averageValueListF[i]))/log(2.0))*header.rowHeight)/maxScaleI);
						}
					}
					painter.drawLine(i, header.rowHeight-1-F_v_pos_f, i, header.rowHeight-1);
				}
			}
			else {
				for(i=0; i<CGIParam.width; i++){
					if(showMaximum){
						F_v_pos=(int)(((qint64)maxValueListF[i]*(qint64)header.rowHeight)/maxScaleI);
					}
					else{
						F_v_pos=(int)(((qint64)averageValueListF[i]*(qint64)header.rowHeight)/maxScaleI);
					}
					painter.drawLine(i, header.rowHeight-1-F_v_pos, i, header.rowHeight-1);
				}
			}
			
			//
			if(strand==-1){
				image=image.mirrored(true, false);
			}


	#ifdef Q_OS_WIN32
		_setmode( _fileno( stdout ), _O_BINARY );
	#endif

		QFile file;
		file.open(stdout, QIODevice::WriteOnly);
		QTextStream out(&file);
		if(CGIParam.is_cgi){
			out << "Content-type: image/png\n"
				<< "Pragma: no-cache\n\n";
			out.flush();
		}
		QImageWriter writer(&file, "png");
		if(!writer.canWrite()){
			return false;
		}
		if(!writer.write(image)){
			QString errorString = writer.errorString();
			return false;
		}
		file.flush();
		file.close();

		return true;
	}

    
	
	//separate//
    if(header.strandSpecificity==0){
			
			QVector<quint32> data_1, data_2 ;
			if(!r.getData(CGIParam.target, bpLower, bpUpper, strand, data_1, data_2 )){
				return false;
			}
			if(data_1.size()!=bpWidth){
				return false;
			}
			if(CGIParam.width==0){
				return false;
			}
			
			quint32 i, j;
			quint64 pixelWidth=CGIParam.width;


		/*------------------------------------------------------------
		     ��������version3(�A�m�e�[�V��������g���b�N)��p�R�[�h
		------------------------------------------------------------*/
		   QBitArray annotation;
		   QBitArray pixelAnnotationList;
		   
		   if(header.version==3){
			   
			   if(!r.getAnnotation(CGIParam.target, bpLower, bpUpper, strand, annotation)){
				   return false;
			   }
			   if(annotation.size()!=bpWidth){
				   return false;
			   }
			   
			   pixelAnnotationList.resize(CGIParam.width);
			   pixelAnnotationList.fill(false);
			   
			   for(i=bpLower; i<=bpUpper; i++){
				   int bpOffset=i-bpLower;
				   quint64 bpOffset64=bpOffset;
				   int pos1=(int)(bpOffset64*pixelWidth/bpWidth);
				   int pos2=(int)(++bpOffset64*pixelWidth/bpWidth);
				   
				   if(pos2>pos1+1){
					   for(j=pos1; j<pos2; j++){
						   pixelAnnotationList[j]=annotation[bpOffset];
					   }
				   }
				   else{
					//�s�N�Z������1�ł�true������΁A���̃s�N�Z����true
					//�܂�A�s�N�Z������bool�l��OR�����΂悢
					   pixelAnnotationList[pos1]=pixelAnnotationList[pos1]|annotation[bpOffset];
				   }
			   }
		   }
		/*------------------------------------------------------------
		     �����܂�version3(�A�m�e�[�V��������g���b�N)��p�R�[�h
		------------------------------------------------------------*/

		QVector<quint32> countListF(CGIParam.width, 0);
		QVector<quint32> maxValueListF(CGIParam.width, 0);
		QVector<quint32> minValueListF(CGIParam.width, 0);
		QVector<quint64> averageValueListF(CGIParam.width, 0);
        
		for(i=bpLower; i<=bpUpper; i++){
			int bpOffset=i-bpLower;
			quint64 bpOffset64=bpOffset;
			int pos1=(int)(bpOffset64*pixelWidth/bpWidth);
			int pos2=(int)(++bpOffset64*pixelWidth/bpWidth);
			if(pos2>pos1+1){
				if(countListF[pos1]==0){
					for(j=pos1; j<pos2; j++){
						maxValueListF[j]=data_1[bpOffset];
						minValueListF[j]=data_1[bpOffset];
						averageValueListF[j]=data_1[bpOffset];
						countListF[j]++;
					}
				}
				else{
					for(j=pos1; j<pos2; j++){
						maxValueListF[j]=qMax(maxValueListF[j], data_1[bpOffset]);
						minValueListF[j]=qMin(minValueListF[j], data_1[bpOffset]);
						averageValueListF[j]+=data_1[bpOffset];
						countListF[j]++;
					}
				}
			}
			else{
				if(countListF[pos1]==0){
					maxValueListF[pos1]=data_1[bpOffset];
					minValueListF[pos1]=data_1[bpOffset];
					averageValueListF[pos1]=data_1[bpOffset];
					countListF[pos1]++;
				}
				else{
					maxValueListF[pos1]=qMax(maxValueListF[pos1], data_1[bpOffset]);
					minValueListF[pos1]=qMin(minValueListF[pos1], data_1[bpOffset]);
					averageValueListF[pos1]+=data_1[bpOffset];
					countListF[pos1]++;
				}
			}
		}

		//���ϒl�v�Z
		for(i=0; i<CGIParam.width; i++){
			if(countListF[i]!=0){
				averageValueListF[i]=averageValueListF[i]/countListF[i];
			}
		}



		QVector<quint32> countListR(CGIParam.width, 0);
		QVector<quint32> maxValueListR(CGIParam.width, 0);
		QVector<quint32> minValueListR(CGIParam.width, 0);
		QVector<quint64> averageValueListR(CGIParam.width, 0);
        
		for(i=bpLower; i<=bpUpper; i++){
			int bpOffset=i-bpLower;
			quint64 bpOffset64=bpOffset;
			int pos1=(int)(bpOffset64*pixelWidth/bpWidth);
			int pos2=(int)(++bpOffset64*pixelWidth/bpWidth);
			if(pos2>pos1+1){
				if(countListR[pos1]==0){
					for(j=pos1; j<pos2; j++){
						maxValueListR[j]=data_2[bpOffset];
						minValueListR[j]=data_2[bpOffset];
						averageValueListR[j]=data_2[bpOffset];
						countListR[j]++;
					}
				}
				else{
					for(j=pos1; j<pos2; j++){
						maxValueListR[j]=qMax(maxValueListR[j], data_2[bpOffset]);
						minValueListR[j]=qMin(minValueListR[j], data_2[bpOffset]);
						averageValueListR[j]+=data_2[bpOffset];
						countListR[j]++;
					}
				}
			}
			else{
				if(countListR[pos1]==0){
					maxValueListR[pos1]=data_2[bpOffset];
					minValueListR[pos1]=data_2[bpOffset];
					averageValueListR[pos1]=data_2[bpOffset];
					countListR[pos1]++;
				}
				else{
					maxValueListR[pos1]=qMax(maxValueListR[pos1], data_2[bpOffset]);
					minValueListR[pos1]=qMin(minValueListR[pos1], data_2[bpOffset]);
					averageValueListR[pos1]+=data_2[bpOffset];
					countListR[pos1]++;
				}
			}
		}

		//���ϒl�v�Z
		for(i=0; i<CGIParam.width; i++){
			if(countListR[i]!=0){
				averageValueListR[i]=averageValueListR[i]/countListR[i];
			}
		}

		//�}�̍쐬
		QImage image(CGIParam.width, header.rowHeight*2+2, QImage::Format_ARGB32);
		QPainter painter(&image);
		painter.setPen(Qt::NoPen);
		painter.setBrush(header.bgColor);
		painter.drawRect(image.rect());

		/*------------------------------------------------------------
		     ��������version3(�A�m�e�[�V��������g���b�N)��p�R�[�h
		------------------------------------------------------------*/
		if(header.version==3){
			//�A�m�e�[�V�����������݁i�o�b�N�O���E���h�j
			painter.setPen(header.anColor);
			painter.setBrush(Qt::NoBrush);
			for(i=0; i<CGIParam.width; i++){
				if(pixelAnnotationList[i]){
					painter.drawLine(i, header.rowHeight-1, i, 0);
				}
			}
		}
		/*------------------------------------------------------------
		     �����܂�version3(�A�m�e�[�V��������g���b�N)��p�R�[�h
		------------------------------------------------------------*/


		drawGrad(maxScaleI, image, painter, strand, dataType, showLine);
		painter.setBrush(Qt::NoBrush);
		painter.setPen(header.fgColor);

		int F_v_pos;
		float F_v_pos_f;

		if(logScale==true){
			for(i=0; i<CGIParam.width; i++){
				if(showMaximum){
					if(maxValueListF[i]==0){
						F_v_pos_f=0;
					}
					else{
						F_v_pos_f=(float)(((log((float)(maxValueListF[i]))/log(2.0))*header.rowHeight)/maxScaleI);
					}
				}
				else{
					if(averageValueListF[i]==0){
						F_v_pos_f=0;
					}
					else{
						F_v_pos_f=(float)(((log((float)(averageValueListF[i]))/log(2.0))*header.rowHeight)/maxScaleI);
					}
				}
				painter.drawLine(i, header.rowHeight-1-F_v_pos_f, i, header.rowHeight-1);
			}
		}
		else {
			for(i=0; i<CGIParam.width; i++){
				if(showMaximum){
					F_v_pos=(int)(((qint64)maxValueListF[i]*(qint64)header.rowHeight)/maxScaleI);
				}
				else{
					F_v_pos=(int)(((qint64)averageValueListF[i]*(qint64)header.rowHeight)/maxScaleI);
				}
				painter.drawLine(i, header.rowHeight-1-F_v_pos, i, header.rowHeight-1);
			}
		}
				
		int R_v_pos;
		float R_v_pos_f;

		if(logScale==true){
			for(i=0; i<CGIParam.width; i++){
				if(showMaximum){
					if(maxValueListR[i]==0){
						R_v_pos_f=0;
					}
					else{
						R_v_pos_f=(float)(((log((float)(maxValueListR[i]))/log(2.0))*header.rowHeight)/maxScaleI);
					}
				}
				else{
					if(averageValueListR[i]==0){
						R_v_pos_f=0;
					}
					else{
						R_v_pos_f=(float)(((log((float)(averageValueListR[i]))/log(2.0))*header.rowHeight)/maxScaleI);
					}
				}
				painter.drawLine(i, header.rowHeight+1+R_v_pos_f, i, header.rowHeight+1);
			}
		}
		else {
			for(i=0; i<CGIParam.width; i++){
				if(showMaximum){
					R_v_pos=(int)(((qint64)maxValueListR[i]*(qint64)header.rowHeight)/maxScaleI);
				}
				else{
					R_v_pos=(int)(((qint64)averageValueListR[i]*(qint64)header.rowHeight)/maxScaleI);
				}
				painter.drawLine(i, header.rowHeight+1+R_v_pos, i, header.rowHeight+1);
			}
		}
		
		if(strand==-2){
			image=image.mirrored(true, true);
		}

	#ifdef Q_OS_WIN32
		_setmode( _fileno( stdout ), _O_BINARY );
	#endif

		QFile file;
		file.open(stdout, QIODevice::WriteOnly);
		QTextStream out(&file);
		if(CGIParam.is_cgi){
			out << "Content-type: image/png\n"
				<< "Pragma: no-cache\n\n";
			out.flush();
		}
		QImageWriter writer(&file, "png");
		if(!writer.canWrite()){
			return false;
		}
		if(!writer.write(image)){
			QString errorString = writer.errorString();
			return false;
		}
		file.flush();
		file.close();
		
		return true;
}

}

/////header.dataType==Float/////
	else{
	
		//unify//
		if(header.strandSpecificity==1){

			QVector<float> data;
			if(!r.getData(CGIParam.target, bpLower, bpUpper, strand, data)){
				return false;
			}
			if(data.size()!=bpWidth){
				return false;
			}
			if(CGIParam.width==0){
				return false;
			}
			
			quint64 pixelWidth=CGIParam.width;

			QVector<qint32> countList(CGIParam.width, 0);
			QVector<float> maxValueList(CGIParam.width, 0);
			QVector<float> minValueList(CGIParam.width, 0);
			QVector<float> averageValueList(CGIParam.width, 0);

			quint32 i, j;
			float value_max, value_min;

			for(i=bpLower; i<=bpUpper; i++){
				int bpOffset=i-bpLower;
				quint64 bpOffset64=bpOffset;
				int pos1=(int)(bpOffset64*pixelWidth/bpWidth);
				int pos2=(int)(++bpOffset64*pixelWidth/bpWidth);
				if(pos2>pos1+1){
					if(countList[pos1]==0){
						for(j=pos1; j<pos2; j++){
							maxValueList[j]=data[bpOffset];
							minValueList[j]=data[bpOffset];
							averageValueList[j]=data[bpOffset];
							countList[j]++;
						}
					}
					else{
						for(j=pos1; j<pos2; j++){
							maxValueList[j]=qMax(maxValueList[j], data[bpOffset]);
							minValueList[j]=qMin(minValueList[j], data[bpOffset]);
							averageValueList[j]+=data[bpOffset];
							countList[j]++;
						}
					}
				}
				else{
					if(countList[pos1]==0){
						maxValueList[pos1]=data[bpOffset];
						minValueList[pos1]=data[bpOffset];
						averageValueList[pos1]=data[bpOffset];
						countList[pos1]++;
					}
					else{
						maxValueList[pos1]=qMax(maxValueList[pos1], data[bpOffset]);
						minValueList[pos1]=qMin(minValueList[pos1], data[bpOffset]);
						averageValueList[pos1]+=data[bpOffset];
						countList[pos1]++;
					}
				}
				float value=data[bpOffset];
				if(i==bpLower){
					value_max=value;
					value_min=value;
				}
				else{
					value_max=qMax(value_max, value);
					value_min=qMin(value_min, value);
				}
			}

			//���ϒl�v�Z
			float max(0), min(0);
			for(i=0; i<CGIParam.width; i++){
				if(countList[i]==0){
					
				}
				else{
					averageValueList[i]=averageValueList[i]/(float)countList[i];
				}
				if(i==0){
					max=averageValueList[i];
					min=averageValueList[i];
				}
				else{
					max=qMax(max, averageValueList[i]);
					min=qMin(min, averageValueList[i]);
				}
			}
			
			//�}�̍쐬
			QImage image(CGIParam.width, header.rowHeight+1, QImage::Format_ARGB32);
		   //printBackground(&image, header.bgColor);

			QPainter painter(&image);
			painter.setBrush(header.bgColor);
			painter.setPen(Qt::NoPen);
			painter.drawRect(image.rect());
			painter.setBrush(Qt::NoBrush);
			painter.setPen(header.fgColor);

			//scale�ύX�̗v��������Ή�����
			for(int i=0;i<CGIParam.anotherParam.size(); i++){	   
				if(CGIParam.anotherParam[i].first == "scale_real"){
					float maxScale = CGIParam.anotherParam[i].second.toInt();
					int v_pos;
					
					for(i=0; i<CGIParam.width; i++){
						float fvpos=maxValueList[i]*(float)header.rowHeight/maxScale;
						int ivpos=floor(fvpos);
						painter.drawLine(i, header.rowHeight-1-ivpos, i, header.rowHeight-1);
					}
				}
			}
			for(int i=0;i<CGIParam.anotherParam.size(); i++){
				if(CGIParam.anotherParam[i].first == "scale_log"){
					float maxScale = CGIParam.anotherParam[i].second.toInt();
					int v_pos;
					float fvpos;
					
					for(i=0; i<CGIParam.width; i++){
						if(maxValueList[i]==0){
							fvpos=0;
						}
						else{
							fvpos=(log(maxValueList[i])/log(2.0))*(float)header.rowHeight/maxScale;
						}
						int ivpos= floor(fvpos);
						painter.drawLine(i, header.rowHeight-1-ivpos, i, header.rowHeight-1);
					}
				}
			}
			
			int v_pos;
			
			for(i=0; i<CGIParam.width; i++){
				float fvpos=maxValueList[i]*(float)header.rowHeight/max;
				int ivpos=floor(fvpos);
				painter.drawLine(i, header.rowHeight-1-ivpos, i, header.rowHeight-1);
			}
			
			if(strand==-1){
				image=image.mirrored(true, false);
			}

		#ifdef Q_OS_WIN32
			_setmode( _fileno( stdout ), _O_BINARY );
		#endif

			QFile file;
			file.open(stdout, QIODevice::WriteOnly);
			QTextStream out(&file);
			if(CGIParam.is_cgi){
				out << "Content-type: image/png\n"
					<< "Pragma: no-cache\n\n";
				out.flush();
			}
			QImageWriter writer(&file, "png");
			if(!writer.canWrite()){
				return false;
			}
			if(!writer.write(image)){
				QString errorString = writer.errorString();
				return false;
			}

			file.flush();
			file.close();
		
			return true;
			
		}
     }
	 //separate//
    if(header.strandSpecificity==0){
			
			QVector<float> data_1, data_2 ;
			if(!r.getData(CGIParam.target, bpLower, bpUpper, strand, data_1, data_2 )){
				return false;
			}
			if(data_1.size()!=bpWidth){
				return false;
			}
			if(CGIParam.width==0){
				return false;
			}
			
			quint32 i, j;
			quint64 pixelWidth=CGIParam.width;


		/*------------------------------------------------------------
		     ��������version3(�A�m�e�[�V��������g���b�N)��p�R�[�h
		------------------------------------------------------------*/
		   QBitArray annotation;
		   QBitArray pixelAnnotationList;
		   
		   if(header.version==3){
			   
			   if(!r.getAnnotation(CGIParam.target, bpLower, bpUpper, strand, annotation)){
				   return false;
			   }
			   if(annotation.size()!=bpWidth){
				   return false;
			   }
			   
			   pixelAnnotationList.resize(CGIParam.width);
			   pixelAnnotationList.fill(false);
			   
			   for(i=bpLower; i<=bpUpper; i++){
				   int bpOffset=i-bpLower;
				   quint64 bpOffset64=bpOffset;
				   int pos1=(int)(bpOffset64*pixelWidth/bpWidth);
				   int pos2=(int)(++bpOffset64*pixelWidth/bpWidth);
				   
				   if(pos2>pos1+1){
					   for(j=pos1; j<pos2; j++){
						   pixelAnnotationList[j]=annotation[bpOffset];
					   }
				   }
				   else{
					//�s�N�Z������1�ł�true������΁A���̃s�N�Z����true
					//�܂�A�s�N�Z������bool�l��OR�����΂悢
					   pixelAnnotationList[pos1]=pixelAnnotationList[pos1]|annotation[bpOffset];
				   }
			   }
		   }
		/*------------------------------------------------------------
		     �����܂�version3(�A�m�e�[�V��������g���b�N)��p�R�[�h
		------------------------------------------------------------*/

		QVector<quint32> countListF(CGIParam.width, 0);
		QVector<float> maxValueListF(CGIParam.width, 0);
		QVector<float> minValueListF(CGIParam.width, 0);
		QVector<float> averageValueListF(CGIParam.width, 0);
        
		for(i=bpLower; i<=bpUpper; i++){
			int bpOffset=i-bpLower;
			quint64 bpOffset64=bpOffset;
			int pos1=(int)(bpOffset64*pixelWidth/bpWidth);
			int pos2=(int)(++bpOffset64*pixelWidth/bpWidth);
			if(pos2>pos1+1){
				if(countListF[pos1]==0){
					for(j=pos1; j<pos2; j++){
						maxValueListF[j]=data_1[bpOffset];
						minValueListF[j]=data_1[bpOffset];
						averageValueListF[j]=data_1[bpOffset];
						countListF[j]++;
					}
				}
				else{
					for(j=pos1; j<pos2; j++){
						maxValueListF[j]=qMax(maxValueListF[j], data_1[bpOffset]);
						minValueListF[j]=qMin(minValueListF[j], data_1[bpOffset]);
						averageValueListF[j]+=data_1[bpOffset];
						countListF[j]++;
					}
				}
			}
			else{
				if(countListF[pos1]==0){
					maxValueListF[pos1]=data_1[bpOffset];
					minValueListF[pos1]=data_1[bpOffset];
					averageValueListF[pos1]=data_1[bpOffset];
					countListF[pos1]++;
				}
				else{
					maxValueListF[pos1]=qMax(maxValueListF[pos1], data_1[bpOffset]);
					minValueListF[pos1]=qMin(minValueListF[pos1], data_1[bpOffset]);
					averageValueListF[pos1]+=data_1[bpOffset];
					countListF[pos1]++;
				}
			}
		}

		//���ϒl�v�Z
		for(i=0; i<CGIParam.width; i++){
			if(countListF[i]!=0){
				averageValueListF[i]=averageValueListF[i]/countListF[i];
			}
		}



		QVector<quint32> countListR(CGIParam.width, 0);
		QVector<float> maxValueListR(CGIParam.width, 0);
		QVector<float> minValueListR(CGIParam.width, 0);
		QVector<float> averageValueListR(CGIParam.width, 0);
        
		for(i=bpLower; i<=bpUpper; i++){
			int bpOffset=i-bpLower;
			quint64 bpOffset64=bpOffset;
			int pos1=(int)(bpOffset64*pixelWidth/bpWidth);
			int pos2=(int)(++bpOffset64*pixelWidth/bpWidth);
			if(pos2>pos1+1){
				if(countListR[pos1]==0){
					for(j=pos1; j<pos2; j++){
						maxValueListR[j]=data_2[bpOffset];
						minValueListR[j]=data_2[bpOffset];
						averageValueListR[j]=data_2[bpOffset];
						countListR[j]++;
					}
				}
				else{
					for(j=pos1; j<pos2; j++){
						maxValueListR[j]=qMax(maxValueListR[j], data_2[bpOffset]);
						minValueListR[j]=qMin(minValueListR[j], data_2[bpOffset]);
						averageValueListR[j]+=data_2[bpOffset];
						countListR[j]++;
					}
				}
			}
			else{
				if(countListR[pos1]==0){
					maxValueListR[pos1]=data_2[bpOffset];
					minValueListR[pos1]=data_2[bpOffset];
					averageValueListR[pos1]=data_2[bpOffset];
					countListR[pos1]++;
				}
				else{
					maxValueListR[pos1]=qMax(maxValueListR[pos1], data_2[bpOffset]);
					minValueListR[pos1]=qMin(minValueListR[pos1], data_2[bpOffset]);
					averageValueListR[pos1]+=data_2[bpOffset];
					countListR[pos1]++;
				}
			}
		}

		//���ϒl�v�Z
		for(i=0; i<CGIParam.width; i++){
			if(countListR[i]!=0){
				averageValueListR[i]=averageValueListR[i]/countListR[i];
			}
		}

		//�}�̍쐬
		QImage image(CGIParam.width, header.rowHeight*2+2, QImage::Format_ARGB32);
		QPainter painter(&image);
		painter.setPen(Qt::NoPen);
		painter.setBrush(header.bgColor);
		painter.drawRect(image.rect());

		/*------------------------------------------------------------
		     ��������version3(�A�m�e�[�V��������g���b�N)��p�R�[�h
		------------------------------------------------------------*/
		if(header.version==3){
			//�A�m�e�[�V�����������݁i�o�b�N�O���E���h�j
			painter.setPen(header.anColor);
			painter.setBrush(Qt::NoBrush);
			for(i=0; i<CGIParam.width; i++){
				if(pixelAnnotationList[i]){
					painter.drawLine(i, header.rowHeight-1, i, 0);
				}
			}
		}
		/*------------------------------------------------------------
		     �����܂�version3(�A�m�e�[�V��������g���b�N)��p�R�[�h
		------------------------------------------------------------*/


		drawGrad(maxScaleF, image, painter, strand, dataType, showLine);
		painter.setBrush(Qt::NoBrush);
		painter.setPen(header.fgColor);

		int F_v_pos;
		float F_v_pos_f;

		if(logScale==true){
			for(i=0; i<CGIParam.width; i++){
				if(showMaximum){
					if(maxValueListF[i]==0){
						F_v_pos_f=0;
					}
					else{
						F_v_pos_f=(float)(((log((float)(maxValueListF[i]))/log(2.0))*header.rowHeight)/maxScaleF);
					}
				}
				else{
					if(averageValueListF[i]==0){
						F_v_pos_f=0;
					}
					else{
						F_v_pos_f=(float)(((log((float)(averageValueListF[i]))/log(2.0))*header.rowHeight)/maxScaleF);
					}
				}
				painter.drawLine(i, header.rowHeight-1-F_v_pos_f, i, header.rowHeight-1);
			}
		}
		else {
			for(i=0; i<CGIParam.width; i++){
				if(showMaximum){
					F_v_pos=(int)(((qint64)maxValueListF[i]*(qint64)header.rowHeight)/maxScaleF);
				}
				else{
					F_v_pos=(int)(((qint64)averageValueListF[i]*(qint64)header.rowHeight)/maxScaleF);
				}
				painter.drawLine(i, header.rowHeight-1-F_v_pos, i, header.rowHeight-1);
			}
		}

		int R_v_pos;
		float R_v_pos_f;

		if(logScale==true){
			for(i=0; i<CGIParam.width; i++){
				if(showMaximum){
					if(maxValueListR[i]==0){
						R_v_pos_f=0;
					}
					else{
						R_v_pos_f=(float)(((log((float)(maxValueListR[i]))/log(2.0))*header.rowHeight)/maxScaleF);
					}
				}
				else{
					if(averageValueListR[i]==0){
						R_v_pos_f=0;
					}
					else{
						R_v_pos_f=(float)(((log((float)(averageValueListR[i]))/log(2.0))*header.rowHeight)/maxScaleF);
					}
				}
				painter.drawLine(i, header.rowHeight+1+R_v_pos_f, i, header.rowHeight+1);
			}
		}
		else {
			for(i=0; i<CGIParam.width; i++){
				if(showMaximum){
					R_v_pos=(int)(((qint64)maxValueListR[i]*(qint64)header.rowHeight)/maxScaleF);
				}
				else{
					R_v_pos=(int)(((qint64)averageValueListR[i]*(qint64)header.rowHeight)/maxScaleF);
				}
				painter.drawLine(i, header.rowHeight+1+R_v_pos, i, header.rowHeight+1);
			}
		}
		
		if(strand==-2){
			image=image.mirrored(true, true);
		}

	#ifdef Q_OS_WIN32
		_setmode( _fileno( stdout ), _O_BINARY );
	#endif

		QFile file;
		file.open(stdout, QIODevice::WriteOnly);
		QTextStream out(&file);
		if(CGIParam.is_cgi){
			out << "Content-type: image/png\n"
				<< "Pragma: no-cache\n\n";
			out.flush();
		}
		QImageWriter writer(&file, "png");
		if(!writer.canWrite()){
			return false;
		}
		if(!writer.write(image)){
			QString errorString = writer.errorString();
			return false;
		}
		file.flush();
		file.close();
		
		return true;
  }

  return false;

}


bool GraphTrack::printIndexImage(void){

	//�g���b�N�f�[�^�̃f�B���N�g���ֈړ�����
	QDir graphFileDir(QApplication::applicationDirPath());
	if(!graphFileDir.exists(RevisionsDirName)){
		return false;
	}
	if(!graphFileDir.cd(RevisionsDirName)){
		return false;
	}
	//species directory
	if(!graphFileDir.exists(CGIParam.species)){
		return false;
	}
	if(!graphFileDir.cd(CGIParam.species)){
		return false;
	}
	//revision directory
	if(!graphFileDir.exists(CGIParam.revision)){
		return false;
	}
	if(!graphFileDir.cd(CGIParam.revision)){
		return false;
	}
	//graph track dir
	if(!graphFileDir.exists(GraphTrackDirName)){
		return false;
	}
	if(!graphFileDir.cd(GraphTrackDirName)){
		return false;
	}
	//graphfile�����݂��邱�Ƃ��m�F
	QString graphFileName=GraphFileNameTemplate.arg(CGIParam.track_name);
	if(!graphFileDir.exists(graphFileName)){
		return false;
	}

	//graphfile���I�[�v��
	GraphFile::FileReader r;
	if(!r.setFile(graphFileDir.filePath(graphFileName))){
		return false;
	}
	//const GraphFile::Header& header=r.getBasicTrackInfo();
	 GraphFile::Header  header=r.getBasicTrackInfo();

	//
	bool changeScale=false;
	quint32 maxScaleI=0;
	float maxScaleF=0;
	bool showMaximum=false;
	
	if(header.version==1){
		if(header.dataType==Integer){
			maxScaleI=100;
		}
		else if(header.dataType==Float){
			maxScaleF=100;
		}
	}
	else if(header.version>=2){
		if(header.dataType==Integer){
			if(header.maxValue>100){
				maxScaleI=100;
			}
			else
				maxScaleI=header.maxValue;
		}
		else if(header.dataType==Float){
			if(header.maxValue>100){
				maxScaleF=100.0;
			}
			else{
				quint32* p=&(header.maxValue);
				maxScaleF=*(float*)p;  //����C���̕K�v����
			}
		}
	}

	for(int i=0;i<CGIParam.anotherParam.size(); i++){
		//�O�ʐF�ύX�̗v���ɑ΂��铮��
		if(CGIParam.anotherParam[i].first=="foreground_color"){
		QByteArray colorArray=CGIParam.anotherParam[i].second.toLatin1();
		QString colorString=QUrl::fromPercentEncoding(colorArray);
		  #if QT_VERSION >= 0x040700
		      if(QColor::isValidColor(colorString)){
			  header.fgColor.setNamedColor(colorString);
		      }
		  #else
		      header.fgColor.setNamedColor(colorString);
		  #endif
	   }
		//��ʐF�ύX�̗v���ɑ΂��铮��
	   if(CGIParam.anotherParam[i].first=="background_color"){
	   QByteArray colorArray=CGIParam.anotherParam[i].second.toLatin1();
	   QString colorString=QUrl::fromPercentEncoding(colorArray);
		  #if QT_VERSION >= 0x040700
		      if(QColor::isValidColor(colorString)){
			  header.bgColor.setNamedColor(colorString);
		      }
		  #else
		      header.bgColor.setNamedColor(colorString);
		  #endif
	   }
		//�摜�����ύX�v���ɑ΂��铮��
		if(CGIParam.anotherParam[i].first=="row_height"){
			if(CGIParam.anotherParam[i].second!="undefined"){
				header.rowHeight = CGIParam.anotherParam[i].second.toInt();
			}
		}
		//�\���X�P�[���ύX�ɑ΂��铮��
		if(CGIParam.anotherParam[i].first == "scale_real"){
			changeScale=true;
			if(header.dataType==Integer){
				if(CGIParam.anotherParam[i].second!="undefined"){
					maxScaleI = CGIParam.anotherParam[i].second.toInt();
					if(maxScaleI==0){
						maxScaleI=1;
					}
				}
			}
			else if(header.dataType==Float){
				if(CGIParam.anotherParam[i].second!="undefined"){
					maxScaleF = CGIParam.anotherParam[i].second.toFloat();
					if(maxScaleF==0){
						maxScaleF=1;
					}
				}
			}
		}
		if(CGIParam.anotherParam[i].first == "scale_log"){
			changeScale=true;
			if(header.dataType==Integer){
				if(CGIParam.anotherParam[i].second!="undefined"){
					maxScaleI = CGIParam.anotherParam[i].second.toInt();
					if(maxScaleI==0){
						maxScaleI=1;
					}
				}
			}
			else if(header.dataType==Float){
				if(CGIParam.anotherParam[i].second!="undefined"){
					maxScaleF = CGIParam.anotherParam[i].second.toFloat();
					if(maxScaleF==0){
						maxScaleF=1;
					}
				}
			}
		}
		//�\�����[�h�ύX�v���ɑ΂��铮��
		if(CGIParam.anotherParam[i].first=="display"){
			if(CGIParam.anotherParam[i].second=="maximum"){
				showMaximum=true;
			}
			else{
				showMaximum=false;
			}
		}
	}

	quint32 strand;
	quint32 bpLower, bpUpper;
	quint32 dataType;
	bool showLine;

	if(header.dataType==0){
		dataType=0;
	}
	else{
		dataType=1;
	}

	if(header.strandSpecificity==1){
		if(CGIParam.start<CGIParam.end){
			strand=1;
			bpLower=CGIParam.start;
			bpUpper=CGIParam.end;
		}
		else{
			strand=-1;
			bpLower=CGIParam.end;
			bpUpper=CGIParam.start;
		}
	}
	
	if(header.strandSpecificity==0){
		if(CGIParam.start<CGIParam.end){
			strand=0;
			bpLower=CGIParam.start;
			bpUpper=CGIParam.end;
		}
		else{
			strand=-2;
			bpLower=CGIParam.end;
			bpUpper=CGIParam.start;
		}
	}

	quint64 bpWidth=bpUpper-bpLower+1;

	if(header.dataType==Integer){

		if(header.strandSpecificity==1){

				//�t�H���g�̏���
				QFont font(QApplication::font());
				font.setPointSize(header.fontSize);

				//�}�̍쐬
				QImage image(IndexWidth, header.rowHeight+1, QImage::Format_ARGB32);
				QPainter painter(&image);
				painter.setPen(Qt::NoPen);
				painter.setBrush(header.bgColor);
				painter.drawRect(image.rect());
				drawIndexGrad(maxScaleI, image, font, painter, changeScale, strand, dataType, showLine);
				painter.setBrush(Qt::NoBrush);
				painter.setPen(header.fgColor);

				
				//�X�P�[���̏�������


			#ifdef Q_OS_WIN32
				_setmode( _fileno( stdout ), _O_BINARY );
			#endif

				QFile file;
				file.open(stdout, QIODevice::WriteOnly);
				QTextStream out(&file);
				if(CGIParam.is_cgi){
					out << "Content-type: image/png\n"
						<< "Pragma: no-cache\n\n";
					out.flush();
				}
				QImageWriter writer(&file, "png");
				if(!writer.canWrite()){
					return false;
				}
				if(!writer.write(image)){
					QString errorString = writer.errorString();
					return false;
				}
				file.flush();
				file.close();

				return true;
		}


		if(header.strandSpecificity==0){

				//�t�H���g�̏���
				QFont font(QApplication::font());
				font.setPointSize(header.fontSize);

				//�}�̍쐬
				QImage image(IndexWidth, header.rowHeight*2+2, QImage::Format_ARGB32);
				QPainter painter(&image);
				painter.setPen(Qt::NoPen);
				painter.setBrush(header.bgColor);
				painter.drawRect(image.rect());
				drawIndexGrad(maxScaleI, image, font, painter, changeScale, strand, dataType, showLine);
				painter.setBrush(Qt::NoBrush);
				painter.setPen(header.fgColor);

				
				//�X�P�[���̏�������


			#ifdef Q_OS_WIN32
				_setmode( _fileno( stdout ), _O_BINARY );
			#endif

				QFile file;
				file.open(stdout, QIODevice::WriteOnly);
				QTextStream out(&file);
				if(CGIParam.is_cgi){
					out << "Content-type: image/png\n"
						<< "Pragma: no-cache\n\n";
					out.flush();
				}
				QImageWriter writer(&file, "png");
				if(!writer.canWrite()){
					return false;
				}
				if(!writer.write(image)){
					QString errorString = writer.errorString();
					return false;
				}
				file.flush();
				file.close();

				return true;
		}
	}


	else{

		if(header.strandSpecificity==1){
			
			//�t�H���g�̏���
			QFont font(QApplication::font());
		    font.setPointSize(header.fontSize);
			
			//�}�̍쐬
			QImage image(IndexWidth, header.rowHeight+1, QImage::Format_ARGB32);
			QPainter painter(&image);
			painter.setPen(Qt::NoPen);
			painter.setBrush(header.bgColor);
			painter.drawRect(image.rect());
			drawIndexGrad(maxScaleF, image, font, painter, changeScale, strand, dataType, showLine);
			painter.setBrush(Qt::NoBrush);
			painter.setPen(header.fgColor);


			//�X�P�[���̏�������


		#ifdef Q_OS_WIN32
			_setmode( _fileno( stdout ), _O_BINARY );
		#endif

			QFile file;
			file.open(stdout, QIODevice::WriteOnly);
			QTextStream out(&file);
			if(CGIParam.is_cgi){
				out << "Content-type: image/png\n"
					<< "Pragma: no-cache\n\n";
				out.flush();
			}
			QImageWriter writer(&file, "png");
			if(!writer.canWrite()){
				return false;
			}
			if(!writer.write(image)){
				QString errorString = writer.errorString();
				return false;
			}
			file.flush();
			file.close();

			return true;
		}


	if(header.strandSpecificity==0){
			
			//�t�H���g�̏���
			QFont font(QApplication::font());
		    font.setPointSize(header.fontSize);
			
			//�}�̍쐬
			QImage image(IndexWidth, header.rowHeight*2+2, QImage::Format_ARGB32);
			QPainter painter(&image);
			painter.setPen(Qt::NoPen);
			painter.setBrush(header.bgColor);
			painter.drawRect(image.rect());
			drawIndexGrad(maxScaleF, image, font, painter, changeScale, strand, dataType, showLine);
			painter.setBrush(Qt::NoBrush);
			painter.setPen(header.fgColor);


			//�X�P�[���̏�������


		#ifdef Q_OS_WIN32
			_setmode( _fileno( stdout ), _O_BINARY );
		#endif

			QFile file;
			file.open(stdout, QIODevice::WriteOnly);
			QTextStream out(&file);
			if(CGIParam.is_cgi){
				out << "Content-type: image/png\n"
					<< "Pragma: no-cache\n\n";
				out.flush();
			}
			QImageWriter writer(&file, "png");
			if(!writer.canWrite()){
				return false;
			}
			if(!writer.write(image)){
				QString errorString = writer.errorString();
				return false;
			}
			file.flush();
			file.close();

			return true;
	}

	}

	return false;

}

bool GraphTrack::printOperation(void){


	return true;
}


bool GraphTrack::printIndexOperation(void){


	return true;
}


int GraphTrack::getMinimumLargerGrad(int value)
{
	int grad;
	int grad_order=1;
	while(1){
		grad=grad_order;
		if(value<grad){
			return grad;
		}
		grad=grad_order*2;
		if(value<grad){
			return grad;
		}
		grad=grad_order*5;
		if(value<grad){
			return grad;
		}
		grad_order=grad_order*10;
	}
}

void GraphTrack::printBackground(QImage* imagePtr, const QColor& color)
{
	QPainter painter(imagePtr);
	painter.setPen(Qt::NoPen);
	painter.setBrush(color);
	painter.drawRect(imagePtr->rect());
}
