#include <iostream>
#include <QtCore>
#include <QtGui>

#include "BinSeq.h"
#include "IndexCreator.h"
#include "BMapCore.h"

using namespace DesktopTrack;

void showUsage(void){
    cout<< "Usage : BMap [options]"                                                                                 		<< endl
		<< "  [Selection of running mode]"																					<< endl
		<< "   -create                 : If you want to create index, use this option. Otherwise BMap runs in mapping mode"	<< endl
        << "  [Basic Parameters]"                                                                                   		<< endl
        << "   -species      [string]  : species name"                                                               		<< endl
        << "   -revision     [string]  : revision name"                                                              		<< endl
		<< "   -root_dir     [string]  : path to revision directry (default is [application's directory path]/Revisions)"	<< endl
        << "   -index        [string]  : index file [*.bmap]"																<< endl
		<< "   -binseq       [string]  : binseq file [*.binseq]"														 	<< endl
        << "   -thread       [integer] : number of thread"																	<< endl
        << "   -bwt          [integer] : index (suffix array or bwt) mode"													<< endl
        << "                           : mode=0, use suffix array. [memory usage for index: 9.5xgenome] [faster]"			<< endl
        << "                           : mode=1, use bwt           [memory usage for index:11.5xgenome] [faster]"			<< endl
        << "                           : mode=2, use bwt           [memory usage for index: 7.5xgenome] [faster][default]"	<< endl
        << "                           : mode=3, use bwt           [memory usage for index: 6.5xgenome] [fast]"				<< endl
        << "                           : mode=4, use bwt           [memory usage for index: 6.0xgenome] [middle]"			<< endl
        << "                           : mode=5, use bwt           [memory usage for index: 4.0xgenome] [slow]"				<< endl
        << "                           : mode=6, use bwt           [memory usage for index: 3.0xgenome] [very slow]"		<< endl
        << "  [Parameters for seed finding]"																				<< endl
        << "   -seedoffset   [integer] : offset position of read to take seed (default=0)"									<< endl
        << "   -seedstep     [integer] : step width of seed (default=5)"													<< endl
        << "   -seediterate  [integer] : count of seed per half strand of read (default=20)"								<< endl
        << "   -minseedlen   [integer] : minimum length of seed (default=20)"												<< endl
        << "   -maxseedlen   [integer] : maximum length of seed (default=26)"												<< endl
        << "   -minseedcount [integer] : minimum number of seeds for varification of alignment(default=2)"					<< endl
		<< "   -maxseedcount [integer] : maximum count of seed (default=10)"												<< endl
        << "  [Parameters for alignment]"																					<< endl
        << "   -minscore     [integer] : minimum threshold for alignment score (default=150)"								<< endl
        << "  [Parameters for I/O]"																							<< endl
		<< "   -reference    [strings] : input file for creating index (formatted in fasta)"								<< endl
        << "   -fasta        [string]  : input file (formatted in fasta)"													<< endl
        << "   -fastq        [string]  : input file (formatted in fastq)"													<< endl
		<< "   -pfastq       [stringx2]: input files (paired fastq files)"													<< endl
        << "   -qseq         [string]  : input file (formatted in qseq)"													<< endl
        << "   -bisulalign   [string]  : path for bisulalign file (human-readable alignments)"								<< endl
        << "   -sum          [string]  : path for summary file (human-readable summary file)"								<< endl;
}

bool createIndex=false;
QString species;
QString revision;
QString indexPath;
QString binseqPath;
QStringList refSourcePaths;
quint64 numThread=1;
quint64 bwtMode=2;
quint64 SCF=2;
quint64 SCL=16;
quint64 seedOffset=0;
quint64 seedLength=20;
quint64 seedLengthMax=26;
quint64 seedStep=5;
quint64 seedIterate=20;
quint64 minSeedHit=2;
quint64 minAlnScore=150;
quint64 maxHitCount=10;
QList<QueryDispatcher::FileFormat> fileFormats;
QStringList queryFilePaths;
QString bisulAlignPath("bmapresult.bisulalign");
QString sumPath("bmapresult.sum");

bool ProcessSpecies(void)
{
	//���s�t�@�C���̑��݂���f�B���N�g�����m�F
	QDir RevisionDir(QCoreApplication::applicationDirPath());
	//Revision�f�B���N�g��
	if(!RevisionDir.exists(RevisionsDirName)){
		cerr << "Coundn't find revision directory.";
		return false;
	}
	if(!RevisionDir.cd(RevisionsDirName)){
		cerr << "Coundn't find revision directory.";
		return false;
	}
	//species�̊m�F
	if(!RevisionDir.exists(species)){
		cerr << "Couldn't find species \"" << species.toStdString() << "\".";
		return false;
	}
	if(!RevisionDir.cd(species)){
		cerr << "Couldn't find species \"" << species.toStdString() << "\".";
		return false;
	}
	//revision�̊m�F
	if(!RevisionDir.exists(revision)){
		cerr << "Couldn't find revision \"" << revision.toStdString() << "\".";
		return false;
	}
	if(!RevisionDir.cd(revision)){
		cerr << "Couldn't find revision \"" << revision.toStdString() << "\".";
		return false;
	}
	//BMap�t�@�C���̊m�F
	QString bmapFileName(BMapIndexFileNameTemplate.arg(species).arg(revision));
	if(RevisionDir.exists(bmapFileName)){
		indexPath=RevisionDir.absoluteFilePath(bmapFileName);
		return true;
	}
	return false;
}

bool ProcessSpeciesForIndexCreation(void)
{
	//���s�t�@�C���̑��݂���f�B���N�g�����m�F
	QDir RevisionDir(QCoreApplication::applicationDirPath());
	//Revision�f�B���N�g��
	if(!RevisionDir.exists(RevisionsDirName)){
		cerr << "Creating revision root directry." << endl;
		if(!RevisionDir.mkdir(RevisionsDirName)){
			cerr << "Couldn't create revision directory for \"" 
				 << RevisionsDirName.toStdString() 
				 << "\"." << endl;
			return false;
		}
	}
	if(!RevisionDir.cd(RevisionsDirName)){
		cerr << "Coundn't find revision directory.";
		return false;
	}
	//species�̊m�F
	if(!RevisionDir.exists(species)){
		cerr << "Creating species directry." << endl;
		if(!RevisionDir.mkdir(species)){
			cerr << "Couldn't create revision directory for \"" 
				 << species.toStdString() 
				 << "\"." << endl;
			return false;
		}
	}
	if(!RevisionDir.cd(species)){
		cerr << "Couldn't find species \"" << species.toStdString() << "\".";
		return false;
	}
	//revision�̊m�F
	if(!RevisionDir.exists(revision)){
		cerr << "Creating revision directry." << endl;
		if(!RevisionDir.mkdir(revision)){
			cerr << "Couldn't create revision directory for \"" 
				 << revision.toStdString() 
				 << "\"." << endl;
			return false;
		}
	}
	if(!RevisionDir.cd(revision)){
		cerr << "Couldn't find revision \"" << revision.toStdString() << "\".";
		return false;
	}
	//Index�t�@�C���̊m�F
	QString bmapFileName(BMapIndexFileNameTemplate.arg(species).arg(revision));
	QString binseqFileName(BinSeqFileTemp.arg(species).arg(revision));
	indexPath=RevisionDir.filePath(bmapFileName);
	binseqPath=RevisionDir.filePath(binseqFileName);
	return true;

}

bool ProcessArguments(int argc, char* argv[]){

	int i=1;
	while(i<argc){
		QString option(argv[i]);
		if(option==QString("-create")){
			createIndex=true;
		}
		else if(option==QString("-species")){
			i++;
			if(i==argc){
				break;
			}
			species=argv[i];
		}
		else if(option==QString("-revision")){
			i++;
			if(i==argc){
				break;
			}
			revision=argv[i];
		}
		else if(option==QString("-index")){
			i++;
			if(i==argc){
				break;
			}
			indexPath=argv[i];
		}
		else if(option==QString("-binseq")){
			i++;
			if(i==argc){
				break;
			}
			binseqPath=argv[i];
		}
		else if(option==QString("-thread")){
			i++;
			if(i==argc){
				break;
			}
			numThread=QString(argv[i]).toUInt();
		}
		else if(option==QString("-bwt")){
			i++;
			if(i==argc){
				break;
			}
			bwtMode=QString(argv[i]).toUInt();
			switch(bwtMode){
			case 0:
                SCF=0;
                SCL=0;
				break;
            case 1:
                SCF=1;
                SCL=16;
                break;
            case 2:
                SCF=2;
                SCL=16;
				break;
            case 3:
                SCF=2;
                SCL=32;
				break;
            case 4:
                SCF=2;
                SCL=64;
                break;
            case 5:
                SCF=4;
                SCL=64;
				break;
            case 6:
                SCF=8;
                SCL=64;
                break;
            default:
				//�������͈͈ȊO�ł���Δ�����
                cerr << "Index mode shoud be specified by integer ranging 0 to 6." << endl;
				return false;
			}
		}
		else if(option==QString("-SCF")){
			i++;
			if(i==argc){
				break;
			}
			SCF=QString(argv[i]).toUInt();
			bwtMode=1;
		}
		else if(option==QString("-SCL")){
			i++;
			if(i==argc){
				break;
			}
			SCL=QString(argv[i]).toUInt();
			bwtMode=1;
		}
		else if(option==QString("-thread")){
			i++;
			if(i==argc){
				break;
			}
			numThread=QString(argv[i]).toUInt();
		}
		else if(option==QString("-seedoffset")){
			i++;
			if(i==argc){
				break;
			}
			seedOffset=QString(argv[i]).toUInt();
		}
		else if(option==QString("-seedstep")){
			i++;
			if(i==argc){
				break;
			}
			seedStep=QString(argv[i]).toUInt();
		}
		else if(option==QString("-seediterate")){
			i++;
			if(i==argc){
				break;
			}
			seedIterate=QString(argv[i]).toUInt();
		}
		else if(option==QString("-minseedcout")){
			i++;
			if(i==argc){
				break;
			}
			minSeedHit=QString(argv[i]).toUInt();
		}
		else if(option==QString("-minseedlen")){
			i++;
			if(i==argc){
				break;
			}
			seedLength=QString(argv[i]).toUInt();
		}
		else if(option==QString("-maxseedlen")){
			i++;
			if(i==argc){
				break;
			}
			seedLengthMax=QString(argv[i]).toUInt();
		}
		else if(option==QString("-maxhitcount")){
			i++;
			if(i==argc){
				break;
			}
			maxHitCount=QString(argv[i]).toUInt();
		}
		else if(option==QString("-minscore")){
			i++;
			if(i==argc){
				break;
			}
			minAlnScore=QString(argv[i]).toUInt();
		}
		else if(option==QString("-fasta")){
			i++;
			if(i==argc){
				break;
			}
			fileFormats.append(QueryDispatcher::fasta);
			queryFilePaths.append(argv[i]);
		}
		else if(option==QString("-fastq")){
			i++;
			if(i==argc){
				break;
			}
			fileFormats.append(QueryDispatcher::fastq);
			queryFilePaths.append(argv[i]);
		}
		else if(option==QString("-pfastq")){
			i++;
			if(i==argc){
				break;
			}
			QString firstQueryFile=argv[i];
			i++;
			if(i==argc){
				break;
			}
			QString secondQueryFile=argv[i];
			QString format("%1\t%2");
			fileFormats.append(QueryDispatcher::pfastq);
			queryFilePaths.append(format.arg(firstQueryFile).arg(secondQueryFile));
		}
		else if(option==QString("-qseq")){
			i++;
			if(i==argc){
				break;
			}
			fileFormats.append(QueryDispatcher::qseq);
			queryFilePaths.append(argv[i]);
		}
		else if(option==QString("-bisulalign")){
			i++;
			if(i==argc){
				break;
			}
			bisulAlignPath=argv[i];
		}
		else if(option==QString("-sum")){
			i++;
			if(i==argc){
				break;
			}
			sumPath=argv[i];
		}
		else if(option==QString("-reference")){
			while(i<argc){
				i++;
				option=argv[i];
				//���̃I�v�V�������o���甲����
				if(option.startsWith('-')){
					i--;
					break;
				}
				if(option.size()!=0){
					refSourcePaths.append(QString(argv[i]));
				}
			}
			if(refSourcePaths.size()==0){
				cerr << "More than file path shoud be specified for option \"-reference\"." << endl;
				return false;
			}
		}
        else{
			cerr << "Error: Unknown option was specified:" << option.toStdString() << "." << endl << endl;
			return false;
        }
        i++;
	}
    return true;
}

bool ConfirmCriticalParameters(void){

	//�C���f�b�N�X�쐬���[�h
	if (createIndex){
		if (species.size() == 0){
			cerr << "Species name should be specified with \"-species\" option for creating index." << endl;
			return false;
		}
		else if (revision.size() == 0){
			cerr << "Revision name should be specified with \"-revision\" option for creating index." << endl;
			return false;
		}
		//BinSeq�̃p�X������
		if (!ProcessSpeciesForIndexCreation()){
			cerr << "Couldn't specify species and/or revision info." << endl;
			return 0;
		}
		QFileInfo info(binseqPath);
		if (info.exists()){
			return true;
		}
		if (refSourcePaths.size()==0){
			cerr << "You have to specify paths to reference genome sequences." << endl;
			return false;
		}

	}
	//�}�b�s���O���[�h
	else{

		//index�̊m�F
		QFileInfo info(indexPath);
		if(!info.exists()){
			//index���������species�������ɍ쐬����K�v������̂ŁA���̏��𓾂�
			if(species.size()==0||revision.size()==0){
				//species��񂪎w�肳��Ă��Ȃ���΂��̎|�`���Ĕ�����
				cerr << "Index file shoud be specified with -index or -species & -revision option." << endl;
				return false;
			}
			if(!ProcessSpecies()){
				return true;
			}
		}
		else{

		}

		//Query�������ƌ����͎��s�ł��Ȃ�
		if(queryFilePaths.size()==0){
			cerr << "Query sequences must be specified with -fasta, -fastq or -qseq option(s)." << endl;
			return false;
		}
		//�p�����[�^�̗�O�I�Ȏw����͂���
		if(numThread==0){
			cerr << "Number of thread must be larger than 0." << endl;
			return false;
		}
		if(seedLength==0){
			cerr << "Length of seed must be larger than 0." << endl;
			return false;
		}
		if(seedLength>=seedLengthMax){
			cerr << "Minimum length of seed shoudl be larger than maximum length of seed." << endl;
			return false;
		}
		if(seedIterate>1){
			if(seedStep==0){
				cerr << "Step of seed must be larger than 0, if iterative seed finding is needed." << endl;
				return false;
			}
		}
		if(bwtMode>0){
			if(SCF<1){
				cerr << "SCF value must be more than 0 when SCL value is more than 0." << endl;
				return false;
			}
			if(SCL<1){
				cerr << "SCL value must be more than 0 when SCL value is more than 0." << endl;
				return false;
			}
		}
		return true;
	}
	return true;

}

int main(int argc, char* argv[]){

	QCoreApplication app(argc, argv);
    if(!ProcessArguments(argc, argv)){
        showUsage();
        return 0;
    }
    if(!ConfirmCriticalParameters()){
        showUsage();
        return 0;
    }
	//�C���f�b�N�X�쐬���[�h
	if(createIndex){

		//BinSeq�̃p�X������
		if(!ProcessSpeciesForIndexCreation()){
			cerr << "Couldn't specify species and/or revision info." << endl;
			return 0;
		}
		IndexCreator creator(&app);
		QObject::connect(&creator, SIGNAL(processFinished()), &app, SLOT(quit()));
		creator.setPathAndRefs(species, revision, binseqPath, indexPath, refSourcePaths);
		creator.start();
		app.exec();
		return 0;

	}
    else{
        BMapCore::BMapCore core(numThread, &app);
        QObject::connect(&core, SIGNAL(finished()), &app, SLOT(quit()));
		if(species.size()!=0&&revision.size()!=0){
			std::cout	<< "Start BMap mapping with following parameters" << endl
						<< " species                :" << species.toStdString() << endl
						<< " revision               :" << revision.toStdString() << endl;
		}
		else{
			std::cout	<< "Start BMap mapping with following parameters" << endl
						<< " index file             :" << indexPath.toStdString() << endl;
		}
		std::cout	<< " seed offset            :" << seedOffset << endl
					<< " seed iterate           :" << seedIterate << endl
					<< " seed step              :" << seedStep << endl
					<< " min seed hit           :" << minSeedHit << endl
					<< " minimum seed length    :" << seedLength << endl
					<< " maximum seed length    :" << seedLengthMax << endl
					<< " seed max hit count     :" << maxHitCount << endl
					<< " minimum alignment score:" << minAlnScore << endl
					<< " output summary file    :" << sumPath.toStdString() << endl
					<< " output alignment file  :" << bisulAlignPath.toStdString() << endl << endl;

		core.setAlignmentParameters(seedOffset, seedLength, seedStep, seedIterate, minSeedHit, seedLengthMax, maxHitCount, minAlnScore);

        if(bwtMode==0){
			std::cout	<< "Loading index (suffix array)" << endl;
            if(!core.setBMapFile(indexPath)){
                return 0;
            }
        }
        else{
			std::cout	<< "Loading index (FM-index)" << endl
						<< "    compression factor for suffix array is " << SCF << "." << endl
						<< "    compression factor for counter table is " << SCL << "." << endl;
            if(!core.setBMapFileAsBWT(indexPath, SCF, SCL)){
                return 0;
            }
        }
        if(!core.setQueryFiles(queryFilePaths, fileFormats)){
            return 0;
        }
        if(!core.setIO(sumPath, bisulAlignPath)){
            return 0;
        }
        if(!core.start()){

            return 0;
        }
        app.exec();
		return 0;
    }
}
