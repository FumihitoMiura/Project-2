#ifndef LINE_BUFFER_H
#define LINE_BUFFER_H

#include <QtCore>
#include <istream>
#include <new>
#include <vector>

#include "DesktopTrackCommon.h"

namespace DesktopTrack{

	class LineBuffer{
	private:
		QFile								file;
		QBuffer								buffer;
		QByteArray							data;
		QMutex								mutex;
		bool loadBuffer(void);
	public:
		LineBuffer(void);
		bool setFile(const QString& pathToFile);
		bool getLine(QByteArray& resultTo);
		QByteArray readLine(void);
		bool hasNextLine(void);
		bool atEnd(void);
	};

};

#endif
