#include "MapSum.h"

#include <iomanip>

using namespace DesktopTrack;
using namespace std;

MapSum::MapSum(QWidget* parent):QWidget(parent){}

bool MapSum::setIO(
	const QStringList& listForInputFilePaths,
	const QString& pathToOutFile,
	const QString& sampleName_)
{
	sumFilePaths=listForInputFilePaths;
	outFilePath=pathToOutFile;
	sampleName=sampleName_;
	return true;
}

void MapSum::start(void)
{

	QMap<qint64, qint64> map, map_r1, map_r2;
	qint64 numReads=0;

	for(int file_id=0; file_id<sumFilePaths.size(); file_id++){

		//sum file���J��
		cout << "Analyzing " << sumFilePaths[file_id].toStdString() << "." << endl;
		QFileInfo info(sumFilePaths[file_id]);
		if(info.suffix()=="gz"){

			QFile sumFile(sumFilePaths[file_id]);
			sumFile.open(QIODevice::ReadOnly);
			if(!sumFile.isOpen()){
				cout << "Couldn't open file \"" << sumFilePaths[file_id].toStdString() << "\"." << endl;
				break;
			}
			z_stream strm;
			strm.zalloc=Z_NULL;
			strm.zfree=Z_NULL;
			strm.opaque=Z_NULL;
			inflateInit2(&strm, 16+MAX_WBITS);

			QByteArray data, remain;

			unsigned char *compressed_data, *decompressed_data;
			try{
				compressed_data=new unsigned char[BufferSizeMax];
				decompressed_data=new unsigned char[BufferSizeMax];
			}
			catch(...){
				cout << "Couldn't allocate enough memory." << endl;
				return;
			}

			bool noError=true;

			while(!sumFile.atEnd()){

				//���̓t�@�C������IN�������[�ɓǂݍ���
				strm.avail_in=sumFile.read((char*)compressed_data, BufferSizeMax);
				strm.next_in=compressed_data;

				data=remain;

				//�ǂݍ��񂾓��e�͑S�ĉ𓀂��C���^�[�i���o�b�t�@�[�ɕۑ�
				do{
					strm.avail_out=BufferSizeMax;
					strm.next_out=decompressed_data;
					int ret=inflate(&strm, Z_NO_FLUSH);
					if( ret< 0 ){
						// error
						cout << "... Error occured during infrating the file. Skip this." << endl;
						noError=false;
						break;	// do while(strm.avail_out==0);
					}
					int outDataSize=BufferSizeMax-strm.avail_out;
					data+=QByteArray((char*)decompressed_data, outDataSize);
				} while(strm.avail_out==0);

				if(!noError){
					break;	//while(!sumFile.atEnd())
				}

				if(data.size()>0){

					int firstIndex=data.indexOf('\n');
					int lastIndex=data.lastIndexOf('\n');
					if(firstIndex==-1){
						cerr << "Invarid file:" << sumFile.fileName().toStdString() << endl;
						return;
					}
					if(lastIndex==-1){
						cerr << "Invarid file:" << sumFile.fileName().toStdString() << endl;
						return;
					}

					//�t�@�C�������֓��B���Ă��Ȃ��ꍇ
					if(!sumFile.atEnd()){
						remain=data.right(data.size()-lastIndex-1);
						data=data.left(lastIndex+1);
					}

				}

				QBuffer buffer(&data);
				buffer.open(QIODevice::ReadOnly);

				while(!buffer.atEnd()){

					QStringList cols=QString::fromLatin1(buffer.readLine()).split('\t');

					numReads++;
					//for single end mapping (no unique hit)
					if(cols.size()==3){
					/*--------------------------------
						cols[0]	clone name
						cols[1]	number of top score alignment
						cols[2]	query length
					--------------------------------*/
						qint64 number_of_hit_region=cols[1].toInt();
						map[number_of_hit_region]++;
					}
					//for single end mapping (unique hit)
					else if(cols.size()==9){
					/*--------------------------------
						cols[0]	clone name
						cols[1]	number of top score alignment
						cols[2]	query length
						cols[3]	target name
						cols[4]	chromosome start
						cols[5]	chromosome end
						cols[6]	query start
						cols[7]	query end
						cols[8]	alignment type
					--------------------------------*/
						qint64 number_of_hit_region=cols[1].toInt();
						map[number_of_hit_region]++;
						if(number_of_hit_region!=1){
							continue;
						}
					}
					//for paired end mapping
					else if(cols.size()==17){
					/*--------------------------------
						cols[0]		clone name
						cols[1]		number of top score alignment for read 1
						cols[2]		query length for read 1
						cols[3]		target name for read 1
						cols[4]		chromosome start for read 1
						cols[5]		chromosome end for read 1
						cols[6]		query start for read 1
						cols[7]		query end for read 1
						cols[8]		alignment type for read 1
						cols[9]		number of top score alignment for read 2
						cols[10]	query length for read 2
						cols[11]	target name for read 2
						cols[12]	chromosome start for read 2
						cols[13]	chromosome end for read 2
						cols[14]	query start for read 2
						cols[15]	query end for read 2
						cols[16]	alignment type for read 2

					--------------------------------*/
						qint64 number_of_hit_region_r1=cols[1].toInt();
						qint64 number_of_hit_region_r2=cols[9].toInt();
						map_r1[number_of_hit_region_r1]++;
						map_r2[number_of_hit_region_r2]++;
						if(1==number_of_hit_region_r1==number_of_hit_region_r2){

						}

					}

				}


			}


		}
		else{

			QFile sumFile(sumFilePaths[file_id]);
			sumFile.open(QIODevice::ReadOnly);
			if(!sumFile.isOpen()){
				cout << "Couldn't open file \"" << sumFilePaths[file_id].toStdString() << "\"." << endl;
				break;
			}

			while(!sumFile.atEnd()){

				//�f�[�^���o�b�t�@�[�ɓǂݍ���
				QByteArray data=sumFile.read(BufferSizeMax);
				QBuffer buffer;
				if(!sumFile.atEnd()){

					int firstIndex=data.indexOf('\n');
					int lastIndex=data.lastIndexOf('\n');
					if(firstIndex==-1){
						cerr << "Invarid file:" << sumFile.fileName().toStdString() << endl;
						return;
					}
					if(lastIndex==-1){
						cerr << "Invarid file:" << sumFile.fileName().toStdString() << endl;
						return;
					}

					sumFile.seek(sumFile.pos()-data.size()+lastIndex+1);
					data=data.left(lastIndex);

				}

				buffer.setBuffer(&data);
				buffer.open(QIODevice::ReadOnly);
		
				while(!buffer.atEnd()){

					QStringList cols=QString::fromLatin1(buffer.readLine()).split('\t');

					numReads++;
					//for single end mapping (no unique hit)
					if(cols.size()==3){
					/*--------------------------------
						cols[0]	clone name
						cols[1]	number of top score alignment
						cols[2]	query length
					--------------------------------*/
						qint64 number_of_hit_region=cols[1].toInt();
						map[number_of_hit_region]++;
					}
					//for single end mapping (unique hit)
					else if(cols.size()==9){
					/*--------------------------------
						cols[0]	clone name
						cols[1]	number of top score alignment
						cols[2]	query length
						cols[3]	target name
						cols[4]	chromosome start
						cols[5]	chromosome end
						cols[6]	query start
						cols[7]	query end
						cols[8]	alignment type
					--------------------------------*/
						qint64 number_of_hit_region=cols[1].toInt();
						map[number_of_hit_region]++;
						if(number_of_hit_region!=1){
							continue;
						}
					}
					//for paired end mapping
					else if(cols.size()==17){
					/*--------------------------------
						cols[0]		clone name
						cols[1]		number of top score alignment for read 1
						cols[2]		query length for read 1
						cols[3]		target name for read 1
						cols[4]		chromosome start for read 1
						cols[5]		chromosome end for read 1
						cols[6]		query start for read 1
						cols[7]		query end for read 1
						cols[8]		alignment type for read 1
						cols[9]		number of top score alignment for read 2
						cols[10]	query length for read 2
						cols[11]	target name for read 2
						cols[12]	chromosome start for read 2
						cols[13]	chromosome end for read 2
						cols[14]	query start for read 2
						cols[15]	query end for read 2
						cols[16]	alignment type for read 2

					--------------------------------*/
						qint64 number_of_hit_region_r1=cols[1].toInt();
						qint64 number_of_hit_region_r2=cols[9].toInt();
						map_r1[number_of_hit_region_r1]++;
						map_r2[number_of_hit_region_r2]++;
						if(1==number_of_hit_region_r1==number_of_hit_region_r2){

						}

					}

				}

			}

		}

	}

	QFileInfo info(outFilePath);

	//�����o�̓t�@�C���̊g���q��html�Ȃ�O���t�B�J���A�E�g�v�b�g
	if(info.suffix()=="html"){

		//�o�̓t�@�C���̃I�[�v��
		QFile outFile(outFilePath);
		outFile.open(QIODevice::WriteOnly);
		if(!outFile.isOpen()){
			cout << "Couldn't open file \"" << outFilePath.toStdString() << "\"" << endl;
			return;
		}

		//�e���v���[�g�̓ǂݏo��
		QFile Resource(QString(":/template/MapSumTemplate.html"));
		Resource.open(QIODevice::ReadOnly);
		QString htmlTemplate=Resource.readAll();
		/*
			%1: Sample Name
			%2: ImageFilePath
			%3: tbody
			%4: tfooter
		*/

		QString ImageFilePath=info.dir().relativeFilePath(info.baseName()+QString(".mapsum.png"));

		//�܂��A�}�b�v�p�x�̍ő�l���擾
		//�����ɑ����[�h�����v�Z
		qint64 s_num(0), r1_num(0), r2_num(0);
		QList<qint64> keys=map.keys();
		qSort(keys.begin(), keys.end());
		qint64 maxValue=0;
		for(int i=0; i<keys.size(); i++){
			s_num+=map[i];
			if(maxValue<keys[i]){
				maxValue=keys[i];
			}
		}
		keys=map_r1.keys();
		qSort(keys.begin(), keys.end());
		for(int i=0; i<keys.size(); i++){
			r1_num+=map_r1[i];
			if(maxValue<keys[i]){
				maxValue=keys[i];
			}
		}
		keys=map_r2.keys();
		qSort(keys.begin(), keys.end());
		for(int i=0; i<keys.size(); i++){
			r2_num+=map_r1[i];
			if(maxValue<keys[i]){
				maxValue=keys[i];
			}
		}
		QByteArray TableTextData;
		QBuffer TableTextStreamBuffer(&TableTextData);
		TableTextStreamBuffer.open(QIODevice::WriteOnly);
		QTextStream TableTextStream(&TableTextStreamBuffer);
		QVector<double> x_data, s_data, r1_data, r2_data;
		QVector<QString> x_label_data;
		for(qint64 i=0; i<maxValue+1; i++){
			TableTextStream << "\t\t\t<tr>" << endl;
			//label�p
			x_data << (double)(i+1);
			x_label_data << QString().setNum(i);
			TableTextStream << "\t\t\t\t<td>" << i << "</td>" << endl;
			//Single-End
			if(map.contains(i)){
				if(s_num>0){
					TableTextStream 
						<< "\t\t\t\t<td>" 
						<< ThousandSeparator(QString().setNum(map[i])).putSeparator()
						<< " (" 
						<< QString().setNum((double)map[i]/(double)s_num*(double)100, 'f', 1) 
						<< "%)</td>"  << endl;
				}
				else{
					TableTextStream << "\t\t\t\t<td>" << map[i] << "</td>"  << endl;
				}
				s_data << (double)map[i];
			}
			else{
				TableTextStream << "\t\t\t\t<td>" << 0 << "</td>" << endl;
				s_data << (double)0;
			}
			//Paired-End Read 1
			if(map_r1.contains(i)){
				if(r1_num>0){
					TableTextStream 
						<< "\t\t\t\t<td>" 
						<< ThousandSeparator(QString().setNum(map_r1[i])).putSeparator()
						<< " (" 
						<< QString().setNum((double)map_r1[i]/(double)r1_num*(double)100, 'f', 1) 
						<< "%)</td>"  << endl;
				}
				else{
					TableTextStream << "\t\t\t\t<td>" << map_r1[i] << "</td>"  << endl;
				}
				r1_data << (double)map_r1[i];
			}
			else{
				TableTextStream << "\t\t\t\t<td>" << 0 << "</td>" << endl;
				r1_data << (double)0;
			}
			//Paired-End Read 2
			if(map_r2.contains(i)){
				if(r2_num>0){
					TableTextStream 
						<< "\t\t\t\t<td>" 
						<< ThousandSeparator(QString().setNum(map_r2[i])).putSeparator()
						<< " (" 
						<< QString().setNum((double)map_r2[i]/(double)r2_num*(double)100, 'f', 1) 
						<< "%)</td>"  << endl;
				}
				else{
					TableTextStream << "\t\t\t\t<td>" << map_r2[i] << "</td>"  << endl;
				}
				r2_data << (double)map_r2[i];
			}
			else{
				TableTextStream << "\t\t\t\t<td>" << 0 << "</td>" << endl;
				r2_data << (double)0;
			}
			TableTextStream << "\t\t\t</tr>" << endl;
		}
		TableTextStreamBuffer.close();

		QByteArray TableFooterData;
		QBuffer TableFooterStreamBuffer(&TableFooterData);
		TableFooterStreamBuffer.open(QIODevice::WriteOnly);
		QTextStream TableFooterStream(&TableFooterStreamBuffer);
		TableFooterStream
			<< "\t\t\t<tr>" << endl
			<< "\t\t\t\t<td>Total</td>" << endl
			<< "\t\t\t\t<td>" << ThousandSeparator(QString().setNum(s_num)).putSeparator() << "(100%)</td>" << endl
			<< "\t\t\t\t<td>" << ThousandSeparator(QString().setNum(r1_num)).putSeparator() << "(100%)</td>" << endl
			<< "\t\t\t\t<td>" << ThousandSeparator(QString().setNum(r2_num)).putSeparator() << "(100%)</td>" << endl
			<< "\t\t\t</tr>" << endl;
		TableFooterStreamBuffer.close();

		//�o��
		outFile.write(
			htmlTemplate
			.arg(sampleName)
			.arg(ImageFilePath)
			.arg(QString(TableTextData))
			.arg(QString(TableFooterData))
			.toLatin1()
			);

		//�v���b�g�쐬
		QCustomPlot* customPlot=new QCustomPlot;

		customPlot->addGraph();
		customPlot->graph(0)->setLineStyle(QCPGraph::lsLine);
		customPlot->graph(0)->setScatterStyle(QCPScatterStyle::ssCircle);
		customPlot->graph(0)->setPen(QColor(247, 171, 108, 255));
		customPlot->graph(0)->setData(x_data, s_data);
		customPlot->graph(0)->setName(QString("Single-End Reads"));

		customPlot->addGraph();
		customPlot->graph(1)->setLineStyle(QCPGraph::lsLine);
		customPlot->graph(1)->setScatterStyle(QCPScatterStyle::ssSquare);
		customPlot->graph(1)->setPen(QColor(164, 194, 104, 255));
		customPlot->graph(1)->setData(x_data, r1_data);
		customPlot->graph(1)->setName(QString("Paired-End Read1"));

		customPlot->addGraph();
		customPlot->graph(2)->setLineStyle(QCPGraph::lsLine);
		customPlot->graph(2)->setScatterStyle(QCPScatterStyle::ssDiamond);
		customPlot->graph(2)->setPen(QColor(205, 116, 114, 255));
		customPlot->graph(2)->setData(x_data, r2_data);
		customPlot->graph(2)->setName(QString("Paired-End Read2"));

		// x���̏���
		customPlot->xAxis->setAutoTicks(false);
		customPlot->xAxis->setAutoTickLabels(false);
		customPlot->xAxis->setTickVector(x_data);
		customPlot->xAxis->setTickVectorLabels(x_label_data);
		customPlot->xAxis->setTickLabelRotation(0);
		customPlot->xAxis->setSubTickCount(0);
		customPlot->xAxis->setTickLength(0, 4);
		customPlot->xAxis->grid()->setVisible(true);
		customPlot->xAxis->setRange(0, (x_data.size()+1));
		customPlot->xAxis->setLabel(QString("Number of hit in the genome"));

		// y���̏���
		customPlot->yAxis->setPadding(5); // a bit more space to the left border
		customPlot->yAxis->setLabel("Number of reads");
		customPlot->yAxis->grid()->setSubGridVisible(true);
		customPlot->yAxis->setLabel(QString("Number of reads"));
		customPlot->yAxis->rescale();

		// �O���b�h
		QPen gridPen;
		gridPen.setStyle(Qt::SolidLine);
		gridPen.setColor(QColor(0, 0, 0, 25));
		customPlot->yAxis->grid()->setPen(gridPen);
		gridPen.setStyle(Qt::DotLine);
		customPlot->yAxis->grid()->setSubGridPen(gridPen);

		//���W�F���h�ǉ�
		customPlot->legend->setVisible(true);
		//�������낦�Č����ڗǂ�����
		customPlot->axisRect()->setupFullAxesBox();

		//�`�� �o�[�̉𑜓x�����Ƃ�����
		const int idealPixPerCoord=20;	// 20px x F, R D
		const int imageHeight=400;
		int imageWidth=x_data.size()+2;
		customPlot->setViewport(QRect(0, 0, imageWidth, imageHeight));
		customPlot->replot();
		while(true){

			qreal pixcelPerCoord=customPlot->xAxis->coordToPixel(2)-customPlot->xAxis->coordToPixel(1);
			if(pixcelPerCoord>=(qreal)idealPixPerCoord){
				break;
			}
			imageWidth++;
			customPlot->setViewport(QRect(0, 0, imageWidth, imageHeight));
			customPlot->replot();

		}

		customPlot->savePng(ImageFilePath, imageWidth, imageHeight, 1);

	}

	//�����łȂ���Ώ]���̃e�L�X�g�ɂ��A�E�g�v�b�g
	else{

		//�o�̓t�@�C���̃I�[�v��
		QFile outFile(outFilePath);
		outFile.open(QIODevice::WriteOnly);
		if(!outFile.isOpen()){
			cout << "Couldn't open file \"" << outFilePath.toStdString() << "\"" << endl;
			return;
		}
		QTextStream out;
		out.setDevice(&outFile);

		//numReads
		out	<< "SE read:\t" << endl;
		QList<qint64> keys=map.keys();
		qSort(keys.begin(), keys.end());
		qint64 maxValue=0;
		for(int i=0; i<keys.size(); i++){
			out << keys[i] << "\t" << map[keys[i]] << endl;
			if(maxValue<keys[i]){
				maxValue=keys[i];
			}
		}
		out	<< endl << "PE read 1:\t" << endl;
		keys=map_r1.keys();
		qSort(keys.begin(), keys.end());
		for(int i=0; i<keys.size(); i++){
			out << keys[i] << "\t" << map_r1[keys[i]] << endl;
			if(maxValue<keys[i]){
				maxValue=keys[i];
			}
		}
		out	<< endl << "PE read 2:\t" << endl;
		keys=map_r2.keys();
		qSort(keys.begin(), keys.end());
		for(int i=0; i<keys.size(); i++){
			out << keys[i] << "\t" << map_r2[keys[i]] << endl;
			if(maxValue<keys[i]){
				maxValue=keys[i];
			}
		}
		out.flush();

	}

}
