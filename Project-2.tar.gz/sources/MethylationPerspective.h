#include <QtCore>
#if QT_VERSION >= 0x050000
#include <QtWidgets>
#else
#include <QtGui>
#endif
#include <vector>
#include <iostream>
using namespace std;

#ifndef METHYLATION_PERSPECTIVE_H
#define METHYLATION_PERSPECTIVE_H

#include "GraphFile.h"

namespace DesktopTrack{

	class MethylationPerspective{
	public:
		MethylationPerspective(void);
		MethylationPerspective(const MethylationPerspective& original);
		~MethylationPerspective(void);
		MethylationPerspective& operator=(const MethylationPerspective& original);

		void							setSeq(const QByteArray& seq_, const QByteArray& name_);
		int								getSeqLen(void);
		void							putC(const int& pos, const int& strand, bool methylated);
		void							putD(const int& pos, const int& strand);
		const std::vector<quint32>&		getListF(void);
		const std::vector<quint32>&		getListR(void);
		bool							setListF(	const std::vector<quint16>& source1, 
													const std::vector<quint16>& source2);
		bool							setListR(	const std::vector<quint16>& source1, 
													const std::vector<quint16>& source2);
		bool							setListF(	const std::vector<quint32>& source1, 
													const std::vector<quint32>& source2);
		bool							setListR(	const std::vector<quint32>& source1, 
													const std::vector<quint32>& source2);
	private:
		QByteArray						seqName;
		int								seqLen;
		
		std::vector<quint32>			valueListF;		//16bitx2�ɕ������Ċi�[
		std::vector<quint32>			valueListR;		//16bitx2�ɕ������Ċi�[
		
		static const int				mutexUnitSize=1000;
		//QMutex							mutex;
		QMutex*							mutexArray;
		int								arraySize;
	};

};

#endif

