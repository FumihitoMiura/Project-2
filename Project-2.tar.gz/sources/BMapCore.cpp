#include "BMapCore.h"

using namespace DesktopTrack::BMapCore;

/*---------------------------------
    class BMapPrep
---------------------------------*/

BMapPrep::BMapPrep(QObject* parent):QThread(parent), BWTBasic(){}

bool BMapPrep::setBinSeq(const QString& path_to_binseq)
{
    if(isRunning()){
        return false;
    }
    pathToBinseq=path_to_binseq;
    return true;
}

bool BMapPrep::setTargetFilePath(const QString& path_to_target_file)
{
    if(isRunning()){
        return false;
    }
    targetFilePath=path_to_target_file;
    return true;
}

void BMapPrep::run(void){

    /*------------------------------------------------------
    binseq����z��擾�A4-bit�G���R�[�f�B���O���Ċi�[
    ------------------------------------------------------*/
    //BinSeq���J��
    BinSeq::FileReader reader;
    if(!reader.setFile(pathToBinseq)){
        return;
    }

    //�w�b�_�[�������߂�
    BinSeq::Header binseqHeader = reader.getTrackConfig();

    //�o�͐�t�@�C�����J��
    QFile file;
    file.setFileName(targetFilePath);
    if(!file.open(QIODevice::WriteOnly)){
        return;
    }
    QDataStream out(&file);

    //�w�b�_�[�̏����Ɖ��o��
    Header header;
    header.species=binseqHeader.species;
    header.revision=binseqHeader.revision;
    header.putSerialized(out);

    //�z�񒷂̍��v�����߂�
    QList<BinSeq::Target> originalTargetList=reader.getTargetList();
    quint64 i, j;
    int k;
    quint64 totalLength=0;
    for(i=0; i<originalTargetList.size(); i++){
        totalLength+=originalTargetList[i].targetLength+1;
    }
    //�z��̊i�[�̈���m��
    quint64 buffSize;
    if(totalLength%2==0){
        buffSize=totalLength/2;
    }
    else{
        buffSize=totalLength/2+1;
    }
    quint8 *s, *bwt;
    try{
        s=new quint8[buffSize];
        bwt=new quint8[buffSize];
        for(i=0; i<buffSize; i++){
            s[i]=0;
            bwt[i]=0;
        }
    }
    catch(...){
        return;
    }

    QList<Target> targetList;
    i=0;
    for(j=0; j<originalTargetList.size(); j++){
        //�L�^
        Target target(originalTargetList[j].targetName, i, originalTargetList[j].targetLength);
        targetList.push_back(target);

        //�z��ǂݍ���
        QByteArray seq;
        reader.getSeq(originalTargetList[j].targetName, seq);
        if(seq.size()!=originalTargetList[j].targetLength){
            return;
        }

        //�i�[�J�n
        for(k=0; k<seq.size(); k++){
            if(i%2==0){
                switch(seq[k]){
                    case 'A':case 'a':s[i/2]=0x10;break;	//A
                    case 'C':case 'c':s[i/2]=0x20;break;	//C
                    case 'G':case 'g':s[i/2]=0x30;break;	//G
                    case 'T':case 't':s[i/2]=0x40;break;	//T
                    default:s[i/2]=0x50;break;				//N
                }
            }
            else{
                switch(seq[k]){
                    case 'A':case 'a':s[i/2]=s[i/2]|0x01;break;		//A
                    case 'C':case 'c':s[i/2]=s[i/2]|0x02;break;		//C
                    case 'G':case 'g':s[i/2]=s[i/2]|0x03;break;		//G
                    case 'T':case 't':s[i/2]=s[i/2]|0x04;break;		//T
                    default:s[i/2]=s[i/2]|0x05;						//N
                }
            }
            i++;
        }
        if(i%2==0){
            s[i/2]=0x00;	//sentinel $
        }
        else{
            s[i/2]=s[i/2]|0x00;	//sentinel $
        }
        i++;

    }

    //sizeofInt�v�Z
    if(totalLength>0x00000000FFFFFFFF){
        setSizeofInt(5);
        header.sizeofInt=5;
		Target::setSizeofInt(5);
    }
    else{
        setSizeofInt(4);
        header.sizeofInt=4;
		Target::setSizeofInt(4);
    }

    //�o�͗p�o�b�t�@����
    QByteArray data;
    QBuffer buffer(&data);
    buffer.open(QIODevice::WriteOnly);
    out.setDevice(&buffer);

    //��񐮗�
    header.seqLength=totalLength;
    header.seqOffset=file.pos();
    header.seqDataSize=buffSize;

    //�z��f�[�^�o��
    for(i=0; i<buffSize; i++){
        out << s[i];
        if(data.size()%BufferSizeMax==0){
            buffer.close();
            file.write(data);
            data.clear();
            buffer.setBuffer(&data);
            buffer.open(QIODevice::WriteOnly);
            out.setDevice(&buffer);
        }
    }
    buffer.close();
    file.write(data);
    data.clear();


    //Target�o��
    buffer.setBuffer(&data);
    buffer.open(QIODevice::WriteOnly);
    out.setDevice(&buffer);
    header.targetListOffset=file.pos();
    for(i=0; i<targetList.size(); i++){
        targetList[i].putSerialized(out);
    }
    buffer.close();
    file.write(data);
    data.clear();
    header.targetListDataSize=file.pos()-header.targetListOffset;
    header.targetListDataCount=targetList.size();

    //suffix array�p�������p��
    quint8* SA;
    try{
        SA=new quint8[totalLength*sizeofInt];
    }
    catch(...){
        return;
    }

    //C2T�ϊ��z����i�[
    i=0;
    for(j=0; j<originalTargetList.size(); j++){

        //�z��ǂݍ���
        QByteArray seq;
        reader.getSeq(originalTargetList[j].targetName, seq);
        if(seq.size()!=originalTargetList[j].targetLength){
            return;
        }

        //�i�[�J�n
        for(k=0; k<seq.size(); k++){
            if(i%2==0){
                switch(seq[k]){
                    case 'A':case 'a':s[i/2]=0x10;break;	//A
                    case 'C':case 'c':s[i/2]=0x40;break;	//C
                    case 'G':case 'g':s[i/2]=0x30;break;	//G
                    case 'T':case 't':s[i/2]=0x40;break;	//T
                    default:s[i/2]=0x50;break;				//N
                }
            }
            else{
                switch(seq[k]){
                    case 'A':case 'a':s[i/2]=s[i/2]|0x01;break;		//A
                    case 'C':case 'c':s[i/2]=s[i/2]|0x04;break;		//C
                    case 'G':case 'g':s[i/2]=s[i/2]|0x03;break;		//G
                    case 'T':case 't':s[i/2]=s[i/2]|0x04;break;		//T
                    default:s[i/2]=s[i/2]|0x05;						//N
                }
            }
            i++;
        }
        if(i%2==0){
            s[i/2]=0x00;	//sentinel $
        }
        else{
            s[i/2]=s[i/2]|0x00;	//sentinel $
        }
        i++;

    }

    //suffix array�\�z
    SAISC(s, SA, totalLength, 6);

    //C2T�z��f�[�^�o��
    header.c2tSeqOffset=file.pos();
    buffer.setBuffer(&data);
    buffer.open(QIODevice::WriteOnly);
    out.setDevice(&buffer);
    for(i=0; i<buffSize; i++){
        out << s[i];
        if(data.size()%BufferSizeMax==0){
            buffer.close();
            file.write(data);
            data.clear();
            buffer.setBuffer(&data);
            buffer.open(QIODevice::WriteOnly);
            out.setDevice(&buffer);
        }
    }
    buffer.close();
    file.write(data);
    data.clear();
    header.c2tSeqDataSize=file.pos()-header.c2tSeqOffset;

    //C2T�z��pSuffixArray�o��
    header.c2tSAOffset=file.pos();
    buffer.setBuffer(&data);
    buffer.open(QIODevice::WriteOnly);
    out.setDevice(&buffer);
    for(i=0; i<totalLength*sizeofInt; i++){
        out << SA[i];
        if(data.size()%BufferSizeMax==0){
            buffer.close();
            file.write(data);
            data.clear();
            buffer.setBuffer(&data);
            buffer.open(QIODevice::WriteOnly);
            out.setDevice(&buffer);
        }
    }
    buffer.close();
    file.write(data);
    data.clear();
    header.c2tSADataSize=file.pos()-header.c2tSAOffset;

    //C2T�z��pBWT�v�Z
    SA2BWT(s, SA, totalLength, bwt);
    //C2T�z��pBWT�o��
    header.c2tBWTOffset=file.pos();
    buffer.setBuffer(&data);
    buffer.open(QIODevice::WriteOnly);
    out.setDevice(&buffer);
    for(i=0; i<buffSize; i++){
        out << bwt[i];
        if(data.size()%BufferSizeMax==0){
            buffer.close();
            file.write(data);
            data.clear();
            buffer.setBuffer(&data);
            buffer.open(QIODevice::WriteOnly);
            out.setDevice(&buffer);
        }
    }
    buffer.close();
    file.write(data);
    data.clear();
    header.c2tBWTDataSize=file.pos()-header.c2tBWTOffset;

    //C2T�z��pBoosterIndex�v�Z
    quint64 bIdxSize=calcBoosterIndexSize(header.bIdxWordSize);
    quint8* bIdx;
    try{
        bIdx=new quint8[bIdxSize];
    }
    catch(...){
        return;
    }
    if(!createBoosterIndex(s, SA, totalLength, header.bIdxWordSize, bIdx, bIdxSize)){
        return;
    }
    header.c2tBIdxOffset=file.pos();
    buffer.setBuffer(&data);
    buffer.open(QIODevice::WriteOnly);
    out.setDevice(&buffer);
    for(i=0; i<bIdxSize; i++){
        out << bIdx[i];
        if(data.size()%BufferSizeMax==0){
            buffer.close();
            file.write(data);
            data.clear();
            buffer.setBuffer(&data);
            buffer.open(QIODevice::WriteOnly);
            out.setDevice(&buffer);
        }
    }
    buffer.close();
    file.write(data);
    data.clear();
    header.c2tBIdxDataSize=file.pos()-header.c2tBIdxOffset;

    //G2A�ϊ��z����i�[
    i=0;
    for(j=0; j<originalTargetList.size(); j++){

        //�z��ǂݍ���
        QByteArray seq;
        reader.getSeq(originalTargetList[j].targetName, seq);
        if(seq.size()!=originalTargetList[j].targetLength){
            return;
        }

        //�i�[�J�n
        for(k=0; k<seq.size(); k++){
            if(i%2==0){
                switch(seq[k]){
                    case 'A':case 'a':s[i/2]=0x10;break;	//A
                    case 'C':case 'c':s[i/2]=0x20;break;	//C
                    case 'G':case 'g':s[i/2]=0x10;break;	//G
                    case 'T':case 't':s[i/2]=0x40;break;	//T
                    default:s[i/2]=0x50;break;				//N
                }
            }
            else{
                switch(seq[k]){
                    case 'A':case 'a':s[i/2]=s[i/2]|0x01;break;		//A
                    case 'C':case 'c':s[i/2]=s[i/2]|0x02;break;		//C
                    case 'G':case 'g':s[i/2]=s[i/2]|0x01;break;		//G
                    case 'T':case 't':s[i/2]=s[i/2]|0x04;break;		//T
                    default:s[i/2]=s[i/2]|0x05;						//N
                }
            }
            i++;
        }
        if(i%2==0){
            s[i/2]=0x00;	//sentinel $
        }
        else{
            s[i/2]=s[i/2]|0x00;	//sentinel $
        }
        i++;

    }

    //suffix array�\�z
    SAISC(s, SA, totalLength, 6);

    //G2A�z��f�[�^�o��
    header.g2aSeqOffset=file.pos();
    buffer.setBuffer(&data);
    buffer.open(QIODevice::WriteOnly);
    out.setDevice(&buffer);
    for(i=0; i<buffSize; i++){
        out << s[i];
        if(data.size()%BufferSizeMax==0){
            buffer.close();
            file.write(data);
            data.clear();
            buffer.setBuffer(&data);
            buffer.open(QIODevice::WriteOnly);
            out.setDevice(&buffer);
        }
    }
    buffer.close();
    file.write(data);
    data.clear();
    header.g2aSeqDataSize=file.pos()-header.g2aSeqOffset;

    //G2A�z��pSuffixArray�o��
    header.g2aSAOffset=file.pos();
    buffer.setBuffer(&data);
    buffer.open(QIODevice::WriteOnly);
    out.setDevice(&buffer);
    for(i=0; i<totalLength*sizeofInt; i++){
        out << SA[i];
        if(data.size()%BufferSizeMax==0){
            buffer.close();
            file.write(data);
            data.clear();
            buffer.setBuffer(&data);
            buffer.open(QIODevice::WriteOnly);
            out.setDevice(&buffer);
        }
    }
    buffer.close();
    file.write(data);
    data.clear();
    header.g2aSADataSize=file.pos()-header.g2aSAOffset;

    //G2A�z��pBWT�v�Z
    SA2BWT(s, SA, totalLength, bwt);
    //G2A�z��pBWT�o��
    header.g2aBWTOffset=file.pos();
    buffer.setBuffer(&data);
    buffer.open(QIODevice::WriteOnly);
    out.setDevice(&buffer);
    for(i=0; i<buffSize; i++){
        out << bwt[i];
        if(data.size()%BufferSizeMax==0){
            buffer.close();
            file.write(data);
            data.clear();
            buffer.setBuffer(&data);
            buffer.open(QIODevice::WriteOnly);
            out.setDevice(&buffer);
        }
    }
    buffer.close();
    file.write(data);
    data.clear();
    header.g2aBWTDataSize=file.pos()-header.g2aBWTOffset;

    //G2A�z��pBoosterIndex�v�Z
    if(!createBoosterIndex(s, SA, totalLength, header.bIdxWordSize, bIdx, bIdxSize)){
        return;
    }
    header.g2aBIdxOffset=file.pos();
    buffer.setBuffer(&data);
    buffer.open(QIODevice::WriteOnly);
    out.setDevice(&buffer);
    for(i=0; i<bIdxSize; i++){
        out << bIdx[i];
        if(data.size()%BufferSizeMax==0){
            buffer.close();
            file.write(data);
            data.clear();
            buffer.setBuffer(&data);
            buffer.open(QIODevice::WriteOnly);
            out.setDevice(&buffer);
        }
    }
    buffer.close();
    file.write(data);
    data.clear();
    header.g2aBIdxDataSize=file.pos()-header.g2aBIdxOffset;

    //�w�b�_�[�o��
    file.seek(0);
    out.setDevice(&file);
    header.putSerialized(out);

    delete[] s;
    delete[] bwt;
    delete[] SA;
    delete[] bIdx;

}


/*--------------------------------------------------
        class BMapCore
--------------------------------------------------*/

BMapCore::BMapCore(int num_of_thread, QObject* parent)
:	BWTBasic(),
    currentQueryFileIndex(0),
    refLen(0), refSeq(0), bIdxWordSize(0),
    c2tSeq(0), c2tSA(0), c2tBIdx(0), c2tBKT(0),  c2tBWT(0),
    g2aSeq(0), g2aSA(0), g2aBIdx(0), g2aBKT(0), g2aBWT(0),
	processed(0), QObject(parent)
{
	time.start();
    int i;
    for(i=0; i<6; i++){
        c2tMCB[i]=0;
        g2aMCB[i]=0;
    }
    for(i=0; i<num_of_thread; i++){
        BMapThread* thread=new BMapThread(/*SCF, SCL, */&queryDispatcher, this);
        QObject::connect(thread, SIGNAL(finished()), this, SLOT(onSearchFinished()));
        QObject::connect(thread, SIGNAL(searchFinished(const QByteArray, const QByteArray)),
                         this, SLOT(exportSearchResult(const QByteArray, const QByteArray)));
        bmapThreads.append(thread);
    }
}

BMapCore::~BMapCore(void)
{
	if(refSeq!=0){delete[] refSeq; refSeq=0;}
	if(c2tSeq!=0){delete[] c2tSeq; c2tSeq=0;}
	if(c2tBKT!=0){delete[] c2tBKT; c2tBKT=0;}
	if(c2tBWT!=0){delete[] c2tBWT; c2tBWT=0;}
	if(c2tMCB[0]!=0){delete[] c2tMCB[0]; c2tMCB[0]=0;}
	if(c2tSA!=0){delete[] c2tSA; c2tSA=0;}
	if(c2tBIdx!=0){delete[] c2tBIdx; c2tBIdx=0;}
	if(g2aSeq!=0){delete[] g2aSeq; g2aSeq=0;}
	if(g2aBKT!=0){delete[] g2aBKT; g2aBKT=0;}
	if(g2aBWT!=0){delete[] g2aBWT; g2aBWT=0;}
	if(g2aMCB[0]!=0){delete[] g2aMCB[0]; g2aMCB[0]=0;}
	if(g2aSA!=0){delete[] g2aSA; g2aSA=0;}
	if(g2aBIdx!=0){delete[] g2aBIdx; g2aBIdx=0;}
	std::cout << "Time elapsed:" << time.elapsed() << "." << endl;
}

void BMapCore::onSearchFinished(void)
{
    bool allQueryFinished=true;
    bool allThreadFinished=true;

    //�S�Ă�query���I�����Ă��邩�ǂ������`�F�b�N
    if(queryDispatcher.hasNextQuery()){
        //�S�Ă�thread���ċN��
        for(int i=0; i<bmapThreads.size(); i++){
            if(!bmapThreads[i]->isRunning()){
                bmapThreads[i]->start();
            }
        }
        allQueryFinished=false;
    }
    //query���Ȃ��Ȃ��Ă��āA����query�t�@�C�������݂�����
    else if(++currentQueryFileIndex<pathsToQueryFiles.size()){
        //�V����query���Z�b�g����
        if(setQueryFile(pathsToQueryFiles[currentQueryFileIndex], queryFileFormats[currentQueryFileIndex])){
            //�S�Ă�thread���ċN��
            for(int i=0; i<bmapThreads.size(); i++){
                if(!bmapThreads[i]->isRunning()){
                    bmapThreads[i]->start();
                }
            }
            allQueryFinished=false;
        }
    }
    //�S�Ă�query���������I���Ă�����
    else{
        //�S�Ă�thread���I�����Ă��邩�ǂ������`�F�b�N
        for(int i=0; i<bmapThreads.size(); i++){
            if(bmapThreads[i]->isRunning()){
                allThreadFinished=false;
                break;
            }
        }
    }
    if(allThreadFinished&&allQueryFinished){
        //���o�͂̃f�[�^��f���o���Ĕ�����
        flushOut();
		std::cout << "Time elapsed: " << time.elapsed() << " ms" << endl;
        emit finished();
    }
}

void BMapCore::
exportSearchResult(
    const QByteArray& sumData,
    const QByteArray& alnData)
{
    mutex.lock();
    QBuffer buffer(&bsSumBuff);
    buffer.open(QIODevice::WriteOnly|QIODevice::Append);
    buffer.write(sumData);
    buffer.close();
    if(alnData.size()>0){
        buffer.setBuffer(&bsAlnBuff);
        buffer.open(QIODevice::WriteOnly|QIODevice::Append);
        buffer.write(alnData);
        buffer.close();
    }
    if(bsSumBuff.size()>BufferSizeMax||bsAlnBuff.size()>BufferSizeMax){
        bsSumFile.write(bsSumBuff);
		bsSumFile.flush();
        bsSumBuff.clear();
        bsAlnFile.write(bsAlnBuff);
		bsAlnFile.flush();
        bsAlnBuff.clear();
		
    }
	processed++;
	if(processed%20000==0){
		std::cout << processed << " reads processed.(" <<  time.elapsed() << ")" << endl << flush;
	}
    mutex.unlock();
	
}

void BMapCore::flushOut(void)
{
    mutex.lock();
    bsSumFile.write(bsSumBuff);
    bsSumBuff.clear();
    bsAlnFile.write(bsAlnBuff);
    bsAlnBuff.clear();
    mutex.unlock();
}

bool BMapCore::setBMapFile(const QString& pathToBMapFile)
{
    //�t�@�C�����I�[�v��
    QFile file;
    file.setFileName(pathToBMapFile);
    if(!file.open(QIODevice::ReadOnly)){
        return false;
    }
    //�t�@�C���w�b�_�[����荞��
    QDataStream in(&file);
    header.getSerialized(in);
	setSizeofInt(header.sizeofInt);
	Target::setSizeofInt(header.sizeofInt);
    //target����S���擾
    targetList.clear();
    file.seek(header.targetListOffset);
    QByteArray data=file.read(header.targetListDataSize);
    QBuffer buffer(&data);
    buffer.open(QIODevice::ReadOnly);
    in.setDevice(&buffer);
    for(quint32 i=0; i<header.targetListDataCount; i++){
        Target target;
        target.getSerialized(in);
        targetList.push_back(target);
    }
    buffer.close();
    data.clear();
    //�Q�ƃQ�m���z��
    //�Q�ƃQ�m���z��
    //�Q�ƃQ�m���C���f�b�N�X
    //���������Ƀ��[�h����
    quint64 toBeRead;
    char* dataTo;

    //refLen
    refLen=header.seqLength;

    //bidxWordSize
    bIdxWordSize=header.bIdxWordSize;

    try{
		if(refSeq!=0){delete[] refSeq; refSeq=0;}
		if(c2tSeq!=0){delete[] c2tSeq; c2tSeq=0;}
		if(c2tSA!=0){delete[] c2tSA; c2tSA=0;}
		if(c2tBIdx!=0){delete[] c2tBIdx; c2tBIdx=0;}
		if(g2aSeq!=0){delete[] g2aSeq; g2aSeq=0;}
		if(g2aSA!=0){delete[] g2aSA; g2aSA=0;}
		if(g2aBIdx!=0){delete[] g2aBIdx; g2aBIdx=0;}
        refSeq=new quint8[header.seqDataSize];
		c2tSeq=new quint8[header.c2tSeqDataSize];
		c2tSA=new quint8[header.c2tSADataSize];
		c2tBIdx=new quint8[header.c2tBIdxDataSize];
		g2aSeq=new quint8[header.g2aSeqDataSize];
		g2aSA=new quint8[header.g2aSADataSize];
		g2aBIdx=new quint8[header.g2aBIdxDataSize];
    }
    catch(...){
		std::cerr << "Couldn't allocate memory" << endl;
        return false;
    }

    std::cout << " -reference sequence...";

    //refSeq
    file.seek(header.seqOffset);
    toBeRead=header.seqDataSize;
    dataTo=(char*)refSeq;
    while(toBeRead>readAmountMax){
        file.read(dataTo, readAmountMax);
        toBeRead-=readAmountMax;
        dataTo+=readAmountMax;
    }
    file.read(dataTo, toBeRead);

    std::cout << " finished (elapsed: " << time.elapsed() << " ms)" << endl;
    std::cout << " -c2t converted reference...";

    //c2tSeq
    file.seek(header.c2tSeqOffset);
    toBeRead=header.c2tSeqDataSize;
    dataTo=(char*)c2tSeq;
    while(toBeRead>readAmountMax){
        file.read(dataTo, readAmountMax);
        toBeRead-=readAmountMax;
        dataTo+=readAmountMax;
    }
    file.read(dataTo, toBeRead);

    std::cout << " finished (elapsed: " << time.elapsed() << " ms)" << endl;
    std::cout << " -c2t suffix array...";

    //c2tSA
    file.seek(header.c2tSAOffset);
    toBeRead=header.c2tSADataSize;
    dataTo=(char*)c2tSA;
    while(toBeRead>readAmountMax){
        file.read(dataTo, readAmountMax);
        toBeRead-=readAmountMax;
        dataTo+=readAmountMax;
    }
    file.read(dataTo, toBeRead);

    std::cout << " finished (elapsed: " << time.elapsed() << " ms)" << endl;
    std::cout << " -c2t fixed length index...";
    //c2tBIdx
    file.seek(header.c2tBIdxOffset);
    file.read((char*)c2tBIdx, header.c2tBIdxDataSize);

    std::cout << " finished (elapsed: " << time.elapsed() << " ms)" << endl;
    std::cout << " -g2a converted reference...";

    //g2aSeq
    file.seek(header.g2aSeqOffset);
    toBeRead=header.g2aSeqDataSize;
    dataTo=(char*)g2aSeq;
    while(toBeRead>readAmountMax){
        file.read(dataTo, readAmountMax);
        toBeRead-=readAmountMax;
        dataTo+=readAmountMax;
    }
    file.read(dataTo, toBeRead);

    std::cout << " finished (elapsed: " << time.elapsed() << " ms)" << endl;
    std::cout << " -g2a suffix array...";

    //g2aSA
    file.seek(header.g2aSAOffset);
    toBeRead=header.g2aSADataSize;
    dataTo=(char*)g2aSA;
    while(toBeRead>readAmountMax){
        file.read(dataTo, readAmountMax);
        toBeRead-=readAmountMax;
        dataTo+=readAmountMax;
    }
    file.read(dataTo, toBeRead);

    std::cout << " finished (elapsed: " << time.elapsed() << " ms)" << endl;
    std::cout << " -g2a fixed length index...";

    //g2aBIdx
    file.seek(header.g2aBIdxOffset);
    file.read((char*)g2aBIdx, header.g2aBIdxDataSize);

    std::cout << " finished (elapsed: " << time.elapsed() << " ms)" << endl;

    for(int i=0; i<bmapThreads.size(); i++){
        bmapThreads[i]->setIndex(targetList, refLen, refSeq, bIdxWordSize,
                                 c2tSeq, c2tSA, c2tBIdx,
                                 g2aSeq, g2aSA, g2aBIdx);
    }

    std::cout << "Index loading finished." << endl;

    file.close();
    useSuffixArray=true;
    return true;

}

bool BMapCore::
setBMapFileAsBWT(const QString& pathToBMapFile,
                 const quint64& scf,
                 const quint64& scl)
{
    //scf, scl���Z�b�g����
	SCF=scf;
	SCL=scl;

    //�t�@�C�����I�[�v��
    QFile file;
    file.setFileName(pathToBMapFile);
    if(!file.open(QIODevice::ReadOnly)){
        return false;
    }
    //�t�@�C���w�b�_�[����荞��
    QDataStream in(&file);
    header.getSerialized(in);
    setSizeofInt(header.sizeofInt);
	Target::setSizeofInt(header.sizeofInt);
    //target����S���擾
    targetList.clear();
    file.seek(header.targetListOffset);
    QByteArray data=file.read(header.targetListDataSize);
    QBuffer buffer(&data);
    buffer.open(QIODevice::ReadOnly);
    in.setDevice(&buffer);
    quint64 i, temp, sum;
    char *dataTo, *dataFrom;
    for(i=0; i<header.targetListDataCount; i++){
        Target target;
        target.getSerialized(in);
        targetList.push_back(target);
		qDebug() << target.targetName << " " << target.targetOffset << " " << target.targetLength;
    }
    buffer.close();
    data.clear();


    //refLen
    refLen=header.seqLength;

	//data size
	quint64 MCBSize=refLen%SCL==0?(refLen/SCL)*sizeofInt:(refLen/SCL+1)*sizeofInt;
	quint64 SASize=refLen%SCF==0?(refLen/SCF)*sizeofInt:(refLen/SCF+1)*sizeofInt;

	//�������̊m��
	try{
		if(refSeq!=0){delete[] refSeq;}
		if(c2tBKT!=0){delete[] c2tBKT;}
		if(c2tBWT!=0){delete[] c2tBWT;}
		if(c2tMCB[0]!=0){delete[] c2tMCB[0];}
		if(c2tSA!=0){delete[] c2tSA;}
		if(c2tBIdx!=0){delete[] c2tBIdx;}
		if(g2aBKT!=0){delete[] c2tBKT;}
		if(g2aBWT!=0){delete[] g2aBWT;}
		if(g2aMCB[0]!=0){delete[] g2aMCB[0];}
		if(g2aSA!=0){delete[] g2aSA;}
		if(g2aBIdx!=0){delete[] g2aBIdx;}

		refSeq=new quint8[header.seqDataSize];
		c2tBKT=new quint64[7];
		c2tBWT=new quint8[header.c2tBWTDataSize];
		c2tMCB[0]=new quint8[MCBSize*6];
		c2tMCB[1]=c2tMCB[0]+MCBSize*1;
		c2tMCB[2]=c2tMCB[0]+MCBSize*2;
		c2tMCB[3]=c2tMCB[0]+MCBSize*3;
		c2tMCB[4]=c2tMCB[0]+MCBSize*4;
		c2tMCB[5]=c2tMCB[0]+MCBSize*5;
        for(i=1; i<6; i++){
            c2tMCB[i]=c2tMCB[0]+MCBSize*i;
        }
		c2tSA=new quint8[SASize];
		c2tBIdx=new quint8[header.c2tBIdxDataSize];
		g2aBKT=new quint64[7];
		g2aBWT=new quint8[header.g2aBWTDataSize];
		g2aMCB[0]=new quint8[MCBSize*6];
		g2aMCB[1]=g2aMCB[0]+MCBSize*1;
		g2aMCB[2]=g2aMCB[0]+MCBSize*2;
		g2aMCB[3]=g2aMCB[0]+MCBSize*3;
		g2aMCB[4]=g2aMCB[0]+MCBSize*4;
		g2aMCB[5]=g2aMCB[0]+MCBSize*5;
        for(i=1; i<6; i++){
            g2aMCB[i]=g2aMCB[0]+MCBSize*i;
        }
		g2aSA=new quint8[SASize];
		g2aBIdx=new quint8[header.g2aBIdxDataSize];
	} 
    catch(...){
		std::cerr << "Couldn't allocate memory" << endl;
        return false;
    }

	QTime time;
	time.start();

	std::cout << " -FM-index for c2t genome....";

    //c2tBWT
    file.seek(header.c2tBWTOffset);
    dataTo=(char*)c2tBWT;
    file.read(dataTo, header.c2tBWTDataSize);

	//c2t counter table
    c2tBKT[0]=0;
    c2tBKT[1]=0;
    c2tBKT[2]=0;
    c2tBKT[3]=0;
    c2tBKT[4]=0;
    c2tBKT[5]=0;
    c2tBKT[6]=0;
    for(i=0; i<refLen; i++){
        if(i%SCL==0){
            quint64 pos=i/SCL;
            setInt(c2tMCB[0], pos, c2tBKT[0]);
            setInt(c2tMCB[1], pos, c2tBKT[1]);
            setInt(c2tMCB[2], pos, c2tBKT[2]);
            setInt(c2tMCB[3], pos, c2tBKT[3]);
            setInt(c2tMCB[4], pos, c2tBKT[4]);
            setInt(c2tMCB[5], pos, c2tBKT[5]);
        }
        switch(quint8 c=getChar(c2tBWT, i)){
            case 0: c2tBKT[0]++; break;
            case 1: c2tBKT[1]++; break;
            case 2: c2tBKT[2]++; break;
            case 3: c2tBKT[3]++; break;
            case 4: c2tBKT[4]++; break;
            default: c2tBKT[5]++; break;
        }
    }
    temp, sum=0;
    for(i=0; i<7; i++){
        temp=c2tBKT[i];
        c2tBKT[i]=sum;
        sum+=temp;
    }

	std::cout << " finished (elapsed: " << time.elapsed() << " ms)" << endl;
	std::cout << " -FM-Index for g2a genome....";

	//g2aBWT
    file.seek(header.g2aBWTOffset);
    dataTo=(char*)g2aBWT;
    file.read(dataTo, header.g2aBWTDataSize);

	//g2a counter table
    g2aBKT[0]=0;
    g2aBKT[1]=0;
    g2aBKT[2]=0;
    g2aBKT[3]=0;
    g2aBKT[4]=0;
    g2aBKT[5]=0;
    g2aBKT[6]=0;
    for(i=0; i<refLen; i++){
        if(i%SCL==0){
            quint64 pos=i/SCL;
            setInt(g2aMCB[0], pos, g2aBKT[0]);
            setInt(g2aMCB[1], pos, g2aBKT[1]);
            setInt(g2aMCB[2], pos, g2aBKT[2]);
            setInt(g2aMCB[3], pos, g2aBKT[3]);
            setInt(g2aMCB[4], pos, g2aBKT[4]);
            setInt(g2aMCB[5], pos, g2aBKT[5]);
        }
        switch(getChar(g2aBWT, i)){
            case 0: g2aBKT[0]++; break;
            case 1: g2aBKT[1]++; break;
            case 2: g2aBKT[2]++; break;
            case 3: g2aBKT[3]++; break;
            case 4: g2aBKT[4]++; break;
            default: g2aBKT[5]++; break;
        }
    }
    temp, sum=0;
    for(i=0; i<7; i++){
        temp=g2aBKT[i];
        g2aBKT[i]=sum;
        sum+=temp;
    }

	std::cout << " finished (elapsed: " << time.elapsed() << " ms)" << endl;
	std::cout << " -suffix array for c2t genome....";

    //shrinked suffix array
	quint64 toBeRead;
	stepSize=sizeofInt*SCF;
	unitNumberMax=header.seqDataSize/stepSize;
	bufferSizeMax=unitNumberMax*stepSize;

	//c2tSA
	file.seek(header.c2tSAOffset);
    toBeRead=header.c2tSADataSize;
	dataTo=(char*)c2tSA;
    while(toBeRead>bufferSizeMax){
		dataFrom=(char*)refSeq;
        file.read(dataFrom, bufferSizeMax);
        toBeRead-=bufferSizeMax;
        for(i=0; i<unitNumberMax; i++){
			memcpy(dataTo, dataFrom, sizeofInt);
			dataFrom+=stepSize;
			dataTo+=sizeofInt;
		}
    }
	dataFrom=(char*)refSeq;
    file.read(dataFrom, toBeRead);
    for(i=0; i<toBeRead/stepSize; i++){
		memcpy(dataTo, dataFrom, sizeofInt);
		dataFrom+=stepSize;
		dataTo+=sizeofInt;
	}
    bIdxWordSize=header.bIdxWordSize;
    //c2tBIdx
    file.seek(header.c2tBIdxOffset);
    file.read((char*)c2tBIdx, header.c2tBIdxDataSize);

	std::cout << " finished (elapsed: " << time.elapsed() << " ms)" << endl;
	std::cout << " -suffix array for g2a genome....";

    //shrinked suffix array
    //g2aSA
	file.seek(header.g2aSAOffset);
    toBeRead=header.g2aSADataSize;
	dataTo=(char*)g2aSA;
    while(toBeRead>bufferSizeMax){
		dataFrom=(char*)refSeq;
        file.read(dataFrom, bufferSizeMax);
        toBeRead-=bufferSizeMax;
        for(i=0; i<unitNumberMax; i++){
			memcpy(dataTo, dataFrom, sizeofInt);
			dataFrom+=stepSize;
			dataTo+=sizeofInt;
		}
    }
	dataFrom=(char*)refSeq;
    file.read(dataFrom, toBeRead);
    for(i=0; i<toBeRead/stepSize; i++){
		memcpy(dataTo, dataFrom, sizeofInt);
		dataFrom+=stepSize;
		dataTo+=sizeofInt;
	}

    //g2aBIdx
    file.seek(header.g2aBIdxOffset);
    file.read((char*)g2aBIdx, header.g2aBIdxDataSize);

	std::cout << " finished (elapsed: " << time.elapsed() << " ms)" << endl;
	std::cout << " -reference sequence....";

	//�Ō��reference��ǂݍ���
    file.seek(header.seqOffset);
    dataTo=(char*)refSeq;
    file.read(dataTo, header.seqDataSize);
    file.close();

	std::cout << " finished (elapsed: " << time.elapsed() << " ms)" << endl;

    for(int i=0; i<bmapThreads.size(); i++){
        bmapThreads[i]->setIndexWithBWT(
                    targetList,
                    refLen,
                    refSeq,
                    bIdxWordSize,
					SCF,
					SCL,
                    c2tBKT,
                    c2tBWT,
                    c2tMCB,
                    c2tSA,
                    c2tBIdx,
                    g2aBKT,
                    g2aBWT,
                    g2aMCB,
                    g2aSA,
                    g2aBIdx);
    }

	std::cout << "Index loading finished." << endl;

    useSuffixArray=false;
    return true;

}

void BMapCore::
setAlignmentParameters(	quint64 seedoffset,
                        quint64 seedlength,
                        quint64 seedstep,
                        quint64 seediterate,
                        quint64 minseedhit,
                        quint64 seedlengthmax,
                        quint64 maxhitcount,
                        qint64 minalnscore)
{
	this->seedOffset=seedoffset;
	this->seedLength=seedlength;
	this->seedStep=seedstep;
	this->seedIterate=seediterate;
	this->minSeedHit=minseedhit;
	this->seedLengthMax=seedlengthmax;
	this->seedFreqMax=maxhitcount;
	this->minAlnScore=minalnscore;


	for(int i=0; i<bmapThreads.size(); i++){
		bmapThreads[i]->setAlignmentParameters(
			seedoffset, 
			seedlength, 
			seedstep, 
			seediterate,
			minseedhit, 
			seedlengthmax, 
			maxhitcount, 
			minalnscore);
	}
}

bool BMapCore::setQueryFiles(
    const QStringList& pathstoqueryfiles,
    const QList<DesktopTrack::QueryDispatcher::FileFormat> formats)
{
    pathsToQueryFiles=pathstoqueryfiles;
    queryFileFormats=formats;
    currentQueryFileIndex=0;
    if(pathsToQueryFiles.size()!=queryFileFormats.size()){
        return false;
    }
    if(pathsToQueryFiles.size()==0){
        return false;
    }
    return setQueryFile(pathsToQueryFiles[currentQueryFileIndex], queryFileFormats[currentQueryFileIndex]);
}

bool BMapCore::setQueryFile(const QString& pathToQueryFile, const DesktopTrack::QueryDispatcher::FileFormat& format)
{
	QString filePath(pathToQueryFile);
	std::cout << "File(s) loaded: " << filePath.replace(QString("\t"), QString(", ")).toStdString() << "." << endl;
    return queryDispatcher.setQueryFile(pathToQueryFile, format);
}

bool BMapCore::
setIO(const QString& pathToBisulSumFile,
      const QString& pathToBisulAlignFile)
{

	//�܂�SumFile
    if(bsSumFile.isOpen()){
        bsSumFile.close();
    }
	QFileInfo sumFileInfo(pathToBisulSumFile);
	if(sumFileInfo.suffix()=="gz"){
		sumOutCompressed=true;
		bsSumFile.setFileName(pathToBisulSumFile);
		bsSumFile.open(QIODevice::WriteOnly);
		if(!bsSumFile.isOpen()){
			std::cerr << "Couldn't open file \"" << pathToBisulSumFile.toStdString() << "\"." << endl;
			return false;
		}
		//sumStream�̏�����

		//�������m��

		//deflateInit2

	}
	else{
		sumOutCompressed=false;
		bsSumFile.setFileName(pathToBisulSumFile);
		bsSumFile.open(QIODevice::WriteOnly);
		if(!bsSumFile.isOpen()){
			std::cerr << "Couldn't open file \"" << pathToBisulSumFile.toStdString() << "\"." << endl;
			return false;
		}
	}

	//����Bisulalign File
    if(bsAlnFile.isOpen()){
        bsAlnFile.close();
    }
	QFileInfo alnFileInfo(pathToBisulAlignFile);
	if(alnFileInfo.suffix()=="gz"){
		sumOutCompressed=true;
		bsAlnFile.setFileName(pathToBisulAlignFile);
		bsAlnFile.open(QIODevice::WriteOnly);
		if(!bsAlnFile.isOpen()){
			std::cerr << "Couldn't open file \"" << pathToBisulAlignFile.toStdString() << "\"." << endl;
			return false;
		}
		//sumStream�̏�����

		//�������m��

		//deflateInit2

	}
	else{
		sumOutCompressed=false;
		bsAlnFile.setFileName(pathToBisulAlignFile);
		bsAlnFile.open(QIODevice::WriteOnly);
		if(!bsAlnFile.isOpen()){
			std::cerr << "Couldn't open file \"" << pathToBisulAlignFile.toStdString() << "\"." << endl;
			return false;
		}
	}
    return true;
}

bool BMapCore::start(void)
{
    if(bmapThreads.size()>0){
        for(int i=0; i<bmapThreads.size(); i++){
            bmapThreads[i]->start();
        }
        return true;
    }
    else{
        return false;
    }
}

