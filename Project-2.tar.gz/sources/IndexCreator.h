#include <QtCore>
#include <QtGui>

#include <iostream>

using namespace std;

#include "SeqInfo.h"
#include "BinSeq.h"
#include "BMapCore.h"
#include "DesktopTrackCommon.h"

namespace DesktopTrack{

	class IndexCreator: public QObject{
		Q_OBJECT
	private:
		bool					initialized;
		QString					species;
		QString					revision;
		QString					pathToBinSeq;
		QString					pathToIndex;
		QStringList				refFiles;
		SeqInfoList				seqInfoList;
		FastaFileAnalyzer		analyzer;
		BinSeq::FileCreator		creator;
		BMapCore::BMapPrep		bmapprep;
	public:
		IndexCreator(QObject* parent=0);
		void setPathAndRefs(const QString& species,
							const QString& revision,
							const QString& pathToBinSeq,
							const QString& pathToIndex,
							const QStringList& refFiles);
		void start(void);
	public slots:
		void	onFinishAnalysis(void);
		void	onFihishBinseqCreate(void);
		void	onFinishIndexCreate(void);
	signals:
		void	processFinished(void);
	};


};