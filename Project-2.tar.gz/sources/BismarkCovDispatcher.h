#ifndef BISULALIGN_DISPACHER_H
#define BISULALIGN_DISPACHER_H

#include <QtCore>
#include <iostream>
#include <istream>
#include <fstream>
#include <new>
#include <vector>

using namespace std;

#include "DesktopTrackCommon.h"

#include "zlib/zlib.h"

namespace DesktopTrack{

	class BismarkCovDispatcher{
	private:
		QStringList							pathsToFiles;
		int									fileIndex;
		int									readNumber;
		QFile								file;
		bool								isComplessedFile;
		QMutex								mutex;

		QByteArray							internalBuffer;
		z_stream							strm;
		unsigned char						*in;
		unsigned char						*out;
	public:
		BismarkCovDispatcher(void);
		~BismarkCovDispatcher(void);
		bool setFilePaths(const QStringList& pathsToFiles);
		bool getData(QByteArray& dataTo);
		
	};
};

#endif
