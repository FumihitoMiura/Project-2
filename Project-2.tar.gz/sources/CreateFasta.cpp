#include "CreateFasta.h"

using namespace DesktopTrack;


CreateFasta::CreateFasta(QObject* parent):
    QThread(parent){}

bool CreateFasta::setFiles(
        const QString& destFasta,
        const SeqInfoList& seqInfoList)
{
    if(isRunning()){
        return false;
    }
    else{
        this->seqInfoList=seqInfoList;
        this->destFasta=destFasta;
        return true;
    }
}

void CreateFasta::setProcessStatus(
        const Process& process_status,
        const quint64& prosessed_data,
        const quint64& total_data)
{
    mutex.lock();
    processStatus = process_status;
    processedData = prosessed_data;
    totalData = total_data;
    mutex.unlock();
}

bool CreateFasta::getOrder(void)
{
    mutex.lock();
    bool order = promoteProcess;
    mutex.unlock();
    return order;
}

void CreateFasta::setOrder(
        bool proceed)
{
    mutex.lock();
    promoteProcess = proceed;
    mutex.unlock();
}

void CreateFasta::getProcessStatus(
        Process& process_status,
        quint64& prosessed_data,
        quint64& total_data)
{
    mutex.lock();
    process_status = processStatus;
    prosessed_data = processedData;
    total_data = totalData;
    mutex.unlock();
}

void CreateFasta::run(void){


    int numOfSeq=seqInfoList.size();
	int totalSize=0;
	int totalProcessedSize=0;
	for(int i=0; i<seqInfoList.size(); i++){
		totalSize+=seqInfoList[i].seqLength;
	}

    setProcessStatus(processing, totalProcessedSize, totalSize);

    //�o�̓t�@�C���̊m��
    QFile outFile(destFasta);
    if(!outFile.open(QIODevice::WriteOnly)){
        return;
    }

    for(int i=0; i<numOfSeq; i++){

        setProcessStatus(processing, totalProcessedSize, totalSize);

        //�z�񖼂̏o��
        QByteArray outData;
        QBuffer out(&outData);
        out.open(QIODevice::WriteOnly);
        QTextStream outstream(&out);
        if(seqInfoList[i].renameTo.size()>0){
            outstream	<< ">"
                        << seqInfoList[i].renameTo.toLatin1()
                        << endl;
        }
        else{
            outstream	<< ">"
                        << seqInfoList[i].seqId.toLatin1()
                        << endl;
        }
        out.close();

		qDebug() << seqInfoList[i].seqId << ", " << seqInfoList[i].fileOffset << ", " << seqInfoList[i].dataSize << ", " << seqInfoList[i].seqLength;

        //�z��̎�荞�݂Əo��
        QFile inFile(seqInfoList[i].seqFilePath);
        if(!inFile.open(QIODevice::ReadOnly)){
            setProcessStatus(failed, totalProcessedSize, totalSize);
            return;
        }
        inFile.seek(seqInfoList[i].fileOffset);

        QByteArray inData=inFile.read(seqInfoList[i].dataSize);
        inFile.close();
        if(inData.size()!=seqInfoList[i].dataSize){
            setProcessStatus(failed, totalProcessedSize, totalSize);
            return;
        }
        QBuffer in(&inData);
        in.open(QIODevice::ReadOnly);
        quint64 numOut=0;

        while(!in.atEnd()){
            QByteArray line=in.readLine().trimmed();
            for(int j=0; j<line.size(); j++){
                outData.append(line[j]);
                numOut++;
				totalProcessedSize++;
                if(numOut%60==0){
                    outData.append('\n');
                }
                if(outData.size()>BufferSizeMax){

                    if(!getOrder()){

                        setProcessStatus(stopped, totalProcessedSize, totalSize);
						inFile.close();
						outFile.close();
						outFile.remove();
                        return;

                    }
                    outFile.write(outData);
                    outData.clear();
                    setProcessStatus(processing, totalProcessedSize, totalSize);

                }
            }
        }
        if(numOut%60!=0){
            outData.append('\n');
        }
        if(outData.size()>0){
            outFile.write(outData);
            outData.clear();
        }

        //�t�@�C���T�C�Y���n���ꂽProperty�ƍ���Ȃ��ꍇ������
        if(numOut!=seqInfoList[i].seqLength){
            setProcessStatus(failed, totalProcessedSize, totalSize);
            return;
        }
        setProcessStatus(processing, totalProcessedSize, totalSize);

    }

    setProcessStatus(finished, totalProcessedSize, totalSize);

}

