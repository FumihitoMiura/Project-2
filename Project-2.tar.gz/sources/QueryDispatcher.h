#ifndef QUERY_DISPACHER_H
#define QUERY_DISPACHER_H

#include <QtCore>
#include <istream>
#include <new>
#include <vector>

#include "DesktopTrackCommon.h"

namespace DesktopTrack{

	class QueryDispatcher{
	public:		
		enum FileFormat{fasta, fastq, pfastq, qseq, unknown};
	private:
		QFile								queryFile;
		QBuffer								queryBuffer;
		QByteArray							bufferData;
		QFile								queryFile2;
		QBuffer								queryBuffer2;
		QByteArray							bufferData2;
		QMutex								mutex;
		quint64								queryProcessed;
		FileFormat							fileFormat;
		bool loadBuffer(void);
		bool loadBuffer2(void);
		QByteArray complement(QByteArray original);
	public:
		QueryDispatcher(void);
		bool setQueryFile(
				const QString& pathToQueryFile,
				const FileFormat& format=unknown);
		bool getQuery(
				QByteArray& nameTo,
				QByteArray& queryTo,
				QByteArray& query2To);
		bool hasNextQuery(void);
	};
};

#endif
