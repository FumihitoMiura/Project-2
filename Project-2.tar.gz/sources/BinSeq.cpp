#include "BinSeq.h"

using namespace DesktopTrack;
using namespace DesktopTrack::BinSeq;

/*-----------------------------------------------------------------------
        struct BinSeq::Header
-----------------------------------------------------------------------*/

Header::Header(void):
magic(2728),version(1),
targetListOffset(0),targetListDataSize(0),targetListDataCount(0),
ovFgColor(FgColor),ovBgColor(BgColor),
ovMarkColor(MkColor),ovRowHeight(RowHeight),
rlFgColor(FgColor),rlBgColor(BgColor),rlRowHeight(RowHeight),
bgColorForA(AColor),bgColorForC(CColor),
bgColorForG(GColor),bgColorForT(TColor),
bgColorForN(NColor),bgRowHeight(RowHeight){}

Header::Header(const Header& original):
magic(original.magic),version(original.version),
species(original.species), revision(original.revision),
targetListOffset(original.targetListOffset), 
targetListDataSize(original.targetListDataSize), 
targetListDataCount(original.targetListDataCount), 
ovFgColor(original.ovFgColor), ovBgColor(original.ovBgColor), 
ovMarkColor(original.ovMarkColor),ovRowHeight(original.ovRowHeight), 
rlFgColor(original.rlFgColor), rlBgColor(original.rlBgColor), rlRowHeight(original.rlRowHeight),
bgColorForA(original.bgColorForA), bgColorForC(original.bgColorForC),
bgColorForG(original.bgColorForG), bgColorForT(original.bgColorForT), 
bgColorForN(original.bgColorForN), bgRowHeight(original.bgRowHeight){}

Header& Header::operator =(const Header& original)
{
	magic = original.magic;
	version = original.version;
	species = original.species;
	revision = original.revision;
	targetListOffset = original.targetListOffset;
	targetListDataSize = original.targetListDataSize;
	targetListDataCount = original.targetListDataCount;
	ovFgColor = original.ovFgColor;
	ovBgColor = original.ovBgColor;
	ovMarkColor = original.ovMarkColor;
	ovRowHeight = original.ovRowHeight;
	rlFgColor = original.rlFgColor;
	rlBgColor = original.rlBgColor;
	rlRowHeight = original.rlRowHeight;
	bgColorForA = original.bgColorForA;
	bgColorForC = original.bgColorForC;
	bgColorForG = original.bgColorForG;
	bgColorForT = original.bgColorForT;
	bgColorForN = original.bgColorForN;
	bgRowHeight = original.bgRowHeight;
	return *this;
}

void Header::putSerialized(QDataStream& out)
{
	out	<< magic
		<< version
		<< species
		<< revision
		<< targetListOffset
		<< targetListDataSize
		<< targetListDataCount
		<< ovFgColor
		<< ovBgColor
		<< ovMarkColor
		<< ovRowHeight
		<< rlFgColor
		<< rlBgColor
		<< rlRowHeight
		<< bgColorForA
		<< bgColorForC
		<< bgColorForG
		<< bgColorForT
		<< bgColorForN
		<< bgRowHeight;
}

void Header::getSerialized(QDataStream& in)
{
	in	>> magic
		>> version
		>> species
		>> revision
		>> targetListOffset
		>> targetListDataSize
		>> targetListDataCount
		>> ovFgColor
		>> ovBgColor
		>> ovMarkColor
		>> ovRowHeight
		>> rlFgColor
		>> rlBgColor
		>> rlRowHeight
		>> bgColorForA
		>> bgColorForC
		>> bgColorForG
		>> bgColorForT
		>> bgColorForN
		>> bgRowHeight;

}

/*-----------------------------------------------------------------------
        struct BinSeq::Target
-----------------------------------------------------------------------*/

qint32 Target::version = 1;

Target::Target(void):
targetOffset(0),
targetLength(0){}

Target::Target(const QString& target_name,
			   const quint64& target_length):
targetName(target_name),
targetOffset(0),
targetLength(target_length){}

Target::Target(const Target& original):
targetName(original.targetName),
targetOffset(original.targetOffset),
targetLength(original.targetLength){}

Target& Target::operator =(const Target& original)
{
	targetName=original.targetName;
	targetOffset=original.targetOffset;
	targetLength=original.targetLength;
	return *this;
}

void Target::putSerialized(QDataStream& out)
{
	if (version == 1){
		quint32 target_offset = (quint32)targetOffset;
		quint32 target_length = (quint32)targetLength;
		out << targetName
			<< target_offset
			<< target_length;
	}
	else{
		out << targetName
			<< targetOffset
			<< targetLength;
	}

}

void Target::getSerialized(QDataStream& in)
{
	if (version == 1){
		quint32 target_offset, target_length;
		in	>> targetName
			>> target_offset
			>> target_length;
		targetOffset = (quint64)target_offset;
		targetLength = (quint64)target_length;
	}
	else{
		in	>> targetName
			>> targetOffset
			>> targetLength;
	}


}

void Target::setVersion(const qint32 target_version){

	if (target_version == 1){
		version = 1;
	}
	else{
		version = 2;
	}
}

TargetLess::TargetLess(void){}

bool TargetLess::operator()(const Target& a, const Target& b)
{
	return a.targetName < b.targetName;
}

TargetShort::TargetShort(void){}

bool TargetShort::operator()(const Target& a, const Target& b)
{
	if(a.targetLength==b.targetLength){
		return a.targetName < b.targetName;
	}
	else{
		return a.targetLength<b.targetLength;
	}
}

TargetLarge::TargetLarge(void){}

bool TargetLarge::operator()(const Target& a, const Target& b)
{
	if(a.targetLength==b.targetLength){
		return a.targetName < b.targetName;
	}
	else{
		return a.targetLength>b.targetLength;
	}
}

/*-----------------------------------------------------------------------
        struct BinSeq::FileCreator
-----------------------------------------------------------------------*/

FileCreator::FileCreator(QObject* parent):QThread(parent){}

void FileCreator::
initialize(	const QString& path_to_binaryseq_file,
		    const Header& conf,
			const SeqInfoList& seq_info_list)
{
	if(isRunning()){
		return;
	}
	pathToBinSeq = path_to_binaryseq_file;
	seqInfoList = seq_info_list;
	Header temp;
	header=temp;
	header.species=conf.species;
	header.revision=conf.revision;
	header.ovFgColor=conf.ovFgColor;
	header.ovBgColor=conf.ovBgColor;
	header.ovRowHeight=conf.ovRowHeight;
	header.rlFgColor=conf.rlFgColor;
	header.rlBgColor=conf.rlBgColor;
	header.rlRowHeight=conf.rlRowHeight;
	header.bgColorForA=conf.bgColorForA;
	header.bgColorForC=conf.bgColorForC;
	header.bgColorForG=conf.bgColorForG;
	header.bgColorForT=conf.bgColorForT;
	header.bgColorForN=conf.bgColorForN;
	header.bgRowHeight=conf.bgRowHeight;
}

void FileCreator::
setProcessStatus(	const Process& process_status,
					const quint64& prosessed_data,
					const quint64& total_data)
{
	mutex.lock();
	processStatus = process_status;
	processedData = prosessed_data;
	totalData = total_data;
	mutex.unlock();
}

bool FileCreator::getOrder(void){
	mutex.lock();
	bool order = promoteProcess;
	mutex.unlock();
	return order;
}

void FileCreator::setOrder(bool proceed){
	mutex.lock();
	promoteProcess = proceed;
	mutex.unlock();
}

void FileCreator::
getProcessStatus(Process& process_status,
				 quint64& prosessed_data,
				 quint64& total_data)
{
	mutex.lock();
	process_status = processStatus;
	prosessed_data = processedData;
	total_data = totalData;
	mutex.unlock();
}

void FileCreator::run(void)
{
	//���ߊm�F
	if(!getOrder()){
		setProcessStatus(stopped, 0, seqInfoList.size());
		return;
	}
	//�J�n�������Ƃ��L�^
	setProcessStatus(processing, 0, seqInfoList.size());

	//�S�Ẵt�@�C���̑��e�ʂ��v�Z
	quint64 totalFileSize = 0;
	for(SeqInfoList::iterator itr=seqInfoList.begin();
		itr!=seqInfoList.end(); itr++)
	{
		totalFileSize += itr->seqLength;	
	}

	//�o�͐�t�@�C���I�[�v��
	QFile outFile(pathToBinSeq);
	if(!outFile.open(QIODevice::WriteOnly)){
		setProcessStatus(failed, 0, seqInfoList.size());
		return;
	}
	QDataStream out(&outFile);
	//�t�@�C���̓�����w�b�_�[���V�[�N���邽�߁A����������
	header.putSerialized(out);

	//�t�@�C���̔z����i�[�̍ő�l���琮���̃������̑傫�������肷��
	if (totalFileSize+outFile.pos() >= 0x00000000FFFFFFFF){
		header.version = 2;
	}
	else{
		header.version = 1;
	}

	//���ߊm�F
	if(!getOrder()){
		setProcessStatus(stopped, 0, seqInfoList.size());
		return;
	}

	//�o�b�t�@�T�C�Y�̎w��
	//const int maxBufferSize = 8388608;

	QList<Target> target_list;
	quint64 processedSize=0;
	int		lineProcessed=0;
	int i;

	for(i=0; i<seqInfoList.size(); i++)
	{
		//�o�͗p�o�b�t�@�̃T�C�Y��\�񂵁A�f�[�^��荞�݈ʒu�܂ŃV�[�N
		SeqInfo& info=seqInfoList[i];
		QByteArray Seq;
		Seq.reserve(BufferSizeMax);

		//���̋L�^
		Target target;
		if(info.renameTo.size()>0){
			target.targetName = info.renameTo;
		}
		else{
			target.targetName = info.seqId;
		}
		target.targetOffset = outFile.pos();
		target.targetLength = info.seqLength;
		target_list.push_back(target);

		//���̓t�@�C���̃I�[�v��
        QFile inFile(info.seqFilePath);
        if(!inFile.open(QIODevice::ReadOnly)){
			setProcessStatus(failed, processedSize, totalFileSize);
			return;
		}
        if(!inFile.seek(info.fileOffset)){
			continue;
		}

		int charPushed=0;

		while(1){

            quint64 offset=inFile.pos();
            QByteArray data=inFile.read(BufferSizeMax);
            if(!inFile.atEnd()){
                int lastIndex=data.lastIndexOf('\n');
                if(lastIndex!=-1){
                    //'\n'�ȍ~�͏���
                    data.resize(lastIndex+1);
                    //����̃t�@�C���ǂݏo���J�n�ʒu�܂ŃV�[�N
                    inFile.seek(offset+lastIndex+1);
                }
            }
            QBuffer in(&data);
            in.open(QIODevice::ReadOnly);

			//�ǂݍ��݊J�n
            while(!in.atEnd()){
                QByteArray line=in.readLine().trimmed().toUpper();
				for(int i=0; i<line.size(); i++){
					Seq.append(line[i]);
					charPushed++;
					processedSize++;
				}
				if(Seq.size()>BufferSizeMax){
					outFile.write(Seq);
					Seq.clear();
				}
				if(charPushed>=info.seqLength){
					break;
				}
				setProcessStatus(processing, processedSize, totalFileSize);
			}
			if(charPushed>=info.seqLength){
				break;
			}
		}
		outFile.write(Seq);
		Seq.clear();
		
		//�t�@�C���T�C�Y���n���ꂽProperty�ƍ���Ȃ��ꍇ������
		if(charPushed!=info.seqLength){
			setProcessStatus(failed, processedSize, totalFileSize);
			return;
		}

		//���ߊm�F
		if(!getOrder()){
			setProcessStatus(stopped, 0, totalFileSize);
			return;
		}

		//���ߊm�F
		if(!getOrder()){
			setProcessStatus(stopped, 0, totalFileSize);
			return;
		}
	}

	//Target�����������ޏ���
	//�����̑傫�����w��
	Target::setVersion(header.version);

	QByteArray data;
	QBuffer buffer(&data);
	buffer.open(QIODevice::WriteOnly);
	out.setDevice(&buffer);
	for(i=0; i<target_list.size(); i++)
	{
		target_list[i].putSerialized(out);
	}
	buffer.close();
	//Target������������
	header.targetListOffset = outFile.pos();
	header.targetListDataSize = data.size();
	header.targetListDataCount = target_list.size();
	outFile.write(data);

	//�w�b�_�[�X�V
	outFile.seek(0);
	data.clear();
	out.setDevice(&outFile);
	header.putSerialized(out);

	setProcessStatus(finished, totalFileSize, totalFileSize);

	return;
}


/*-----------------------------------------------------------------------
        struct BinSeq::FileReader
-----------------------------------------------------------------------*/


FileReader::FileReader(QObject* parent):
mode(single),/* fileData(0),*/  QObject(parent){}

FileReader::~FileReader(void)
{
	//if(fileData!=0){
	//	delete [] fileData;
	//}
}

bool FileReader::setFile(const QString& pathToBinSeqFile, ProcessMode process_mode)
{

	//�t�@�C�����I�[�v��
	if(file.isOpen()){
		file.close();
	}
	file.setFileName(pathToBinSeqFile);
	if(!file.open(QIODevice::ReadOnly)){
		return false;
	}
	//�t�@�C���w�b�_�[����荞��
	QDataStream in(&file);
	header.getSerialized(in);

	//target����S���擾
	//�܂��o�[�W�����̎w�肩��
	Target::setVersion(header.version);
	targetList.clear();
	file.seek(header.targetListOffset);
	QByteArray data=file.read(header.targetListDataSize);
	QBuffer buffer(&data);
	buffer.open(QIODevice::ReadOnly);
	in.setDevice(&buffer);
	for(int i=0; i<(int)header.targetListDataCount; i++){
		Target target;
		target.getSerialized(in);
		targetList.push_back(target);
	}
	buffer.close();
	data.clear();

	mode=process_mode;

	//if(process_mode==batch){
	//	try{
	//		if(fileData!=0){
	//			delete [] fileData;
	//		}
	//		fileData=new char[file.size()];
	//		file.seek(0);
	//		file.read(fileData, file.size());
	//	}
	//	catch(...){
	//		return 0;
	//	}
	//}

	if(process_mode==batch){

		targetSeqList.clear();
		for(int i=0; i<targetList.size(); i++){

			//1/2�Ɉ��k�����z��i�[��̗p��
			Target& target=targetList[i];
			int size;
			if(target.targetLength%2==0){
				size=target.targetLength/2;
			}
			else{
				size=target.targetLength/2+1;
			}
			targetSeqList.push_back(QByteArray(size, 0));
			QByteArray& targetSeq=targetSeqList.last();

			//�z��ǂݏo��
			file.seek(target.targetOffset);
			QByteArray originalSeq=file.read(target.targetLength);

			bool isEven=true;
			for(int j=0, k=0; j<originalSeq.size(); j++){
				if(isEven){
					switch(originalSeq[j]){
						case 'A':
						case 'a':
							targetSeq[k]=0x00;	//0->A
							break;
						case 'C':
						case 'c':
							targetSeq[k]=0x10;	//1->C
							break;
						case 'G':
						case 'g':
							targetSeq[k]=0x20;	//2->G
							break;
						case 'T':
						case 't':
							targetSeq[k]=0x30;	//3->T
							break;
						case 'U':
						case 'u':
							targetSeq[k]=0x40;	//4->U
							break;
						case 'R':
						case 'r':
							targetSeq[k]=0x50;	//5->R
							break;
						case 'Y':
						case 'y':
							targetSeq[k]=0x60;	//6->Y
							break;
						case 'S':
						case 's':
							targetSeq[k]=0x70;	//7->S
							break;
						case 'W':
						case 'w':
							targetSeq[k]=0x80;	//8->W
							break;
						case 'K':
						case 'k':
							targetSeq[k]=0x90;	//9->K
							break;
						case 'M':
						case 'm':
							targetSeq[k]=0xA0;	//10->M
							break;
						case 'B':
						case 'b':
							targetSeq[k]=0xB0;	//11->B
							break;
						case 'D':
						case 'd':
							targetSeq[k]=0xC0;	//12->D
							break;
						case 'H':
						case 'h':
							targetSeq[k]=0xD0;	//13->H
							break;
						case 'V':
						case 'v':
							targetSeq[k]=0xE0;	//14->V
							break;
						default:
							targetSeq[k]=0xF0;	//16->N
					}
					isEven=false;
				}
				else{
					switch(originalSeq[j]){
						case 'A':
						case 'a':
							targetSeq[k]=targetSeq[k]|0x00;	//0->A
							break;
						case 'C':
						case 'c':
							targetSeq[k]=targetSeq[k]|0x01;	//1->C
							break;
						case 'G':
						case 'g':
							targetSeq[k]=targetSeq[k]|0x02;	//2->G
							break;
						case 'T':
						case 't':
							targetSeq[k]=targetSeq[k]|0x03;	//3->T
							break;
						case 'U':
						case 'u':
							targetSeq[k]=targetSeq[k]|0x04;	//4->U
							break;
						case 'R':
						case 'r':
							targetSeq[k]=targetSeq[k]|0x05;	//5->R
							break;
						case 'Y':
						case 'y':
							targetSeq[k]=targetSeq[k]|0x06;	//6->Y
							break;
						case 'S':
						case 's':
							targetSeq[k]=targetSeq[k]|0x07;	//7->S
							break;
						case 'W':
						case 'w':
							targetSeq[k]=targetSeq[k]|0x08;	//8->W
							break;
						case 'K':
						case 'k':
							targetSeq[k]=targetSeq[k]|0x09;	//9->K
							break;
						case 'M':
						case 'm':
							targetSeq[k]=targetSeq[k]|0x0A;	//10->M
							break;
						case 'B':
						case 'b':
							targetSeq[k]=targetSeq[k]|0x0B;	//11->B
							break;
						case 'D':
						case 'd':
							targetSeq[k]=targetSeq[k]|0x0C;	//12->D
							break;
						case 'H':
						case 'h':
							targetSeq[k]=targetSeq[k]|0x0D;	//13->H
							break;
						case 'V':
						case 'v':
							targetSeq[k]=targetSeq[k]|0x0E;	//14->V
							break;
						default:
							targetSeq[k]=targetSeq[k]|0x0F;	//16->N
					}
					isEven=true;
					k++;
				}
			}

		}
	}

	return true;

}

bool FileReader::releaseFile(void)
{
	if(file.isOpen()){
		file.close();
		return true;
	}
	else{
		return false;
	}
}

const Header& FileReader::getTrackConfig(void) const
{
	return header;
}

const QList<Target>& FileReader::getTargetList(void) const
{
	return targetList;
}

bool FileReader::targetExists(const QString& targetName, quint64& sizeTo)
{
	for(int i=0; i<targetList.size(); i++){
		if(targetList[i].targetName==targetName){
			sizeTo=targetList[i].targetLength;
			return true;
		}
	}
	return false;
}

bool FileReader::getSeq(const QString& targetName, QByteArray& to)
{

	for(int i=0; i<targetList.size(); i++){
		if(targetList[i].targetName==targetName){
			Target& target=targetList[i];
			if(mode==single){
				if(!file.isOpen()){
					return false;
				}
				file.seek(target.targetOffset);
				to=file.read(target.targetLength);
				return true;
			}
			else{
				//to=QByteArray::fromRawData(fileData+target.targetOffset, target.targetLength);
				//return true;

				//1/2���k�z�񂩂�𓀂���
				QByteArray& targetSeq=targetSeqList[i];
				to.fill(0, target.targetLength);
				bool isEven=true;
				for(int i=0, j=0; i<(int)target.targetLength; i++){
					if(isEven){
						switch(targetSeq[j]&0xF0){
							case 0x00:
								to[i]='A';
								break;
							case 0x10:
								to[i]='C';
								break;
							case 0x20:
								to[i]='G';
								break;
							case 0x30:
								to[i]='T';
								break;
							case 0x40:
								to[i]='U';
								break;
							case 0x50:
								to[i]='R';
								break;
							case 0x60:
								to[i]='Y';
								break;
							case 0x70:
								to[i]='S';
								break;
							case 0x80:
								to[i]='W';
								break;
							case 0x90:
								to[i]='K';
								break;
							case 0xA0:
								to[i]='M';
								break;
							case 0xB0:
								to[i]='B';
								break;
							case 0xC0:
								to[i]='D';
								break;
							case 0xD0:
								to[i]='H';
								break;
							case 0xE0:
								to[i]='V';
								break;
							case 0xF0:
								to[i]='N';
								break;
						}
						isEven=false;
					}
					else{
						switch(targetSeq[j]&0x0F){
							case 0x00:
								to[i]='A';
								break;
							case 0x01:
								to[i]='C';
								break;
							case 0x02:
								to[i]='G';
								break;
							case 0x03:
								to[i]='T';
								break;
							case 0x04:
								to[i]='U';
								break;
							case 0x05:
								to[i]='R';
								break;
							case 0x06:
								to[i]='Y';
								break;
							case 0x07:
								to[i]='S';
								break;
							case 0x08:
								to[i]='W';
								break;
							case 0x09:
								to[i]='K';
								break;
							case 0x0A:
								to[i]='M';
								break;
							case 0x0B:
								to[i]='B';
								break;
							case 0x0C:
								to[i]='D';
								break;
							case 0x0D:
								to[i]='H';
								break;
							case 0x0E:
								to[i]='V';
								break;
							case 0x0F:
								to[i]='N';
								break;
						}
						j++;
						isEven=true;
					}
				}
				return true;
			}
		}
	}
	return false;

}

bool FileReader::getSeq(const QString& targetName,
							 const quint64& start,		//�P�I���W��
							 const quint64& end,		//�P�I���W��
							 QByteArray& to)
{
	//start must smaller than end
	if(start>end){
		return false;
	}
	for(int i=0; i<targetList.size(); i++){
		if(targetList[i].targetName==targetName){
			Target& target=targetList[i];
			//�z�񒷂��w��͈͊O�Ȃ甲����
			if(target.targetLength<end){
				return false;
			}
			//�t�@�C�����J���Ă��Ȃ���Δ�����
			if(mode==single){
				if(!file.isOpen()){
					return false;
				}
				file.seek(target.targetOffset+start-1);
				to=file.read(end-start+1);
				return true;
			}
			else{

				//to=QByteArray::fromRawData(fileData+target.targetOffset+start-1, end-start+1);
				//return true;

				//1/2���k�z�񂩂�𓀂���
				QByteArray& targetSeq=targetSeqList[i];
				
				//�o�͐�
				int size=end-start+1;
				int begin=start-1;
				to.fill(0, size);

				bool isEven;
				if(begin%2==0){
					isEven=true;
				}
				else{
					isEven=false;
				}
				for(int i=0, j=begin/2; i<size; i++){
					if(isEven){
						switch(targetSeq[j]&0xF0){
							case 0x00:
								to[i]='A';
								break;
							case 0x10:
								to[i]='C';
								break;
							case 0x20:
								to[i]='G';
								break;
							case 0x30:
								to[i]='T';
								break;
							case 0x40:
								to[i]='U';
								break;
							case 0x50:
								to[i]='R';
								break;
							case 0x60:
								to[i]='Y';
								break;
							case 0x70:
								to[i]='S';
								break;
							case 0x80:
								to[i]='W';
								break;
							case 0x90:
								to[i]='K';
								break;
							case 0xA0:
								to[i]='M';
								break;
							case 0xB0:
								to[i]='B';
								break;
							case 0xC0:
								to[i]='D';
								break;
							case 0xD0:
								to[i]='H';
								break;
							case 0xE0:
								to[i]='V';
								break;
							case 0xF0:
								to[i]='N';
								break;
						}
						isEven=false;
					}
					else{
						switch(targetSeq[j]&0x0F){
							case 0x00:
								to[i]='A';
								break;
							case 0x01:
								to[i]='C';
								break;
							case 0x02:
								to[i]='G';
								break;
							case 0x03:
								to[i]='T';
								break;
							case 0x04:
								to[i]='U';
								break;
							case 0x05:
								to[i]='R';
								break;
							case 0x06:
								to[i]='Y';
								break;
							case 0x07:
								to[i]='S';
								break;
							case 0x08:
								to[i]='W';
								break;
							case 0x09:
								to[i]='K';
								break;
							case 0x0A:
								to[i]='M';
								break;
							case 0x0B:
								to[i]='B';
								break;
							case 0x0C:
								to[i]='D';
								break;
							case 0x0D:
								to[i]='H';
								break;
							case 0x0E:
								to[i]='V';
								break;
							case 0x0F:
								to[i]='N';
								break;
						}
						j++;
						isEven=true;
					}
				}
				return true;
			} //else{
		} //if(targetList[i].targetName==targetName){
	} //for(int i=0; i<targetList.size(); i++)
	return false;
}

bool FileReader::updateConfig(const Header& new_conf)
{
	if(mode==single){
		if(file.isOpen()){
			file.close();
		}
		file.open(QIODevice::Append);
		if(!file.isOpen()){
			return false;
		}
		//������header�Ɋi�[
		header.ovFgColor=new_conf.ovFgColor;
		header.ovBgColor=new_conf.ovBgColor;
		header.ovMarkColor=new_conf.ovMarkColor;
		header.ovRowHeight=new_conf.ovRowHeight;
		header.rlFgColor=new_conf.rlFgColor;
		header.rlBgColor=new_conf.rlBgColor;
		header.rlRowHeight=new_conf.rlRowHeight;
		header.bgColorForA=new_conf.bgColorForA;
		header.bgColorForC=new_conf.bgColorForC;
		header.bgColorForG=new_conf.bgColorForG;
		header.bgColorForT=new_conf.bgColorForT;
		header.bgColorForN=new_conf.bgColorForN;
		header.bgRowHeight=new_conf.bgRowHeight;
		//��������
		file.seek(0);
		QDataStream out(&file);
		header.putSerialized(out);
		file.close();
		//
		return true;
	}
	else{
		return false;
	}

}
