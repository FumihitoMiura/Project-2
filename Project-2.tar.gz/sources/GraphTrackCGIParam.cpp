#include "GraphTrackCGIParam.h"

using namespace DesktopTrack;

GraphTrackCGIParam::GraphTrackCGIParam(void)
:start(0), end(0), width(0)
{

	QString query_string;
	if(std::getenv( "SERVER_NAME" )!=0){
		if(std::getenv("HTTPS")!=0){
			address=QString("https://")+QString(std::getenv("SERVER_NAME"))+QString(std::getenv("SCRIPT_NAME"));
		}
		else{
			address=QString("http://")+QString(std::getenv("SERVER_NAME"))+QString(std::getenv("SCRIPT_NAME"));
		}
		if(std::getenv( "QUERY_STRING" )!=0){
			query_string = std::getenv("QUERY_STRING");
		}
		is_cgi=true;
	}
	else{
		address=QCoreApplication::arguments().at(0);
		if(std::getenv( "QUERY_STRING" )!=0){
			query_string = std::getenv("QUERY_STRING");
		}
		is_cgi=false;
	}

	QList<QString> arg_list = query_string.split('&');
	for(int i=0; i<arg_list.size(); i++)
	{
		QStringList key_to_value = arg_list[i].split('=');
		if(key_to_value.size()<2){
			continue;
		}
		if(key_to_value[0].trimmed()=="track_layer"){
			layer = key_to_value[1];
		}
		else if(key_to_value[0].trimmed()=="track_name"){
			track_name = key_to_value[1];
		}
		else if(key_to_value[0].trimmed()=="species"){
			species = key_to_value[1];
		}
		else if(key_to_value[0].trimmed()=="revision"){
			revision = key_to_value[1];
		}
		else if(key_to_value[0].trimmed()=="target"){
			target = key_to_value[1];
		}
		else if(key_to_value[0].trimmed()=="start"){
			start = key_to_value[1].toUInt();
		}
		else if(key_to_value[0].trimmed()=="end"){
			end = key_to_value[1].toUInt();
		}
		else if(key_to_value[0].trimmed()=="width"){
			width = key_to_value[1].toUInt();
		}
		else{
			anotherParam.push_back(qMakePair(key_to_value[0].trimmed(), key_to_value[1].trimmed()));
		}

	}
}
