#include "BMapFile.h"

using namespace DesktopTrack::BMapCore;

Header::Header(void):
    magic(2731),
    version(1),
    targetListOffset(0),
    targetListDataSize(0),
    targetListDataCount(0),
    seqLength(0),
    sizeofInt(4),
    seqOffset(0),
    seqDataSize(0),
    c2tSeqOffset(0),
    c2tSeqDataSize(0),
    c2tSAOffset(0),
    c2tSADataSize(0),
    g2aSeqOffset(0),
    g2aSeqDataSize(0),
    g2aSAOffset(0),
    g2aSADataSize(0),
    c2tBWTOffset(0),
    g2aBWTOffset(0),
    bIdxWordSize(9),
    c2tBIdxOffset(0),
    c2tBIdxDataSize(0),
    g2aBIdxOffset(0),
    g2aBIdxDataSize(0){}

Header::Header(const Header& original):
    magic(original.magic),
    version(original.version),
    species(original.species),
    revision(original.revision),
    targetListOffset(original.targetListOffset),
    targetListDataSize(original.targetListDataSize),
    targetListDataCount(original.targetListDataCount),
    seqLength(original.seqLength),
    sizeofInt(original.sizeofInt),
    seqOffset(original.seqOffset),
    seqDataSize(original.seqDataSize),
    c2tSeqOffset(original.c2tSeqOffset),
    c2tSeqDataSize(original.c2tSeqDataSize),
    c2tSAOffset(original.c2tSAOffset),
    c2tSADataSize(original.c2tSADataSize),
    g2aSeqOffset(original.g2aSeqOffset),
    g2aSeqDataSize(original.g2aSeqDataSize),
    g2aSAOffset(original.g2aSAOffset),
    g2aSADataSize(original.g2aSADataSize),
    c2tBWTOffset(original.c2tBWTOffset),
    g2aBWTOffset(original.g2aBWTOffset),
    bIdxWordSize(original.bIdxWordSize),
    c2tBIdxOffset(original.c2tBIdxOffset),
    c2tBIdxDataSize(original.c2tBIdxDataSize),
    g2aBIdxOffset(original.g2aBIdxOffset),
    g2aBIdxDataSize(original.g2aBIdxDataSize){}

Header& Header::operator=(const Header& original)
{
    magic=original.magic;
    version=original.version;
    species=original.species;
    revision=original.revision;
    targetListOffset=original.targetListOffset;
    targetListDataSize=original.targetListDataSize;
    targetListDataCount=original.targetListDataCount;
    seqLength=original.seqLength;
    sizeofInt=original.sizeofInt;
    seqOffset=original.seqOffset;
    seqDataSize=original.seqDataSize;
    c2tSeqOffset=original.c2tSeqOffset;
    c2tSeqDataSize=original.c2tSeqDataSize;
    c2tSAOffset=original.c2tSAOffset;
    c2tSADataSize=original.c2tSADataSize;
    g2aSeqOffset=original.g2aSeqOffset;
    g2aSeqDataSize=original.g2aSeqDataSize;
    g2aSAOffset=original.g2aSAOffset;
    g2aSADataSize=original.g2aSADataSize;
    c2tBWTOffset=original.c2tBWTOffset;
    g2aBWTOffset=original.g2aBWTOffset;
    bIdxWordSize=original.bIdxWordSize;
    c2tBIdxOffset=original.c2tBIdxOffset;
    c2tBIdxDataSize=original.c2tBIdxDataSize;
    g2aBIdxOffset=original.g2aBIdxOffset;
    g2aBIdxDataSize=original.g2aBIdxDataSize;
    return *this;
}

void Header::putSerialized(QDataStream& out)
{
    out	<< magic
        << version
        << species
        << revision
        << targetListOffset
        << targetListDataSize
        << targetListDataCount
        << seqLength
        << sizeofInt
        << seqOffset
        << seqDataSize
        << c2tSeqOffset
        << c2tSeqDataSize
        << c2tSAOffset
        << c2tSADataSize
        << g2aSeqOffset
        << g2aSeqDataSize
        << g2aSAOffset
        << g2aSADataSize
        << c2tBWTOffset
        << c2tBWTDataSize
        << g2aBWTOffset
        << g2aBWTDataSize
        << bIdxWordSize
        << c2tBIdxOffset
        << c2tBIdxDataSize
        << g2aBIdxOffset
        << g2aBIdxDataSize;
}

void Header::getSerialized(QDataStream& in)
{
    in	>> magic
        >> version
        >> species
        >> revision
        >> targetListOffset
        >> targetListDataSize
        >> targetListDataCount
        >> seqLength
        >> sizeofInt
        >> seqOffset
        >> seqDataSize
        >> c2tSeqOffset
        >> c2tSeqDataSize
        >> c2tSAOffset
        >> c2tSADataSize
        >> g2aSeqOffset
        >> g2aSeqDataSize
        >> g2aSAOffset
        >> g2aSADataSize
        >> c2tBWTOffset
        >> c2tBWTDataSize
        >> g2aBWTOffset
        >> g2aBWTDataSize
        >> bIdxWordSize
        >> c2tBIdxOffset
        >> c2tBIdxDataSize
        >> g2aBIdxOffset
        >> g2aBIdxDataSize;
}

quint64 Target::sizeofInt=4;

void Target::setSizeofInt(quint64 byte_num)
{
	if(byte_num>8){
		return;
	}
	else{
		sizeofInt=byte_num;
	}
}

Target::Target(void):targetOffset(0),targetLength(0){}

Target::Target(const QString& target_name,
               const quint64& target_offset,
               const quint64& target_length):
targetName(target_name),
targetOffset(target_offset),
targetLength(target_length){}

Target::Target(const Target& original):
targetName(original.targetName),
targetOffset(original.targetOffset),
targetLength(original.targetLength){}

Target& Target::operator=(const Target& original)
{
    targetName=original.targetName;
    targetOffset=original.targetOffset;
    targetLength=original.targetLength;
    return *this;
}

void Target::putSerialized(QDataStream& out)
{
	if(sizeofInt<=4){
		quint32 offset=(quint32)targetOffset;
		quint32 length=(quint32)targetLength;
		out << targetName
			<< offset
			<< length;
	}
	else{
		out << targetName
			<< targetOffset
			<< targetLength;
	}
}

void Target::getSerialized(QDataStream& in)
{
	if(sizeofInt<=4){
		quint32 offset, length;
		in  >> targetName
			>> offset
			>> length;
		targetOffset=(quint64)offset;
		targetLength=(quint64)length;
	}
	else{
		in  >> targetName
			>> targetOffset
			>> targetLength;
	}
}
