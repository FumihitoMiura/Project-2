#include "MethylationPerspective.h"

using namespace DesktopTrack;

MethylationPerspective::MethylationPerspective(void):
seqLen(0), mutexArray(0), arraySize(0){}

MethylationPerspective::~MethylationPerspective(void)
{
	if(mutexArray!=0){
		delete[] mutexArray;
	}
}

MethylationPerspective::MethylationPerspective(const MethylationPerspective& original):
seqName(original.seqName), seqLen(original.seqLen), 
valueListF(original.valueListF), 
valueListR(original.valueListR){

	arraySize=seqLen%mutexUnitSize==0?seqLen/mutexUnitSize:seqLen/mutexUnitSize+1;
	try{
		mutexArray=new QMutex[arraySize];
	}
	catch(...){
		qDebug() << "Couldn't allocate enough memory." << endl;	
	}

}

/* now thread-safe */
MethylationPerspective& MethylationPerspective::operator =(const MethylationPerspective& original)
{
	seqName=original.seqName;
	seqLen=original.seqLen;
	valueListF=original.valueListF;
	valueListR=original.valueListR;
	
	arraySize=seqLen%mutexUnitSize==0?seqLen/mutexUnitSize:seqLen/mutexUnitSize+1;
	if(mutexArray!=0){
		delete[] mutexArray;
	}
	try{
		mutexArray=new QMutex[arraySize];
	}
	catch(...){
		qDebug() << "Couldn't allocate enough memory." << endl;	
	}
	return *this;
}

/* now thread-safe */
void MethylationPerspective::setSeq(const QByteArray& seq, const QByteArray& name)
{
	//mutex.lock();
	seqName=name;
	seqLen=seq.size();
	valueListF.clear();
	valueListF.resize(seq.size(), 0);
	valueListR.clear();
	valueListR.resize(seq.size(), 0);
	arraySize=seqLen%mutexUnitSize==0?seqLen/mutexUnitSize:seqLen/mutexUnitSize+1;
	if(mutexArray!=0){
		delete[] mutexArray;
	}
	try{
		mutexArray=new QMutex[arraySize];
	}
	catch(...){
		qDebug() << "Couldn't allocate enough memory." << endl;	
	}
}

int MethylationPerspective::getSeqLen(void)
{
	return seqLen;
}

/* pos は1オリジンのアドレス*/
/* now thread-safe */
void MethylationPerspective::putC(const int& pos, const int& strand, bool methylated)
{
	if(pos<1||pos>seqLen){
		return;
	}
	int mutexUnitPoint=pos/mutexUnitSize;
	if(mutexUnitPoint>=arraySize||mutexUnitPoint<0){
		return;
	}

	int data_pos=pos-1;
	quint32 count_residue, count_methylated;
	if(strand==1){
		mutexArray[mutexUnitPoint].lock();
		quint32 value=valueListF[data_pos];
		count_residue=value&0x0000FFFF;
		count_methylated=(value&0xFFFF0000)>>16;
		if(count_residue>=0x0000FFFF){
			mutexArray[mutexUnitPoint].unlock();
			return;
		}
		count_residue++;
		if(methylated){
			count_methylated++;
		}
		count_methylated=count_methylated<<16;
		value=count_methylated|count_residue;
		valueListF[data_pos]=value;
		mutexArray[mutexUnitPoint].unlock();
	}
	else if(strand==-1){
		mutexArray[mutexUnitPoint].lock();
		quint32 value=valueListR[data_pos];
		count_residue=value&0x0000FFFF;
		count_methylated=(value&0xFFFF0000)>>16;
		if(count_residue>=0x0000FFFF){
			mutexArray[mutexUnitPoint].unlock();
			return;
		}
		count_residue++;
		if(methylated){
			count_methylated++;
		}
		count_methylated=count_methylated<<16;
		value=count_methylated|count_residue;
		valueListR[data_pos]=value;
		mutexArray[mutexUnitPoint].unlock();
	}

}

/* pos は1オリジンのアドレス*/
/* now thread-safe */
void MethylationPerspective::putD(const int& pos, const int& strand)
{

	if(pos<1||pos>seqLen){
		return;
	}
	int mutexUnitPoint=pos/mutexUnitSize;
	if(mutexUnitPoint>=arraySize||mutexUnitPoint<0){
		return;
	}

	if(pos<1||pos>seqLen){
		return;
	}
	int data_pos=pos-1;
	quint32 count;
	if(strand==1){
		mutexArray[mutexUnitPoint].lock();
		quint32 value=valueListF[data_pos];
		count=value&0x0000FFFF;
		if(count>=0x0000FFFF){
			mutexArray[mutexUnitPoint].unlock();
			return;
		}
		count++;
		valueListF[data_pos]=count|0xFFFF0000;
		mutexArray[mutexUnitPoint].unlock();
	}
	else if(strand==-1){
		mutexArray[mutexUnitPoint].lock();
		quint32 value=valueListR[data_pos];
		count=value&0x0000FFFF;
		if(count>=0x0000FFFF){
			mutexArray[mutexUnitPoint].unlock();
			return;
		}
		count++;
		valueListR[data_pos]=count|0xFFFF0000;

		mutexArray[mutexUnitPoint].unlock();
	}
}

/* now thread-safe */
const std::vector<quint32>&	 MethylationPerspective::getListF(void)
{
	return valueListF;
}

/* now thread-safe */
const std::vector<quint32>&	 MethylationPerspective::getListR(void)
{
	return valueListR;
}

/* now thread-safe */
bool MethylationPerspective::setListF(
	const std::vector<quint16>& source1, 
	const std::vector<quint16>& source2)
{
	if(source1.size()!=source2.size()){
		return false;
	}
	if(source1.size()!=valueListF.size()){
		valueListF.resize(source1.size());
	}
	if(source1.size()!=valueListF.size()){
		return false;
	}
	for(int i=0; i<arraySize; i++){
		mutexArray[i].lock();
	}
	for(int i=0; i<valueListF.size(); i++){
		quint32 methyl=(quint32)source1[i];
		quint32 count=(quint32)source2[i];
		valueListF[i]=(methyl<<16)|count;
	}
	for(int i=0; i<arraySize; i++){
		mutexArray[i].unlock();
	}
	return true;
}

/* now thread-safe */
bool MethylationPerspective::setListR(
	const std::vector<quint16>& source1, 
	const std::vector<quint16>& source2)
{
	if(source1.size()!=source2.size()){
		return false;
	}
	if(source1.size()!=valueListR.size()){
		return false;
	}
	for(int i=0; i<arraySize; i++){
		mutexArray[i].lock();
	}
	for(int i=0; i<valueListR.size(); i++){
		quint32 methyl=(quint32)source1[i];
		quint32 count=(quint32)source2[i];
		valueListR[i]=(methyl<<16)|count;
	}
	for(int i=0; i<arraySize; i++){
		mutexArray[i].unlock();
	}
	return true;
}

/* now thread-safe */
bool MethylationPerspective::setListF(
	const std::vector<quint32>& source1, 
	const std::vector<quint32>& source2)
{
	if(source1.size()!=source2.size()){
		return false;
	}
	if(source1.size()!=valueListF.size()){
		return false;
	}
	for(int i=0; i<arraySize; i++){
		mutexArray[i].lock();
	}
	for(int i=0; i<valueListF.size(); i++){
		
		quint32 methyl=source1[i];
		quint32 count=source2[i];

		if(count>0x0000FFFF){
			methyl = (quint32)((quint64)methyl*0x000000000000FFFF/(quint64)count);
			if(methyl>0x0000FFFF){
				methyl=0x0000FFFF;
			}
			count = 0x0000FFFF;
		}

		valueListF[i]=(methyl<<16)|count;

	}
	for(int i=0; i<arraySize; i++){
		mutexArray[i].unlock();
	}
	return true;
}

/* now thread-safe */
bool MethylationPerspective::setListR(
	const std::vector<quint32>& source1, 
	const std::vector<quint32>& source2)
{
	if(source1.size()!=source2.size()){
		return false;
	}
	if(source1.size()!=valueListR.size()){
		return false;
	}
	for(int i=0; i<arraySize; i++){
		mutexArray[i].lock();
	}
	for(int i=0; i<valueListR.size(); i++){
		
		quint32 methyl=source1[i];
		quint32 count=source2[i];

		if(count>0x0000FFFF){
			methyl = (quint32)((quint64)methyl*0x000000000000FFFF/(quint64)count);
			if(methyl>0x0000FFFF){
				methyl=0x0000FFFF;
			}
			count = 0x0000FFFF;
		}

		valueListR[i]=(methyl<<16)|count;

	}
	for(int i=0; i<arraySize; i++){
		mutexArray[i].unlock();
	}
	return true;
}
