#include <QtCore>
#include "BisulAlignDispatcher.h"
#include "MethylationPerspective.h"
#include "MethylationPerspectiveTrack.h"

using namespace DesktopTrack;

namespace DesktopTrack{

	class MPTrackCreatorSubThread: public QThread{
		Q_OBJECT
	private:

	public:
		BisulAlignDispatcher					*dispatcher;
		QMap<QString, MethylationPerspective>	*methylationMap;
		MPTrackCreatorSubThread(QObject* parent);
		void setMap(QMap<QString, MethylationPerspective> *methylmap);
		void setDispatcher(BisulAlignDispatcher* dispatcher);
		void run(void);
signals:
		void processFinished(MPTrackCreatorSubThread* ptr);

	};

	class MPTrackCreator: public QObject{
		Q_OBJECT
		friend class MPTrackCreatorSubThread;
	private:
		bool									isInitialized;
		QMutex									mutex;
		GraphFile::Header						header;
		QFile									outFile;
		BisulAlignDispatcher					dispatcher;
		QList<MPTrackCreatorSubThread*>			threads;
		QList<bool>								threadStates;
		QMap<QString, MethylationPerspective>	methylationMap;
		QList<GraphFile::Target>				targetList;
		int										finishedProcess;

	public:
		MPTrackCreator(int num_of_thread, QObject* parent);
		bool setBinSeq(const QString& pathTo);
		bool setGraph(const QString& pathTo);
		void setTrackName(const QString& trackName);
		void setOutfilePath(const QString& pathTo);
		bool setBisulAlignPaths(const QStringList& paths);
		//bool setBedGraphPaths(const QStringList& paths);

		void start(void);

	public slots:
		void onProcessFinished(void);

	signals:
		void allProcessFinished(void);

	};

};