#include "MethylationPerspectiveTrack.h"

using namespace DesktopTrack;

#ifdef Q_OS_WIN32
#include <io.h>
#include <fcntl.h>
#endif

#include <cmath>

//default�̐F�͂����Œ�`
QColor readColor(158, 188, 240);
QColor methylMaxColor(235, 0, 235);
QColor methylAveColor(0, 0, 0);
QColor methylSignalColor(235, 188, 235);
QColor gridColor(0, 0, 255);
quint32	maxBpWidth=10000000;

MethylationPerspectiveFileReader::MethylationPerspectiveFileReader(void):
    GraphFile::FileReader(){}

/* start��end��1�I���W���ɂ��w��*/
bool MethylationPerspectiveFileReader::getData(const QString& target_name,
                                               const qint32& strand,
                                               QVector<quint16>& methylation_data_to,
                                               QVector<quint16>& cytosine_data_to)
{

    if(!targetMap.contains(target_name)){
        return false;
    }
    GraphFile::Target& target=targetList[targetMap[target_name]];

    return getData(target_name, 1, target.targetLength, strand, methylation_data_to, cytosine_data_to);

}

/* start��end��1�I���W���ɂ��w��*/
bool MethylationPerspectiveFileReader::getData(const QString& target_name,
                                               const quint32& start,
                                               const quint32& end,
                                               const qint32& strand,
                                               QVector<quint16>& methylation_data_to,
                                               QVector<quint16>& cytosine_data_to)
{

    if(start>end){
        return false;
    }
    if(!targetMap.contains(target_name)){
        return false;
    }
    GraphFile::Target& target=targetList[targetMap[target_name]];
    if(end>target.targetLength){
        return false;
    }

    //
    if(strand==1){
        if(file.isOpen()){
            file.close();
        }
        file.open(QIODevice::ReadOnly);
        if(!file.isOpen()){
            return false;
        }

        int sizeofint=target.fwDataSize/target.targetLength;
        int offset=sizeofint*(start-1);
        int datacount=end-start+1;
        int datasize=sizeofint*datacount;

        file.seek(target.fwDataOffset+offset);
        QByteArray data=file.read(datasize);
        QBuffer buffer(&data);
        buffer.open(QIODevice::ReadOnly);
        QDataStream in(&buffer);
        methylation_data_to.resize(datacount);
        cytosine_data_to.resize(datacount);
        for(int i=0; i<datacount; i++){
            quint32 temp;
            in >> temp;
            methylation_data_to[i]=(qint16)(temp>>16);
            cytosine_data_to[i]=(qint16)(0x0000FFFF&temp);
        }
        return true;
    }
    else if(strand==-1){
        if(file.isOpen()){
            file.close();
        }
        file.open(QIODevice::ReadOnly);
        if(!file.isOpen()){
            return false;
        }

        int sizeofint=target.rvDataSize/target.targetLength;
        int offset=sizeofint*(start-1);
        int datacount=end-start+1;
        int datasize=sizeofint*datacount;

        file.seek(target.rvDataOffset+offset);
        QByteArray data=file.read(datasize);
        QBuffer buffer(&data);
        buffer.open(QIODevice::ReadOnly);
        QDataStream in(&buffer);
        methylation_data_to.resize(datacount);
        cytosine_data_to.resize(datacount);
        for(int i=0; i<datacount; i++){
            quint32 temp;
            in >> temp;
            methylation_data_to[i]=(qint16)(temp>>16);
            cytosine_data_to[i]=(qint16)(0x0000FFFF&temp);
        }
        return true;
    }
    else{
        return false;
    }
}

/* start��end��1�I���W���ɂ��w��*/
bool MethylationPerspectiveFileReader::getData(const QString& target_name,
                                               const qint32& strand,
                                               vector<quint16>& methylation_data_to,
                                               vector<quint16>& cytosine_data_to)
{

    if(!targetMap.contains(target_name)){
        return false;
    }
    GraphFile::Target& target=targetList[targetMap[target_name]];

    return getData(target_name, 1, target.targetLength, strand, methylation_data_to, cytosine_data_to);

}

/* start��end��1�I���W���ɂ��w��*/
bool MethylationPerspectiveFileReader::getData(const QString& target_name,
                                               const quint32& start,
                                               const quint32& end,
                                               const qint32& strand,
                                               vector<quint16>& methylation_data_to,
                                               vector<quint16>& cytosine_data_to)
{

    if(start>end){
        return false;
    }
    if(!targetMap.contains(target_name)){
        return false;
    }
    GraphFile::Target& target=targetList[targetMap[target_name]];
    if(end>target.targetLength){
        return false;
    }

    //
    if(strand==1){

		//�t�@�C���I�[�v������
		if (file.isOpen()) {
			file.close();
		}
		file.open(QIODevice::ReadOnly);
		if (!file.isOpen()) {
			return false;
		}

		//�f�[�^�T�C�Y�v�Z
		int unitSize = target.rvDataSize / target.targetLength;
		int offset = unitSize*(start - 1);
		int datacount = end - start + 1;
		int datasize = unitSize*datacount;

		//�f�[�^�o�͐�̃������m��
		methylation_data_to.clear();
		methylation_data_to.reserve(datacount);
		cytosine_data_to.clear();
		cytosine_data_to.reserve(datacount);

		//�t�@�C������f�[�^��ǂݍ���
		file.seek(target.fwDataOffset + offset);
		char *buffer;
		try {
			buffer = new char[datasize];
		}
		catch (...) {
			return false;
		}
		quint64 readamount = file.read(buffer, datasize);
		if (readamount != datasize) {
			delete[] buffer;
			return false;
		}

		//�f�[�^�T�C�Y
		for (int i = 0; i < datacount; i += BufferSizeMax) {

			qint64 countMax = qMin(BufferSizeMax, datacount - i);
			QByteArray data(buffer + i*unitSize, countMax*unitSize);
			QDataStream in(&data, QIODevice::ReadOnly);

			for (int j = 0; j < countMax; j++) {

				quint16 temp;
				in >> temp;
				methylation_data_to.push_back(temp);
				in >> temp;
				cytosine_data_to.push_back(temp);

			}
		}

        delete[] buffer;
        return true;
    }
    else if(strand==-1){

		//�t�@�C���I�[�v������
        if(file.isOpen()){
            file.close();
        }
        file.open(QIODevice::ReadOnly);
        if(!file.isOpen()){
            return false;
        }

		//�f�[�^�T�C�Y�v�Z
        int unitSize=target.rvDataSize/target.targetLength;
        int offset=unitSize*(start-1);
        int datacount=end-start+1;
        int datasize=unitSize*datacount;

		//�f�[�^�o�͐�̃������m��
		methylation_data_to.clear();
		methylation_data_to.reserve(datacount);
		cytosine_data_to.clear();
		cytosine_data_to.reserve(datacount);

		//�t�@�C������f�[�^��ǂݍ���
        file.seek(target.rvDataOffset+offset);
		char *buffer;
		try {
			buffer = new char[datasize];
		}
		catch (...) {
			return false;
		}
		quint64 readamount = file.read(buffer, datasize);
		if (readamount != datasize) {
			delete[] buffer;
			return false;
		}

		//�f�[�^�T�C�Y
		for (int i = 0; i < datacount; i+=BufferSizeMax) {

			qint64 countMax = qMin(BufferSizeMax, datacount - i);
			QByteArray data(buffer + i*unitSize, countMax*unitSize);
			QDataStream in(&data, QIODevice::ReadOnly);

			for (int j = 0; j < countMax; j++) {

				quint16 temp;
				in >> temp;
				methylation_data_to.push_back(temp);
				in >> temp;
				cytosine_data_to.push_back(temp);

			}
		}

		delete[] buffer;
		return true;
		    }
    else{
        return false;
    }
}

MethylationPerspectiveTrack::MethylationPerspectiveTrack(void):readNumberThreshold(5), GraphTrack(){}

bool MethylationPerspectiveTrack::printTrackLayer(void){

    if(CGIParam.layer==""){
        return printTrackList();
    }
    else if(CGIParam.layer=="description"){
        return printTrackDescription();
    }

    //�u���E�U�[���C���[
    else if(CGIParam.layer=="image"){
        return printImage();
    }
    else if(CGIParam.layer=="index"){
        return printIndexImage();
    }
    else if(CGIParam.layer=="operation"){
        printOperation();
    }
    else if(CGIParam.layer=="index_operation"){
        printIndexOperation();
    }

    return true;

}

bool MethylationPerspectiveTrack::printTrackList(void){

    QStringList filters;
    filters << GraphFileNameFilter;

#ifdef Q_OS_WIN32
    _setmode( _fileno( stdout ), _O_BINARY );
#endif
    QFile file;
    file.open(stdout, QIODevice::WriteOnly);
    QTextStream out(&file);

    QDomDocument doc("track_list");
    QDomElement root = doc.createElement("track_list");
    doc.appendChild(root);

    QDir revisionDir(QApplication::applicationDirPath());
    if(!revisionDir.exists(RevisionsDirName)){
        return false;
    }
    if(!revisionDir.cd(RevisionsDirName)){
        return false;
    }
    QStringList speciesList;
    if(CGIParam.species.size()!=0){
        speciesList.push_back(CGIParam.species);
    }
    else{
        speciesList=revisionDir.entryList(QDir::Dirs|QDir::NoDotAndDotDot, QDir::Name);
    }
    for(int i=0; i<speciesList.size(); i++){
        QDir speciesDir(revisionDir);
        QString& species=speciesList[i];
        if(!speciesDir.exists(species)){
            continue;
        }
        if(!speciesDir.cd(species)){
            continue;
        }
        QStringList revisionsList;
        if(CGIParam.revision.size()!=0){
            revisionsList.push_back(CGIParam.revision);
        }
        else{
            revisionsList=speciesDir.entryList(QDir::Dirs|QDir::NoDotAndDotDot, QDir::Name);
        }
        for(int j=0; j<revisionsList.size(); j++){
            QDir revisionsDir(speciesDir);
            QString& revision=revisionsList[j];
            if(!revisionsDir.exists(revision)){
                continue;
            }
            if(!revisionsDir.cd(revision)){
                continue;
            }
            if(!revisionsDir.exists(MethylationPerspectiveTrackDirName)){
                continue;
            }
            if(!revisionsDir.cd(MethylationPerspectiveTrackDirName)){
                continue;
            }
            QFileInfoList entryInfoList=revisionsDir.entryInfoList(filters, QDir::Files, QDir::Name);


            for(int k=0; k<entryInfoList.size(); k++){

                MethylationPerspectiveFileReader r;
                if(!r.setFile(entryInfoList[k].absoluteFilePath())){
                    continue;
                }
                const GraphFile::Header& header=r.getBasicTrackInfo();
                if(header.species!=species){
                    continue;
                }
                if(header.revision!=revision){
                    continue;
                }
                if(header.trackName!=entryInfoList[k].baseName()){
                    continue;
                }
                QDomElement track_tag = doc.createElement(TrackTag);
                track_tag.setAttribute(SpeciesAttr, species);
                track_tag.setAttribute(RevisionAttr, revision);
                track_tag.setAttribute(NameAttr, entryInfoList[k].baseName());
                track_tag.setAttribute(ProgramAttr, CGIParam.address);
                root.appendChild(track_tag);

            }
        }
    }

    if(CGIParam.is_cgi){
        out << "Content-type: text/xml\n"
            << "Pragma: no-cache\n\n";
        out.flush();
    }

    out << doc.toString();

    return true;
}


bool MethylationPerspectiveTrack::printTrackDescription(void){

    //�g���b�N�f�[�^�̃f�B���N�g���ֈړ�����
    QDir graphFileDir(QApplication::applicationDirPath());
    if(!graphFileDir.exists(RevisionsDirName)){
        return false;
    }
    if(!graphFileDir.cd(RevisionsDirName)){
        return false;
    }
    //species directory
    if(!graphFileDir.exists(CGIParam.species)){
        return false;
    }
    if(!graphFileDir.cd(CGIParam.species)){
        return false;
    }
    //revision directory
    if(!graphFileDir.exists(CGIParam.revision)){
        return false;
    }
    if(!graphFileDir.cd(CGIParam.revision)){
        return false;
    }
    //graph track dir
    if(!graphFileDir.exists(MethylationPerspectiveTrackDirName)){
        return false;
    }
    if(!graphFileDir.cd(MethylationPerspectiveTrackDirName)){
        return false;
    }
    //graphfile�����݂��邱�Ƃ��m�F
    QString graphFileName=GraphFileNameTemplate.arg(CGIParam.track_name);
    if(!graphFileDir.exists(graphFileName)){
        return false;
    }

    //graphfile���I�[�v��
    MethylationPerspectiveFileReader r;
    if(!r.setFile(graphFileDir.filePath(graphFileName))){
        return false;
    }
    const GraphFile::Header& header=r.getBasicTrackInfo();

    //�p�����[�^�`�F�b�N
    if(header.species!=CGIParam.species){
        return false;
    }
    if(header.revision!=CGIParam.revision){
        return false;
    }
    if(header.trackName!=CGIParam.track_name){
        return false;
    }

#ifdef Q_OS_WIN32
    _setmode( _fileno( stdout ), _O_BINARY );
#endif
    QFile file;
    file.open(stdout, QIODevice::WriteOnly);
    QTextStream out(&file);
    if(CGIParam.is_cgi){
        out << "Content-type: text/javascript\n"
            << "Pragma: no-cache\n\n";
        out.flush();
    }

    //�g���b�N�R���t�B�O���[�V�����y�[���̓��\�[�X���Ɋi�[���Ă���
    QFile resource(":/browser/MethylationPerspectiveTrackConfigPane.js");
    resource.open(QIODevice::ReadOnly);
    //�I���W�i����JavaScript��S���ǂݏo��
    QString document(QString::fromUtf8(resource.readAll().data()));

    QString anotherParams;
    for(int i=0; i<CGIParam.anotherParam.size(); i++){
        anotherParams
                .append(",\n\t\t'")
                .append(CGIParam.anotherParam[i].first)
                .append("':'")
                .append(CGIParam.anotherParam[i].second)
                .append("'");
    }

    out << document
           .replace(QString("TRACK_NAME"), header.trackName)
           .replace(QString("SPECIES"), header.species)
           .replace(QString("REVISION"), header.revision)
           .replace(QString("TRACK_URL"), CGIParam.address)
           .replace(QString("GRID_COLOR"), gridColor.name())
           .replace(QString("READ_COLOR"), readColor.name())
           .replace(QString("AVE_MET_COLOR"), methylAveColor.name())
           .replace(QString("MAX_MET_COLOR"), methylMaxColor.name())
           .replace(QString("SIGNAL_MET_COLOR"), methylSignalColor.name())
           .replace(QString("ROW_HEIGHT"), QString("%1").arg(header.rowHeight))
           .replace(QString("ANOTHER_PARAM"), anotherParams);

    return true;
}


bool MethylationPerspectiveTrack::printImage(void){

    //�g���b�N�f�[�^�̃f�B���N�g���ֈړ�����
    QDir graphFileDir(QApplication::applicationDirPath());
    if(!graphFileDir.exists(RevisionsDirName)){
        return false;
    }
    if(!graphFileDir.cd(RevisionsDirName)){
        return false;
    }
    //species directory
    if(!graphFileDir.exists(CGIParam.species)){
        return false;
    }
    if(!graphFileDir.cd(CGIParam.species)){
        return false;
    }
    //revision directory
    if(!graphFileDir.exists(CGIParam.revision)){
        return false;
    }
    if(!graphFileDir.cd(CGIParam.revision)){
        return false;
    }

    //BinSeq�̊m�F
    QString binseqFileName(BinSeqFileTemp.arg(CGIParam.species).arg(CGIParam.revision));
    if(!graphFileDir.exists(binseqFileName)){
        return false;
    }
    BinSeq::FileReader br;
    if(!br.setFile(graphFileDir.filePath(binseqFileName))){
        return false;
    }

    //track dir
    if(!graphFileDir.exists(MethylationPerspectiveTrackDirName)){
        return false;
    }
    if(!graphFileDir.cd(MethylationPerspectiveTrackDirName)){
        return false;
    }
    //graphfile�����݂��邱�Ƃ��m�F
    QString graphFileName=GraphFileNameTemplate.arg(CGIParam.track_name);
    if(!graphFileDir.exists(graphFileName)){
        return false;
    }

    //graphfile���I�[�v��
    MethylationPerspectiveFileReader mr;
    if(!mr.setFile(graphFileDir.filePath(graphFileName))){
        return false;
    }
    //const GraphFile::Header& header=mr.getBasicTrackInfo();
    GraphFile::Header header=mr.getBasicTrackInfo();

    int strand;
    quint32 bpLower, bpUpper;;
    if(CGIParam.start<CGIParam.end){
        strand=1;
        bpLower=CGIParam.start;
        bpUpper=CGIParam.end;
    }
    else{
        strand=-1;
        bpLower=CGIParam.end;
        bpUpper=CGIParam.start;
    }
    quint64 bpWidth=bpUpper-bpLower+1;

    //CGI�p�����[�^�i�R���t�B�O�֘A�j�̐���
    bool CG(false), CHG(false), CHH(false), AllC(true),Invisible(false), MethylationSignal(false), ShowGrid(false), ShowRead(true);
    QString colorTemp("#%1");
    int readScale(4);

    for(int i=0;i<CGIParam.anotherParam.size(); i++){
        if(CGIParam.anotherParam[i].first=="readNumberThreshold"){
            int IntThreshold=CGIParam.anotherParam[i].second.toInt();
            readNumberThreshold=IntThreshold;
        }
        else if(CGIParam.anotherParam[i].first=="CG"){
            if(CGIParam.anotherParam[i].second=="true"){
                CG=true;
                AllC=false;
                Invisible=false;
            }
        }
        else if(CGIParam.anotherParam[i].first=="CHG"){
            if(CGIParam.anotherParam[i].second=="true"){
                CHG=true;
                AllC=false;
                Invisible=false;
            }
        }
        else if(CGIParam.anotherParam[i].first=="CHH"){
            if(CGIParam.anotherParam[i].second=="true"){
                CHH=true;
                AllC=false;
                Invisible=false;
            }
        }
        else if(CGIParam.anotherParam[i].first=="Invisible"){
            if(CGIParam.anotherParam[i].second=="true"){
                CHH=false;
                AllC=false;
                Invisible=true;
            }
        }
        else if(CGIParam.anotherParam[i].first=="Methylation_Signal"){
            if(CGIParam.anotherParam[i].second=="true"){
                MethylationSignal=true;
            }
        }
        else if(CGIParam.anotherParam[i].first=="read"){
            if(CGIParam.anotherParam[i].second=="false"){
                ShowRead=false;
            }
        }
        else if(CGIParam.anotherParam[i].first=="show_grid"){
            if(CGIParam.anotherParam[i].second=="true"){
                ShowGrid=true;
            }
            else{
                ShowGrid=false;
            }
        }
        else if(CGIParam.anotherParam[i].first=="read_number_threshold"){
            int value=CGIParam.anotherParam[i].second.toInt();
            if(value>0){
                readNumberThreshold=value;
            }
        }
        else if(CGIParam.anotherParam[i].first=="read_color"){
            QByteArray colorArray=CGIParam.anotherParam[i].second.toLatin1();
            QString colorString=QUrl::fromPercentEncoding(colorArray);
#if QT_VERSION >= 0x040700
            if(QColor::isValidColor(colorString)){
                readColor.setNamedColor(colorString);
            }
#else
            readColor.setNamedColor(colorString);
#endif
        }
        
        else if(CGIParam.anotherParam[i].first=="read_scale"){
            readScale=CGIParam.anotherParam[i].second.toInt();
        }

        else if(CGIParam.anotherParam[i].first=="methyl_max_color"){
            QByteArray colorArray=CGIParam.anotherParam[i].second.toLatin1();
            QString colorString=QUrl::fromPercentEncoding(colorArray);
#if QT_VERSION >= 0x040700
            if(QColor::isValidColor(colorString)){
                methylMaxColor.setNamedColor(colorString);
            }
#else
            methylMaxColor.setNamedColor(colorString);
#endif
        }
        else if(CGIParam.anotherParam[i].first=="methyl_ave_color"){
            QByteArray colorArray=CGIParam.anotherParam[i].second.toLatin1();
            QString colorString=QUrl::fromPercentEncoding(colorArray);
#if QT_VERSION >= 0x040700
            if(QColor::isValidColor(colorString)){
                methylAveColor.setNamedColor(colorString);
            }
#else
            methylAveColor.setNamedColor(colorString);
#endif
        }
        else if(CGIParam.anotherParam[i].first=="methyl_signal_color"){
            QByteArray colorArray=CGIParam.anotherParam[i].second.toLatin1();
            QString colorString=QUrl::fromPercentEncoding(colorArray);
#if QT_VERSION >= 0x040700
            if(QColor::isValidColor(colorString)){
                methylSignalColor.setNamedColor(colorString);
            }
#else
            methylSignalColor.setNamedColor(colorString);
#endif
        }
        //�摜�����ύX�v���ɑ΂��铮��
        else if(CGIParam.anotherParam[i].first=="row_height"){
            if(CGIParam.anotherParam[i].second!="undefined"){
                header.rowHeight = CGIParam.anotherParam[i].second.toInt();
            }
        }
        else if(CGIParam.anotherParam[i].first=="grid_color"){
            QByteArray colorArray=CGIParam.anotherParam[i].second.toLatin1();
            QString colorString=QUrl::fromPercentEncoding(colorArray);
#if QT_VERSION >= 0x040700
            if(QColor::isValidColor(colorString)){
                gridColor.setNamedColor(colorString);
            }
#else
            gridColor.setNamedColor(colorString);
#endif
        }
    }

    //���~�b�^�[�ݒ�
    if(bpWidth>maxBpWidth){
        //�}�̍쐬
        QImage image(CGIParam.width, header.rowHeight, QImage::Format_ARGB32);
        QPainter painter(&image);
        painter.fillRect(image.rect(), header.bgColor);
        painter.setPen(header.fgColor);
        painter.drawText(	image.rect(),
                            Qt::AlignRight|Qt::AlignVCenter,
                            QString("Exceed limit to be shown. Less than %1bp in width allowed.").arg(maxBpWidth));
        return true;
    }

    //�Q�m���z��̎擾
    quint64 targetSize;
    if(!br.targetExists(CGIParam.target, targetSize)){
        return false;
    }
    int rightExtra;
    if(bpUpper>=targetSize){
        rightExtra=0;
    }
    else if(bpUpper+1==targetSize){
        rightExtra=1;
    }
    else if(bpUpper+2<=targetSize){
        rightExtra=2;
    }
    int leftExtra;
    if(bpLower==1){
        leftExtra=0;
    }
    else if(bpLower==2){
        leftExtra=1;
    }
    else if(bpLower>=3){
        leftExtra=2;
    }
    QByteArray seq;
    if(!br.getSeq(CGIParam.target, bpLower-leftExtra, bpUpper+rightExtra, seq)){
        return false;
    }
    //���`�����f�[�^�擾�ʒu�̏W�v
    QBitArray fwMPos(bpWidth, false), rvMPos(bpWidth, false);
    for(int mpos=0, spos=leftExtra; mpos<bpWidth; mpos++, spos++){
        if(seq[spos]=='C'){
            if(AllC){
                fwMPos[mpos]=true;
            }
            else{
                if(CG){
                    if(spos+1<seq.size()&&seq[spos+1]=='G'){
                        fwMPos[mpos]=true;
                    }
                }
                if(CHG){
                    if(spos+2<seq.size()&&seq[spos+1]!='G'&&seq[spos+2]=='G'){
                        fwMPos[mpos]=true;
                    }
                }
                if(CHH){
                    if(spos+2<seq.size()&&seq[spos+1]!='G'&&seq[spos+1]!='G'){
                        fwMPos[mpos]=true;
                    }
                }
            }
        }
        else if(seq[spos]=='G'){
            if(AllC){
                rvMPos[mpos]=true;
            }
            else{
                if(CG){
                    if(spos-1>=0&&seq[spos-1]=='C'){
                        rvMPos[mpos]=true;
                    }
                }
                if(CHG){
                    if(spos-2>=0&&seq[spos-1]!='C'&&seq[spos-2]=='C'){
                        rvMPos[mpos]=true;
                    }
                }
                if(CHH){
                    if(spos-2>=0&&seq[spos-1]!='C'&&seq[spos-2]!='C'){
                        rvMPos[mpos]=true;
                    }
                }
            }
        }
    }


    //���`�����f�[�^�̎擾
    //QVector<quint16> methylation_data_f, cytosine_data_f, methylation_data_r, cytosine_data_r;
    QVector<quint16> methylation_data_f, cytosine_data_f, methylation_data_r, cytosine_data_r;
    if(!mr.getData(CGIParam.target, bpLower, bpUpper, 1, methylation_data_f, cytosine_data_f)){
        return false;
    }
    if(!mr.getData(CGIParam.target, bpLower, bpUpper, -1, methylation_data_r, cytosine_data_r)){
        return false;
    }
    if(methylation_data_f.size()!=bpWidth||cytosine_data_f.size()!=bpWidth){
        return false;
    }
    if(methylation_data_r.size()!=bpWidth||cytosine_data_r.size()!=bpWidth){
        return false;
    }

    if(CGIParam.width==0){
        return false;
    }

    quint64 pixelWidth=CGIParam.width;

    //�s�N�Z�����̍ő�V�O�i���l�����߂�
    QVector<int> pixelSignalF(CGIParam.width, 0);
    QVector<int> pixelSignalR(CGIParam.width, 0);
    QVector<int> totalSignalF(CGIParam.width, 0);
    QVector<int> totalSignalCountF(CGIParam.width, 0);
    QVector<int> readCountF(CGIParam.width, 0);
    QVector<int> totalCountF(CGIParam.width, 0);
    QVector<int> totalSignalR(CGIParam.width, 0);
    QVector<int> totalSignalCountR(CGIParam.width, 0);
    QVector<int> readCountR(CGIParam.width, 0);
    QVector<int> totalCountR(CGIParam.width, 0);
    QBitArray MethylationSignalF(CGIParam.width, false);
    QBitArray MethylationSignalR(CGIParam.width, false);

    quint32 i, j;
    float max=0;
    float min;
    for(i=bpLower; i<=bpUpper; i++){
        int bpOffset=i-bpLower;
        quint64 bpOffset64=bpOffset;
        int pos1=(int)(bpOffset64*pixelWidth/bpWidth);
        int pos2=(int)((bpOffset64+1)*pixelWidth/bpWidth);
        if(pos2>pos1){
            for(j=pos1; j<pos2; j++){
                //���[�h��
                readCountF[j]+=cytosine_data_f[bpOffset];
                totalCountF[j]++;
                readCountR[j]+=cytosine_data_r[bpOffset];
                totalCountR[j]++;
                //���`������
                if(fwMPos[bpOffset]&&cytosine_data_f[bpOffset]>readNumberThreshold){
                    int valf=(header.rowHeight*methylation_data_f[bpOffset])/cytosine_data_f[bpOffset];
                    pixelSignalF[j]=qMax(pixelSignalF[j], valf);
                    totalSignalF[j]+=valf;
                    totalSignalCountF[j]++;
                    
                }
                if(rvMPos[bpOffset]&&cytosine_data_r[bpOffset]>readNumberThreshold){
                    int valr=(header.rowHeight*methylation_data_r[bpOffset])/cytosine_data_r[bpOffset];
                    pixelSignalR[j]=qMax(pixelSignalR[j], valr);
                    totalSignalR[j]+=valr;
                    totalSignalCountR[j]++;

                }
                if(fwMPos[bpOffset]){
                    MethylationSignalF[j]=true;
                }
                if(rvMPos[bpOffset]){
                    MethylationSignalR[j]=true;
                }
            }
        }
        else{
            //���[�h��
            readCountF[pos1]+=cytosine_data_f[bpOffset];
            totalCountF[pos1]++;
            readCountR[pos1]+=cytosine_data_r[bpOffset];
            totalCountR[pos1]++;
            //���`������
            if(fwMPos[bpOffset]&&cytosine_data_f[bpOffset]>readNumberThreshold){
                int valf=(header.rowHeight*methylation_data_f[bpOffset])/cytosine_data_f[bpOffset];
                pixelSignalF[pos1]=qMax(pixelSignalF[pos1], valf);
                totalSignalF[pos1]+=valf;
                totalSignalCountF[j]++;

            }
            if(rvMPos[bpOffset]&&cytosine_data_r[bpOffset]>readNumberThreshold){
                int valr=(header.rowHeight*methylation_data_r[bpOffset])/cytosine_data_r[bpOffset];
                pixelSignalR[pos1]=qMax(pixelSignalR[pos1], valr);
                totalSignalR[pos1]+=valr;
                totalSignalCountR[j]++;
            }
            if(fwMPos[bpOffset]){
                MethylationSignalF[j]=true;
            }
            if(rvMPos[bpOffset]){
                MethylationSignalR[j]=true;
            }
        }
    }

    //���ꂼ��̉��s�N�Z�����ɏc�s�N�Z�������v�Z
    //���`�������͏퐔�X�P�[��
    //���[�h���͑ΐ��X�P�[��
    
    for(i=0; i<CGIParam.width; i++){
        if(totalSignalCountF[i]>0){
            totalSignalF[i]=totalSignalF[i]/totalSignalCountF[i];
        }
        else{
            totalSignalF[i]=0;
        }

        if(totalCountF[i]>0){
            //totalSignalF[i]=totalSignalF[i]/totalSignalCountF[i];
            //readCountF[i]=log(readCountF[i]/totalCountF[i], 2, 15);
            readCountF[i]=log(readCountF[i]/totalCountF[i], 2, (header.rowHeight/readScale));
            if(readCountF[i]>header.rowHeight){
                readCountF[i]=header.rowHeight;
            }
        }
        else{
            //totalSignalF[i]=0;
            readCountF[i]=0;
        }
        if(totalSignalCountR[i]>0){
            totalSignalR[i]=totalSignalR[i]/totalSignalCountR[i];
        }
        else{
            totalSignalR[i];
        }
        if(totalCountR[i]>0){
            //totalSignalR[i]=totalSignalR[i]/totalSignalCountR[i];
            //readCountR[i]=log(readCountR[i]/totalCountR[i], 2, 15);
            readCountR[i]=log(readCountR[i]/totalCountR[i], 2, (header.rowHeight/readScale));
            if(readCountF[i]>header.rowHeight){
                readCountF[i]=header.rowHeight;
            }
        }
        else{
            //totalSignalR[i]=0;
            readCountR[i]=0;
        }
    }

    //�}�̍쐬
    QImage image(CGIParam.width, header.rowHeight*2+2, QImage::Format_ARGB32);

    QPainter painter(&image);
    painter.fillRect(image.rect(), header.bgColor);
    QPen defaultPen=painter.pen();

    //grid���v������Ă���Ε`��
    if(ShowGrid){
        //Grid��QPen��p��
        QPen gridPen(Qt::NoBrush, 1, Qt::DotLine);
        gridPen.setColor(gridColor);
        painter.setPen(gridPen);

        if(readScale==1){
            //	for(int i=0; i<1; i++){
            //		if(i>0){
            painter.setPen(gridColor);
            painter.drawLine(0, header.rowHeight+1-(header.rowHeight/1)*1, CGIParam.width-1, header.rowHeight+1-(header.rowHeight/1)*1);
            painter.drawLine(0, header.rowHeight+1+(header.rowHeight/1)*1, CGIParam.width-1, header.rowHeight+1+(header.rowHeight/1)*1);
            //		}
            //	}
        }
        if(readScale==2){
            for(int i=0; i<2; i++){
                if(i>0){
                    painter.setPen(gridColor);
                    painter.drawLine(0, header.rowHeight+1-(header.rowHeight/2)*i, CGIParam.width-1, header.rowHeight+1-(header.rowHeight/2)*i);
                    painter.drawLine(0, header.rowHeight+1+(header.rowHeight/2)*i, CGIParam.width-1, header.rowHeight+1+(header.rowHeight/2)*i);
                }
            }
        }
        if(readScale%3==0){
            for(int i=0; i<3; i++){
                if(i>0){
                    painter.setPen(gridPen);
                    painter.drawLine(0, header.rowHeight+1-(header.rowHeight/3)*i, CGIParam.width-1, header.rowHeight+1-(header.rowHeight/3)*i);
                    painter.drawLine(0, header.rowHeight+1+(header.rowHeight/3)*i, CGIParam.width-1, header.rowHeight+1+(header.rowHeight/3)*i);
                }
            }
        }
        if(readScale%4==0){
            for(int i=0; i<4; i++){
                if((header.rowHeight/4)*i==(header.rowHeight/4)*2||(header.rowHeight/4)*i==header.rowHeight){
                    painter.setPen(gridColor);
                    painter.drawLine(0, header.rowHeight+1-(header.rowHeight/4)*i, CGIParam.width-1, header.rowHeight+1-(header.rowHeight/4)*i);
                    painter.drawLine(0, header.rowHeight+1+(header.rowHeight/4)*i, CGIParam.width-1, header.rowHeight+1+(header.rowHeight/4)*i);
                }
                else if(i>0)
                {
                    painter.setPen(gridPen);
                    painter.drawLine(0, header.rowHeight+1-(header.rowHeight/4)*i, CGIParam.width-1, header.rowHeight+1-(header.rowHeight/4)*i);
                    painter.drawLine(0, header.rowHeight+1+(header.rowHeight/4)*i, CGIParam.width-1, header.rowHeight+1+(header.rowHeight/4)*i);
                }
            }
        }
        if(readScale%5==0){
            for(int i=0; i<5; i++){
                if(i>0){
                    painter.setPen(gridPen);
                    painter.drawLine(0, header.rowHeight+1-(header.rowHeight/5)*i, CGIParam.width-1, header.rowHeight+1-(header.rowHeight/5)*i);
                    painter.drawLine(0, header.rowHeight+1+(header.rowHeight/5)*i, CGIParam.width-1, header.rowHeight+1+(header.rowHeight/5)*i);
                }
            }
        }
        if(readScale%7==0){
            for(int i=0; i<7; i++){
                if((header.rowHeight/7)*i==(header.rowHeight/7)*2||(header.rowHeight/7)*i==(header.rowHeight/7)*4||(header.rowHeight/7)*i==(header.rowHeight/7)*6)
                {
                    painter.setPen(gridPen);
                    painter.drawLine(0, header.rowHeight+1-(header.rowHeight/7)*i, CGIParam.width-1, header.rowHeight+1-(header.rowHeight/7)*i);
                    painter.drawLine(0, header.rowHeight+1+(header.rowHeight/7)*i, CGIParam.width-1, header.rowHeight+1+(header.rowHeight/7)*i);
                }
            }
        }
        //painter.drawLine(0, header.rowHeight+1-15, CGIParam.width-1, header.rowHeight+1-15);
        //painter.setPen(gridColor);
        //painter.drawLine(0, header.rowHeight+1-30, CGIParam.width-1, header.rowHeight+1-30);
        //painter.setPen(gridPen);
        //painter.drawLine(0, header.rowHeight+1-45, CGIParam.width-1, header.rowHeight+1-45);
        //painter.setPen(gridColor);
        //painter.drawLine(0, header.rowHeight+1-60, CGIParam.width-1, header.rowHeight+1-60);
        //painter.setPen(gridPen);
        //painter.drawLine(0, header.rowHeight+1+15, CGIParam.width-1, header.rowHeight+1+15);
        //painter.setPen(gridColor);
        //painter.drawLine(0, header.rowHeight+1+30, CGIParam.width-1, header.rowHeight+1+30);
        //painter.setPen(gridPen);
        //painter.drawLine(0, header.rowHeight+1+45, CGIParam.width-1, header.rowHeight+1+45);
        //painter.setPen(gridColor);
        //painter.drawLine(0, header.rowHeight+1+60, CGIParam.width-1, header.rowHeight+1+60);
        //painter.setPen(defaultPen);
    }

    for(i=0; i<CGIParam.width; i++){
        //���[�h��
        if(ShowRead){
            painter.setPen(readColor);
            painter.drawLine(i, header.rowHeight, i, header.rowHeight-readCountF[i]);
            painter.drawLine(i, header.rowHeight, i, header.rowHeight+readCountR[i]);
        }

        //���`������
        //�����
        painter.setPen(methylMaxColor);
        painter.drawLine(i, header.rowHeight, i, header.rowHeight-pixelSignalF[i]);

        if(MethylationSignal){
            if (MethylationSignalF[i]){
                painter.setPen(methylSignalColor);
                painter.drawLine(i, header.rowHeight-pixelSignalF[i], i, 0);
            }
        }
        image.setPixel(i, header.rowHeight-totalSignalF[i], methylAveColor.rgb());


        //������
        painter.setPen(methylMaxColor);
        painter.drawLine(i, header.rowHeight, i, header.rowHeight+pixelSignalR[i]);

        if(MethylationSignal){
            if (MethylationSignalR[i]){
                painter.setPen(methylSignalColor);
                painter.drawLine(i, header.rowHeight+pixelSignalR[i], i, header.rowHeight+header.rowHeight);
            }
        }
        image.setPixel(i, header.rowHeight+totalSignalR[i], methylAveColor.rgb());

    }

    painter.setPen(gridColor);
    painter.drawLine(0, header.rowHeight, CGIParam.width-1, header.rowHeight);

    QImage finalImage;
    if(strand==1){
        finalImage=image;
    }
    if(strand==-1){
        finalImage=image.mirrored(true, true);
    }

#ifdef Q_OS_WIN32
    _setmode( _fileno( stdout ), _O_BINARY );
#endif

    QFile file;
    file.open(stdout, QIODevice::WriteOnly);
    QTextStream out(&file);
    if(CGIParam.is_cgi){
        out << "Content-type: image/png\n"
            << "Pragma: no-cache\n\n";
        out.flush();
    }
    QImageWriter writer(&file, "png");
    if(!writer.canWrite()){
        return false;
    }
    if(!writer.write(finalImage)){
        QString errorString = writer.errorString();
        return false;
    }
    file.flush();
    file.close();

    return true;
}


bool MethylationPerspectiveTrack::printIndexImage(void){

    //�g���b�N�f�[�^�̃f�B���N�g���ֈړ�����
    QDir graphFileDir(QApplication::applicationDirPath());
    if(!graphFileDir.exists(RevisionsDirName)){
        return false;
    }
    if(!graphFileDir.cd(RevisionsDirName)){
        return false;
    }
    //species directory
    if(!graphFileDir.exists(CGIParam.species)){
        return false;
    }
    if(!graphFileDir.cd(CGIParam.species)){
        return false;
    }
    //revision directory
    if(!graphFileDir.exists(CGIParam.revision)){
        return false;
    }
    if(!graphFileDir.cd(CGIParam.revision)){
        return false;
    }
    //graph track dir
    if(!graphFileDir.exists(MethylationPerspectiveTrackDirName)){
        return false;
    }
    if(!graphFileDir.cd(MethylationPerspectiveTrackDirName)){
        return false;
    }
    //graphfile�����݂��邱�Ƃ��m�F
    QString graphFileName=GraphFileNameTemplate.arg(CGIParam.track_name);
    if(!graphFileDir.exists(graphFileName)){
        return false;
    }

    //graphfile���I�[�v��
    MethylationPerspectiveFileReader r;
    if(!r.setFile(graphFileDir.filePath(graphFileName))){
        return false;
    }
    //const GraphFile::Header& header=r.getBasicTrackInfo();
    GraphFile::Header header=r.getBasicTrackInfo();

    int strand;
    quint32 bpLower, bpUpper;;
    if(CGIParam.start<CGIParam.end){
        strand=1;
        bpLower=CGIParam.start;
        bpUpper=CGIParam.end;
    }
    else{
        strand=-1;
        bpLower=CGIParam.end;
        bpUpper=CGIParam.start;
    }
    quint64 bpWidth=bpUpper-bpLower+1;

    //CGI�p�����[�^�i�R���t�B�O�֘A�j�̐���
    bool CG(false), CHG(false), CHH(false), AllC(true),Invisible(false), ShowRead(true);
    QColor readColor(158, 188, 240), methylMaxColor(235, 0, 235), methylAveColor(255, 0, 0), gridColor(0, 0, 255);
    int readScale(4);

    for(int i=0;i<CGIParam.anotherParam.size(); i++){
        if(CGIParam.anotherParam[i].first=="CG"){
            if(CGIParam.anotherParam[i].second=="true"){
                CG=true;
                AllC=false;
                Invisible=false;
            }
        }
        else if(CGIParam.anotherParam[i].first=="CHG"){
            if(CGIParam.anotherParam[i].second=="true"){
                CHG=true;
                AllC=false;
                Invisible=false;
            }
        }
        else if(CGIParam.anotherParam[i].first=="CHH"){
            if(CGIParam.anotherParam[i].second=="true"){
                CHH=true;
                AllC=false;
                Invisible=false;
            }
        }
        else if(CGIParam.anotherParam[i].first=="Invisible"){
            if(CGIParam.anotherParam[i].second=="true"){
                CHH=false;
                AllC=false;
                Invisible=true;
            }
        }
        else if(CGIParam.anotherParam[i].first=="read"){
            if(CGIParam.anotherParam[i].second=="false"){
                ShowRead=false;
            }
        }
        else if(CGIParam.anotherParam[i].first=="readNumberThreshold"){
            int Threshold=CGIParam.anotherParam[i].second.toInt();
            readNumberThreshold=Threshold;
        }
        //�摜�����ύX�v���ɑ΂��铮��
        else if(CGIParam.anotherParam[i].first=="row_height"){
            if(CGIParam.anotherParam[i].second!="undefined"){
                header.rowHeight = CGIParam.anotherParam[i].second.toInt();
            }
        }

        else if(CGIParam.anotherParam[i].first=="read_color"){
            QByteArray colorArray=CGIParam.anotherParam[i].second.toLatin1();
            QString colorString=QUrl::fromPercentEncoding(colorArray);
#if QT_VERSION >= 0x040700
            if(QColor::isValidColor(colorString)){
#endif
                readColor.setNamedColor(colorString);
#if QT_VERSION >= 0x040700
            }
#endif
        }

        else if(CGIParam.anotherParam[i].first=="read_scale"){
            readScale=CGIParam.anotherParam[i].second.toInt();
        }

        else if(CGIParam.anotherParam[i].first=="methyl_max_color"){
            QByteArray colorArray=CGIParam.anotherParam[i].second.toLatin1();
            QString colorString=QUrl::fromPercentEncoding(colorArray);
#if QT_VERSION >= 0x040700
            if(QColor::isValidColor(colorString)){
#endif
                methylMaxColor.setNamedColor(colorString);
#if QT_VERSION >= 0x040700
            }
#endif
        }
        else if(CGIParam.anotherParam[i].first=="methyl_ave_color"){
            QByteArray colorArray=CGIParam.anotherParam[i].second.toLatin1();
            QString colorString=QUrl::fromPercentEncoding(colorArray);
#if QT_VERSION >= 0x040700
            if(QColor::isValidColor(colorString)){
#endif
                methylAveColor.setNamedColor(colorString);
#if QT_VERSION >= 0x040700
            }
#endif
        }
        else if(CGIParam.anotherParam[i].first=="grid_color"){
            QByteArray colorArray=CGIParam.anotherParam[i].second.toLatin1();
            QString colorString=QUrl::fromPercentEncoding(colorArray);
#if QT_VERSION >= 0x040700
            if(QColor::isValidColor(colorString)){
                gridColor.setNamedColor(colorString);
            }
#else
            gridColor.setNamedColor(colorString);
#endif
        }
    }

    //���~�b�^�[�ݒ�
    if(bpWidth>maxBpWidth){
        //�}�̍쐬
        QImage image(IndexWidth, header.rowHeight, QImage::Format_ARGB32);
        QPainter painter(&image);
        painter.fillRect(image.rect(), header.bgColor);
        return true;
    }

    //�}�̍쐬
    QImage image(IndexWidth, header.rowHeight*2+2, QImage::Format_ARGB32);
    QPainter painter(&image);
    painter.fillRect(image.rect(), header.bgColor);
    QPen defaulPen=painter.pen();

    //�t�H���g�̏���
    QFont font(QApplication::font());
    font.setPointSize(header.fontSize);
    painter.setFont(font);
    QFontMetrics fm(font);
    int fontHeight=fm.height();
    int fontWidth=fm.averageCharWidth();

    //Grid��QPen��p��
    QPen gridPen(Qt::NoBrush, 1, Qt::DotLine);
    gridPen.setColor(gridColor);

    //���[�h��
    if(ShowRead){
        //�T���v���F
        painter.setPen(readColor);
        painter.setBrush(readColor);
        painter.drawEllipse(QRect(IndexWidth-1-15, 0, 15, header.rowHeight*2+1));
        //Grid�F
        if(readScale==1){
            //for(int i=0; i<2; i++){
            //if(i>0){
            painter.setPen(gridColor);
            painter.drawLine(IndexWidth-1, header.rowHeight+1-(header.rowHeight/1)*1, IndexWidth-1-15, header.rowHeight+1-(header.rowHeight/1)*1);
            painter.drawLine(IndexWidth-1, header.rowHeight+1+(header.rowHeight/1)*1, IndexWidth-1-15, header.rowHeight+1+(header.rowHeight/1)*1);

            painter.setPen(gridColor);
            QString str=QString::number(pow(2.0, 1));
            painter.drawText(QRect(IndexWidth-1-15-fm.width(1)-2, header.rowHeight+1-(header.rowHeight/1)*1-fontHeight/4, fm.width(str), fontHeight),
                             Qt::AlignRight|Qt::AlignVCenter,
                             QString(str));
            painter.drawText(QRect(IndexWidth-1-15-fm.width(1)-2, header.rowHeight+1+(header.rowHeight/1)*1-fontHeight/1, fm.width(str), fontHeight),
                             Qt::AlignRight|Qt::AlignVCenter,
                             QString(str));
            //}
            //}
        }

        if(readScale==2){
            for(int i=0; i<2; i++){
                if(i>0){
                    painter.setPen(gridColor);
                    painter.drawLine(IndexWidth-1, header.rowHeight+1-(header.rowHeight/2)*i, IndexWidth-1-15, header.rowHeight+1-(header.rowHeight/2)*i);
                    painter.drawLine(IndexWidth-1, header.rowHeight+1+(header.rowHeight/2)*i, IndexWidth-1-15, header.rowHeight+1+(header.rowHeight/2)*i);

                    painter.setPen(gridColor);
                    QString str=QString::number(pow(2.0, i));
                    painter.drawText(QRect(IndexWidth-1-15-fm.width(i)-2, header.rowHeight+1-(header.rowHeight/2)*i-fontHeight/2, fm.width(str), fontHeight),
                                     Qt::AlignRight|Qt::AlignVCenter,
                                     QString(str));
                    painter.drawText(QRect(IndexWidth-1-15-fm.width(i)-2, header.rowHeight+1+(header.rowHeight/2)*i-fontHeight/2, fm.width(str), fontHeight),
                                     Qt::AlignRight|Qt::AlignVCenter,
                                     QString(str));
                }
            }
        }
        if(readScale%3==0){
            for(int i=0; i<3; i++){
                if(i>0){
                    painter.setPen(gridPen);
                    painter.drawLine(IndexWidth-1, header.rowHeight+1-(header.rowHeight/3)*i, IndexWidth-1-15, header.rowHeight+1-(header.rowHeight/3)*i);
                    painter.drawLine(IndexWidth-1, header.rowHeight+1+(header.rowHeight/3)*i, IndexWidth-1-15, header.rowHeight+1+(header.rowHeight/3)*i);

                    if(readScale==3){
                        painter.setPen(gridColor);
                        QString str=QString::number(pow(2.0, i));
                        painter.drawText(QRect(IndexWidth-1-15-fm.width(i)-2, header.rowHeight+1-(header.rowHeight/3)*i-fontHeight/2, fm.width(str), fontHeight),
                                         Qt::AlignRight|Qt::AlignVCenter,
                                         QString(str));
                        painter.drawText(QRect(IndexWidth-1-15-fm.width(i)-2, header.rowHeight+1+(header.rowHeight/3)*i-fontHeight/2, fm.width(str), fontHeight),
                                         Qt::AlignRight|Qt::AlignVCenter,
                                         QString(str));
                    }
                    else{
                        int readScale_num=readScale/3;
                        painter.setPen(gridColor);
                        QString str=QString::number(pow(2.0, i*readScale_num));
                        painter.drawText(QRect(IndexWidth-1-15-fm.width(i)-2, header.rowHeight+1-(header.rowHeight/3)*i-fontHeight/2, fm.width(str), fontHeight),
                                         Qt::AlignRight|Qt::AlignVCenter,
                                         QString(str));
                        painter.drawText(QRect(IndexWidth-1-15-fm.width(i)-2, header.rowHeight+1+(header.rowHeight/3)*i-fontHeight/2, fm.width(str), fontHeight),
                                         Qt::AlignRight|Qt::AlignVCenter,
                                         QString(str));
                    }
                }
            }
        }
        if(readScale%4==0){
            for(int i=0; i<4; i++){
                if((header.rowHeight/4)*i==(header.rowHeight/4)*2||(header.rowHeight/4)*i==header.rowHeight){
                    painter.setPen(gridColor);
                    painter.drawLine(IndexWidth-1, header.rowHeight+1-(header.rowHeight/4)*i, IndexWidth-1-15, header.rowHeight+1-(header.rowHeight/4)*i);
                    painter.drawLine(IndexWidth-1, header.rowHeight+1+(header.rowHeight/4)*i, IndexWidth-1-15, header.rowHeight+1+(header.rowHeight/4)*i);
                }
                else if(i>0)
                {
                    painter.setPen(gridPen);
                    painter.drawLine(IndexWidth-1, header.rowHeight+1-(header.rowHeight/4)*i, IndexWidth-1-15, header.rowHeight+1-(header.rowHeight/4)*i);
                    painter.drawLine(IndexWidth-1, header.rowHeight+1+(header.rowHeight/4)*i, IndexWidth-1-15, header.rowHeight+1+(header.rowHeight/4)*i);
                }

                if(readScale==4 && i>0){
                    painter.setPen(gridColor);
                    QString str=QString::number(pow(2.0, i));
                    painter.drawText(QRect(IndexWidth-1-15-fm.width(i)-2, header.rowHeight+1-(header.rowHeight/4)*i-fontHeight/2, fm.width(str), fontHeight),
                                     Qt::AlignRight|Qt::AlignVCenter,
                                     QString(str));
                    painter.drawText(QRect(IndexWidth-1-15-fm.width(i)-2, header.rowHeight+1+(header.rowHeight/4)*i-fontHeight/2, fm.width(str), fontHeight),
                                     Qt::AlignRight|Qt::AlignVCenter,
                                     QString(str));
                }
                else if(i>0){
                    int readScale_num=readScale/4;
                    painter.setPen(gridColor);
                    QString str=QString::number(pow(2.0, i*readScale_num));
                    painter.drawText(QRect(IndexWidth-1-15-fm.width(i)-2, header.rowHeight+1-(header.rowHeight/4)*i-fontHeight/2, fm.width(str), fontHeight),
                                     Qt::AlignRight|Qt::AlignVCenter,
                                     QString(str));
                    painter.drawText(QRect(IndexWidth-1-15-fm.width(i)-2, header.rowHeight+1+(header.rowHeight/4)*i-fontHeight/2, fm.width(str), fontHeight),
                                     Qt::AlignRight|Qt::AlignVCenter,
                                     QString(str));
                }
            }
        }
        if(readScale%5==0){
            for(int i=0; i<5; i++){
                if(i>0){
                    painter.setPen(gridPen);
                    painter.drawLine(IndexWidth-1, header.rowHeight+1-(header.rowHeight/5)*i, IndexWidth-1-15, header.rowHeight+1-(header.rowHeight/5)*i);
                    painter.drawLine(IndexWidth-1, header.rowHeight+1+(header.rowHeight/5)*i, IndexWidth-1-15, header.rowHeight+1+(header.rowHeight/5)*i);

                    if(readScale==5){
                        painter.setPen(gridColor);
                        QString str=QString::number(pow(2.0, i));
                        painter.drawText(QRect(IndexWidth-1-15-fm.width(i)-2, header.rowHeight+1-(header.rowHeight/5)*i-fontHeight/2, fm.width(str), fontHeight),
                                         Qt::AlignRight|Qt::AlignVCenter,
                                         QString(str));
                        painter.drawText(QRect(IndexWidth-1-15-fm.width(i)-2, header.rowHeight+1+(header.rowHeight/5)*i-fontHeight/2, fm.width(str), fontHeight),
                                         Qt::AlignRight|Qt::AlignVCenter,
                                         QString(str));
                    }
                    else{
                        int readScale_num=readScale/5;
                        painter.setPen(gridColor);
                        QString str=QString::number(pow(2.0, i*readScale_num));
                        painter.drawText(QRect(IndexWidth-1-15-fm.width(i)-2, header.rowHeight+1-(header.rowHeight/5)*i-fontHeight/2, fm.width(str), fontHeight),
                                         Qt::AlignRight|Qt::AlignVCenter,
                                         QString(str));
                        painter.drawText(QRect(IndexWidth-1-15-fm.width(i)-2, header.rowHeight+1+(header.rowHeight/5)*i-fontHeight/2, fm.width(str), fontHeight),
                                         Qt::AlignRight|Qt::AlignVCenter,
                                         QString(str));
                    }
                }
            }
        }
        if(readScale%7==0){
            for(int i=0; i<7; i++){
                if((header.rowHeight/7)*i==(header.rowHeight/7)*2||(header.rowHeight/7)*i==(header.rowHeight/7)*4||(header.rowHeight/7)*i==(header.rowHeight/7)*6)
                {
                    painter.setPen(gridPen);
                    painter.drawLine(IndexWidth-1, header.rowHeight+1-(header.rowHeight/7)*i, IndexWidth-1-15, header.rowHeight+1-(header.rowHeight/7)*i);
                    painter.drawLine(IndexWidth-1, header.rowHeight+1+(header.rowHeight/7)*i, IndexWidth-1-15, header.rowHeight+1+(header.rowHeight/7)*i);
                }

                if(readScale==7 && (header.rowHeight/7)*i==(header.rowHeight/7)*2||(header.rowHeight/7)*i==(header.rowHeight/7)*4||(header.rowHeight/7)*i==(header.rowHeight/7)*6){
                    painter.setPen(gridColor);
                    QString str=QString::number(pow(2.0, i));
                    painter.drawText(QRect(IndexWidth-1-15-fm.width(i)-2, header.rowHeight+1-(header.rowHeight/7)*i-fontHeight/2, fm.width(str), fontHeight),
                                     Qt::AlignRight|Qt::AlignVCenter,
                                     QString(str));
                    painter.drawText(QRect(IndexWidth-1-15-fm.width(i)-2, header.rowHeight+1+(header.rowHeight/7)*i-fontHeight/2, fm.width(str), fontHeight),
                                     Qt::AlignRight|Qt::AlignVCenter,
                                     QString(str));
                }
                else if(i>7 && (header.rowHeight/7)*i==(header.rowHeight/7)*2||(header.rowHeight/7)*i==(header.rowHeight/7)*4||(header.rowHeight/7)*i==(header.rowHeight/7)*6){
                    int readScale_num=readScale/7;
                    painter.setPen(gridColor);
                    QString str=QString::number(pow(2.0, i*readScale_num));
                    painter.drawText(QRect(IndexWidth-1-15-fm.width(i)-2, header.rowHeight+1-(header.rowHeight/7)*i-fontHeight/2, fm.width(str), fontHeight),
                                     Qt::AlignRight|Qt::AlignVCenter,
                                     QString(str));
                    painter.drawText(QRect(IndexWidth-1-15-fm.width(i)-2, header.rowHeight+1+(header.rowHeight/7)*i-fontHeight/2, fm.width(str), fontHeight),
                                     Qt::AlignRight|Qt::AlignVCenter,
                                     QString(str));
                }
            }
        }

        //painter.setPen(gridPen);
        //painter.drawLine(IndexWidth-1, header.rowHeight+1-15, IndexWidth-1-15, header.rowHeight+1-15);
        //painter.setPen(gridColor);
        //painter.drawLine(IndexWidth-1, header.rowHeight+1-30, IndexWidth-1-15, header.rowHeight+1-30);
        //painter.setPen(gridPen);
        //painter.drawLine(IndexWidth-1, header.rowHeight+1-45, IndexWidth-1-15, header.rowHeight+1-45);
        //painter.setPen(gridColor);
        //painter.drawLine(IndexWidth-1, header.rowHeight+1-60, IndexWidth-1-15, header.rowHeight+1-60);
        //painter.setPen(gridPen);
        //painter.drawLine(IndexWidth-1, header.rowHeight+1+15, IndexWidth-1-15, header.rowHeight+1+15);
        //painter.setPen(gridColor);
        //painter.drawLine(IndexWidth-1, header.rowHeight+1+30, IndexWidth-1-15, header.rowHeight+1+30);
        //painter.setPen(gridPen);
        //painter.drawLine(IndexWidth-1, header.rowHeight+1+45, IndexWidth-1-15, header.rowHeight+1+45);
        //painter.setPen(gridColor);
        //painter.drawLine(IndexWidth-1, header.rowHeight+1+60, IndexWidth-1-15, header.rowHeight+1+60);
        //��������
        //painter.setPen(gridColor);
        //painter.drawText(	QRect(IndexWidth-1-15-fm.width("2")-2, header.rowHeight+1-15-fontHeight/2, fm.width("2"), fontHeight),
        //					Qt::AlignRight|Qt::AlignVCenter,
        //					QString("2"));
        //painter.drawText(	QRect(IndexWidth-1-15-fm.width("4")-2, header.rowHeight+1-30-fontHeight/2, fm.width("4"), fontHeight),
        //					Qt::AlignRight|Qt::AlignVCenter,
        //					QString("4"));
        //painter.drawText(	QRect(IndexWidth-1-15-fm.width("8")-2, header.rowHeight+1-45-fontHeight/2, fm.width("8"), fontHeight),
        //					Qt::AlignRight|Qt::AlignVCenter,
        //					QString("8"));
        //painter.drawText(	QRect(IndexWidth-1-15-fm.width("2")-2, header.rowHeight+1+15-fontHeight/2, fm.width("2"), fontHeight),
        //					Qt::AlignRight|Qt::AlignVCenter,
        //					QString("2"));
        //painter.drawText(	QRect(IndexWidth-1-15-fm.width("4")-2, header.rowHeight+1+30-fontHeight/2, fm.width("4"), fontHeight),
        //					Qt::AlignRight|Qt::AlignVCenter,
        //					QString("4"));
        //painter.drawText(	QRect(IndexWidth-1-15-fm.width("8")-2, header.rowHeight+1+45-fontHeight/2, fm.width("8"), fontHeight),
        //					Qt::AlignRight|Qt::AlignVCenter,
        //					QString("8"));

        painter.rotate(90);
        painter.drawText(	QRect(	0,
                                    -(IndexWidth-1-15-fm.width("8")-3)+1,
                                    header.rowHeight,
                                    fm.height()
                                    ),
                            Qt::AlignCenter,
                            QString("# of reads")
                            );
        painter.drawText(	QRect(	header.rowHeight+2,
                                    -(IndexWidth-1-15-fm.width("8")-3)+1,
                                    header.rowHeight,
                                    fm.height()
                                    ),
                            Qt::AlignCenter,
                            QString("# of reads")
                            );
        painter.rotate(-90);
    }


    painter.setPen(methylMaxColor);
    for(int i=IndexWidth/2-1-2; i<=IndexWidth/2-1+12; i++){
        int height=qrand()%header.rowHeight;
        painter.drawLine(i, header.rowHeight, i, header.rowHeight-height);
        painter.drawLine(i, header.rowHeight+2, i, header.rowHeight+2+height);
        image.setPixel(i, header.rowHeight-height/2, methylAveColor.rgba());
        image.setPixel(i, header.rowHeight+2+height/2, methylAveColor.rgba());
    }

    painter.setPen(gridPen);
    painter.drawLine(IndexWidth/2-1+12, header.rowHeight+1-(header.rowHeight/4*1), IndexWidth/2-1-2, header.rowHeight+1-(header.rowHeight/4*1));
    painter.setPen(gridColor);
    painter.drawLine(IndexWidth/2-1+12, header.rowHeight+1-(header.rowHeight/4*2), IndexWidth/2-1-2, header.rowHeight+1-(header.rowHeight/4*2));
    painter.setPen(gridPen);
    painter.drawLine(IndexWidth/2-1+12, header.rowHeight+1-(header.rowHeight/4*3), IndexWidth/2-1-2, header.rowHeight+1-(header.rowHeight/4*3));
    painter.setPen(gridColor);
    painter.drawLine(IndexWidth/2-1+12, header.rowHeight+1-(header.rowHeight/4*4), IndexWidth/2-1-2, header.rowHeight+1-(header.rowHeight/4*4));
    painter.setPen(gridPen);
    painter.drawLine(IndexWidth/2-1+12, header.rowHeight+1+(header.rowHeight/4*1), IndexWidth/2-1-2, header.rowHeight+1+(header.rowHeight/4*1));
    painter.setPen(gridColor);
    painter.drawLine(IndexWidth/2-1+12, header.rowHeight+1+(header.rowHeight/4*2), IndexWidth/2-1-2, header.rowHeight+1+(header.rowHeight/4*2));
    painter.setPen(gridPen);
    painter.drawLine(IndexWidth/2-1+12, header.rowHeight+1+(header.rowHeight/4*3), IndexWidth/2-1-2, header.rowHeight+1+(header.rowHeight/4*3));
    painter.setPen(gridColor);
    painter.drawLine(IndexWidth/2-1+12, header.rowHeight+1+(header.rowHeight/4*4), IndexWidth/2-1-2, header.rowHeight+1+(header.rowHeight/4*4));

    painter.setPen(gridColor);
    painter.drawText(	QRect(IndexWidth/2-1-4-fm.width("25%"), header.rowHeight+1-(header.rowHeight/4*1)-fontHeight/2, fm.width("25%"), fontHeight),
                        Qt::AlignRight|Qt::AlignVCenter,
                        QString("25%"));
    painter.drawText(	QRect(IndexWidth/2-1-4-fm.width("50%"), header.rowHeight+1-(header.rowHeight/4*2)-fontHeight/2, fm.width("50%"), fontHeight),
                        Qt::AlignRight|Qt::AlignVCenter,
                        QString("50%"));
    painter.drawText(	QRect(IndexWidth/2-1-4-fm.width("75%"), header.rowHeight+1-(header.rowHeight/4*3)-fontHeight/2, fm.width("75%"), fontHeight),
                        Qt::AlignRight|Qt::AlignVCenter,
                        QString("75%"));
    painter.drawText(	QRect(IndexWidth/2-1-4-fm.width("25%"), header.rowHeight+1+(header.rowHeight/4*1)-fontHeight/2, fm.width("25%"), fontHeight),
                        Qt::AlignRight|Qt::AlignVCenter,
                        QString("25%"));
    painter.drawText(	QRect(IndexWidth/2-1-4-fm.width("50%"), header.rowHeight+1+(header.rowHeight/4*2)-fontHeight/2, fm.width("50%"), fontHeight),
                        Qt::AlignRight|Qt::AlignVCenter,
                        QString("50%"));
    painter.drawText(	QRect(IndexWidth/2-1-4-fm.width("75%"), header.rowHeight+1+(header.rowHeight/4*3)-fontHeight/2, fm.width("75%"), fontHeight),
                        Qt::AlignRight|Qt::AlignVCenter,
                        QString("75%"));
    painter.rotate(90);
    painter.drawText(	QRect(	0,
                                -fm.height()-2,
                                header.rowHeight,
                                fm.height()
                                ),
                        Qt::AlignCenter,
                        QString("methyl. rate")
                        );
    painter.drawText(	QRect(	0,
                                -fm.height()*2,
                                header.rowHeight,
                                fm.height()
                                ),
                        Qt::AlignCenter,
                        QString("max    ave.")
                        );
    painter.drawText(	QRect(	header.rowHeight+2,
                                -fm.height()-2,
                                header.rowHeight,
                                fm.height()
                                ),
                        Qt::AlignCenter,
                        QString("methyl. rate")
                        );
    painter.drawText(	QRect(	header.rowHeight+2,
                                -fm.height()*2,
                                header.rowHeight,
                                fm.height()
                                ),
                        Qt::AlignCenter,
                        QString("max    ave.")
                        );

    painter.setPen(methylMaxColor);
    painter.drawLine(26, -fm.height()*2+fm.height()/2, 31, -fm.height()*2+fm.height()/2);
    painter.drawLine(header.rowHeight+2+26, -fm.height()*2+fm.height()/2, header.rowHeight+2+31, -fm.height()*2+fm.height()/2);
    painter.setPen(methylAveColor);
    painter.drawLine(53, -fm.height()*2+fm.height()/2, 54, -fm.height()*2+fm.height()/2);
    painter.drawLine(header.rowHeight+2+53, -fm.height()*2+fm.height()/2, header.rowHeight+2+54, -fm.height()*2+fm.height()/2);

    painter.rotate(-90);

    painter.setPen(gridColor);
    painter.drawLine(0, header.rowHeight, IndexWidth-1, header.rowHeight);

#ifdef Q_OS_WIN32
    _setmode( _fileno( stdout ), _O_BINARY );
#endif

    QFile file;
    file.open(stdout, QIODevice::WriteOnly);
    QTextStream out(&file);
    if(CGIParam.is_cgi){
        out << "Content-type: image/png\n"
            << "Pragma: no-cache\n\n";
        out.flush();
    }
    QImageWriter writer(&file, "png");
    if(!writer.canWrite()){
        return false;
    }
    if(!writer.write(image)){
        QString errorString = writer.errorString();
        return false;
    }
    file.flush();
    file.close();

    return true;
}


bool MethylationPerspectiveTrack::printOperation(void){


    return true;
}


bool MethylationPerspectiveTrack::printIndexOperation(void){


    return true;
}

quint32	MethylationPerspectiveTrack::
log(
        const quint32& value,
        const quint32& base,
        const quint32& pixel_per_unit)
{
    if(value==0){
        return 0;
    }
    return (quint32)std::floor(std::log((double)value)/std::log((double)base)*(double)pixel_per_unit);
}


