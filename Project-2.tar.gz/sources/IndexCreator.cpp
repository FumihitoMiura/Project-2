#include "IndexCreator.h"

using namespace DesktopTrack;

IndexCreator::IndexCreator(QObject* parent)
:initialized(false), QObject(parent)
{
	connect(&analyzer, SIGNAL(finished()), this, SLOT(onFinishAnalysis()));
	connect(&creator, SIGNAL(finished()), this, SLOT(onFihishBinseqCreate()));
	connect(&bmapprep, SIGNAL(finished()), this, SLOT(onFinishIndexCreate()));
}

void IndexCreator::
setPathAndRefs(
	const QString& species_,
	const QString& revision_,
	const QString& path_to_binseq, 
	const QString& path_to_index,
	const QStringList& ref_files)
{
	species=species_;
	revision=revision_;
	pathToBinSeq=path_to_binseq;
	pathToIndex=path_to_index;
	refFiles=ref_files;
	initialized=true;
	return;
}

void IndexCreator::
start(void)
{
	//��������BinSeq�t�@�C�������݂������͍͂s��Ȃ�
	QFileInfo info(pathToBinSeq);
	if(info.exists()){
		cerr << "Binseq file already exists." << endl
			 << pathToBinSeq.toStdString() << endl;
		analyzer.setOrder(false);
		analyzer.start();
	}
	else{
		cout << "Analyzing fasta files ....." << endl;
		analyzer.setFilePath(refFiles);
		analyzer.setOrder(true);
		analyzer.start();
	}
}

void IndexCreator::
onFinishAnalysis(void)
{

	//BinSeq�t�@�C��������΂����������쐬����t�������ăv���Z�X���I����
	QFileInfo info(pathToBinSeq);
	if(info.exists()){
		creator.setOrder(false);
		creator.start();
		return;
	}

	cout << "Analysis finished." << endl;

	FastaFileAnalyzer::Process status;
	quint64 processed_data, total_data;
	analyzer.getProcessStatus(status, processed_data, total_data);
	if(processed_data!=total_data){
		cerr << "Some Errors had occured during analyzing reference file(s)." << endl;
		return;
	}
	seqInfoList=analyzer.getSeqInfo();
	if(seqInfoList.size()==0){
		cerr << "Some Errors had occured during analyzing reference file(s)." << endl;
		return;
	}
	BinSeq::Header header;
	header.species=this->species;
	header.revision=this->revision;
	header.ovFgColor=FgColor;
	header.ovBgColor=BgColor;
	header.ovMarkColor=MkColor;
	header.ovRowHeight=RowHeight;
	header.rlFgColor=FgColor;
	header.rlBgColor=BgColor;
	header.rlRowHeight=RowHeight;
	header.bgColorForA=AColor;
	header.bgColorForC=CColor;
	header.bgColorForG=GColor;
	header.bgColorForT=TColor;
	header.bgColorForN=NColor;
	header.bgRowHeight=RowHeight;
	creator.initialize(pathToBinSeq, header, seqInfoList);
	creator.setOrder(true);
	cout << "Creating binseq file ....." << endl;
	creator.start();

}

void IndexCreator::
onFihishBinseqCreate(void)
{
	//��������BMap�t�@�C�������݂������͍͂s��Ȃ�
	QFileInfo info(pathToIndex);
	if(info.exists()){
		cerr << "Index file already exists." << endl
			 << pathToIndex.toStdString() << endl;
		emit processFinished();
		return;
	}

	if(!bmapprep.setBinSeq(pathToBinSeq)){
		cerr << "Couldn't find binseq file." << endl;
		emit processFinished();
		return;
	}
	if(!bmapprep.setTargetFilePath(pathToIndex)){
		cerr << "Couldn't open index file." << endl;
		emit processFinished();
		return;
	}
	cout << "Now making index file ....." << endl;
	bmapprep.start();
}

void IndexCreator::
onFinishIndexCreate(void)
{
	cout << "Index file created." << endl;
	emit processFinished();
}