#include <QtCore>
#include <iostream>
#include <vector>

using namespace std;

#include "MethylationPerspective.h"
#include "MethylationPerspectiveTrack.h"
#include "MPTC.h"
#include "BinSeq.h"
#include "LineBuffer.h"
#include "BisulAlignDispatcher.h"
#include "DesktopTrackCommon.h"

using namespace DesktopTrack;



void showUsage(void){
    cout<< "Usage : MethylationPerspectiveTrackCreator [option1] [value1] ... "<< endl
        << "  [Basic Parameters]"											<< endl
        << "   -species      [string]  : species name"						<< endl
        << "   -revision     [string]  : revision name"						<< endl
		<< "   -track        [string]  : track name"						<< endl
		<< "   -binseq       [string]  : binseq file name"					<< endl
		<< "   -graph        [string]  : path to output file"				<< endl
		<< "   -bisulalign   [strings] : input files"						<< endl
		<< "   -thread       [integer] : number of threads used"			<< endl;
}

QString species;
QString revision;
QString binseqPath;
QStringList dataFilePathList;	//bisulalign
QStringList dataFilePathList2;	//bedGraph
QString trackName;
QString graphFilePath;
int numThread=1;
bool appending_mode=false; //false: create, true: append

bool ProcessSpecies(void)
{

	if(binseqPath.size()>0){
		return true;
	}

	QDir RevisionDir(QCoreApplication::applicationDirPath());
	if(!RevisionDir.exists(RevisionsDirName)){
		cerr << "Coundn't find revision directory.";
		return false;
	}
	if(!RevisionDir.cd(RevisionsDirName)){
		cerr << "Coundn't find revision directory.";
		return false;
	}
	if(species.size()==0){
		cerr << "Species name was not provided." << endl;
		return false;
	}
	if(!RevisionDir.exists(species)){
		cerr << "Species \"" << species.toStdString() << "\" not found.";
		return false;
	}
	if(!RevisionDir.cd(species)){
		cerr << "Species \"" << species.toStdString() << "\" not found.";
		return false;
	}
	if(revision.size()==0){
		cerr << "Revision name was not provided." << endl;
		return false;
	}
	if(!RevisionDir.exists(revision)){
		cerr << "Revision \"" << revision.toStdString() << "\" not found.";
		return false;
	}
	if(!RevisionDir.cd(revision)){
		cerr << "Revision \"" << revision.toStdString() << "\" not found.";
		return false;	}

	QString binseqFileName(BinSeqFileTemp.arg(species).arg(revision));
	if(RevisionDir.exists(binseqFileName)){
		binseqPath=RevisionDir.absoluteFilePath(binseqFileName);
		return true;
	}
	return false;
}

bool ProcessArguments(int argc, char* argv[]){

	if(argc==1){
		cerr << "No arguments were provided." << endl;
		return false;
	}

	int i=1;
	while(i<argc){
		QString option(argv[i]);
		if(option==QString("-species")){
			i++;
			if(i==argc){
				break;
			}
			species=argv[i];
		}
		else if(option==QString("-revision")){
			i++;
			if(i==argc){
				break;
			}
			revision=argv[i];
		}
		else if(option==QString("-track")){
			i++;
			if(i==argc){
				break;
			}
			trackName=argv[i];
		}
		else if(option==QString("-graph")){
			i++;
			if(i==argc){
				break;
			}
			graphFilePath=argv[i];
		}
		else if(option==QString("-binseq")){
			i++;
			if(i==argc){
				break;
			}
			binseqPath=argv[i];
		}
		else if(option==QString("-thread")){
			i++;
			if(i==argc){
				break;
			}
			numThread=QString(argv[i]).toInt();
		}
		else if(option==QString("-bisulalign")){
			i++;
			while(i<argc){
				QString path(argv[i]);
				if(path.startsWith(QChar('-'))){
					i--;
					break;
				}
				QFileInfo info(path);
				if(info.exists()){
					dataFilePathList.append(path);
				}
				else{ //windows
					QDir dir=info.dir();
					QStringList filters;
					filters << info.fileName();
					QFileInfoList infoList=dir.entryInfoList(filters);
					for(int j=0; j<infoList.size(); j++){
						dataFilePathList.append(infoList[j].filePath());
					}
				}
				i++;
			}
		}
		//else if (option == QString("-bedgraph")){
		//	i++;
		//	while (i<argc){
		//		QString path(argv[i]);
		//		if (path.startsWith(QChar('-'))){
		//			i--;
		//			break;
		//		}
		//		QFileInfo info(path);
		//		if (info.exists()){
		//			dataFilePathList2.append(path);
		//		}
		//		else{ //windows
		//			QDir dir = info.dir();
		//			QStringList filters;
		//			filters << info.fileName();
		//			QFileInfoList infoList = dir.entryInfoList(filters);
		//			for (int j = 0; j<infoList.size(); j++){
		//				dataFilePathList2.append(infoList[j].filePath());
		//			}
		//		}
		//		i++;
		//	}
		//}
		else{
			cerr << "Incorrect option parameter usage." << endl
				 << "\"" << option.toStdString() << "\"" << endl; 
			return false;
		}
        i++;
	}
    return true;
}


int main(int argc, char* argv[]){

	QCoreApplication app(argc, argv);
    if(!ProcessArguments(argc, argv)){
        showUsage();
        return 0;
    }
	if(!ProcessSpecies()){
		showUsage();
		return 0;
	}

	if(numThread<1){
		cerr << "Number of threads should be more than zero." << endl;
		showUsage();
		return 0;
	}

	MPTrackCreator trackCreator(numThread, &app);
	QObject::connect(&trackCreator, SIGNAL(allProcessFinished()), &app, SLOT(quit()));

	//creating mode
	if(binseqPath.size()>0&&graphFilePath.size()>0){
		if(trackName.size()==0){
			cerr << "No track name provided." << endl;
			showUsage();
			return 0;
		}
		QFileInfo info(graphFilePath);
		if(info.completeBaseName()!=trackName){
			cerr << "Track name and the basename of output file should be the same." << endl;
			return 0;
		}
		if(info.suffix()!=GraphFileExtension){
			cerr << "Track extension of output file should be \"graph\"." << endl;
			return 0;
		}
		trackCreator.setTrackName(trackName);
		if(!trackCreator.setBinSeq(binseqPath)){
			cerr << "Couldn't set specified graph file:" << binseqPath.toStdString() << "." << endl;
			return 0;
		}
	}
	//appending mode
	else if(binseqPath.size()==0&&graphFilePath.size()>0){
		if(!trackCreator.setGraph(graphFilePath)){
			cerr << "Couldn't set specified graph file:" << graphFilePath.toStdString() << "." << endl;
			return 0;
		}
	}
	//error
	else{
		cerr << "One of followings can be selected exclusively." << endl
			 << " 1, Paired specification of species and revision name." << endl
			 << " 2, Specification of binseq file." << endl
			 << " 3, Specification of graph file (effective only for appending mode)" << endl << endl;
		showUsage();
		return 0;
	}
	trackCreator.setOutfilePath(graphFilePath);

	if(!trackCreator.setBisulAlignPaths(dataFilePathList)){
		cerr << "Couldn't set bisulalign paths." << endl;
		return 0;
	}
	//if (!trackCreator.setBedGraphPaths(dataFilePathList2)){
	//	cerr << "Couldn't set bedGraph paths." << endl;
	//	return 0;
	//}
	trackCreator.start();
	app.exec();

	return 0;

}



