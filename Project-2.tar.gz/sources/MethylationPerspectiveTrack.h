#include <QtCore>
#include <QtXml>
#include <cmath>

#include <vector>

using namespace std;

#ifndef METHYLATION_PERSPECTIVE_TRACK_H
#define METHYLATION_PERSPECTIVE_TRACK_H

#include "MethylationPerspective.h"
#include "GraphTrack.h"
#include "BinSeq.h"

namespace DesktopTrack{

	struct MethylationPerspectiveFileReader:public GraphFile::FileReader{
	private:
		GraphFile::Header		header;

	public:
		MethylationPerspectiveFileReader(void);
		
		bool					getData(const QString& target_name,
										const qint32& strand,
										QVector<quint16>& methylation_data_to,
										QVector<quint16>& cytosine_data_to);

		bool					getData(const QString& target_name,
										const quint32& start,
										const quint32& end,
										const qint32& strand,
										QVector<quint16>& methylation_data_to,
										QVector<quint16>& cytosine_data_to);

		bool					getData(const QString& target_name,
										const qint32& strand,
										vector<quint16>& methylation_data_to,
										vector<quint16>& cytosine_data_to);

		bool					getData(const QString& target_name,
										const quint32& start,
										const quint32& end,
										const qint32& strand,
										vector<quint16>& methylation_data_to,
										vector<quint16>& cytosine_data_to);

	};

	class MethylationPerspectiveTrack: public GraphTrack{
	public:
		MethylationPerspectiveTrack(void);
		bool					printTrackLayer(void);
	private:

		int		readNumberThreshold;

		//
		bool	printTrackList(void);
		bool	printTrackDescription(void);

		//ブラウザーレイヤー
		bool	printImage(void);
		bool	printIndexImage(void);
		bool	printOperation(void);
		bool	printIndexOperation(void);

		quint32	log(const quint32& value, const quint32& base, const quint32& pixel_per_unit);

	};

};


#endif

