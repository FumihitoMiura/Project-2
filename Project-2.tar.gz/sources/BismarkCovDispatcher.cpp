#include "BismarkCovDispatcher.h"

using namespace std;
using namespace DesktopTrack;

/*--------------------------------------------------
        class BismarkCovDispatcher
--------------------------------------------------*/
BismarkCovDispatcher::BismarkCovDispatcher(void) :
 in(0), out(0)
{
	in=new unsigned char[BufferSizeMax];
	out=new unsigned char[BufferSizeMax];
}

BismarkCovDispatcher::~BismarkCovDispatcher(void){
	if(in!=0){
		delete[] in;
	}
	if(out!=0){
		delete[] out;
	}
}

bool BismarkCovDispatcher::setFilePaths(const QStringList& paths_to_files)
{

	//�t�@�C�����I�[�v��
	mutex.lock();
	pathsToFiles=paths_to_files;
	if(pathsToFiles.size()==0){
		mutex.unlock();
		cerr << "Please specify one or more file names." << endl;
		return false;
	}
    if(file.isOpen()){
		file.close();
    }

	fileIndex=0;
	
	QFileInfo info(pathsToFiles[fileIndex]);
	if(info.suffix()=="gz"){
		isComplessedFile=true;
		//Initialize zstream
		strm.zalloc=Z_NULL;
		strm.zfree=Z_NULL;
		strm.opaque=Z_NULL;
		inflateInit2(&strm, 16+MAX_WBITS);
		file.setFileName(pathsToFiles[fileIndex]);
		file.open(QIODevice::ReadOnly);
		if(!file.isOpen()){
			inflateEnd(&strm);
			mutex.unlock();
			cerr << "Couldn't open file \"" << file.fileName().toStdString() << "\".";
			return false;
		}
	}
	else{
		isComplessedFile=false;
		file.setFileName(pathsToFiles[fileIndex]);
		file.open(QIODevice::ReadOnly);
		if(!file.isOpen()){
			mutex.unlock();
			cerr << "Couldn't open file \"" << file.fileName().toStdString() << "\".";
			return false;
		}
	}



	cout << "Processing \"" << pathsToFiles[fileIndex].toStdString() << "\" (" << file.size() << " bytes)" << endl;
	readNumber=0;

    mutex.unlock();
    return true;

}

bool BismarkCovDispatcher::getData(QByteArray& dataTo)
{
	
	dataTo.clear();
	mutex.lock();

	while(true){

		while(!file.atEnd()){

			if(isComplessedFile){

				//���̓t�@�C������IN�������[�ɓǂݍ���
				strm.avail_in=file.read((char*)in, BufferSizeMax);
				strm.next_in=in;
				cout << "*" << flush;
				readNumber++;
				if(readNumber%50==0){
					cout << ": " << file.pos()*100/file.size() << "% processed." << flush << endl;
				}
				
				//�ǂݍ��񂾓��e�͑S�ĉ𓀂��C���^�[�i���o�b�t�@�[�ɕۑ�
				do{
					strm.avail_out=BufferSizeMax;
					strm.next_out=out;
					int ret=inflate(&strm, Z_NO_FLUSH);
					if( ret< 0 ){
						// error
						cout << "something happened." << endl;
						return  false;
					}
					int outDataSize=BufferSizeMax-strm.avail_out;
					internalBuffer+=QByteArray((char*)out, outDataSize);
				} while(strm.avail_out==0);

				if(internalBuffer.size()>0){

					int firstIndex=internalBuffer.indexOf('\n');
					int lastIndex=internalBuffer.lastIndexOf('\n');
					if(firstIndex==-1){
						cerr << "Invarid file:" << file.fileName().toStdString() << endl;
						mutex.unlock();
						return false;
					}
					if(lastIndex==-1){
						cerr << "Invarid file:" << file.fileName().toStdString() << endl;
						mutex.unlock();
						return false;;
					}

					//�t�@�C�������֓��B���Ă���ꍇ
					if(file.atEnd()){
						internalBuffer.remove(0, firstIndex);
						dataTo=internalBuffer;
						inflateEnd(&strm);
						mutex.unlock();
						return true;
					}
					//�t�@�C�������܂œ��B���Ă��Ȃ��ꍇ
					else{
						if(firstIndex==lastIndex){
							cerr << "Invarid file:" << file.fileName().toStdString() << endl;
							mutex.unlock();
							return false;
						}
						dataTo=internalBuffer.mid(firstIndex, lastIndex-firstIndex);
						internalBuffer.remove(0, lastIndex);
						mutex.unlock();
						return true;
					}

				}

			}
			else{
				dataTo=file.read(BufferSizeMax);
				cout << "*" << flush;
				readNumber++;
				if(readNumber%50==0){
					cout << ": " << file.pos()*100/file.size() << "% processed." << flush << endl;
				}
				if(dataTo.size()>0){
					int firstIndex=dataTo.indexOf('>');
					int lastIndex=dataTo.lastIndexOf('>');
					if(firstIndex==-1){
						cerr << "Invarid file:" << file.fileName().toStdString() << endl;
						mutex.unlock();
						return false;
					}
					if(lastIndex==-1){
						cerr << "Invarid file:" << file.fileName().toStdString() << endl;
						mutex.unlock();
						return false;;
					}
					//�t�@�C�������֓��B���Ă���ꍇ
					if(file.atEnd()){
						dataTo.remove(0, firstIndex);
						mutex.unlock();
						return true;
					}
					//�t�@�C�������܂œ��B���Ă��Ȃ��ꍇ
					else{
						if(firstIndex==lastIndex){
							cerr << "Invarid file:" << file.fileName().toStdString() << endl;
							mutex.unlock();
							return false;
						}
						int offset=dataTo.size()-lastIndex;
						file.seek(file.pos()-offset);
						dataTo.truncate(lastIndex);
						dataTo.remove(0, firstIndex);
						mutex.unlock();
						return true;
					}
				}
			}
		}

		if(file.isOpen()){
			file.close();
			cout << ": finished." << endl;
		}
		fileIndex++;

		if(fileIndex>=pathsToFiles.size()){
			mutex.unlock();
			return false;
		}

		QFileInfo info(pathsToFiles[fileIndex]);
		if(info.suffix()=="gz"){
			isComplessedFile=true;
			//Initialize zstream
			strm.zalloc=Z_NULL;
			strm.zfree=Z_NULL;
			strm.opaque=Z_NULL;
			inflateInit2(&strm, 16+MAX_WBITS);
			file.setFileName(pathsToFiles[fileIndex]);
			file.open(QIODevice::ReadOnly);
			if(!file.isOpen()){
				inflateEnd(&strm);
				mutex.unlock();
				cerr << "Couldn't open file \"" << file.fileName().toStdString() << "\".";
				return false;
			}
			cout << "Processing \"" << pathsToFiles[fileIndex].toStdString() << "\" (" << file.size() << " bytes)" << endl;
			readNumber=0;
		}
		else{
			isComplessedFile=false;
			file.setFileName(pathsToFiles[fileIndex]);
			file.open(QIODevice::ReadOnly);
			if(!file.isOpen()){
				mutex.unlock();
				cerr << "Couldn't open file \"" << file.fileName().toStdString() << "\".";
				return false;
			}
			cout << "Processing \"" << pathsToFiles[fileIndex].toStdString() << "\" (" << file.size() << " bytes)" << endl;
			readNumber=0;
		}

	}

}

