﻿#include <iostream>
#include <cmath>
#include <cstdlib>
#include <QtCore>
#include "BinSeq.h"
#include "MethylationPerspectiveTrack.h"
#include "CompMethylationAnalysis.h"

using namespace DesktopTrack;
using namespace std;

QString species;
QString revision;
QString binseqPath;
QString graphFile1;		//should be specified
QString graphFile2;		//should be specified
QString bedFileName;	//optional
int windowSize=1;
int stepSize=1;
int readThreshold=1;
int averageThreshold=1;
int minRateD1=0;
int maxRateD1=1;
int minRateD2=0;
int maxRateD2=1;
int imageScale=10;
int matrixSize=300;
int maxDepth=300;

enum Context{all, CG, CHG, CHH} context=all;
QString methylCompOut("methyl.png");	//should be specified
QString coverCompOut("cover.png");
QString thermalCompOut;                 //optional
QString resultLog;

bool exportList=false;
QFile expList;
QTextStream listStream;

void showUsage(void){

	cout << "Usage: CompMethylationAnalysis [option 1] [value 1] [option 2] [value 2] ....." << endl
		<< endl
		<< " options" << endl
		<< "   -species  [string]              : Species (required)" << endl
		<< "   -revision [string]              : Revision (required)" << endl
		<< "   -binseq   [string]              : Binseq file, exclusive with the combination of -species and -revision " << endl
		<< "   -graph    [string] [string]     : Pair of graph file for methylation perspective track (required)" << endl
		<< "   -bed      [string]              : Path to BED file that specify the regions to be analyzed" << endl
		<< "   -window   [string]              : Size of window for calculation of average methylation rates [default=1]" << endl
		<< "   -step     [string]              : Step size for moving window [default=1]" << endl
		<< "   -read     [integer]             : Minimum read number for calculation of methylation rate. (optional) [default=10]" << endl
		<< "   -num_c    [integer]             : Number of cytosines to calculate average methylation rate (optional) [default=1]" << endl
		<< "   -context  [string]              : Context of cytosines from {all, CG, CHG, CHH}]. Default is all cytosines (optional) [default=\"all\"]" << endl
		<< "   -min_r1   [real]                : Minimum methylation value for data 1" << endl
		<< "   -max_r1   [real]                : Maximum methylation value for data 1" << endl
		<< "   -min_r2   [real]                : Minimum methylation value for data 2" << endl
		<< "   -max_r2   [real]                : Maximum methylation value for data 2" << endl
		<< "   -scale    [integer]             : Upper limit for image scaling (values larger than 0) (optional) [default=10]" << endl
		<< "   -depth    [integer]             : Upper limit for read depth to be shown in a chart (values larger than 0) (optional) [default=300]" << endl
		<< "   -methyl   [string]              : Name for output file for comparison of methylation [default=\"mout.png\"]" << endl
		<< "   -cover    [string]              : Name for output file for comparison of coverage [default=\"rout.png\"]" << endl
		<< "   -thermal  [string]              : Name for beautiful output file (created only when specified)" << endl
		<< "   -log      [string]              : Name for log file (created only when specified)" << endl;


}

bool processArguments(int argc, char* argv[]){

	int i=1;

	while(i<argc){

		QString option(argv[i]);
		if(option=="-species"){
			i++;
			if(i>=argc){
				showUsage();
				return false;
			}
			QString value(argv[i]);
			if(value.startsWith("-")){
				cout << "Invalid usage of option \"-species\"." << endl;
				showUsage();
				return false;
			}
			species=value;
		}
		else if(option=="-revision"){
			i++;
			if(i>=argc){
				showUsage();
				return false;
			}
			QString value(argv[i]);
			if(value.startsWith("-")){
				cout << "Invalid usage of option \"-revision\"." << endl;
				showUsage();
				return false;
			}
			revision=value;
		}
		else if(option=="-binseq"){
			i++;
			if(i>=argc){
				showUsage();
				return false;
			}
			QString value(argv[i]);
			if(value.startsWith("-")){
				cout << "Invalid usage of option \"-binseq\"." << endl;
				showUsage();
				return false;
			}
			binseqPath=value;
		}
		else if(option=="-graph"){
			i++;
			if(i>=argc){
				showUsage();
				return false;
			}
			QString value(argv[i]);
			if(value.startsWith("-")){
				cout << "Invalid usage of option \"-graph\"." << endl;
				showUsage();
				return false;
			}
			graphFile1=value;
			i++;
			if(i>=argc){
				showUsage();
				return false;
			}
			value=argv[i];
			if(value.startsWith("-")){
				cout << "Invalid usage of option \"-graph\"." << endl;
				showUsage();
				return false;
			}
			graphFile2=value;
		}
		else if (option == "-bed"){
			i++;
			if (i >= argc){
				showUsage();
				return false;
			}
			QString value(argv[i]);
			if (value.startsWith("-")){
				cout << "Invalid usage of option \"-window\"." << endl;
				showUsage();
				return false;
			}
			bedFileName = value.toInt();
			if (windowSize<1){
				cout << "Invalid value was specified for option \"-bed\"." << endl;
				showUsage();
				return false;
			}
		}
		else if(option=="-window"){
			i++;
			if(i>=argc){
				showUsage();
				return false;
			}
			QString value(argv[i]);
			if(value.startsWith("-")){
				cout << "Invalid usage of option \"-window\"." << endl;
				showUsage();
				return false;
			}
			windowSize=value.toInt();
			if(windowSize<1){
				cout << "Invalid value was specified for option \"-window\"." << endl;
				showUsage();
				return false;
			}
		}
		else if(option=="-step"){
			i++;
			if(i>=argc){
				showUsage();
				return false;
			}
			QString value(argv[i]);
			if(value.startsWith("-")){
				cout << "Invalid usage of option \"-step\"." << endl;
				showUsage();
				return false;
			}
			stepSize=value.toInt();
			if(stepSize<1){
				cout << "Invalid value was specified for option \"-step\"." << endl;
				showUsage();
				return false;
			}
		}
		else if(option=="-read"){
			i++;
			if(i>=argc){
				showUsage();
				return false;
			}
			QString value(argv[i]);
			if(value.startsWith("-")){
				cout << "Invalid usage of option \"-read\"." << endl;
				showUsage();
				return false;
			}
			readThreshold=value.toInt();
			if(readThreshold<1){
				cout << "Invalid value was specified for option \"-read\"." << endl;
				showUsage();
				return false;
			}
		}
		else if(option=="-num_c"){
			i++;
			if(i>=argc){
				showUsage();
				return false;
			}
			QString value(argv[i]);
			if(value.startsWith("-")){
				cout << "Invalid usage of option \"-num_c\"." << endl;
				showUsage();
				return false;
			}
			averageThreshold=value.toInt();
			if(averageThreshold<1){
				cout << "Invalid value was specified for option \"-num_c\"." << endl;
				showUsage();
				return false;
			}
		}
		else if(option=="-context"){
			i++;
			if(i>=argc){
				showUsage();
				return false;
			}
			QString value(argv[i]);
			if(value=="all"){
				context=all;
			}
			else if(value=="CG"){
				context=CG;
			}
			else if(value=="CHG"){
				context=CHG;
			}
			else if(value=="CHH"){
				context=CHH;
			}
			else{
				cout << "Value for option -c should be selected from following four strings, all, CG, CHG, or CHH." << endl;
				showUsage();
				return false;
			}
		}

		else if (option == "-min_r1"){
			i++;
			if (i >= argc){
				showUsage();
				return false;
			}
			QString value(argv[i]);
			if (value.startsWith("-")){
				cout << "Invalid usage of option \"-min_r1\"." << endl;
				showUsage();
				return false;
			}
			qreal v = value.toDouble();
			if (v < 0 || v > 1){
				cout << "value should be 0 to 1 for option \"-min_r1\"." << endl;
				return false;
			}
			minRateD1 = v;
		}
		else if (option == "-max_r1"){
			i++;
			if (i >= argc){
				showUsage();
				return false;
			}
			QString value(argv[i]);
			if (value.startsWith("-")){
				cout << "Invalid usage of option \"-max_r1\"." << endl;
				showUsage();
				return false;
			}
			qreal v = value.toDouble();
			if (v < 0||v > 1){
				cout << "value should be 0 to 1 for option \"-max_r1\"." << endl;
				return false;
			}
			maxRateD1 = v;
		}
		else if (option == "-min_r2"){
			i++;
			if (i >= argc){
				showUsage();
				return false;
			}
			QString value(argv[i]);
			if (value.startsWith("-")){
				cout << "Invalid usage of option \"-min_r2\"." << endl;
				showUsage();
				return false;
			}
			qreal v = value.toDouble();
			if (v < 0 || v > 1){
				cout << "value should be 0 to 1 for option \"-min_r2\"." << endl;
				return false;
			}
			minRateD2 = v;
		}
		else if (option == "-max_r2"){
			i++;
			if (i >= argc){
				showUsage();
				return false;
			}
			QString value(argv[i]);
			if (value.startsWith("-")){
				cout << "Invalid usage of option \"-max_r2\"." << endl;
				showUsage();
				return false;
			}
			qreal v = value.toDouble();
			if (v < 0 || v > 1){
				cout << "value should be 0 to 1 for option \"-max_r2\"." << endl;
				return false;
			}
			maxRateD2 = v;
		}

		else if(option=="-scale"){
			i++;
			if(i>=argc){
				showUsage();
				return false;
			}
			QString value(argv[i]);
			if(value.startsWith("-")){
				cout << "Invalid usage of option \"-scale\"." << endl;
				showUsage();
				return false;
			}
			imageScale=value.toInt();
			if(imageScale<1){
				cout << "Invalid value was specified for option \"-scale\"." << endl;
				showUsage();
				return false;
			}
		}
		else if (option == "-depth") {
			i++;
			if (i >= argc) {
				showUsage();
				return false;
			}
			QString value(argv[i]);
			if (value.startsWith("-")) {
				cout << "Invalid usage of option \"-scale\"." << endl;
				showUsage();
				return false;
			}
			maxDepth = value.toInt();
			if (maxDepth<1) {
				cout << "Invalid value was specified for option \"-depth\"." << endl;
				showUsage();
				return false;
			}
		}
        else if(option=="-methyl"){
			i++;
			if(i>=argc){
				showUsage();
				return false;
			}
			QString value(argv[i]);
			if(value.startsWith("-")){
                cout << "Invalid usage of option \"-methyl\"." << endl;
				showUsage();
				return false;
			}
            methylCompOut=value;
		}
        else if (option == "-cover"){
			i++;
			if (i >= argc){
				showUsage();
				return false;
			}
			QString value(argv[i]);
			if (value.startsWith("-")){
                cout << "Invalid usage of option \"-cover\"." << endl;
				showUsage();
				return false;
			}
            coverCompOut = value;
		}
        else if (option == "-thermal"){
            i++;
            if (i >= argc){
                showUsage();
                return false;
            }
            QString value(argv[i]);
            if (value.startsWith("-")){
                cout << "Invalid usage of option \"-thermal\"." << endl;
                showUsage();
                return false;
            }
            thermalCompOut = value;
        }
		else if (option == "-log") {
			i++;
			if (i >= argc) {
				showUsage();
				return false;
			}
			QString value(argv[i]);
			if (value.startsWith("-")) {
				cout << "Invalid usage of option \"-log\"." << endl;
				showUsage();
				return false;
			}
			resultLog = value;
		}
		else{
			break;
		}

		i++;

	}

	if(binseqPath.size()>0){

		if(species.size()>0||revision.size()>0){
			cerr << "Please specify reference genome information by one of following procedures." << endl
				 << " 1, Specyfication of species and revision by options -species and -revision." << endl
				 << " 2, Direct specification of binseq file by option -binseq." << endl << endl;
			return false;
		}

	}
	else{

		QString path = QCoreApplication::applicationDirPath();

		QDir RevisionDir(QCoreApplication::applicationDirPath());
		if(!RevisionDir.exists(RevisionsDirName)){
			cerr << "Coundn't find revision directory.";
			return false;
		}
		if(!RevisionDir.cd(RevisionsDirName)){
			cerr << "Coundn't find revision directory.";
			return false;
		}
		if(species.size()==0){
			cerr << "Species name was not provided." << endl;
			return false;
		}
		if(!RevisionDir.exists(species)){
			cerr << "Species \"" << species.toStdString() << "\" not found.";
			return false;
		}
		if(!RevisionDir.cd(species)){
			cerr << "Species \"" << species.toStdString() << "\" not found.";
			return false;
		}
		if(revision.size()==0){
			cerr << "Revision name was not provided." << endl;
			return false;
		}
		if(!RevisionDir.exists(revision)){
			cerr << "Revision \"" << revision.toStdString() << "\" not found.";
			return false;
		}
		if(!RevisionDir.cd(revision)){
			cerr << "Revision \"" << revision.toStdString() << "\" not found.";
			return false;	}

		QString binseqFileName(BinSeqFileTemp.arg(species).arg(revision));
		if(RevisionDir.exists(binseqFileName)){
			binseqPath=RevisionDir.absoluteFilePath(binseqFileName);
		}
		else{ 
			return false; 
		}

	}

	if (graphFile1.size() == 0){
		cerr << "Please specify graph file." << endl;
		return false;
	}
	if (graphFile2.size() == 0){
		cerr << "Please specify graph file." << endl;
		return false;
	}

	if (minRateD1 >= maxRateD1){
		cerr << "Minimum limit for methylation rate should be smaller than maximum limit." << endl;
		return false;
	}
	if (minRateD2 >= maxRateD2){
		cerr << "Minimum limit for methylation rate should be smaller than maximum limit." << endl;
		return false;
	}

	if(exportList){
		expList.open(QIODevice::WriteOnly);
		if(!expList.isOpen()){
			cerr << "Couldn't open file for data export." << endl;
			return false;
		}
		listStream.setDevice(&expList);
	}


	cout	<< "BinSeq                  :" << binseqPath.toStdString() << endl
			<< "GraphFile[1]            :" << graphFile1.toStdString() << endl
			<< "GraphFile[2]            :" << graphFile2.toStdString() << endl
            << "Output File (methyl)    :" << methylCompOut.toStdString() << endl
            << "Output File (coverage)  :" << coverCompOut.toStdString() << endl
			<< "Window size             :" << windowSize << endl
			<< "Step size               :" << stepSize << endl
			<< "Minimum num of reads    :" << readThreshold << endl
			<< "Methylation rate for 1  :" << minRateD1 << "-" << maxRateD1 << endl
			<< "Methylation rate for 2  :" << minRateD2 << "-" << maxRateD2 << endl
			<< "Context                 :";

	if(context==all){
		cout << "all cytosines" << endl;
	}
	else if(context==CG){
		cout << "CpGs" << endl;
	}
	else if(context==CHG){
		cout << "CHGs" << endl;
	}
	else if(context==CHH){
		cout << "CHHs" << endl;
	}
	cout	<< "Minimum num of cytosines:" << averageThreshold << endl
			<< "Scale                   :0-" << imageScale << endl << endl;

	if(exportList){
		cout << "Data will be exported to " << expList.fileName().toStdString() << "." << endl;
	}

	return true;

}



int main(int argc, char* argv[]){

	QApplication app(argc, argv);

	if(!processArguments(argc, argv)){
		showUsage();
		return false;
	}

    DesktopTrack::CompMethylationAnalysis factory;

    if(!factory.setSpecies(binseqPath)){
        cout << "Couldn't set file \"" << binseqPath.toStdString() << "\"." << endl;
		showUsage();
		return 0;
	}

    if (bedFileName.size()!=0){
        if(!factory.setProbeMap(bedFileName)){
            cout << "Couldn't set file \"" << bedFileName.toStdString() << "\"." << endl;
            showUsage();
            return 0;
        }
    }

    if(!factory.setGraphFiles(graphFile1, graphFile2)){
        cout << "Couldn(t open file \""
             << graphFile1.toStdString()
             << "\" or \""
             << graphFile2.toStdString()
             << "\"." << endl;
		showUsage();
		return 0;
	}

	cout << endl << "Start analysis..." << endl;


    if(windowSize>1&&stepSize<1){
        showUsage();
    }

    if(windowSize<1){
        showUsage();
    }

	factory.setImageScale(imageScale);
	factory.setMaxDepth(300);

    //計算中身
    switch (context){
    case all:
        factory.AnalyzeAll(QByteArray("C"), windowSize, stepSize);
        break;
    case CG:
        factory.AnalyzeAll(QByteArray("CG"), windowSize, stepSize);
        break;
    case CHG:
        factory.AnalyzeAll(QByteArray("CHG"), windowSize, stepSize);
        break;
    case CHH:
        factory.AnalyzeAll(QByteArray("CHH"), windowSize, stepSize);
        break;
    default:
        showUsage();
        break;
    }

    //ファイル出力
    if(methylCompOut.size()>0){
        factory.DrawChart(methylCompOut);
    }
    if(thermalCompOut.size()>0){
        factory.DrawThermoChart(thermalCompOut);
    }
	if (coverCompOut.size() > 0) {
		factory.DrawCoverageChart(coverCompOut);
	}
	if (resultLog.size() > 0) {
		factory.OutputParameters(resultLog);
	}
	return 0;

}

