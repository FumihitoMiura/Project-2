#include <QtCore>
#include <iostream>
#include <vector>

using namespace std;

#include "MethylationPerspective.h"
#include "MPTC.h"
#include "BinSeq.h"
#include "BisulAlignDispatcher.h"
#include "DesktopTrackCommon.h"

using namespace DesktopTrack;

/*--------------------------------------------------------------
                    MPTrackCreatorSubThread
--------------------------------------------------------------*/
MPTrackCreatorSubThread::
MPTrackCreatorSubThread(QObject* parent):QThread(parent){}

void MPTrackCreatorSubThread::
setMap(QMap<QString, MethylationPerspective> *methylmap)
{
	methylationMap=methylmap;
}

void MPTrackCreatorSubThread::
setDispatcher(BisulAlignDispatcher* dispat)
{
	dispatcher=dispat;
}

void MPTrackCreatorSubThread::run(void)
{
	QByteArray data;

	while(dispatcher->getData(data)){

		QBuffer buffer(&data);
		buffer.open(QIODevice::ReadOnly);

		while(!buffer.atEnd()){

			QByteArray queryName=buffer.readLine().trimmed();	//1
			QByteArray sbjctName=buffer.readLine().trimmed();	//2
			quint32 queryFrom=buffer.readLine().trimmed().toUInt();	//3
			quint32 queryTo=buffer.readLine().trimmed().toUInt();	//4
			quint32 sbjctFrom=buffer.readLine().trimmed().toUInt();	//5
			quint32 sbjctTo=buffer.readLine().trimmed().toUInt();	//6
			if(sbjctFrom>sbjctTo){
				quint32 temp=sbjctFrom;
				sbjctFrom=sbjctTo;
				sbjctTo=temp;
			}
			QByteArray alignType=buffer.readLine().trimmed();	//7
			qint32 sbjctStrand;
			if(alignType=="+"||alignType=="1"||alignType=="2"){
				sbjctStrand=1;
			}
			else if(alignType=="-"||alignType=="-1"||alignType=="3"||alignType=="4"){
				sbjctStrand=-1;
			}
			else{
				sbjctStrand=0;
			}		
			QByteArray query=buffer.readLine().trimmed();	//8
			if(query.startsWith("query  ")){
				query=query.right(query.size()-7);
			}
			QByteArray call=buffer.readLine().trimmed();	//9
			if(call.startsWith("call   ")){
				call=call.right(call.size()-7);
			}
			QByteArray sbjct=buffer.readLine().trimmed();	//10
			if(sbjct.startsWith("sbjct  ")){
				sbjct=sbjct.right(sbjct.size()-7);
			}
			QByteArray temp = buffer.readLine().trimmed();	//11

			if(!methylationMap->contains(sbjctName)){	//read only operation�Ȃ̂�thread safe
				continue;
			}

			DesktopTrack::MethylationPerspective& methylationPerspective = (*methylationMap)[sbjctName];
			int sbjct_pos;

			if(sbjctStrand==1){
				sbjct_pos=sbjctFrom;
				for(int pos=0; pos<query.size(); pos++){
					if(query[pos]=='-'){
						sbjct_pos++;
						continue;
					}
					else if(sbjct[pos]=='-'){
						continue;
					}
					else if(sbjct[pos]=='C'||sbjct[pos]=='c'){
						if(call[pos]=='M'){
							methylationPerspective.putC(sbjct_pos, 1, true);
						}
						else{
							methylationPerspective.putC(sbjct_pos, 1, false);
						}
						sbjct_pos++;
					}
					else if(query[pos]>='a'&&query[pos]<'z'){
						sbjct_pos++;
						continue;
					}
					else{
						methylationPerspective.putD(sbjct_pos, 1);
						sbjct_pos++;
					}
				}

			}
			else if(sbjctStrand==-1){
				sbjct_pos=sbjctTo;
				for(int pos=0; pos<query.size(); pos++){
					if(query[pos]=='-'){
						sbjct_pos--;
						continue;
					}
					else if(sbjct[pos]=='-'){
						continue;
					}
					else if(sbjct[pos]=='C'||sbjct[pos]=='c'){
						if(call[pos]=='M'){
							methylationPerspective.putC(sbjct_pos, -1, true);
						}
						else{
							methylationPerspective.putC(sbjct_pos, -1, false);
						}
						sbjct_pos--;
					}
					else if(query[pos]>='a'&&query[pos]<'z'){
						sbjct_pos--;
						continue;
					}
					else{
						methylationPerspective.putD(sbjct_pos, -1);
						sbjct_pos--;
					}

				}

			}
			else{
				cout << "no strand" << endl;
				continue;
			}

		}

	}

}


/*--------------------------------------------------------------
                    MPTrackCreatorMainThread
--------------------------------------------------------------*/
MPTrackCreator::MPTrackCreator(int numThread, QObject* parent=0):
	isInitialized(false), QObject(parent)
{
	for(int i=0; i<numThread; i++){
		MPTrackCreatorSubThread* thread=new MPTrackCreatorSubThread(this);
		QObject::connect(thread, SIGNAL(finished()), this, SLOT(onProcessFinished()));
		threads.append(thread);
		threadStates.append(false);
	}	
}

bool MPTrackCreator::setBinSeq(const QString& pathTo)
{

	//BinSeq���������
	DesktopTrack::BinSeq::FileReader reader;
	if(!reader.setFile(pathTo)){
		isInitialized=false;
		return false;
	}
	DesktopTrack::BinSeq::Header bHeader;
	bHeader=reader.getTrackConfig();

	//��{�����R�s�[���f�t�H���g�l�����
	header.species=bHeader.species;
	header.revision=bHeader.revision;
	header.dataType=DesktopTrack::Integer;
	header.rowHeight=60;
	header.fontSize=10;
	header.fgColor=QColor::fromRgb(0, 0, 0);
	header.bgColor=QColor::fromRgb(255, 255, 255);
	header.anColor=QColor::fromRgb(255, 0, 0);
	header.strandSpecificity=DesktopTrack::SeparateStrands;

	//�z�񖈂ɃO���t�f�[�^���쐬���t�@�C���ɏo��
	QList<DesktopTrack::BinSeq::Target> bTargetList = reader.getTargetList();
	methylationMap.clear();
	targetList.clear();

	for(int i=0; i<bTargetList.size(); i++){

		//�z��̎擾
		QByteArray seq;
		QString seqName=bTargetList[i].targetName;
		if(!reader.getSeq(seqName, seq)){
			continue;
		}
		//MethylationPerspective�̍\�z
		DesktopTrack::MethylationPerspective methylationPerspective;
		if(methylationMap.contains(bTargetList[i].targetName)){
			continue;
		}
		else{
			methylationMap[bTargetList[i].targetName]=methylationPerspective;
			methylationMap[bTargetList[i].targetName].setSeq(seq, seqName.toLatin1());
		}

		GraphFile::Target target(bTargetList[i].targetName, bTargetList[i].targetLength);
		targetList.append(target);

	}

	for(int i=0; i<threads.size(); i++){
		threads[i]->setMap(&methylationMap);
	}

	isInitialized=true;
	return true;

}

bool MPTrackCreator::setGraph(const QString& pathTo)
{

	DesktopTrack::MethylationPerspectiveFileReader Reader;
	if(!Reader.setFile(pathTo)){
		isInitialized=false;
		return false;
	}
	GraphFile::Header gHeader=Reader.getBasicTrackInfo();

	//��{�����R�s�[
	header.species=gHeader.species;
	header.revision=gHeader.revision;
	header.dataType=gHeader.dataType;
	header.rowHeight=gHeader.rowHeight;
	header.fontSize=gHeader.fontSize;
	header.fgColor=gHeader.fgColor;
	header.bgColor=gHeader.bgColor;
	header.anColor=gHeader.anColor;
	header.strandSpecificity=gHeader.strandSpecificity;

	targetList=Reader.getTargetList();

	for(int i=0; i<targetList.size(); i++){
		vector<quint16> temp1, temp2;
		if(!Reader.getData(targetList[i].targetName, 1, temp1, temp2)){
			if(!methylationMap[targetList[i].targetName].setListF(temp1, temp2)){
				isInitialized=false;
				return false;
			}
		}
		if(!Reader.getData(targetList[i].targetName, -1, temp1, temp2)){
			if(!methylationMap[targetList[i].targetName].setListR(temp1, temp2)){
				isInitialized=false;
				return false;
			}
		}
	}

	for(int i=0; i<threads.size(); i++){
		threads[i]->setMap(&methylationMap);
	}

	isInitialized=true;
	return true;

}

void MPTrackCreator::setTrackName(const QString& track_name)
{
	header.trackName=track_name;
}

void MPTrackCreator::setOutfilePath(const QString& file_path)
{
	outFile.setFileName(file_path);
}

bool MPTrackCreator::setBisulAlignPaths(const QStringList& paths)
{
	if(!dispatcher.setFilePaths(paths)){
		return false;
	}
	else{
		for(int i=0; i<threads.size(); i++){
			threads[i]->setDispatcher(&dispatcher);
		}
		return true;
	}
}

//bool MPTrackCreator::setBedGraphPaths(const QStringList& paths)
//{
//	if (!dispatcher.setFilePaths(paths)){
//		return false;
//	}
//	else{
//		for (int i = 0; i<threads.size(); i++){
//			threads[i]->setDispatcher(&dispatcher);
//		}
//		return true;
//	}
//}

void MPTrackCreator::start(void)
{
	finishedProcess=0;
	for(int i=0; i<threads.size(); i++){
		threads[i]->start();
	}
}

void MPTrackCreator::onProcessFinished(void)
{

	//�S�Ẵv���Z�X���I���������Ƃ��m�F
	mutex.lock();
	finishedProcess++;
	if(finishedProcess<threads.size()){
		mutex.unlock();
		return;
	}
	
	//�o�̓t�@�C���̓v���Z�X�J�n�O�ɃI�[�v������Ă���͂��ł���
	outFile.open(QIODevice::WriteOnly);
	if(!outFile.isOpen()){
		cerr << "Couldn't open output file." << endl;
		mutex.unlock();
		return;
	}

	//GraphFile�쐬�J�n
	cout << "Start exporting ..." << endl;

	//�w�b�_�[�̉��o��
	QDataStream out(&outFile);
	header.putSerialized(out);

	//�o�b�t�@�[����
	QByteArray data;
	QBuffer buffer;
	//�f�[�^�̏o��
	buffer.setBuffer(&data);
	buffer.open(QIODevice::WriteOnly);
	out.setDevice(&buffer);
	
	//�o�͊J�n
	for(int i=0; i<targetList.size(); i++){

		GraphFile::Target& target=targetList[i];
		target.fwDataOffset=outFile.pos()+buffer.pos();
		DesktopTrack::MethylationPerspective& methylationPerspective = methylationMap[target.targetName];
		const std::vector<quint32>&	listF=methylationPerspective.getListF();
		const std::vector<quint32>&	listR=methylationPerspective.getListR();

		for(int j=0; j<target.targetLength; j++){
			out << listF[j];
			if(data.size()>DesktopTrack::BufferSizeMax){
				buffer.close();
				outFile.write(data);
				data.clear();
				buffer.setBuffer(&data);
				buffer.open(QIODevice::WriteOnly);
				out.setDevice(&buffer);
			}
		}
		target.rvDataOffset=outFile.pos()+buffer.pos();
		target.fwDataSize=target.rvDataOffset-target.fwDataOffset;
		for(int j=0; j<target.targetLength; j++){
			out << listR[j];
			if(data.size()>DesktopTrack::BufferSizeMax){
				buffer.close();
				outFile.write(data);
				data.clear();
				buffer.setBuffer(&data);
				buffer.open(QIODevice::WriteOnly);
				out.setDevice(&buffer);
			}
		}
		target.rvDataSize=outFile.pos()+buffer.pos()-target.rvDataOffset;
	}
	
	buffer.close();
	outFile.write(data);
	data.clear();
	buffer.setBuffer(&data);
	buffer.open(QIODevice::WriteOnly);
	out.setDevice(&buffer);

	//Target�̏����o�͂�header�Ƀf�[�^�̊i�[�ʒu�ƃT�C�Y��o�^
	header.targetListOffset=outFile.pos()+buffer.pos();
	header.targetListDataCount=targetList.size();
	for(int i=0; i<targetList.size(); i++){
		targetList[i].putSerialized(out);
	}
	buffer.close();
	outFile.write(data);
	data.clear();
	header.targetListDataSize=outFile.pos()+buffer.pos()-header.targetListOffset;

	outFile.seek(0);
	out.setDevice(&outFile);
	header.putSerialized(out);

	cout << "Finished." << endl;
	mutex.unlock();
	emit allProcessFinished();

}