#ifndef ENCODER_BASIC_H
#define ENDOCER_BASIC_H

#include <QtCore>
#include <iostream>
#include <cstring>

#include "DesktopTrackCommon.h"

#define INLINE

#ifdef INLINE

namespace DesktopTrack{

    class EncoderBasic{
	public:
        EncoderBasic(void);
        ~EncoderBasic(void);

		bool getBit(const quint8* s, quint64 pos){
			quint64 array_offset=pos/8;
			quint64 bit_offset=pos%8;	
			if(s[array_offset]&onMask[bit_offset]){
				return true;
			}
			else{
				return false;
			}
		};

		void setBit(quint8* s, quint64 pos, bool flag){
			quint64 array_offset=pos/8;
			quint64 bit_offset=pos%8;
			if(flag){
				s[array_offset]=s[array_offset]|onMask[bit_offset];
			}
			else{
				s[array_offset]=s[array_offset]&offMask[bit_offset];
			}
		};

		quint8 getChar(const quint8* s, quint64 pos){
			if(pos%2==0){
				return s[pos/2]>>4;
			}
			else{
				return s[pos/2]&0x0f;
			}
		};

		void setChar(quint8* s, quint64 pos, quint8 value){
			quint64 offset=pos/2;
			if(pos%2==0){
				s[offset]=(s[offset]&0x0f)|(value<<4);
			}
			else{
				s[offset]=(s[offset]&0xf0)|(value&0x0f);
			}
		};

		void setSizeofInt(quint64 byte_num);

		quint64 getInt(const quint8* s, quint64 pos){
			quint64 value=0;
			const quint8* c=s+pos*sizeofInt;
			int i=0;
			int j=sizeofInt-1;
			while(true){
				quint64 temp=(quint64)(c[i]);
				value=value|temp<<j*8;
				i++;
				j--;
				if(i>=(int)sizeofInt){
					break;
				}
			}
			return value;
		};

		void setInt(quint8* s, quint64 pos, quint64 value){
			quint8 i=0;
			quint8 j=sizeofInt-1;
			quint8* c=s+pos*sizeofInt;
			while(true){
				c[i]=quint8(value>>j*8);
				i++;
				j--;
				if(i>=sizeofInt){
					break;
				}
			}
		};

		//id
        quint64                 getId(quint8* s, quint64 sl, quint64 pos, quint64 idlen);

		//member variables
		const static quint8		onMask[8];
		const static quint8		offMask[8];
		static quint64			sizeofInt;
		static quint64			maxValue;
	};

};

#endif

#ifndef INLINE

namespace DesktopTrack{

    class EncoderBasic{
	public:
        EncoderBasic(void);
        ~EncoderBasic(void);

		bool getBit(const quint8* s, quint64 pos);
		void setBit(quint8* s, quint64 pos, bool flag);
		quint8 getChar(const quint8* s, quint64 pos);
		void setChar(quint8* s, quint64 pos, quint8 value);
		void setSizeofInt(quint64 byte_num);
		quint64 getInt(const quint8* s, quint64 pos);
		void setInt(quint8* s, quint64 pos, quint64 value);

		//id
        quint64                 getId(quint8* s, quint64 sl, quint64 pos, quint64 idlen);

		//member variables
		const static quint8		onMask[8];
		const static quint8		offMask[8];
		quint64					sizeofInt;
		quint64					maxValue;
	};

};

#endif //INLINE

#endif //ENDOCER_BASIC_H
