#ifndef BMAP_THREAD_H
#define BMAP_THREAD_H


#include <QtCore>
#include <istream>
#include <new>
#include <vector>
#include <algorithm>

#include "DesktopTrackCommon.h"
#include "SeqInfo.h"
#include "BinSeq.h"
#include "BWTBasic.h"
#include "QueryDispatcher.h"
#include "BMapFile.h"

//#define TEST
//#define TEST2

namespace DesktopTrack{

	namespace BMapCore{

		class BMapThread: public QThread, BWTBasic{
			Q_OBJECT
		public:

		private:

			//seed finding
			quint64								seedOffset;
			quint64								seedLength;
			quint64								seedLengthMax;
			quint64								seedFreqMax;
			quint64								seedStep;
			quint64								seedIterate;
			quint64								minSeedHit;
			qint64								minAlnScore;
			quint64								maxPEPairLen;

			//alignment score
			const static quint32				maxQueryLength=1024;
			const static quint32				maxQueryBufSize=512;
			const static qint64					c2tMatrix[6][6];
			const static qint64					g2aMatrix[6][6];

			quint32								maxQueryListSize;

			//index
			QList<Target>						targetList;
			bool								useSuffixArray;
			quint64								refLen;
			quint8*								refSeq;
            quint64                             bIdxWordSize;
			quint8*								c2tSeq;
            quint8*								c2tSA;
            quint8*                             c2tBIdx;
			quint64*							c2tBKT;
			quint8*								c2tBWT;
			quint8**							c2tMCB;
			quint8*								g2aSeq;
            quint8*								g2aSA;
            quint8*                             g2aBIdx;
			quint64*							g2aBKT;
			quint8*								g2aBWT;
			quint8**							g2aMCB;


			//�V���O���G���h�E�y�A�G���h���[�h�P���p
			QByteArray							cloneName;
			quint64								queryLen;
			quint8								queryF[maxQueryBufSize];
			quint8								queryR[maxQueryBufSize];

            quint64								topQueryOffset;
            quint64								topSbjctOffset;
            quint64								topAlignLength;
            quint64								topAlignType;
			qint64								topScore;
			quint64								topCount;

			quint8								c2tF[maxQueryBufSize];
			quint8								c2tR[maxQueryBufSize];
			quint8								g2aF[maxQueryBufSize];
			quint8								g2aR[maxQueryBufSize];

			
			//�y�A�G���h���[�h�Q��͗p
			QByteArray							cloneName2;
			quint64								queryLen2;
			quint8								queryF2[maxQueryBufSize];
			quint8								queryR2[maxQueryBufSize];

            quint64								topQueryOffset2;
            quint64								topSbjctOffset2;
            quint64								topAlignLength2;
            quint64								topAlignType2;
			qint64								topScore2;
			quint64								topCount2;

			quint8								c2tF2[maxQueryBufSize];
			quint8								c2tR2[maxQueryBufSize];
			quint8								g2aF2[maxQueryBufSize];
			quint8								g2aR2[maxQueryBufSize];

			

			
			//alignment
			qint64								scoringArray[1025];

			//hit
			//C2T�ϊ������N�G���[�𓖂Ă�i���t�@�����X��C2T�jtopAlignType=1
			//G2A�ϊ������N�G���[�̑��⍽�𓖂Ă�i���t�@�����X��C2T���jtopAlignType=2
			//C2T�ϊ������N�G���[�̑��⍽�𓖂Ă�i���t�@�����X��G2A���jtopAlignType=3
			//G2A�ϊ������N�G���[�𓖂Ă�i���t�@�����X�͂�G2A���jtopAlignType=4

			void								run(void);

			QueryDispatcher*					queryDispatcher;
            void                                callAlign(void);
			void                                callPEAlign(void);

			void								setQuery(
													const QByteArray& name, 
													const QByteArray& query);
			void								setQuery2(
													const QByteArray& name,
													const QByteArray& query);

			void								alignWithSA(void);
			void								alignWithBWT(void);
			void								alignWithSA2(void);
			void								alignWithBWT2(void);

			void								limAlignWithSA1(void);
			void								limAlignWithSA2(void);
			void								limAlignWithBWT1(void);
			void								limAlignWithBWT2(void);

		signals:
			void bufferLimitExceeded(void);
			void searchFinished(
                    const QByteArray&    sumData,
                    const QByteArray&    alnData);
		public:
            BMapThread(
					//quint64				SCF,
					//quint64				SCL,
                    QueryDispatcher*    diapatcher,
                    QObject*            parent=0);
            ~BMapThread(void);

			void setIndex(
                    QList<Target> targetList,
                    quint64 refLen,
                    quint8* refSeq,
                    quint64 bidxWordSize,
                    quint8* c2tSeq,
                    quint8* c2tSA,
                    quint8* c2tBIdx,
                    quint8* g2aSeq,
                    quint8* g2aSA,
                    quint8* g2aBIdx);

			void setIndexWithBWT(
                    QList<Target> targetList,
                    quint64 refLen,
                    quint8* refSeq,
                    quint64 bidxWordSize,
					quint64 SCF,
					quint64 SCL,
                    quint64* c2tBKT,
                    quint8* c2tBWT,
                    quint8** c2tMCB,
                    quint8* c2tSA,
                    quint8* c2tBIdx,
                    quint64* g2aBKT,
                    quint8* g2aBWT,
                    quint8** g2aMCB,
                    quint8* g2aSA,
                    quint8* g2aBIdx);


			void setAlignmentParameters(
				quint64 seedoffset, 
				quint64 seedlength, 
				quint64 seedstep, 
				quint64 seediterate,
				quint64 minseedhit,
				quint64 seedlengthmax,
				quint64 maxhitcount,
				qint64 minalnscore,
				quint64 maxpepairlen=1000
			);



		};
	};

};

#endif
