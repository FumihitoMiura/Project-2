#include <QtCore>
#include <QtGui>
#include <iostream>

#include "DesktopTrackCommon.h"

#include "zlib/zlib.h"
#include "qcustomplot/qcustomplot.h"

#ifndef MAP_SUM_H
#define MAP_SUM_H

namespace DesktopTrack{

	class MapSum:public QWidget{
		Q_OBJECT
	public:
		MapSum(QWidget* parent=0);

		bool setIO(
			const QStringList& listForInputFilePaths, 
			const QString& pathToOutFile,
			const QString& sampleName);

		void start(void);

	signals:

	private:
		QStringList	sumFilePaths;
		QString		outFilePath;
		QString		sampleName;

	};

};

struct ThousandSeparator: public QString{

	ThousandSeparator(void): QString(){};

	ThousandSeparator(const QString& original):
		QString(original){};

	QString& putSeparator(void){
		if(size()<3){
			return *this;
		}
		int pos=QString::indexOf('.');
		if(pos==-1){
			pos=size();
		}
		pos=pos-3;
		while(pos>0){
			insert(pos, QChar(','));
			pos=pos-3;
		}
		return *this;
	};

};

#endif