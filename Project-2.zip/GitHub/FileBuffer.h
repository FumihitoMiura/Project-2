#include <QtCore>
#if QT_VERSION >= 0x050000
#include <QtWidgets>
#else
#include <QtGui>
#endif

#ifndef FILE_BUFFER_H
#define FILE_BUFFER_H

namespace DesktopTrack{

	class FileBuffer{
	public:
		FileBuffer(QFile* file=0);
		FileBuffer(QFile* file, const quint64& offset);
		void			setFile(QFile* file);
		void			setFile(QFile* file, const quint64& offset);
		bool			getLine(QString& to);
		const quint64&	processed(void) const;
		bool			setOffset(const quint64& offset);

	private:
		QFile*			file;
		QByteArray		buffer;
		int				currentIndex;
		const int		maxBufferSize;
		quint64			processedDataSize;
	};

};

#endif


