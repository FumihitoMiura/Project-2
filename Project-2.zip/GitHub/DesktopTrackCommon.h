#include <QtCore>
#include <QColor>

#ifndef DESKTOP_TRACK_COMMON_H
#define DESKTOP_TRACK_COMMON_H

namespace DesktopTrack{
	
	//Revision�֘A
	const QString		RevisionsDirName("Revisions");
	const QString		RevisionFileName("revision.xml");
	const QString		RevisionSourceDirName("source");
	const QString		RevisionFastaFileTemp("%1_%2.fasta");
	const QString		RevisionFileRootTag("revision_info");
	const QString		SpeciesTag("species");
	const QString		RevisionTag("revision");
	const QString		TargetsTag("targets");
	const QString		NumOfTargetsAttr("number_of_targets");
	const QString		TargetTag("target");
	const QString		NameAttr("name");
	const QString		PathAttr("path");
	const QString		AliasAttr("alias");
	const QString		DescAttr("desc");
	const QString		LengthAttr("length");
	const QString		OffsetAttr("offset");
	const QString		SourceDirTag("source");
	const QString		FastaFileTag("fasta");

	//blast
	const QString		NhrFileTemp("%1_%2.fasta.nhr");
	const QString		NinFileTemp("%1_%2.fasta.nin");
	const QString		NsqFileTemp("%1_%2.fasta.nsq");

	//BrowserConfig�֘A
	const QString		BrowserConfigFileName("browser_config.xml");
	const QString		BrowserConfigDocType("browser_config");
	const QString		DesktopTrackTag("desktop_track");
	const QString		ProgramNameAttr("program_name");


	//Track�֘A
	const QString		TrackFileName("tracks.xml");
	const QString		TrackListTag("track_list");
	const QString		TrackTag("track");
	const QString		SpeciesAttr("species");
	const QString		RevisionAttr("revision");
	const QString		ProgramAttr("program");
	const QString		AuthorAttr("author");
	const QString		UrlAttr("url");


	//Strand���ِ�
	const qint32		SeparateStrands=0;
	const qint32		UnifyStrands=1;

	//���͊֘A
	const QRegExp		InputValidator("[A-Za-z0-9_]+");

	//BasicTrack�֘A
	const QString		BinSeqFileTemp("%1_%2.binseq");
	const QString		Overview("overview");
	const QString		Ruler("ruler");
	const QString		Basecolor("basecolor");

	//C2TTrack�֘A
	const QString		ForwardC2T("forward_c2t");
	const QString		ReverseC2T("reverse_c2t");

	//FeatureFile�֘A
	const QString		FeatureFileExtension("bgf");
	const QString		FeatureFileNameTemplate("%1.bgf");
	const QString		FeatureFileNameFilter("*.bgf");
	const QString		FeatureTrackDirName("feature_track");

	//GraphFile�֘A
	const QString		GraphFileExtension("graph");
	const QString		GraphFileNameTemplate("%1.graph");
	const QString		GraphFileNameFilter("*.graph");
	const QString		GraphTrackDirName("graph_track");
	const quint32		Integer=0;
	const quint32		Float=1;
	const QString		MethylationPerspectiveTrackDirName("methylation_perspective_track");

	//AlignmentFile�֘A
	const QString		AlignmentFileExtension("bas");
	const QString		AlignmentFileNameTemplate("%1.bas");
	const QString		AlignmentFileNameFilter("*.bas");
	const QString		AlignmentTrackDirName("alignment_track");
	const qint64		BlockSize=1024;

	//DitagFile�֘A
	const QString		DitagFileExtension("ditag");
	const QString		DitagFileNameTemplate("%1.ditag");
	const QString		DitagFileNameFilter("*.ditag");
	const QString		DitagTrackDirName("ditag_track");

	//DomainFile�֘A
	const QString		DomainFileExtension("domain");
	const QString		DomainFileNameTemplate("%1.domain");
	const QString		DomainFileNameFilter("*.domain");
	//const QString		DomainTrackDirName("domain_track");
	
	//SuffixArray�֘A
	const QString		SuffixArrayFileTemp("%1_%2.suffix");

	//AMap�֘A
	const QString		AMapIndexExtension("amap");
	const QString		AMapIndexFileNameTemplate("%1_%2.amap");	//%1 for species, %2 for revision
	const QString		AMapIndexFileNameFilter("*.amap");

	//BMap�֘A
	const QString		BMapIndexExtension("bmap");
	const QString		BMapIndexFileNameTemplate("%1_%2.bmap");	//%1 for species, %2 for revision
	const QString		BMapIndexFileNameFilter("*.bmap");
	
	//CMap
	const QString           CMapIndexExtension("cmap");
	const QString           CMapIndexFileNameTemplate("%1_%2.cmap");
	const QString           CMapIndexFileNameFilter("*.cmap");

	//VPlotFile�֘A
	const QString		VPlotFileExtension("vplot");
	const QString		VPlotFileNameTemplate("%1.vplot");
	const QString		VPlotFileNameFilter("*.vplot");
	const QString		VPlotTrackDirName("vplot_track");

	//TrackConfig�֘A
	const QColor		FgColor(0, 0, 0);
	const QColor		BgColor(255, 255, 255);
	const QColor		AnColor(255, 0, 0);
	const QColor		MkColor(255, 255, 0);
	const QColor		AColor(255, 0, 0);
	const QColor		CColor(0, 0, 255);
	const QColor		GColor(0, 255, 0);
	const QColor		TColor(0, 0, 0);
	const QColor		NColor(255, 255, 255);
	const quint32		FontSize=12;
	const quint32		RowHeight=20;
	const quint32		IndexWidth=100;
	const QColor		FwColor(255, 0, 0);
	const QColor		RvColor(0, 0, 255);

	const qint32		BufferSizeMax=1048576;

};


#endif

