#include "SeqInfo.h"

using namespace DesktopTrack;

SeqInfo::SeqInfo(void):
seqLength(0),
fileOffset(0),
dataSize(0){}

SeqInfo::
SeqInfo(const QString&	seqId_,
			const QString&	descriptions_,
			const qint64&	seqLength_,
			const qint64&	fileOffset_,
			const qint64&	dataSize_,
			const QString&	seqFilePath_)
	:	seqId(seqId_),
		renameTo(""),
		descriptions(descriptions_),
		seqLength(seqLength_),
		fileOffset(fileOffset_),
		dataSize(dataSize_),
		seqFilePath(seqFilePath_){}


SeqInfo& SeqInfo::operator=(const SeqInfo& original)
{
	seqId = original.seqId;
	renameTo = original.renameTo;
	descriptions = original.descriptions;
	seqLength = original.seqLength;
	fileOffset = original.fileOffset;
	dataSize = original.dataSize;
	seqFilePath = original.seqFilePath;
	return *this;
}

bool SeqInfoLess(const SeqInfo& a, const SeqInfo& b){
	return a.seqId < b.seqId;
}

void FastaFileAnalyzer::
setProcessStatus(	const Process& process_status,
					const quint64& prosessed_data,
					const quint64& total_data)
{
	mutex.lock();
	processStatus = process_status;
	processedData = prosessed_data;
	totalData = total_data;
	mutex.unlock();
}

bool FastaFileAnalyzer::getOrder(void)
{
	mutex.lock();
	bool order = promoteProcess;
	mutex.unlock();
	return order;
}

FastaFileAnalyzer::FastaFileAnalyzer(QObject* parent):
promoteProcess(true),
processStatus(stopped),
countA(0),
countC(0),
countG(0),
countT(0),
countN(0),
processedData(0),
totalData(0),
QThread(parent){}

void FastaFileAnalyzer::
setFilePath(const QStringList& filePathList_)
{
	filePathList=filePathList_;
	seqInfoList.clear();
};

void FastaFileAnalyzer::
setOrder(bool proceed){
	mutex.lock();
	promoteProcess = proceed;
	processStatus = underway;
	mutex.unlock();
}

void FastaFileAnalyzer::
getProcessStatus(	Process& process_status,
					quint64& prosessed_data,
					quint64& total_data)
{
	mutex.lock();
	process_status = processStatus;
	prosessed_data = processedData;
	total_data = totalData;
	mutex.unlock();
}


void FastaFileAnalyzer::run(void)
{
	//�t�@�C���̃T�C�Y�̑��v���v�Z
	quint64 totalFileSize = 0;
	quint64 processedFileSize = 0;
	countA = 0;
	countC = 0;
	countG = 0;
	countT = 0;
	countN = 0;
	int i;
	for(i=0; i<filePathList.size(); i++){
		QFileInfo info(filePathList[i]);
		if(!info.exists()){
			setProcessStatus(failed, 0, 0);
			return;
		}
		totalFileSize += info.size();
	}

	for(i=0; i<filePathList.size(); i++){

		QFile inFile(filePathList[i]);
		if(!inFile.open(QIODevice::ReadOnly)){
			setProcessStatus(failed, 0, totalFileSize);
			return;
		}
        quint64 offset=inFile.pos();
        QByteArray data=inFile.read(BufferSizeMax);
        if(!inFile.atEnd()){
            int lastIndex=data.lastIndexOf('\n');
            if(lastIndex!=-1){
                //'\n'�ȍ~�͏���
                data.resize(lastIndex+1);
                //����̃t�@�C���ǂݏo���J�n�ʒu�܂ŃV�[�N
                inFile.seek(offset+lastIndex+1);
            }
        }
		QBuffer in(&data);
		in.open(QIODevice::ReadOnly);
		if(!in.isOpen()){
			break;
		}

		QString seqName;
		QString	seqDesc;
		qint64	seqLength = 0;
		qint64	seqStartOffset = 0;
		qint64	seqEndOffset = 0;
		qint64	dataSize = 0;
		qint64	numAnalized = 0;
		QByteArray line;

		//GFF�t�@�C���Ȃ�ΑO�������K�v
		QFileInfo info(filePathList[i]);
		if(info.suffix()=="gff"||info.suffix()=="gtf"){
            //GFF�t�@�C���Ȃ�GFF��PRAGMA���K�v
			//QByteArray GFF3Pragma("##gff-version\\s3");
			QRegExp GFF3Pragma("##gff-version\\s3");
			//QByteArray buffer=in.readLine().trimmed();
			QString buffer = QString(in.readLine().trimmed());
			if(buffer.indexOf(GFF3Pragma)!=0){
				setProcessStatus(failed, 0, 0);
				return;
			}
            //##FASTA���o������܂Ői��
			while(!in.atEnd()||!inFile.atEnd()){
				if(in.atEnd()){
					in.close();
                    offset=inFile.pos();
                    data=inFile.read(BufferSizeMax);
                    if(!inFile.atEnd()){
                        int lastIndex=data.lastIndexOf('\n');
                        if(lastIndex!=-1){
                            //'\n'�ȍ~�͏���
                            data.resize(lastIndex+1);
                            //����̃t�@�C���ǂݏo���J�n�ʒu�܂ŃV�[�N
                            inFile.seek(offset+lastIndex+1);
                        }
                    }
					in.open(QIODevice::ReadOnly);
					if(!in.isOpen()){
						break;
					}
				}
				line=in.readLine().trimmed();
				numAnalized++;
				if(numAnalized%1000==0){
					//
					if(!getOrder()){
						setProcessStatus(stopped, 0, 0);
						return;
					}
					setProcessStatus(underway, processedFileSize+in.pos()+inFile.pos()-data.size(), totalFileSize);
				}
				QByteArray FastaPragma("##FASTA");
				if(line.indexOf(FastaPragma)==0){
					break;
				}
			}
		}

		while(!in.atEnd()||!inFile.atEnd()){

            if(in.atEnd()){
                in.close();
                offset=inFile.pos();
                data=inFile.read(BufferSizeMax);
                if(!inFile.atEnd()){
                    int lastIndex=data.lastIndexOf('\n');
                    if(lastIndex!=-1){
                        //'\n'�ȍ~�͏���
                        data.resize(lastIndex+1);
                        //����̃t�@�C���ǂݏo���J�n�ʒu�܂ŃV�[�N
                        inFile.seek(offset+lastIndex+1);
                    }
                }
                in.open(QIODevice::ReadOnly);
                if(!in.isOpen()){
                    break;
                }
            }
            seqEndOffset=in.pos()+inFile.pos()-data.size();
			line=in.readLine().trimmed();
			if(line.size()>0&&line[0]=='>'){
				if(seqLength!=0){
					dataSize=seqEndOffset-seqStartOffset;
					SeqInfo seqInfo(seqName, seqDesc, seqLength, seqStartOffset, dataSize, filePathList[i]);
					seqInfoList.push_back(seqInfo);
					seqLength = 0;
				}
				QString buffer(line);
				//���O�Ɣ��l�̐؂蕪���Ɗi�[
				QString titleLine(buffer);
				int seqPos = titleLine.indexOf(QRegExp("[\\s]+"), 1);
				if(seqPos==-1){
					seqName = titleLine.right(line.size()-1);
					seqDesc = "";
				}
				else{
					seqName = titleLine.mid(1, seqPos-1);
					seqDesc = titleLine.right(line.size()-seqPos-1);
				}
				//�I�t�Z�b�g�̋L�^
                seqStartOffset = in.pos()+inFile.pos()-data.size();
				
			}
			else{
				seqLength += line.size();
				for(int i=0; i<line.size(); i++){
					if(line[i]=='A'){
						countA++;
					}
					else if(line[i]=='a'){
						countA++;
					}
					else if(line[i]=='C'){
						countC++;
					}
					else if(line[i]=='c'){
						countC++;
					}
					else if(line[i]=='G'){
						countG++;
					}
					else if(line[i]=='g'){
						countG++;
					}
					else if(line[i]=='T'){
						countT++;
					}
					else if(line[i]=='t'){
						countT++;
					}
					else{
						countN++;
					}
				}
			}
			numAnalized++;
			if(numAnalized%1000==0){
				//
				if(!getOrder()){
					setProcessStatus(stopped, 0, 0);
					return;
				}
				setProcessStatus(underway, processedFileSize+in.pos()+inFile.pos()-data.size(), totalFileSize);
			}
		}
		seqEndOffset=in.pos()+inFile.pos()-data.size();
		if(seqLength!=0){
			dataSize=seqEndOffset-seqStartOffset;
			SeqInfo seqInfo(seqName, seqDesc, seqLength, seqStartOffset, dataSize, filePathList[i]);
			seqInfoList.push_back(seqInfo);
			seqLength = 0;
		}
		processedFileSize+=inFile.size();
	}

	setProcessStatus(finished, totalFileSize, totalFileSize);
	return;

}

const SeqInfoList& FastaFileAnalyzer::getSeqInfo(void) const
{
	return seqInfoList;
}

void FastaFileAnalyzer::
GetNucleitodeConents(	quint64& count_a,
						quint64& count_c,
						quint64& count_g,
						quint64& count_t,
						quint64& count_n)
{
	count_a=countA;
	count_c=countC;
	count_g=countG;
	count_t=countT;
	count_n=countN;
}
