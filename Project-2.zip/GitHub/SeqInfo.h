#include <QtCore>
#if QT_VERSION >= 0x050000
#include <QtWidgets>
#else
#include <QtGui>
#endif

#ifndef SEQ_INFO_H
#define SEQ_INFO_H

#include "DesktopTrackCommon.h"

namespace DesktopTrack{

	struct SeqInfo{
		QString		seqId;
		QString		renameTo;
		QString		descriptions;
		qint64		seqLength;
		qint64		fileOffset;
		qint64		dataSize;
		QString		seqFilePath;
		SeqInfo(void);
		SeqInfo(const QString&	seqId,
				const QString&	descriptions,
				const qint64&	seqLength,
				const qint64&	fileOffset,
				const qint64&	dataSize,
				const QString&	seqFilePath);
		SeqInfo& operator=(const SeqInfo& original);
	};

	typedef QList<SeqInfo> SeqInfoList;

	class FastaFileAnalyzer: public QThread{ 
	public:
		enum Process{underway, stopped, failed, finished};
	private:
		//
		QStringList	filePathList;
		SeqInfoList seqInfoList;
		quint64		countA;
		quint64		countC;
		quint64		countG;
		quint64		countT;
		quint64		countN;

		/*-----thread�ԒʐM�p�ϐ���������-----*/
		QMutex	mutex;
		bool	promoteProcess;
		Process processStatus;
		quint64	processedData;
		quint64	totalData;
		/*-----thread�ԒʐM�p�ϐ������܂�-----*/

		//Thread Safe�̂͂�
		void setProcessStatus(	const Process& process_status,
								const quint64& prosessed_data,
								const quint64& total_data);
		//Thread Safe�̂͂�
		bool getOrder(void);

	public:
		FastaFileAnalyzer(QObject* parent=0);
		void setFilePath(	const QStringList& filePathList);

		//Thread Safe�̂͂�
		void setOrder(bool proceed);
		//Thread Safe�̂͂�
		void getProcessStatus(	Process& process_status,
								quint64& prosessed_data,
								quint64& total_data);
		const SeqInfoList& getSeqInfo(void) const;
		void GetNucleitodeConents(	quint64& count_a,
									quint64& count_c,
									quint64& count_g,
									quint64& count_t,
									quint64& count_n);
		void run(void);

	};
	
};

#endif

