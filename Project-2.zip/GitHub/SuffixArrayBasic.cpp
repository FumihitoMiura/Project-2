#include "SuffixArrayBasic.h"

using namespace DesktopTrack;

/*---------------------------------
	class SuffixArrayBasic
---------------------------------*/

SuffixArrayBasic::SuffixArrayBasic(void):EncoderBasic(){}

SuffixArrayBasic::~SuffixArrayBasic(void){}

void SuffixArrayBasic::debugC(quint8* s, quint64 n, quint64 o)
{
	quint64 i;

	QString line;
	QTextStream txt(&line);

	txt << endl;

	for(i=n; i<n+o; i++){
		txt << getChar(s, i) << '\t';
	}
	txt << endl;
	qDebug() << line;

}

void SuffixArrayBasic::debugC(quint8* s, quint8* SA, quint8* type, quint64 n)
{
	quint64 i;

	QString line;
	QTextStream txt(&line);

	txt << endl;

	for(i=0; i<n; i++){
		txt << getChar(s, i) << '\t';
	}
	txt << endl;
	for(i=0; i<n; i++){
		txt << getInt(SA, i) << '\t';
	}
	txt << endl;
	for(i=0; i<n; i++){
		if(getBit(type, i)){
			txt << "S\t";
		}
		else{
			txt << "L\t";
		}
	}
	txt << endl;
	qDebug() << line;

};

void SuffixArrayBasic::debugI(quint8* s, quint8* SA, quint8* type, quint64 n)
{
	quint64 i;

	QString line;
	QTextStream txt(&line);


	for(i=0; i<n; i++){
		txt << getInt(s, i) << '\t';
	}
	txt << endl;
	for(i=0; i<n; i++){
		txt << getInt(SA, i) << '\t';
	}
	txt << endl;
	for(i=0; i<n; i++){
		if(getBit(type, i)){
			txt << "S\t";
		}
		else{
			txt << "L\t";
		}
	}
	qDebug() << line;

};

bool SuffixArrayBasic::SAISC(quint8* s, quint8* SA, quint64 n, quint64 k){
	
	if(n<3){
		return false;
	}

	quint64 i, j, sum;
	//Character��S��L�ɕ���
	//S�Ȃ�true, L�Ȃ�false
	quint8* type;
	try{
		quint64 size;
		if(n%8==0){
			size=n/8;
		}
		else{
			size=n/8+1;
		}
		type=new quint8[size];
		for(i=0; i<size; i++){
			type[i]=0;
		}
	}
	catch(...){
		return false;
	}

	setBit(type, n-1, true);
	setBit(type, n-2, false);

	i=n-3;
	while(true){
		quint8 base1=getChar(s, i);
		quint8 base2=getChar(s, i+1);
		if(base1<base2){
			setBit(type, i, true);
		}
		else if(base1==base2&&getBit(type, i+1)){
			setBit(type, i, true);
		}
		if(i==0){
			break;
		}
		i--;
	}

	//�o�P�b�g�p��
	quint64* bucket;
	try{
		bucket=new quint64[k];
	}
	catch(...){
		return false;
	}

	//�o�P�b�g�v�Z�i�E�l�߁j
	for(i=0; i<k; i++){
		bucket[i]=0;
	}
	for(i=0; i<n; i++){
		bucket[getChar(s, i)]++;
	}
	sum=0;
	for(i=0; i<k; i++){
		sum+=bucket[i];
		bucket[i]=sum-1;
	}
	//SuffixArray���ő�l�ŏ�����
	for(i=0; i<n; i++){
		setInt(SA, i, maxValue);
	}
	//LMS�𔲂��o��
	for(i=1; i<n; i++){
		if(getBit(type, i)&&!getBit(type, i-1)){
			quint8 base=getChar(s, i);
			quint64 pos=bucket[base];
			setInt(SA, pos, i);
			bucket[base]--;
		}
	}

	//debugC(s, SA, type, n);

	//�o�P�b�g�v�Z�i���l�߁j
	for(i=0; i<k; i++){
		bucket[i]=0;
	}
	for(i=0; i<n; i++){
		bucket[getChar(s, i)]++;
	}
	sum=0;
	for(i=0; i<k; i++){
		quint64 value=bucket[i];
		bucket[i]=sum;
		sum+=value;
	}
	//L-type string��induced soat
	for(i=0; i<n; i++) {
		if(getInt(SA, i)==maxValue||getInt(SA, i)==0){
			continue;
		}
		j=getInt(SA, i)-1;
		if(!getBit(type, j)){
			quint8 base=getChar(s, j);
			quint64 pos=bucket[base];
			setInt(SA, pos, j);
			bucket[base]++;
		}
	}

	//debugC(s, SA, type, n);

	//�o�P�b�g�v�Z�i�E�l�߁j
	for(i=0; i<k; i++){
		bucket[i]=0;
	}
	for(i=0; i<n; i++){
		bucket[getChar(s, i)]++;
	}
	sum=0;
	for(i=0; i<k; i++){
		sum+=bucket[i];
		bucket[i]=sum-1;
	}
	//S-type string��induced soat
	i=n-1;
	while(1){
		if(getInt(SA, i)==maxValue||getInt(SA, i)==0){
			if(i==0){
				break;
			}
			i--;
			continue;
		}
		j=getInt(SA, i)-1;
		if(getBit(type, j)){
			quint8 base=getChar(s, j);
			quint64 pos=bucket[base];
			setInt(SA, pos, j);
			bucket[base]--;
		}
		if(i==0){
			break;
		}
		i--;
	}

	//debugC(s, SA, type, n);

	//LMS�𔲂��o��
	quint64 n1=0;
	for(i=0; i<n; i++) {
		j=getInt(SA, i);
		if(j==0||j==maxValue){
			continue;
		}
		if(getBit(type, j)&&!getBit(type, j-1)){
			setInt(SA, n1, j);
			n1++;
		}
	}
	//LMS�ȊO�͍ő�l�Ŗ��߂�
	for(i=n1; i<n; i++) {
		setInt(SA, i, maxValue);
	}

	//debugC(s, SA, type, n);

	//LMS�ɖ��O��t����
	quint64 name=1;
	quint64 prev=getInt(SA, 0);
	quint64 curr=prev;
	quint64 pos=curr/2;
	setInt(SA, n1+pos, name-1);
	for(i=1; i<n1; i++) {
		curr=getInt(SA, i);
		if(getChar(s, curr)!=getChar(s, prev)){
			name++;
			prev=curr;
			pos=curr/2;
			setInt(SA, n1+pos, name-1);
			
		}
		else{
			for(j=1; j<n; j++){
				if(getChar(s, curr+j)!=getChar(s, prev+j)){
					name++;
					prev=curr;
					pos=curr/2;
					setInt(SA, n1+pos, name-1);
					break;
				}
				else if(getBit(type, curr+j)!=getBit(type, prev+j)){
					name++;
					prev=curr;
					pos=curr/2;
					setInt(SA, n1+pos, name-1);
					break;
				}
				else if(getBit(type, curr+j)&&!getBit(type, curr+j-1)){
					pos=curr/2;
					setInt(SA, n1+pos, name-1);
					break;
				}
				else if(getBit(type, prev+j)&&!getBit(type, prev+j-1)){
					pos=curr/2;
					setInt(SA, n1+pos, name-1);
					break;
				}
			}
		}
	}
	//debugC(s, SA, type, n);
	//���O�̕t����LMS���E��
	for(i=n-1, j=n-1; i>=n1; i--) {
		quint64 value=getInt(SA, i);
		if(value!=maxValue){
			setInt(SA, j, value);
			setInt(SA, i, maxValue);
			j--;
		}
	}

	//debugC(s, SA, type, n);

	quint8* SA1=SA;
	quint8* s1=SA+(n-n1)*sizeofInt;
	if(name<n1){
		SAISI(s1, SA1, n1, name);
	}
	else{
		for(i=0; i<n1; i++){
			quint64 pos=getInt(s1, i);
			setInt(SA1, pos, i);
		}
	}

	//debugC(s, SA, type, n);

	//s����LMS���ēx�����o��
	j=0;
	for(i=1; i<n; i++){
		if(getBit(type, i)&&!getBit(type, i-1)){
			setInt(s1, j, i);
			j++;
		}
	}

	//debug(s, SA, type, n);

	//���O���ʒu�ɖ߂�
	for(i=0; i<n1; i++){
		//SA1[i]=s1[SA1[i]];
		setInt(SA1, i, getInt(s1, getInt(SA1, i)));
	}

	//debugC(s, SA, type, n);

	for(i=n1; i<n; i++){
		setInt(SA1, i, maxValue);
	}

	//debugC(s, SA, type, n);

	//�o�P�b�g�v�Z�i�E�l�߁j�j
	for(i=0; i<k; i++){
		bucket[i]=0;
	}
	for(i=0; i<n; i++){
		bucket[getChar(s, i)]++;
	}
	sum=0;
	for(i=0; i<k; i++){
		sum+=bucket[i];
		bucket[i]=sum-1;
	}

	//LMS���o�P�b�g�ɕ��z
	i=n1-1;
	while(true){
		j=getInt(SA, i);
		setInt(SA, i, maxValue);
		quint8 base=getChar(s, j);
		quint64 pos=bucket[base];
		setInt(SA, pos, j);
		bucket[base]--;
		if(i==0){
			break;
		}
		i--;
	}

	//debugC(s, SA, type, n);
	
	//�o�P�b�g�v�Z�i���l�߁j
	for(i=0; i<k; i++){
		bucket[i]=0;
	}
	for(i=0; i<n; i++){
		bucket[getChar(s, i)]++;
	}
	sum=0;
	for(i=0; i<k; i++){
		quint64 value=bucket[i];
		bucket[i]=sum;
		sum+=value;
	}
	//L-type string��induced soat
	for(i=0; i<n; i++) {
		if(getInt(SA, i)==maxValue||getInt(SA, i)==0){
			continue;
		}
		j=getInt(SA, i)-1;
		if(!getBit(type, j)){
			quint8 base=getChar(s, j);
			quint64 pos=bucket[base];
			setInt(SA, pos, j);
			bucket[base]++;
		}
	}

	//debugC(s, SA, type, n);

	//�o�P�b�g�v�Z�i�E�l�߁j
	for(i=0; i<k; i++){
		bucket[i]=0;
	}
	for(i=0; i<n; i++){
		bucket[getChar(s, i)]++;
	}
	sum=0;
	for(i=0; i<k; i++){
		sum+=bucket[i];
		bucket[i]=sum-1;
	}
	//S-type string��induced soat
	i=n-1;
	while(1){
		if(getInt(SA, i)==maxValue||getInt(SA, i)==0){
			if(i==0){
				break;
			}
			i--;
			continue;
		}
		j=getInt(SA, i)-1;
		if(getBit(type, j)){
			quint8 base=getChar(s, j);
			quint64 pos=bucket[base];
			setInt(SA, pos, j);
			bucket[base]--;
		}
		if(i==0){
			break;
		}
		i--;
	}

	delete[] type;
	delete[] bucket;

	//debugC(s, SA, type, n);
	return true;

}

bool SuffixArrayBasic::SAISI(quint8* s, quint8* SA, quint64 n, quint64 k){

	quint64 i, j, sum;
	//Character��S��L�ɕ���
	//S�Ȃ�true, L�Ȃ�false
	quint8* type;
	try{
		quint64 size;
		if(n%8==0){
			size=n/8;
		}
		else{
			size=n/8+1;
		}
		type=new quint8[size];
		for(i=0; i<size; i++){
			type[i]=0;
		}
	}
	catch(...){
		return false;
	}
	setBit(type, n-1, true);
	setBit(type, n-2, false);
	i=n-3;
	while(1){
		quint64 base1=getInt(s, i);
		quint64 base2=getInt(s, i+1);
		if(base1<base2){
			setBit(type, i, true);
		}
		else if(base1==base2&&getBit(type, i+1)){
			setBit(type, i, true);
		}
		if(i==0){
			break;
		}
		i--;
	}

	//debugI(s, SA, type, n);

	//�o�P�b�g�p��
	quint64* bucket;
	try{
		bucket=new quint64[k];
	}
	catch(...){
		return false;
	}

	//�o�P�b�g�v�Z�i�E�l�߁j
	for(i=0; i<k; i++){
		bucket[i]=0;
	}
	for(i=0; i<n; i++){
		bucket[getInt(s, i)]++;
	}
	sum=0;
	for(i=0; i<k; i++){
		sum+=bucket[i];
		bucket[i]=sum-1;
	}
	//SuffixArray���ő�l�ŏ�����
	for(i=0; i<n; i++){
		setInt(SA, i, maxValue);
	}
	//LMS�𔲂��o��
	for(i=1; i<n; i++){
		if(getBit(type, i)&&!getBit(type, i-1)){
			quint64 base=getInt(s, i);
			quint64 pos=bucket[base];
			setInt(SA, pos, i);
			bucket[base]--;
		}
	}

	//debugI(s, SA, type, n);

	//�o�P�b�g�v�Z�i���l�߁j
	for(i=0; i<k; i++){
		bucket[i]=0;
	}
	for(i=0; i<n; i++){
		bucket[getInt(s, i)]++;
	}
	sum=0;
	for(i=0; i<k; i++){
		quint64 value=bucket[i];
		bucket[i]=sum;
		sum+=value;
	}
	//L-type string��induced soat
	for(i=0; i<n; i++) {
		quint64 v=getInt(SA, i);
		if(v==maxValue||v==0){
			continue;
		}
		j=v-1;
		if(!getBit(type, j)){
			quint64 base=getInt(s, j);
			quint64 pos=bucket[base];
			setInt(SA, pos, j);
			bucket[base]++;
		}
	}

	//debugI(s, SA, type, n);

	//�o�P�b�g�v�Z�i�E�l�߁j
	for(i=0; i<k; i++){
		bucket[i]=0;
	}
	for(i=0; i<n; i++){
		bucket[getInt(s, i)]++;
	}
	sum=0;
	for(i=0; i<k; i++){
		sum+=bucket[i];
		bucket[i]=sum-1;
	}
	//S-type string��induced soat
	i=n-1;
	while(true){
		if(getInt(SA, i)==maxValue||getInt(SA, i)==0){
			if(i==0){
				break;
			}
			i--;
			continue;
		}
		j=getInt(SA, i)-1;
		if(getBit(type, j)){
			quint64 base=getInt(s, j);
			quint64 pos=bucket[base];
			setInt(SA, pos, j);
			bucket[base]--;
		}
		if(i==0){
			break;
		}
		i--;
	}

	//debugI(s, SA, type, n);

	//LMS�𔲂��o��
	quint64 n1=0;
	for(i=0; i<n; i++) {
		j=getInt(SA, i);
		if(j==0||j==maxValue){
			continue;
		}
		if(getBit(type, j)&&!getBit(type, j-1)){
			setInt(SA, n1, j);
			n1++;
		}
	}
	//LMS�ȊO�͍ő�l�Ŗ��߂�
	for(i=n1; i<n; i++) {
		setInt(SA, i, maxValue);
	}

	//debugI(s, SA, type, n);

	//LMS�ɖ��O��t����
	quint64 name=1;
	quint64 prev=getInt(SA, 0);
	quint64 curr=prev;
	quint64 pos=curr/2;
	setInt(SA, n1+pos, name-1);
	for(i=1; i<n1; i++) {
		curr=getInt(SA, i);
		if(getInt(s, curr)!=getInt(s, prev)){
			name++;
			prev=curr;
			pos=curr/2;
			setInt(SA, n1+pos, name-1);
			
		}
		else{
			for(j=1; j<n; j++){
				if(getInt(s, curr+j)!=getInt(s, prev+j)){
					name++;
					prev=curr;
					pos=curr/2;
					setInt(SA, n1+pos, name-1);
					
					break;
				}
				else if(getBit(type, curr+j)!=getBit(type, prev+j)){
					name++;
					prev=curr;
					pos=curr/2;
					setInt(SA, n1+pos, name-1);
					
					break;
				}
				else if(getBit(type, curr+j)&&!getBit(type, curr+j-1)){
					pos=curr/2;
					setInt(SA, n1+pos, name-1);
					break;
				}
				else if(getBit(type, prev+j)&&!getBit(type, prev+j-1)){
					pos=curr/2;
					setInt(SA, n1+pos, name-1);
					break;
				}
			}
		}
	}
	//debugI(s, SA, type, n);
	//���O�̕t����LMS���E��
	for(i=n-1, j=n-1; i>=n1; i--) {
		quint64 value=getInt(SA, i);
		if(value!=maxValue){
			setInt(SA, j, value);
			setInt(SA, i, maxValue);
			j--;
		}
	}

	//debugI(s, SA, type, n);

	quint8* SA1=SA;
	quint8* s1=SA+(n-n1)*sizeofInt;
	if(name<n1){
		SAISI(s1, SA1, n1, name);
	}
	else{
		for(i=0; i<n1; i++){
			quint64 pos=getInt(s1, i);
			setInt(SA1, pos, i);
		}
	}

	//debugI(s, SA, type, n);

	//s����LMS���ēx�����o��
	j=0;
	for(i=1; i<n; i++){
		if(getBit(type, i)&&!getBit(type, i-1)){
			setInt(s1, j, i);
			j++;
		}
	}

	//debugI(s, SA, type, n);

	//���O���ʒu�ɖ߂�
	for(i=0; i<n1; i++){
		//SA1[i]=s1[SA1[i]];
		setInt(SA1, i, getInt(s1, getInt(SA1, i)));
	}

	//debugI(s, SA, type, n);

	for(i=n1; i<n; i++){
		setInt(SA1, i, maxValue);
	}

	//debugI(s, SA, type, n);

	//�o�P�b�g�v�Z�i�E�l�߁j�j
	for(i=0; i<k; i++){
		bucket[i]=0;
	}
	for(i=0; i<n; i++){
		bucket[getInt(s, i)]++;
	}
	sum=0;
	for(i=0; i<k; i++){
		sum+=bucket[i];
		bucket[i]=sum-1;
	}

	//LMS���o�P�b�g�ɕ��z
	i=n1-1;
	while(1){
		j=getInt(SA, i);
		setInt(SA, i, maxValue);
		quint64 base=getInt(s, j);
		quint64 pos=bucket[base];
		setInt(SA, pos, j);
		bucket[base]--;
		if(i==0){
			break;
		}
		i--;
	}

	//debugI(s, SA, type, n);
	
	//�o�P�b�g�v�Z�i���l�߁j
	for(i=0; i<k; i++){
		bucket[i]=0;
	}
	for(i=0; i<n; i++){
		bucket[getInt(s, i)]++;
	}
	sum=0;
	for(i=0; i<k; i++){
		quint64 value=bucket[i];
		bucket[i]=sum;
		sum+=value;
	}
	//L-type string��induced soat
	for(i=0; i<n; i++) {
		quint64 v=getInt(SA, i);
		if(v==maxValue||v==0){
			continue;
		}
		j=v-1;
		if(!getBit(type, j)){
			quint64 base=getInt(s, j);
			quint64 pos=bucket[base];
			setInt(SA, pos, j);
			bucket[base]++;
		}
	}

	//debugI(s, SA, type, n);

	//�o�P�b�g�v�Z�i�E�l�߁j
	for(i=0; i<k; i++){
		bucket[i]=0;
	}
	for(i=0; i<n; i++){
		bucket[getInt(s, i)]++;
	}
	sum=0;
	for(i=0; i<k; i++){
		sum+=bucket[i];
		bucket[i]=sum-1;
	}
	//S-type string��induced soat
	i=n-1;
	while(1){
		if(getInt(SA, i)==maxValue||getInt(SA, i)==0){
			if(i==0){
				break;
			}
			i--;
			continue;
		}
		j=getInt(SA, i)-1;
		if(getBit(type, j)){
			quint64 base=getInt(s, j);
			quint64 pos=bucket[base];
			setInt(SA, pos, j);
			bucket[base]--;
		}
		if(i==0){
			break;
		}
		i--;
	}

	//debugI(s, SA, type, n);

	delete[] type;
	delete[] bucket;

	return true;

}

quint64 SuffixArrayBasic::
lowerBound(	quint8* s, quint8* SA, quint64 sl,
			quint64 lb, quint64 ub, 
			quint8* q, quint64 qo, quint64 ql)
{
	if(lb>ub){
		return maxValue;
	}
	quint8 sc, qc;
	quint64 i, j, pivot;
	for(i=qo, j=getInt(SA, lb); i<qo+ql&&j<sl; i++, j++)
	{
		sc=getChar(s, j);
		qc=getChar(q, i);
		if(sc==qc){
			continue;
		}
		else{
			break;
		}
	}
	if(sc==qc){
		return lb;
	}
    else if(lb==ub){
        return maxValue;
    }

	while(true)
	{
		pivot=((lb+ub)%2==0)?(lb+ub)/2:(lb+ub+1)/2;
		for(i=qo, j=getInt(SA, pivot); i<qo+ql&&j<sl; i++, j++)
		{
			sc=getChar(s, j);
			qc=getChar(q, i);
			if(sc==qc){
				continue;
			}
			else if(sc<qc){
				if(lb+1==ub){
					return maxValue;
				}
				lb=pivot;
				break;
			}
			else{
				if(lb+1==ub){
					return maxValue;
				}
				ub=pivot;
				break;
			}
		}
		if(sc==qc){
			if(lb+1==ub){
				return ub;
			}
			else{
				ub=pivot;
			}
		}
	}
}

quint64 SuffixArrayBasic::
upperBound(	quint8* s, quint8* SA, quint64 sl,
			quint64 lb, quint64 ub, 
			quint8* q, quint64 qo, quint64 ql)
{
	if(lb>ub){
		return maxValue;
	}
	quint8 sc, qc;
	quint64 i, j, pivot;
	for(i=qo, j=getInt(SA, ub); i<qo+ql&&j<sl; i++, j++)
	{
		sc=getChar(s, j);
		qc=getChar(q, i);
		if(sc==qc){
			continue;
		}
		else{
			break;
		}
	}
	if(sc==qc){
		return ub;
	}
    else if(lb==ub){
        return maxValue;
    }

	while(true)
	{
		pivot=(lb+ub)/2;
		for(i=qo, j=getInt(SA, pivot); i<qo+ql&&j<sl; i++, j++)
		{
			sc=getChar(s, j);
			qc=getChar(q, i);
			if(sc==qc){
				continue;
			}
			else if(sc<qc){
				if(lb+1==ub){
					return maxValue;
				}
				lb=pivot;
				break;
			}
			else{
				if(lb+1==ub){
					return maxValue;
				}
				ub=pivot;
				break;
			}
		}
		if(sc==qc){
			if(lb+1==ub){
				return lb;
			}
			else{
				lb=pivot;
			}
		}
	}
}

//


quint64 SuffixArrayBasic::
lowerBoundE(quint8* s, quint8* SA, quint64 sl,
			quint64 lb, quint64 ub, 
			quint8* q, quint64 qo, quint64 ql)
{
	//lb�͕K��ub�Ɠ������������l�łȂ���΂Ȃ�Ȃ�
	if(lb>ub){
		return maxValue;
	}
	//lb������ql�̒����̌������s�\�Ȃ甲����
	quint64 pos=getInt(SA, lb);
	if(pos+ql>=sl){
		return maxValue;
	}
	quint8 sc=getChar(s, pos+ql-1);
	quint8 qc=getChar(q, qo+ql-1);
	quint64 pivot;
	//�ꉖ��L�΂��Ă�lb��query�ƈ�v����Ȃ�lb���V����lb
	if(sc==qc){
		return lb;
	}
    else if(lb==ub){
        return maxValue;
    }
	while(true)
	{
		//lb�͈�v���Ȃ����Ƃ͊m�F�ς�
		//�̂�pivot��ub���Ɉړ�����ilb+1=ub�̂Ƃ��ɏd�v�j
		if((lb+ub)%2==0){
			pivot=(lb+ub)/2;
		}
		else{
			pivot=(lb+ub+1)/2;
		}
		//pivot=((lb+ub)%2==0)?(lb+ub)/2:(lb+ub+1)/2;	
		pos=getInt(SA, pivot);
		//qDebug() << pos ;
		sc=getChar(s, pos+ql-1);
		if(sc<qc){
			if(lb+1==ub){
				return maxValue;
			}
			lb=pivot;
		}
		else if(sc>qc){
			if(lb+1==ub){
				return maxValue;
			}
			ub=pivot;
		}
		else{	//sc==qc
			if(lb+1==ub){
				return ub;
			}
			ub=pivot;
		}
	}
}

quint64 SuffixArrayBasic::
upperBoundE(quint8* s, quint8* SA, quint64 sl,
			quint64 lb, quint64 ub, 
			quint8* q, quint64 qo, quint64 ql)
{
	//lb�͕K��ub�Ɠ������������l�łȂ���΂Ȃ�Ȃ�
	if(lb>ub){
		return maxValue;
	}
	//ub������ql�̒����̌������s�\�Ȃ甲����
	quint64 pos=getInt(SA, ub);
	if(pos+ql>=sl){
		return maxValue;
	}
	quint8 sc=getChar(s, pos+ql-1);
	quint8 qc=getChar(q, qo+ql-1);
	quint64 pivot;
	//�ꉖ��L�΂��Ă�ub����v����Ȃ�ub���V����ub
	if(sc==qc){
		return ub;
	}
    else if(lb==ub){
        return maxValue;
    }
	while(true)
	{
		pivot=(lb+ub)/2;
		pos=getInt(SA, pivot);
		sc=getChar(s, pos+ql-1);
		if(sc<qc){
			if(lb+1==ub){
				return maxValue;
			}
			lb=pivot;
		}
		else if(sc>qc){
			if(lb+1==ub){
				return maxValue;
			}
			ub=pivot;
		}
		else{	//sc==qc
			if(lb+1==ub){
				return lb;
			}
			lb=pivot;
		}
	}
}

quint64 SuffixArrayBasic::calcBoosterIndexSize(quint64 wordSize)
{
	//�K�v�������e�ʌv�Z
    quint64 i, size=1;
    for(i=0; i<wordSize; i++){
        size*=6;
    }
    return size*sizeofInt;
}

bool SuffixArrayBasic::
createBoosterIndex(quint8* s, quint8* SA, quint64 sl,
                   quint64 wordSize, quint8* boosterIndex, quint64 bl)
{
    //�K�v�������e�ʌv�Z
    quint64 i, idxCount=1;
    for(i=0; i<wordSize; i++){
        idxCount*=6;
    }
    //�v�Z�e�ʂƊ��蓖�ėe�ʂ��قȂ�Δ�����
    if(bl!=idxCount*sizeofInt){
        return false;
    }
	setInt(boosterIndex, 0, 0);
    quint64 previousPos=0, previousID=0;
	quint64 currentPos, currentID;
    for(currentPos=0; currentPos<sl; currentPos++){
        currentID=getId(s, sl, getInt(SA, currentPos), wordSize);
        if(currentID==maxValue){
            continue;
        }
        if(previousID==currentID){
            previousPos=currentPos;
        }
        else{
            for(i=previousID; i<currentID; i++){
				setInt(boosterIndex, i, previousPos);
			}
			previousPos=currentPos;
			previousID=currentID;
        }
    }
    for(i=previousID; i<idxCount; i++){
        setInt(boosterIndex, i, previousPos);
    }
	return true;
}

bool SuffixArrayBasic::
searchBounds(quint8* BIdx, quint64 id,
             quint64& lb, quint64& ub)
{
    if(id==0){
        quint64 l=0;
        quint64 u=getInt(BIdx, id);
        if(u>l){
            lb=l+1;
            ub=u;
            return true;
        }
        else{
            return false;
        }
    }
    else{
        quint64 l=getInt(BIdx, id-1);
        quint64 u=getInt(BIdx, id);
        if(u>l){
            lb=l+1;
            ub=u;
            return true;
        }
        else{
            return false;
        }
    }
 }

bool SuffixArrayBasic::
shrinkBoosterIndex(	quint8* BIdxOrig, quint8* BIdxTo,
					quint64 wsBefore, quint64 wsAfter)
{
	//word size�͏�����K���������Ȃ�
	if(wsBefore<=wsAfter){
		return false;
	}
	quint64 i, idxCountBefore=1, idxCountAfter, shrinkRatio;
    for(i=0; i<wsBefore; i++){
        idxCountBefore*=6;
		if(i==wsBefore-wsAfter-1){
			shrinkRatio=idxCountBefore;
		}
		if(i==wsAfter-1){
			idxCountAfter=idxCountBefore;
		}
    }

	for(i=0; i<idxCountAfter; i++){
		setInt(BIdxTo, i, getInt(BIdxOrig, shrinkRatio*i));
	}
	return true;
}

