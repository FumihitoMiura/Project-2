#include "BWTBasic.h"

using namespace DesktopTrack;

BWTBasic::BWTBasic(const quint64& scf, const quint64& scl):
SCF(scf), SCL(scl), SuffixArrayBasic(){}

BWTBasic::~BWTBasic(void){}

void BWTBasic::SA2BWT(quint8* s, quint8* SA, quint64 n, quint8* BWT)
{

	for(quint64 i=0; i<n; i++){
		//�܂��A�ʒu���擾
		quint64 pos=getInt(SA, i);
		quint8 c;
		if(pos==0){
			c=getChar(s, n-1);
		}
		else{
			c=getChar(s, pos-1);
		}
        setChar(BWT, i, c);
	}

}

quint64 BWTBasic::calcMemorySize(quint64 refSize, quint64 shCoef)
{
	quint64 size=0;

	/*�@�܂��͍��Ȃ����́@*/
	//Bwt�̃T�C�Y
	size+=(refSize%2==0?refSize/2:(refSize+1)/2);
	/*�@���͍�����́@*/
	//Shrinked SuffixArray�̃T�C�Y�i�����A���C�j
	size+=(refSize*sizeofInt%shCoef==0?refSize*sizeofInt/shCoef:refSize*sizeofInt/shCoef+refSize*sizeofInt);
	//Milestone Counter for BWT�i$�AA�AC�AG�AT�AN��6��ށj
	size+=((refSize*sizeofInt%shCoef==0?refSize*sizeofInt/shCoef:refSize*sizeofInt/shCoef+refSize*sizeofInt)*6);

	return size;

}

#ifndef INLINE
quint64 BWTBasic::
BWTOcc(	quint8			c, 
		quint8*			BWT, 
		quint8**		MCB, 
        quint64 		pos)
{
	quint64 mcbPos=pos/SCL;
	quint64 bwtBgn=mcbPos*SCL;
    quint64 count=getInt(MCB[c], mcbPos);
	for(quint64 i=bwtBgn; i<pos; i++){
		if(getChar(BWT, i)==c){
			count++;
		}
	}
	return count;
}
#endif

bool BWTBasic::
BWTSearch(	quint64*		BKT,	//backet
			quint8*			BWT,	//bwt
			quint8**		MCB,	//milestone counter
			quint8*			q,		//query sequence
            quint64 		qo,		//query offset
            quint64 		ql,		//seed length
            quint64&		lb,		//lower bound
            quint64& 		ub)		//upper bound
{
	if(qo+1<ql){
		return false;
	}
	quint8 c=getChar(q, qo);
	if(c==0||c==5){
		return false;
	}
    lb=BKT[c];
    ub=BKT[c+1]-1;
    if(lb>ub){
        return false;
    }
	for(quint64 i=1; i<ql; i++){
		c=getChar(q, qo-i);
		if(c==0||c==5){
			return false;
		}
		lb=BKT[c]+BWTOcc(c, BWT, MCB, lb);
		ub=BKT[c]+BWTOcc(c, BWT, MCB, ub+1)-1;
        if(lb>ub){
            return false;
        }
	}
    return true;
}

bool BWTBasic::
BWTSearchA(	quint64*		BKT,	//backet
            quint8*			BWT,	//bwt
            quint8**		MCB,	//milestone counter
            quint8*			q,		//query sequence
            quint64 		qo,		//query offset
            quint64 		ql,		//seed length
            quint64&		lb,		//lower bound
            quint64& 		ub)		//upper bound
{
    if(qo+1<ql){
        return false;
    }
    quint8 c;
    for(quint64 i=0; i<ql; i++){
        c=getChar(q, qo-i);
		if(c==0||c==5){
			return false;
		}
		lb=BKT[c]+BWTOcc(c, BWT, MCB, lb);
		ub=BKT[c]+BWTOcc(c, BWT, MCB, ub+1)-1;
        if(lb>ub){
            return false;
        }
    }
    return true;
}

bool BWTBasic::
BWTSearchE(	quint64*		BKT,	//backet
            quint8*			BWT,	//bwt
            quint8**		MCB,	//milestone counter
            quint8*			q,		//query sequence
            quint64 		qo,		//query offset
            quint64 		ql,		//seed length
            quint64&		lb,		//lower bound
            quint64& 		ub)		//upper bound
{
    if(qo+1<ql){
        return false;
    }
    quint8 c=getChar(q, qo-ql);
	if(c==0||c==5){
		return false;
	}
	lb=BKT[c]+BWTOcc(c, BWT, MCB, lb);
	ub=BKT[c]+BWTOcc(c, BWT, MCB, ub+1)-1;
    if(lb>ub){
        return false;
    }
    return true;
}

#ifndef INLINE
quint64 BWTBasic::
BWTPos(quint8* SSA, quint64* BKT,
       quint8* BWT, quint8** MCB, quint64 pos)
{
    quint64 moveCount=0;
    while(pos%SCF!=0){
        quint8 c=getChar(BWT, pos);
        pos=BKT[c]+BWTOcc(c, BWT, MCB, pos);
        moveCount++;
    }
    return getInt(SSA, pos/SCF)+moveCount;
}
#endif
