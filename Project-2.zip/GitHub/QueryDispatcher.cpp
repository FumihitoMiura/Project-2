#include "QueryDispatcher.h"

using namespace DesktopTrack;

/*--------------------------------------------------
        class QueryDispatcher
--------------------------------------------------*/
QueryDispatcher::QueryDispatcher(void):fileFormat(unknown){}

bool QueryDispatcher::setQueryFile(const QString& pathToQueryFile,
                                   const FileFormat& format)
{
    //FileFormat���w�肳��Ă��Ȃ���Δ�����
    if(format==unknown){
        return false;
    }
    //�t�@�C���t�H�[�}�b�g��ݒ肷��
    //1, fasta	">name"
    //2, fastq	"@name"
	//3, pfastq "@name" x 2
    //4, qseq	""
    fileFormat=format;

	//�t�@�C�����I�[�v��
	mutex.lock();
	QString queryFileName=pathToQueryFile;
	if(fileFormat==pfastq){
		//�y�A�G���h���[�h�Ȃ�u���[�h1�t�@�C��\t���[�h2�t�@�C���v�`��
		QStringList files=queryFileName.split('\t');
		if(files.size()!=2){
			mutex.unlock();
			return false;
		}
		if(queryFile2.isOpen()){
			queryFile2.close();
		}
		queryFile2.setFileName(files[1]);
		queryFile2.open(QIODevice::ReadOnly);
		if(!queryFile2.isOpen()){
			mutex.unlock();
			qDebug() << "Couldn't open file \"" << files[1] << "\".";
			return false;
		}
		queryFileName=files[0];
	}
    if(queryFile.isOpen()){
        queryFile.close();
    }
    queryFile.setFileName(queryFileName);
    queryFile.open(QIODevice::ReadOnly);
    if(!queryFile.isOpen()){
        mutex.unlock();
		qDebug() << "Couldn't open file \"" << queryFileName << "\".";
        return false;
    }

    //�o�b�t�@�[�Ƀf�[�^�����[�h����
    if(!loadBuffer()){
        return false;
    }
	if(fileFormat==pfastq){
		if(!loadBuffer2()){
			return false;
		}
	}
	queryProcessed=0;
    mutex.unlock();
    return true;

}

bool QueryDispatcher::loadBuffer(void)
{
    //�ǂݏo���\�[�X�������ł��Ă��Ȃ���Δ�����
    if(!queryFile.isReadable()){
        return false;
    }
    //�ǂݏo���e�ʂ��Ȃ���Δ�����
    if(queryFile.atEnd()){
        return false;
    }
    //�o�b�t�@�[�����
    if(queryBuffer.isOpen()){
        queryBuffer.close();
    }
    qint64 fileOffset=queryFile.pos();
    bufferData=queryFile.read(BufferSizeMax);
    if(!queryFile.atEnd()){
        int lastIndex=bufferData.lastIndexOf('\n');
        if(lastIndex!=-1){
            //'\n'�ȍ~�͏���
            bufferData.resize(lastIndex);
            //����̃t�@�C���ǂݏo���J�n�ʒu�܂ŃV�[�N
            queryFile.seek(fileOffset+lastIndex+1);
        }
    }
    queryBuffer.setBuffer(&bufferData);
    queryBuffer.open(QIODevice::ReadOnly);
    return true;
}

bool QueryDispatcher::loadBuffer2(void)
{
    //�ǂݏo���\�[�X�������ł��Ă��Ȃ���Δ�����
    if(!queryFile2.isReadable()){
        return false;
    }
    //�ǂݏo���e�ʂ��Ȃ���Δ�����
    if(queryFile2.atEnd()){
        return false;
    }
    //�o�b�t�@�[�����
    if(queryBuffer2.isOpen()){
        queryBuffer2.close();
    }
    qint64 fileOffset=queryFile2.pos();
    bufferData2=queryFile2.read(BufferSizeMax);
    if(!queryFile2.atEnd()){
        int lastIndex=bufferData2.lastIndexOf('\n');
        if(lastIndex!=-1){
            //'\n'�ȍ~�͏���
            bufferData2.resize(lastIndex);
            //����̃t�@�C���ǂݏo���J�n�ʒu�܂ŃV�[�N
            queryFile2.seek(fileOffset+lastIndex+1);
        }
    }
    queryBuffer2.setBuffer(&bufferData2);
    queryBuffer2.open(QIODevice::ReadOnly);
    return true;
}

QByteArray QueryDispatcher::complement(QByteArray original)
{
	QByteArray dest(original);
	for(int i=0, j=dest.size()-1; i<dest.size(); i++, j--){
		switch(original[i]){
			case 'A':
			case 'a':
				dest[j]='T';
				break;
			case 'C':
			case 'c':
				dest[j]='G';
				break;
			case 'G':
			case 'g':
				dest[j]='C';
				break;
			case 'T':
			case 't':
				dest[j]='A';
				break;
			default:
				dest[j]=original[i];
				break;
		}
	}
	return dest;
}

bool QueryDispatcher::getQuery(QByteArray &nameTo,
							   QByteArray &queryTo,
							   QByteArray &query2To)
{
    QByteArray line;
    qint64 bufferPos;
	query2To="";

    if(fileFormat==fasta){
        mutex.lock();
        //�ǂݍ��ރN�G���[���Ȃ���Δ�����
        if(queryFile.atEnd()&&queryBuffer.atEnd()){
            mutex.unlock();
            return false;
        }
        while(!queryFile.atEnd()||!queryBuffer.atEnd()){
            //�o�b�t�@�[����Ȃ疞����
            if(queryBuffer.atEnd()){
                if(!loadBuffer()){
                    mutex.unlock();
                    return false;
                }
            }
            //���O�s��ǂݍ���
            line=queryBuffer.readLine();
            if(line.startsWith('>')){
                QStringList cols=QString(line.right(line.size()-1)).split(QRegExp("\\s+"));
                nameTo=cols[0].toLatin1();
                break;
            }
        }
        //��s�ǂݍ���
        queryTo.clear();
        while(!queryFile.atEnd()||!queryBuffer.atEnd()){
            if(queryBuffer.atEnd()){
                if(!loadBuffer()){
                    mutex.unlock();
                    return false;
                }
            }
            bufferPos=queryBuffer.pos();
            line=queryBuffer.readLine();
            if(line.startsWith('>')){
                //���̔z�񂪏o����1�s�ǂݏo���O�̏�Ԃ֖߂�
                queryBuffer.seek(bufferPos);
                mutex.unlock();
                return true;
            }
            queryTo.append(line);
        }
		queryProcessed++;
        mutex.unlock();
        return true;
    }
    else if(fileFormat==fastq){
        mutex.lock();
        //�ǂݍ��ރN�G���[���Ȃ���Δ�����
        if(queryFile.atEnd()&&queryBuffer.atEnd()){
            mutex.unlock();
            return false;
        }
        while(!queryFile.atEnd()||!queryBuffer.atEnd()){
            //�o�b�t�@�[����Ȃ疞����
            if(queryBuffer.atEnd()){
                if(!loadBuffer()){
                    mutex.unlock();
                    return false;
                }
            }
            //���O�s��ǂݍ���
            line=queryBuffer.readLine();
            if(line.startsWith('@')){
                QStringList cols=QString(line.right(line.size()-1)).split(QRegExp("\\s+"));
                nameTo=cols[0].toLatin1();
                break;
            }
        }
        //�o�b�t�@�[����Ȃ疞����
        if(queryBuffer.atEnd()){
            if(!loadBuffer()){
                mutex.unlock();
                return false;
            }
        }
        //@�Ŏn�܂�s�̎��̍s���N�G���[
        queryTo=queryBuffer.readLine();
        //���̌�Q�s���Ӑ}�I�ɓǂݔ�΂�
        QByteArray line;
        if(queryBuffer.atEnd()){
            if(!loadBuffer()){
                mutex.unlock();
                return false;
            }
        }
        line=queryBuffer.readLine();
        if(queryBuffer.atEnd()){
            if(!loadBuffer()){
                mutex.unlock();
                return false;
            }
        }
        line=queryBuffer.readLine();
		queryProcessed++;
        mutex.unlock();
        return true;
    }
    else if(fileFormat==pfastq){
        mutex.lock();
        //�ǂݍ��ރN�G���[���Ȃ���Δ�����
        if(queryFile.atEnd()&&queryBuffer.atEnd()&&queryFile2.atEnd()&&queryBuffer2.atEnd()){
            mutex.unlock();
            return false;
        }
		//���[�h�P
        while(!queryFile.atEnd()||!queryBuffer.atEnd()){
            //�o�b�t�@�[����Ȃ疞����
            if(queryBuffer.atEnd()){
                if(!loadBuffer()){
                    mutex.unlock();
                    return false;
                }
            }
            //���O�s��ǂݍ���
            line=queryBuffer.readLine();
            if(line.startsWith('@')){
                QStringList cols=QString(line.right(line.size()-1)).split(QRegExp("[\\s/]+"));
                nameTo=cols[0].toLatin1();
                break;
            }
        }
        //�o�b�t�@�[����Ȃ疞����
        if(queryBuffer.atEnd()){
            if(!loadBuffer()){
                mutex.unlock();
                return false;
            }
        }
        //@�Ŏn�܂�s�̎��̍s���N�G���[
        queryTo=queryBuffer.readLine();
        //���̌�Q�s���Ӑ}�I�ɓǂݔ�΂�
        QByteArray line;
        if(queryBuffer.atEnd()){
            if(!loadBuffer()){
                mutex.unlock();
                return false;
            }
        }
        line=queryBuffer.readLine();
        if(queryBuffer.atEnd()){
            if(!loadBuffer()){
                mutex.unlock();
                return false;
            }
        }
        line=queryBuffer.readLine();

		//���[�h�Q
        while(!queryFile2.atEnd()||!queryBuffer2.atEnd()){
            //�o�b�t�@�[����Ȃ疞����
            if(queryBuffer2.atEnd()){
                if(!loadBuffer2()){
                    mutex.unlock();
                    return false;
                }
            }
            //���O�s��ǂݍ���
            line=queryBuffer2.readLine();
            if(line.startsWith('@')){
                QStringList cols=QString(line.right(line.size()-1)).split(QRegExp("[\\s/]+"));
				//���[�h1�Ɩ��O���قȂ�Δ�����
				QByteArray name2(cols[0].toLatin1());
				if(nameTo!=name2){
					qDebug()	<< "Different queryname between two fastq files"
								<< "Query ID=" << queryProcessed << endl
								<< nameTo << " vs " << name2 << endl;
                    mutex.unlock();
					QCoreApplication::quit();
                    return false;
				}
                break;
            }
        }
        //�o�b�t�@�[����Ȃ疞����
        if(queryBuffer2.atEnd()){
            if(!loadBuffer2()){
                mutex.unlock();
                return false;
            }
        }
        //@�Ŏn�܂�s�̎��̍s���N�G���[
        query2To=complement(queryBuffer2.readLine());
        //���̌�Q�s���Ӑ}�I�ɓǂݔ�΂�
        if(queryBuffer2.atEnd()){
            if(!loadBuffer2()){
                mutex.unlock();
                return false;
            }
        }
        line=queryBuffer2.readLine();
        if(queryBuffer2.atEnd()){
            if(!loadBuffer2()){
                mutex.unlock();
                return false;
            }
        }
        line=queryBuffer2.readLine();
		queryProcessed++;
        mutex.unlock();
        return true;
    }
    else if(fileFormat==qseq){
        mutex.lock();
        //�ǂݍ��ރN�G���[���Ȃ���Δ�����
        if(queryFile.atEnd()&&queryBuffer.atEnd()){
            mutex.unlock();
            return false;
        }
        while(!queryFile.atEnd()||!queryBuffer.atEnd()){
            //�o�b�t�@�[����Ȃ疞����
            if(queryBuffer.atEnd()){
                if(!loadBuffer()){
                    mutex.unlock();
                    return false;
                }
            }
            //1�s��ǂݍ���
            line=queryBuffer.readLine();
            QList<QByteArray> cols=line.split('\t');
            if(cols.size()==11){
                nameTo=cols[0].append('_').append(cols[1]).append('_').append(cols[2]).append('_').append(cols[3]).append('_').append(cols[4]).append('_').append(cols[5]);
                queryTo=cols[8];
				queryProcessed++;
                mutex.unlock();
                return true;
            }
        }
        return false;
    }
    else{
        return false;
    }
}

bool QueryDispatcher::hasNextQuery(void){
    mutex.lock();
    if(queryFile.atEnd()&&queryBuffer.atEnd()){
        mutex.unlock();
        return false;
    }
    else{
        mutex.unlock();
        return true;
    }
}

