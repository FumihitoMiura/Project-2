#include <QtCore>
#include <QtGui>
#include <iostream>

#include "DesktopTrackCommon.h"

#include "zlib/zlib.h"
#include "qcustomplot/qcustomplot.h"

#include "MapSum.h"

using namespace DesktopTrack;
using namespace std;

//QByteArray complement(const QByteArray& original);


void showUsage(void){
    cout	<< "Usage : MapSum [option1] [value1]"                                                                         	<< endl
			<< "   -sum          [string]  : sum file name"                                                              	<< endl
			<< "   -out          [string]  : output file name"																<< endl
			<< "   -sample       [string]  : sample name"																	<< endl;
}

QStringList sumFilePaths;
QString outFilePath;
QString sampleName("Your Sample");

bool ProcessArguments(int argc, char* argv[]){

	int i=1;
	while(i<argc){
		QString option(argv[i]);
		if(option==QString("-sum")){

			i++;
			while(i<argc){
				QString path(argv[i]);
				if(path.startsWith(QChar('-'))){
					i--;
					break;
				}
				QFileInfo info(path);
				if(info.exists()){
					sumFilePaths.append(path);
				}
				else{ //windows
					QDir dir=info.dir();
					QStringList filters;
					filters << info.fileName();
					QFileInfoList infoList=dir.entryInfoList(filters);
					for(int j=0; j<infoList.size(); j++){
						sumFilePaths.append(infoList[j].filePath());
					}
				}
				i++;
			}

		}
		else if(option==QString("-out")){
			i++;
			if(i==argc){
				break;
			}
			outFilePath=QString(argv[i]);
		}
		else if(option==QString("-sample")){
			i++;
			if(i==argc){
				break;
			}
			sampleName=QString(argv[i]);
		}
        i++;
	}
	QSet<QString> set;
	for(int i=0; i<sumFilePaths.size(); i++){
		QFileInfo info(sumFilePaths[i]);
		if(info.exists()){
			set.insert(sumFilePaths[i]);
		}
		else{
			QDir dir=info.dir();
			QStringList nameList=(QStringList()<<info.fileName());
			QFileInfoList infolist=dir.entryInfoList(nameList);
			for(int i=0; i<infolist.size(); i++){
				set.insert(infolist[i].filePath());
			}
		}
	}
	sumFilePaths=set.values();
	sumFilePaths.sort();
	for(int i=0; i<sumFilePaths.size(); i++){
		cout << sumFilePaths[i].toStdString() << " was set to analysis list." << endl;
	}
    return true;
}

int main(int argc, char* argv[]){


	QApplication app(argc, argv);
	QDir appDir(app.applicationDirPath());
	int font_id=QFontDatabase::addApplicationFont(":/font/ArenaCondensed.ttf");
	QStringList fontFamilies=QFontDatabase::applicationFontFamilies(font_id);
	QFontDatabase fontDatabase;
	QApplication::setFont(fontDatabase.font(fontFamilies[0], "normal", 12));

	if(!ProcessArguments(argc, argv)){
		showUsage();
 		return 0;
 	}

	//���̓t�@�C���m�F
	if(sumFilePaths.size()==0){
		cout << "No input file name was specified." << endl;
		showUsage();
		return 0;
	}

	if(sumFilePaths.size()==0){
		cout << "Please specify input file name." << endl;
		showUsage();
		return 0;
	}

	MapSum mapSum;
	mapSum.setIO(sumFilePaths, outFilePath, sampleName);
	mapSum.start();
	

	return 0;

}

