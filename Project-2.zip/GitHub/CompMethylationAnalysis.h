#ifndef COMPMETHYLATIONANALYSIS_H
#define COMPMETHYLATIONANALYSIS_H

#include <QtCore>
#include "DesktopTrackCommon.h"
#include "BinSeq.h"
#include "MethylationPerspectiveTrack.h"
#include "qcustomplot/qcustomplot.h"

namespace DesktopTrack {

    class CompMethylationAnalysis{
    private:
        //材料
        QMap<QString, QBitArray> probeMap;
        QList<BinSeq::Target>targetList;
        BinSeq::FileReader binReader;
        MethylationPerspectiveFileReader graphReader1;
        MethylationPerspectiveFileReader graphReader2;

        //パラメータ
        int windowSize;         //windowSize==1
        int stepSize;			//stepSize
        int readThreshold;		//
        int averageThreshold;	//wind
        qreal minRateD1;
        qreal maxRateD1;
        qreal minRateD2;
        qreal maxRateD2;
        int imageScale;         //
        int maxDepth;

		QString contextAnalyzed;

        //成果物
        int matrixSize;
        QVector<QVector<int> > methyMatrix;
		QVector<QVector<int> > depthMatrix;

		double cSlope;
		double cIntercept;
		double cCorrel;
        double mSlope;
        double mIntercept;
        double mCorrel;

        //ヘルパー関数
        const QByteArray reverseComplement(const QByteArray& seq);
        //C, G, Hを用いた表現を判断
        bool patternMatch(
                const QByteArray& pattern,
                const QByteArray& sample);
		bool patternMatch(
			const QByteArray& pattern, 
			int pos_pattern,
			const QByteArray& sample, 
			int pos_sample);

    public:
        CompMethylationAnalysis(void);

        bool setSpecies(
			const QString& pathToBinSeq);

        bool setProbeMap(
			const QString& pathToBam);

        void setReadnumberThreshold(
			const int num);

        bool setGraphFiles(
			const QString& pathToGraph1,
            const QString& pathToGraph2);

        void setMatrixSize(int size);

		void setImageScale(int scale);
		void setMaxDepth(int depth);

        void AnalyzeAll(
			const QByteArray& context,
			const int windowSize=1,
			const int stepSize=1);

        void DrawChart(
			const QString& filePath);

        void DrawThermoChart(
			const QString& filePath);

        void DrawCoverageChart(
			const QString& filePath);

		void OutputParameters(
			const QString& filePath);

    };

};

#endif // COMPMETHYLATIONANALYSIS_H
