#ifndef BWT_BASIC_H
#define BWT_BASIC_H

#include <QtCore>

#include "SuffixArrayBasic.h"
#include "DesktopTrackCommon.h"

#define INLINE

namespace DesktopTrack{

	class BWTBasic:public SuffixArrayBasic{
	protected:
        quint64	SCF;	//shrinking coefficient for first column
        quint64	SCL;	//shrinking coefficient for last column
	public:
        BWTBasic(const quint64& scf=32, const quint64& scl=16);
        ~BWTBasic(void);

		// SA2BWT 
		// :function to convert suffix array to bwt
		//  quint8* s   : 4-bit encoded nucleotide base
		//  quint8* SA  : suffix array
		//  quint64 n   : length of array
		//  quint8* BWT : bwt
		void SA2BWT(quint8* s, quint8* SA, quint64 n, quint8* BWT);

		quint64 calcMemorySize(quint64 refSize, quint64 shCoef);

#ifdef INLINE
		// BWTOcc
		// :function to count of "c" in 0 to pos-1 position of bwt
		// quint8 c		: nucleotide base (8-bit)
		// quint8* BWT	: BWT
		// quint8** MCB	: milestone counter MCB[a, c, g, t][pos/shCoef]
        // quint64 pos	: position
		quint64 BWTOcc(	quint8 c, quint8* BWT, 
                        quint8** MCB, quint64 pos)
		{
			quint64 mcbPos=pos/SCL;
			quint64 bwtBgn=mcbPos*SCL;
			quint64 count=getInt(MCB[c], mcbPos);
			for(quint64 i=bwtBgn; i<pos; i++){
				if(getChar(BWT, i)==c){
					count++;
				}
			}
			return count;
		};
#else
		// BWTOcc
		// :function to count of "c" in 0 to pos-1 position of bwt
		// quint8 c		: nucleotide base (8-bit)
		// quint8* BWT	: BWT
		// quint8** MCB	: milestone counter MCB[a, c, g, t][pos/shCoef]
        // quint64 pos	: position
		quint64 BWTOcc(	quint8 c, quint8* BWT, 
                        quint8** MCB, quint64 pos);
#endif

		// BWTSearch
		// :function to search query in BWT
		// quint64* BKT	: bucket (counter of characters alphabettically smaller than "c"
		// quint8* BWT	: BWT
		// quint8** MCB	: milestone counter
		// quint8* q	: query (4-bit encoded)
        // quint64 qo	: query offset
        // quint64 ql	: query length (must be ql<=qo+1)
		// quint64& lb	: lower bound of suffix array (first column of M)
		// quint64& ub	: upper bound of suffix array (first column of M)
		bool BWTSearch(	quint64* BKT, quint8* BWT, quint8** MCB,
                        quint8* q, quint64 qo, quint64 ql,
						quint64& lb, quint64& ub);

        // BWTSearchA
        // :function to search query in BWT (starting from precalculated lb-ub)
        // quint64* BKT	: bucket (counter of characters alphabettically smaller than "c"
        // quint8* BWT	: BWT
        // quint8** MCB	: milestone counter
        // quint8* q	: query (4-bit encoded)
        // quint64 qo	: query offset
        // quint64 ql	: query length (must be ql<=qo+1)
        // quint64& lb	: lower bound of suffix array (first column of M)
        // quint64& ub	: upper bound of suffix array (first column of M)
        bool BWTSearchA(quint64* BKT, quint8* BWT, quint8** MCB,
                        quint8* q, quint64 qo, quint64 ql,
                        quint64& lb, quint64& ub);

        // BWTSearchE
        // :function to search query in BWT (only effective for extending 1 base)
        // quint64* BKT	: bucket (counter of characters alphabettically smaller than "c"
        // quint8* BWT	: BWT
        // quint8** MCB	: milestone counter
        // quint8* q	: query (4-bit encoded)
        // quint64 qo	: query offset
        // quint64 ql	: query length (must be ql<=qo+1)
        // quint64& lb	: lower bound of suffix array (first column of M)
        // quint64& ub	: upper bound of suffix array (first column of M)
        bool BWTSearchE(quint64* BKT, quint8* BWT, quint8** MCB,
                        quint8* q, quint64 qo, quint64 ql,
                        quint64& lb, quint64& ub);


#ifdef INLINE
		// BWTPos
		// :fuction to get SA value for pos
		// quint8* SSA,	: shrinked suffix arrray
		// quint8* BWT,	: BWT
		// quint64* BKT	: bucket (counter of characters alphabettically smaller than "c"
		quint64 BWTPos(	quint8* SSA, quint64* BKT, 
                        quint8* BWT, quint8** MCB, quint64 pos){
			quint64 moveCount=0;
			while(pos%SCF!=0){
				quint8 c=getChar(BWT, pos);
				pos=BKT[c]+BWTOcc(c, BWT, MCB, pos);
				moveCount++;
			}
			return getInt(SSA, pos/SCF)+moveCount;
		};
#else
		// BWTPos
		// :fuction to get SA value for pos
		// quint8* SSA,	: shrinked suffix arrray
		// quint8* BWT,	: BWT
		// quint64* BKT	: bucket (counter of characters alphabettically smaller than "c"
		quint64 BWTPos(	quint8* SSA, quint64* BKT, 
                        quint8* BWT, quint8** MCB, quint64 pos);

#endif

	};



};

#endif //BWT_BASIC_H
