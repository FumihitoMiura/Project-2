#include "BMapThread.h"


using namespace DesktopTrack::BMapCore;

/*--------------------------------------------------
        class BMapThread
--------------------------------------------------*/
const qint64 BMapThread::c2tMatrix[6][6] = {
//		  $		  A		  C		  G		  T		  N				<---	query
    {	-60,	-60,	-60,	-60,	-60,	-60},			//	$	sbject
    {	-60,	  5,	-30,	-30,	-30,	-30},			//	A	sbject
    {	-60,	-30,	  5,	-30,	  5,	-30},			//	C	sbject
    {	-60,	-30,	-30,	  5,	-30,	-30},			//	G	sbject
    {	-60,	-30,	-30,	-30,	  5,	-30},			//	T	sbject
    {	-60,	-30,	-30,	-30,	-30,	-30},			//	N	sbject
};
const qint64 BMapThread::g2aMatrix[6][6] = {
//		  $		  A		  C		  G		  T		  N				<---	query
    {	-60,	-60,	-60,	-60,	-60,	-60},			//	$	sbject
    {	-60,	  5,	-30,	-30,	-30,	-30},			//	A	sbject
    {	-60,	-30,	  5,	-30,	-30,	-30},			//	C	sbject
    {	-60,	  5,	-30,	  5,	-30,	-30},			//	G	sbject
    {	-60,	-30,	-30,	-30,	  5,	-30},			//	T	sbject
    {	-60,	-30,	-30,	-30,	-30,	-30},			//	N	sbject
};

BMapThread::BMapThread(
	//quint64	scf,
	//quint64 scl,
	DesktopTrack::QueryDispatcher* dispatcher,
	QObject* parent)
:	QThread(parent),
	//BWTBasic(scf, scl),
    BWTBasic(),
	queryDispatcher(dispatcher),
    refLen(0), refSeq(0), bIdxWordSize(0),
    c2tSeq(0), c2tSA(0), c2tBIdx(0), c2tBKT(0), c2tMCB(0),
    g2aSeq(0), g2aSA(0), g2aBIdx(0), g2aBKT(0), g2aMCB(0),
	maxQueryListSize(0), useSuffixArray(true)
{}

BMapThread::~BMapThread(void){}

void BMapThread::
setIndex(
    QList<Target> targetlist,
    quint64 reflen,
    quint8* refseq,
    quint64 bidxwordsize,
    quint8* c2tseq,
    quint8* c2tsa,
    quint8* c2tbidx,
    quint8* g2aseq,
    quint8* g2asa,
    quint8* g2abidx)
{
    useSuffixArray=true;
    targetList=targetlist;
    refLen=reflen;
    refSeq=refseq;
    bIdxWordSize=bidxwordsize;
    c2tSeq=c2tseq;
    c2tSA=c2tsa;
    c2tBIdx=c2tbidx;
    g2aSeq=g2aseq;
    g2aSA=g2asa;
    g2aBIdx=g2abidx;
}

void BMapThread::
setIndexWithBWT(
    QList<Target> targetlist,
    quint64 reflen,
    quint8* refseq,
    quint64 bidxwordsize,
	quint64 scf,
	quint64 scl,
    quint64* c2tbkt,
    quint8* c2tbwt,
    quint8** c2tmcb,
    quint8* c2tsa,
    quint8* c2tbidx,
    quint64* g2abkt,
    quint8* g2abwt,
    quint8** g2amcb,
    quint8* g2asa,
    quint8* g2abidx)
{
    useSuffixArray=false;
    targetList=targetlist;
    refLen=reflen;
    refSeq=refseq;
    bIdxWordSize=bidxwordsize;
	SCF=scf;
	SCL=scl;
    c2tBKT=c2tbkt;
    c2tBWT=c2tbwt;
    c2tMCB=c2tmcb;
    c2tSA=c2tsa;
    c2tBIdx=c2tbidx;
    g2aBKT=g2abkt;
    g2aBWT=g2abwt;
    g2aMCB=g2amcb;
    g2aSA=g2asa;
    g2aBIdx=g2abidx;
}

void BMapThread::
setAlignmentParameters(	quint64 seedoffset,
                        quint64 seedlength,
                        quint64 seedstep,
                        quint64 seediterate,
                        quint64 minseedhit,
                        quint64 seedlengthmax,
                        quint64 maxhitcount,
                        qint64 minalnscore,
						quint64 maxpepairlen)
{
    seedOffset=seedoffset;
    seedLength=seedlength;
    seedStep=seedstep;
    seedIterate=seediterate;
    minSeedHit=minseedhit;
    seedLengthMax=seedlengthmax;
    seedFreqMax=maxhitcount;
    minAlnScore=minalnscore;
	maxPEPairLen=maxpepairlen;
}

void BMapThread::run(void){

    QByteArray name, query, query2;

        if(useSuffixArray){
            while(queryDispatcher->getQuery(name, query, query2)){
				if(query2.size()==0){
					setQuery(name, query);
					alignWithSA();
					callAlign();
				}
				else{
					setQuery(name, query);
					alignWithSA();
					setQuery2(name, query2);
					alignWithSA2();
					//if(topCount==1&&topCount2>1){
					//	limAlignWithSA1();
					//}
					//else if(topCount>1&&topCount2==1){
					//	limAlignWithSA2();
					//}
					callPEAlign();
				}
            }
        }
        else{
            while(queryDispatcher->getQuery(name, query, query2)){
				if(query2.size()==0){
	                setQuery(name, query);
		            alignWithBWT();
					callAlign();
				}
				else{
	                setQuery(name, query);
		            alignWithBWT();
	                setQuery2(name, query2);
		            alignWithBWT2();
					//if(topCount==1&&topCount2>1){
					//	limAlignWithBWT1();
					//}
					//else if(topCount>1&&topCount2==1){
					//	limAlignWithBWT2();
					//}
					callPEAlign();
				}
            }
        }

}

void BMapThread::callAlign(void){
	
	//�o�͏���
    QByteArray sumData;
    QByteArray alnData;
    QBuffer buffer;
    QTextStream out;
    if(topCount==1){
        //���F�̖�����
        quint64 lb=0, ub=targetList.size()-1;
        quint64 i;
        int pos;
        quint64 pvt=(ub+lb)/2;
        quint64 chStart(0), chEnd(0), quStart(0), quEnd(0);
        QString targetName;
        while(true){
            chStart=targetList[pvt].targetOffset;
            chEnd=chStart+targetList[pvt].targetLength;
            if(chStart<=topSbjctOffset){
                if(topSbjctOffset<chEnd){
                    targetName=targetList[pvt].targetName;
                    break;
                }
                else{
                    if(lb+1==ub){
                        lb=ub;
                    }
                    else{
                        lb=pvt;
                    }
                }
            }
            else{
                ub=pvt;
            }
            pvt=(ub+lb)/2;
        }
        QByteArray query, sbjct, call;
        //C2T�ϊ������N�G���[�𓖂Ă����ʁi������̂�C2T���j
        if(topAlignType==1){
            for(i=topQueryOffset; i<topQueryOffset+topAlignLength; i++){
                switch(getChar(queryF, i)){
                    case 0x00:query.append('$');break;
                    case 0x01:query.append('A');break;
                    case 0x02:query.append('C');break;
                    case 0x03:query.append('G');break;
                    case 0x04:query.append('T');break;
                    default:query.append('N');
                }
            }
            for(i=topSbjctOffset; i<topSbjctOffset+topAlignLength; i++){
                switch(getChar(refSeq, i)){
                    case 0x00:sbjct.append('$');break;
                    case 0x01:sbjct.append('A');break;
                    case 0x02:sbjct.append('C');break;
                    case 0x03:sbjct.append('G');break;
                    case 0x04:sbjct.append('T');break;
                    default:sbjct.append('N');
                }
            }
			chStart=topSbjctOffset-chStart+1;
			chEnd=chStart+topAlignLength-1;
			quStart=topQueryOffset+1;
			quEnd=topQueryOffset+topAlignLength;
        }
        //G2A�ϊ������N�G���[�̑��⍽�𓖂Ă����ʁi������̂�C2T���j
        else if(topAlignType==2){
            for(i=topQueryOffset; i<topQueryOffset+topAlignLength; i++){
                switch(getChar(queryR, i)){
                    case 0x00:query.append('$');break;
                    case 0x01:query.append('A');break;
                    case 0x02:query.append('C');break;
                    case 0x03:query.append('G');break;
                    case 0x04:query.append('T');break;
                    default:query.append('N');
                }
            }
            for(i=topSbjctOffset; i<topSbjctOffset+topAlignLength; i++){
                switch(getChar(refSeq, i)){
                    case 0x00:sbjct.append('$');break;
                    case 0x01:sbjct.append('A');break;
                    case 0x02:sbjct.append('C');break;
                    case 0x03:sbjct.append('G');break;
                    case 0x04:sbjct.append('T');break;
                    default:sbjct.append('N');
                }
            }
			chStart=topSbjctOffset-chStart+1;
			chEnd=chStart+topAlignLength-1;
			quStart=queryLen-topQueryOffset;
			quEnd=quStart-topAlignLength+1;
        }
        //C2T�ϊ������N�G���[�̑��⍽�𓖂Ă����ʁi������̂�G2A���j
        else if(topAlignType==3){
            for(i=topQueryOffset; i<topQueryOffset+topAlignLength; i++){
                switch(getChar(queryR, i)){
                    case 0x00:query.prepend('$');break;
                    case 0x01:query.prepend('T');break;
                    case 0x02:query.prepend('G');break;
                    case 0x03:query.prepend('C');break;
                    case 0x04:query.prepend('A');break;
                    default:query.prepend('N');
                }

            }
            for(i=topSbjctOffset; i<topSbjctOffset+topAlignLength; i++){
                switch(getChar(refSeq, i)){
                    case 0x00:sbjct.prepend('$');break;
                    case 0x01:sbjct.prepend('T');break;
                    case 0x02:sbjct.prepend('G');break;
                    case 0x03:sbjct.prepend('C');break;
                    case 0x04:sbjct.prepend('A');break;
                    default:sbjct.prepend('N');
                }
            }
            //chStart��chEnd�͌���
			chEnd=topSbjctOffset-chStart+1;
			chStart=chEnd+topAlignLength-1;
			quStart=queryLen-topQueryOffset-topAlignLength+1;
			quEnd=queryLen-topQueryOffset;
        }
        //G2A�ϊ������N�G���[�𓖂Ă����ʁi������̂�G2A���j
        else if(topAlignType==4){
            for(i=topQueryOffset; i<topQueryOffset+topAlignLength; i++){
                switch(getChar(queryF, i)){
                    case 0x00:query.prepend('$');break;
                    case 0x01:query.prepend('T');break;
                    case 0x02:query.prepend('G');break;
                    case 0x03:query.prepend('C');break;
                    case 0x04:query.prepend('A');break;
                    default:query.prepend('N');
                }

            }
            for(i=topSbjctOffset; i<topSbjctOffset+topAlignLength; i++){
                switch(getChar(refSeq, i)){
                    case 0x00:sbjct.prepend('$');break;
                    case 0x01:sbjct.prepend('T');break;
                    case 0x02:sbjct.prepend('G');break;
                    case 0x03:sbjct.prepend('C');break;
                    case 0x04:sbjct.prepend('A');break;
                    default:sbjct.prepend('N');
                }
            }
            //chStart��chEnd�͌���
			chEnd=topSbjctOffset-chStart+1;
			chStart=chEnd+topAlignLength-1;
			quStart=topQueryOffset+topAlignLength;
			quEnd=topQueryOffset+1;

        }
        for(pos=0; pos<(int)topAlignLength; pos++){
            if(sbjct[pos]=='C'){
                if(query[pos]=='C'){
                    call.append('M');
                }
                else if(query[pos]=='T'){
                    call.append('U');
                }
                else{
                    call.append(' ');
                }
            }
            else{
                if(query[pos]==sbjct[pos]){
                    call.append('|');
                }
                else{
                    call.append(' ');
                }
            }
        }
        //�܂���sum���o��
        buffer.setBuffer(&sumData);
        buffer.open(QIODevice::WriteOnly);
        out.setDevice(&buffer);
        out << cloneName << '\t'
            << topCount << '\t'
            << queryLen << '\t'
            << targetName << '\t'
            << chStart << '\t'
            << chEnd << '\t'
            << quStart << '\t'
            << quEnd << '\t'
            << topAlignType << endl;
        buffer.close();
        //�����ŃA���C�����g
        buffer.setBuffer(&alnData);
        buffer.open(QIODevice::WriteOnly);
        out.setDevice(&buffer);
        out << ">" << cloneName << endl
            << targetName << endl
            << quStart << endl
            << quEnd << endl
            << chStart << endl
            << chEnd << endl
            << topAlignType << endl
            << query << endl
            << call << endl
            << sbjct << endl
            << endl;
        buffer.close();

    }
    else{
        //sum
        buffer.setBuffer(&sumData);
        buffer.open(QIODevice::WriteOnly);
        out.setDevice(&buffer);
        out << cloneName << '\t'
            << topCount << '\t'
            << queryLen << endl;
    }

    emit searchFinished(sumData, alnData);
}

void BMapThread::callPEAlign(void){
	
	//�o�͏���
    QByteArray sumData;
    QByteArray alnData;
    QBuffer buffer;
    QTextStream out;
	quint64 i;
	int pos;

	QString targetName, targetName2;
    quint64 chStart(0), chEnd(0), chStart2(0), chEnd2(0);
	quint64 quStart(0), quEnd(0), quStart2(0), quEnd2(0);

    if(topCount==1){

        //���F�̖�����
        quint64 lb=0, ub=targetList.size()-1;
        quint64 pvt=(ub+lb)/2;
        while(true){
            chStart=targetList[pvt].targetOffset;
            chEnd=chStart+targetList[pvt].targetLength;
            if(chStart<=topSbjctOffset){
                if(topSbjctOffset<chEnd){
                    targetName=targetList[pvt].targetName;
                    break;
                }
                else{
                    if(lb+1==ub){
                        lb=ub;
                    }
                    else{
                        lb=pvt;
                    }
                }
            }
            else{
                ub=pvt;
            }
            pvt=(ub+lb)/2;
        }

	}
	if(topCount2==1){

        //���F�̖�����
        quint64 lb=0, ub=targetList.size()-1;
        quint64 pvt=(ub+lb)/2;
        while(true){
            chStart2=targetList[pvt].targetOffset;
            chEnd2=chStart2+targetList[pvt].targetLength;
            if(chStart2<=topSbjctOffset2){
                if(topSbjctOffset2<chEnd2){
                    targetName2=targetList[pvt].targetName;
                    break;
                }
                else{
                    if(lb+1==ub){
                        lb=ub;
                    }
                    else{
                        lb=pvt;
                    }
                }
            }
            else{
                ub=pvt;
            }
            pvt=(ub+lb)/2;
        }

	}

	if(topCount==1&&topCount2==1){

		quint64 sbjctMin=qMin(topSbjctOffset, topSbjctOffset2);
		quint64 sbjctMax=qMax(topSbjctOffset+topAlignLength-1, topSbjctOffset2+topAlignLength2-1);
		quint64 sbjctLen=sbjctMax-sbjctMin+1;
		quint64 sbjctStart(0), sbjctEnd(0);

		if(targetName==targetName2&&sbjctLen<=maxPEPairLen&&topAlignType==topAlignType2){

			QByteArray query, query2, sbjct, call;
			quint64 queryStart=topSbjctOffset-sbjctMin;
			quint64 queryEnd=queryStart+topAlignLength-1;
			quint64 query2Start=topSbjctOffset2-sbjctMin;
			quint64 query2End=query2Start+topAlignLength2-1;

			//C2T�ϊ������N�G���[�𓖂Ă����ʁi������̂�C2T���j
			if(topAlignType==1){
				for(i=0; i<sbjctLen; i++){
					switch(getChar(refSeq, sbjctMin+i)){
						case 0x00:sbjct.append('$');break;
						case 0x01:sbjct.append('A');break;
						case 0x02:sbjct.append('C');break;
						case 0x03:sbjct.append('G');break;
						case 0x04:sbjct.append('T');break;
						default:sbjct.append('N');
					}
					
					if(i>=queryStart&&i<=queryEnd){
						switch(getChar(queryF, i-queryStart+topQueryOffset)){
							case 0x00:query.append('$');break;
							case 0x01:query.append('A');break;
							case 0x02:query.append('C');break;
							case 0x03:query.append('G');break;
							case 0x04:query.append('T');break;
							default:query.append('N');
						}
					}
					else{
						query.append('-');
					}
					if(i>=query2Start&&i<=query2End){
						switch(getChar(queryF2, i-query2Start+topQueryOffset2)){
							case 0x00:query2.append('$');break;
							case 0x01:query2.append('A');break;
							case 0x02:query2.append('C');break;
							case 0x03:query2.append('G');break;
							case 0x04:query2.append('T');break;
							default:query2.append('N');
						}
					}
					else{
						query2.append('-');
					}
				}

				chStart=topSbjctOffset-chStart+1;
				chEnd=chStart+topAlignLength-1;

				quStart=topQueryOffset+1;
				quEnd=topQueryOffset+topAlignLength;

				chStart2=topSbjctOffset2-chStart2+1;
				chEnd2=chStart2+topAlignLength2-1;

				//�����C���K�v
				quStart2=queryLen2-topQueryOffset2;
				quEnd2=quStart2-topAlignLength2+1;

				sbjctStart=qMin(chStart, chStart2);
				sbjctEnd=qMax(chEnd, chEnd2);

			}
			else if(topAlignType==2){
				for(i=0; i<sbjctLen; i++){
					switch(getChar(refSeq, sbjctMin+i)){
						case 0x00:sbjct.append('$');break;
						case 0x01:sbjct.append('A');break;
						case 0x02:sbjct.append('C');break;
						case 0x03:sbjct.append('G');break;
						case 0x04:sbjct.append('T');break;
						default:sbjct.append('N');
					}
					
					if(i>=queryStart&&i<=queryEnd){
						switch(getChar(queryR, i-queryStart+topQueryOffset)){
							case 0x00:query.append('$');break;
							case 0x01:query.append('A');break;
							case 0x02:query.append('C');break;
							case 0x03:query.append('G');break;
							case 0x04:query.append('T');break;
							default:query.append('N');
						}
					}
					else{
						query.append('-');
					}
					if(i>=query2Start&&i<=query2End){
						switch(getChar(queryR2, i-query2Start+topQueryOffset2)){
							case 0x00:query2.append('$');break;
							case 0x01:query2.append('A');break;
							case 0x02:query2.append('C');break;
							case 0x03:query2.append('G');break;
							case 0x04:query2.append('T');break;
							default:query2.append('N');
						}
					}
					else{
						query2.append('-');
					}
				}

				chStart=topSbjctOffset-chStart+1;
				chEnd=chStart+topAlignLength-1;

				quStart=queryLen-topQueryOffset;
				quEnd=quStart-topAlignLength+1;

				chStart2=topSbjctOffset2-chStart2+1;
				chEnd2=chStart2+topAlignLength2-1;

				//�����C���K�v
				quStart2=topQueryOffset2+1;
				quEnd2=topQueryOffset2+topAlignLength2;

				sbjctStart=qMin(chStart, chStart2);
				sbjctEnd=qMax(chEnd, chEnd2);


			}
			else if(topAlignType==3){

				for(i=0; i<sbjctLen; i++){
					switch(getChar(refSeq, sbjctMin+i)){
						case 0x00:sbjct.prepend('$');break;
						case 0x01:sbjct.prepend('T');break;
						case 0x02:sbjct.prepend('G');break;
						case 0x03:sbjct.prepend('C');break;
						case 0x04:sbjct.prepend('A');break;
						default:sbjct.prepend('N');
					}
					if(i>=queryStart&&i<=queryEnd){
						switch(getChar(queryR, i-queryStart+topQueryOffset)){
							case 0x00:query.prepend('$');break;
							case 0x01:query.prepend('T');break;
							case 0x02:query.prepend('G');break;
							case 0x03:query.prepend('C');break;
							case 0x04:query.prepend('A');break;
							default:query.prepend('N');
						}
					}
					else{
						query.prepend('-');
					}
					if(i>=query2Start&&i<=query2End){
						switch(getChar(queryR2, i-query2Start+topQueryOffset2)){
							case 0x00:query2.prepend('$');break;
							case 0x01:query2.prepend('T');break;
							case 0x02:query2.prepend('G');break;
							case 0x03:query2.prepend('C');break;
							case 0x04:query2.prepend('A');break;
							default:query2.prepend('N');
						}
					}
					else{
						query2.prepend('-');
					}
				}

				chEnd=topSbjctOffset-chStart+1;
				chStart=chEnd+topAlignLength-1;

				quStart=queryLen-topQueryOffset-topAlignLength+1;
				quEnd=queryLen-topQueryOffset;

				chStart2=topSbjctOffset2-chStart2+topAlignLength2;
				chEnd2=topSbjctOffset2-chStart2+1;

				quStart2=topQueryOffset2+topAlignLength2;
				quEnd2=topQueryOffset2+1;

				sbjctEnd=qMin(chEnd, chEnd2);
				sbjctStart=qMax(chStart, chStart2);

			}
			else if(topAlignType==4){

				for(i=0; i<sbjctLen; i++){
					switch(getChar(refSeq, sbjctMin+i)){
						case 0x00:sbjct.prepend('$');break;
						case 0x01:sbjct.prepend('T');break;
						case 0x02:sbjct.prepend('G');break;
						case 0x03:sbjct.prepend('C');break;
						case 0x04:sbjct.prepend('A');break;
						default:sbjct.prepend('N');
					}
					if(i>=queryStart&&i<=queryEnd){
						switch(getChar(queryF, i-queryStart+topQueryOffset)){
							case 0x00:query.prepend('$');break;
							case 0x01:query.prepend('T');break;
							case 0x02:query.prepend('G');break;
							case 0x03:query.prepend('C');break;
							case 0x04:query.prepend('A');break;
							default:query.prepend('N');
						}
					}
					else{
						query.prepend('-');
					}
					if(i>=query2Start&&i<=query2End){
						switch(getChar(queryF2, i-query2Start+topQueryOffset2)){
							case 0x00:query2.prepend('$');break;
							case 0x01:query2.prepend('T');break;
							case 0x02:query2.prepend('G');break;
							case 0x03:query2.prepend('C');break;
							case 0x04:query2.prepend('A');break;
							default:query2.prepend('N');
						}
					}
					else{
						query2.prepend('-');
					}
				}

				chEnd=topSbjctOffset-chStart+1;
				chStart=chEnd+topAlignLength-1;

				quStart=topQueryOffset+topAlignLength;
				quEnd=topQueryOffset+1;

				chEnd2=topSbjctOffset2-chStart2+1;
				chStart2=chEnd2+topAlignLength2-1;

				quStart2=queryLen2-topQueryOffset2-topAlignLength2+1;
				quEnd2=queryLen2-topQueryOffset2;

				sbjctEnd=qMin(chEnd, chEnd2);
				sbjctStart=qMax(chStart, chStart2);

			}

			//query��query2���}�[�W
			for(pos=0; pos<qMin(query.size(), query2.size()); pos++){
				if(query[pos]=='A'||query[pos]=='C'||query[pos]=='G'||query[pos]=='T'){
					if(query2[pos]=='A'||query2[pos]=='C'||query2[pos]=='G'||query2[pos]=='T'){
						if(query[pos]==query2[pos]){
							//���̂܂�
							//query[pos]=query[pos];
						}
						else{
							if(query[pos]=='A'){
								if(query2[pos]=='C'){
									query[pos]='m';
								}
								else if(query2[pos]=='G'){
									query[pos]='r';
								}
								else if(query2[pos]=='T'){
									query[pos]='w';
								}
							}
							else if(query[pos]=='C'){
								if(query2[pos]=='A'){
									query[pos]='m';
								}
								else if(query2[pos]=='G'){
									query[pos]='s';
								}
								else if(query2[pos]=='T'){
									query[pos]='y';
								}
							}
							else if(query[pos]=='G'){
								if(query2[pos]=='A'){
									query[pos]='r';
								}
								else if(query2[pos]=='C'){
									query[pos]='s';
								}
								else if(query2[pos]=='T'){
									query[pos]='k';
								}
							}
							else if(query[pos]=='T'){
								if(query2[pos]=='A'){
									query[pos]='w';
								}
								else if(query2[pos]=='C'){
									query[pos]='y';
								}
								else if(query2[pos]=='G'){
									query[pos]='k';
								}
							}
						}
					}
					else{
						//���̂܂�
						//query[pos]=query[pos];
					}
				}
				else{
					if(query2[pos]=='A'||query2[pos]=='C'||query2[pos]=='G'||query2[pos]=='T'){
						//query2�D��
						query[pos]=query2[pos];
					}
					else{
						//�s������
						query[pos]='-';						
					}
				}
			}

			for(pos=0; pos<qMin(sbjct.size(), query.size()); pos++){
				if(sbjct[pos]=='C'){
					if(query[pos]=='C'){
						call.append('M');
					}
					else if(query[pos]=='T'){
						call.append('U');
					}
					else{
						call.append(' ');
					}
				}
				else{
					if(query[pos]==sbjct[pos]){
						call.append('|');
					}
					else{
						call.append(' ');
					}
				}
			}

			//�A���C�����g�̏o��
			buffer.setBuffer(&alnData);
			buffer.open(QIODevice::WriteOnly);
			out.setDevice(&buffer);
			out << ">" << cloneName << " MergedPE" << endl
				<< targetName << endl
				<< quStart << "," << quStart2 << endl
				<< quEnd << "," << quEnd2 << endl
				<< sbjctStart << endl
				<< sbjctEnd << endl
				<< topAlignType << endl
				<< query << endl
				<< call << endl
				<< sbjct << endl
				<< endl;
			buffer.close();

		}
		else{
			QByteArray query, sbjct, call, query2, sbjct2, call2;
			//C2T�ϊ������N�G���[�𓖂Ă����ʁi������̂�C2T���j
			if(topAlignType==1){
				for(i=topQueryOffset; i<topQueryOffset+topAlignLength; i++){
					switch(getChar(queryF, i)){
						case 0x00:query.append('$');break;
						case 0x01:query.append('A');break;
						case 0x02:query.append('C');break;
						case 0x03:query.append('G');break;
						case 0x04:query.append('T');break;
						default:query.append('N');
					}
				}
				for(i=topSbjctOffset; i<topSbjctOffset+topAlignLength; i++){
					switch(getChar(refSeq, i)){
						case 0x00:sbjct.append('$');break;
						case 0x01:sbjct.append('A');break;
						case 0x02:sbjct.append('C');break;
						case 0x03:sbjct.append('G');break;
						case 0x04:sbjct.append('T');break;
						default:sbjct.append('N');
					}
				}

				//sbjct
				chStart=topSbjctOffset-chStart+1;
				chEnd=chStart+topAlignLength-1;

				//query �m�F��
				quStart=topQueryOffset+1;
				quEnd=topQueryOffset+topAlignLength;

			}
			//G2A�ϊ������N�G���[�̑��⍽�𓖂Ă����ʁi������̂�C2T���j
			else if(topAlignType==2){
				for(i=topQueryOffset; i<topQueryOffset+topAlignLength; i++){
					switch(getChar(queryR, i)){
						case 0x00:query.append('$');break;
						case 0x01:query.append('A');break;
						case 0x02:query.append('C');break;
						case 0x03:query.append('G');break;
						case 0x04:query.append('T');break;
						default:query.append('N');
					}
				}
				for(i=topSbjctOffset; i<topSbjctOffset+topAlignLength; i++){
					switch(getChar(refSeq, i)){
						case 0x00:sbjct.append('$');break;
						case 0x01:sbjct.append('A');break;
						case 0x02:sbjct.append('C');break;
						case 0x03:sbjct.append('G');break;
						case 0x04:sbjct.append('T');break;
						default:sbjct.append('N');
					}
				}

				//sbjct
				chStart=topSbjctOffset-chStart+1;
				chEnd=chStart+topAlignLength-1;

				//query �m�F��
				quStart=queryLen-topQueryOffset;
				quEnd=queryLen-topQueryOffset-topAlignLength+1;

			}
			//C2T�ϊ������N�G���[�̑��⍽�𓖂Ă����ʁi������̂�G2A���j
			else if(topAlignType==3){
				for(i=topQueryOffset; i<topQueryOffset+topAlignLength; i++){
					switch(getChar(queryR, i)){
						case 0x00:query.prepend('$');break;
						case 0x01:query.prepend('T');break;
						case 0x02:query.prepend('G');break;
						case 0x03:query.prepend('C');break;
						case 0x04:query.prepend('A');break;
						default:query.prepend('N');
					}

				}
				for(i=topSbjctOffset; i<topSbjctOffset+topAlignLength; i++){
					switch(getChar(refSeq, i)){
						case 0x00:sbjct.prepend('$');break;
						case 0x01:sbjct.prepend('T');break;
						case 0x02:sbjct.prepend('G');break;
						case 0x03:sbjct.prepend('C');break;
						case 0x04:sbjct.prepend('A');break;
						default:sbjct.prepend('N');
					}
				}

				//sbjct
				chEnd=topSbjctOffset-chStart+1;
				chStart=chEnd+topAlignLength-1;

				//query �m�F��
				quStart=queryLen+1-topQueryOffset-topAlignLength;
				quEnd=queryLen-topQueryOffset;

			}
			//G2A�ϊ������N�G���[�𓖂Ă����ʁi������̂�G2A���j
			else if(topAlignType==4){
				for(i=topQueryOffset; i<topQueryOffset+topAlignLength; i++){
					switch(getChar(queryF, i)){
						case 0x00:query.prepend('$');break;
						case 0x01:query.prepend('T');break;
						case 0x02:query.prepend('G');break;
						case 0x03:query.prepend('C');break;
						case 0x04:query.prepend('A');break;
						default:query.prepend('N');
					}

				}
				for(i=topSbjctOffset; i<topSbjctOffset+topAlignLength; i++){
					switch(getChar(refSeq, i)){
						case 0x00:sbjct.prepend('$');break;
						case 0x01:sbjct.prepend('T');break;
						case 0x02:sbjct.prepend('G');break;
						case 0x03:sbjct.prepend('C');break;
						case 0x04:sbjct.prepend('A');break;
						default:sbjct.prepend('N');
					}
				}

				//sbject
				chEnd=topSbjctOffset-chStart+1;
				chStart=chEnd+topAlignLength-1;

				//query �m�F�ς�
				quStart=queryLen+1-topQueryOffset-topAlignLength;
				quEnd=queryLen-topQueryOffset+1;

			}
			for(pos=0; pos<(int)topAlignLength; pos++){
				if(sbjct[pos]=='C'){
					if(query[pos]=='C'){
						call.append('M');
					}
					else if(query[pos]=='T'){
						call.append('U');
					}
					else{
						call.append(' ');
					}
				}
				else{
					if(query[pos]==sbjct[pos]){
						call.append('|');
					}
					else{
						call.append(' ');
					}
				}
			}

			//C2T�ϊ������N�G���[�𓖂Ă����ʁi������̂�C2T���j
			if(topAlignType2==1){
				for(i=topQueryOffset2; i<topQueryOffset2+topAlignLength2; i++){
					switch(getChar(queryF2, i)){
						case 0x00:query2.append('$');break;
						case 0x01:query2.append('A');break;
						case 0x02:query2.append('C');break;
						case 0x03:query2.append('G');break;
						case 0x04:query2.append('T');break;
						default:query2.append('N');
					}
				}
				for(i=topSbjctOffset2; i<topSbjctOffset2+topAlignLength2; i++){
					switch(getChar(refSeq, i)){
						case 0x00:sbjct2.append('$');break;
						case 0x01:sbjct2.append('A');break;
						case 0x02:sbjct2.append('C');break;
						case 0x03:sbjct2.append('G');break;
						case 0x04:sbjct2.append('T');break;
						default:sbjct2.append('N');
					}
				}

				//sbjct
				chStart2=topSbjctOffset2-chStart2+1;
				chEnd2=chStart2+topAlignLength2-1;

				//query �m�F��
				quStart2=queryLen2-topQueryOffset2;
				quEnd2=quStart2-topAlignLength2+1;

			}
			//G2A�ϊ������N�G���[�̑��⍽�𓖂Ă����ʁi������̂�C2T���j
			else if(topAlignType2==2){
				for(i=topQueryOffset2; i<topQueryOffset2+topAlignLength2; i++){
					switch(getChar(queryR2, i)){
						case 0x00:query2.append('$');break;
						case 0x01:query2.append('A');break;
						case 0x02:query2.append('C');break;
						case 0x03:query2.append('G');break;
						case 0x04:query2.append('T');break;
						default:query2.append('N');
					}
				}
				for(i=topSbjctOffset2; i<topSbjctOffset2+topAlignLength2; i++){
					switch(getChar(refSeq, i)){
						case 0x00:sbjct2.append('$');break;
						case 0x01:sbjct2.append('A');break;
						case 0x02:sbjct2.append('C');break;
						case 0x03:sbjct2.append('G');break;
						case 0x04:sbjct2.append('T');break;
						default:sbjct2.append('N');
					}
				}

				//sbjct
				chStart2=topSbjctOffset2-chStart2+1;
				chEnd2=chStart2+topAlignLength2-1;

				//query (HISEQ:104:HGM5KADXX:1:1101:2056:1975 Read2)
				quStart2=topQueryOffset2+1;
				quEnd2=topQueryOffset2+topAlignLength2;

			}
			//C2T�ϊ������N�G���[�̑��⍽�𓖂Ă����ʁi������̂�G2A���j
			else if(topAlignType2==3){
				for(i=topQueryOffset2; i<topQueryOffset2+topAlignLength2; i++){
					switch(getChar(queryR2, i)){
						case 0x00:query2.prepend('$');break;
						case 0x01:query2.prepend('T');break;
						case 0x02:query2.prepend('G');break;
						case 0x03:query2.prepend('C');break;
						case 0x04:query2.prepend('A');break;
						default:query2.prepend('N');
					}

				}
				for(i=topSbjctOffset2; i<topSbjctOffset2+topAlignLength2; i++){
					switch(getChar(refSeq, i)){
						case 0x00:sbjct2.prepend('$');break;
						case 0x01:sbjct2.prepend('T');break;
						case 0x02:sbjct2.prepend('G');break;
						case 0x03:sbjct2.prepend('C');break;
						case 0x04:sbjct2.prepend('A');break;
						default:sbjct2.prepend('N');
					}
				}

				//sbjct
				chEnd2=topSbjctOffset2-chStart2+1;
				chStart2=chEnd2+topAlignLength2-1;

				//query
				quStart2=topQueryOffset2+topAlignLength2;
				quEnd2=topQueryOffset2+1;


			}
			//G2A�ϊ������N�G���[�𓖂Ă����ʁi������̂�G2A���j
			else if(topAlignType2==4){
				for(i=topQueryOffset2; i<topQueryOffset2+topAlignLength2; i++){
					switch(getChar(queryF2, i)){
						case 0x00:query2.prepend('$');break;
						case 0x01:query2.prepend('T');break;
						case 0x02:query2.prepend('G');break;
						case 0x03:query2.prepend('C');break;
						case 0x04:query2.prepend('A');break;
						default:query2.prepend('N');
					}

				}
				for(i=topSbjctOffset2; i<topSbjctOffset2+topAlignLength2; i++){
					switch(getChar(refSeq, i)){
						case 0x00:sbjct2.prepend('$');break;
						case 0x01:sbjct2.prepend('T');break;
						case 0x02:sbjct2.prepend('G');break;
						case 0x03:sbjct2.prepend('C');break;
						case 0x04:sbjct2.prepend('A');break;
						default:sbjct2.prepend('N');
					}
				}

				//sbjct
				chEnd2=topSbjctOffset2-chStart2+1;
				chStart2=chEnd2+topAlignLength2-1;

				//query(HISEQ:104:HGM5KADXX:1:1101:1703:1983 Read2)
				quEnd2=queryLen2-topQueryOffset2;
				quStart2=quEnd2-topAlignLength2+1;


			}
			for(pos=0; pos<(int)topAlignLength2; pos++){
				if(sbjct2[pos]=='C'){
					if(query2[pos]=='C'){
						call2.append('M');
					}
					else if(query2[pos]=='T'){
						call2.append('U');
					}
					else{
						call2.append(' ');
					}
				}
				else{
					if(query2[pos]==sbjct2[pos]){
						call2.append('|');
					}
					else{
						call2.append(' ');
					}
				}
			}

			//�A���C�����g�̏o��
			buffer.setBuffer(&alnData);
			buffer.open(QIODevice::WriteOnly);
			out.setDevice(&buffer);
			out << ">" << cloneName << " Read1" << endl
				<< targetName << endl
				<< quStart << endl
				<< quEnd << endl
				<< chStart << endl
				<< chEnd << endl
				<< topAlignType << endl
				<< query << endl
				<< call << endl
				<< sbjct << endl
				<< endl
				<< ">" << cloneName << " Read2" << endl
				<< targetName2 << endl
				<< quStart2 << endl
				<< quEnd2 << endl
				<< chStart2 << endl
				<< chEnd2 << endl
				<< topAlignType2 << endl
				<< query2 << endl
				<< call2 << endl
				<< sbjct2 << endl
				<< endl;
			buffer.close();

		}

        buffer.setBuffer(&sumData);
        buffer.open(QIODevice::WriteOnly);
        out.setDevice(&buffer);
        out << cloneName << '\t'
            << topCount << '\t'
            << queryLen << '\t'
            << targetName << '\t'
            << chStart << '\t'
            << chEnd << '\t'
            << quStart << '\t'
            << quEnd << '\t'
            << topAlignType << '\t'
			<< topCount2 << '\t'
			<< queryLen2 << '\t'
			<< targetName2 << '\t'
			<< chStart2 << '\t'
			<< chEnd2 << '\t'
			<< quStart2 << '\t'
			<< quEnd2 << '\t'
			<< topAlignType2 << endl;
        buffer.close();
	}
	else if(topCount==1&&topCount2!=1){

        QByteArray query, sbjct, call;
        //C2T�ϊ������N�G���[�𓖂Ă����ʁi������̂�C2T���j
        if(topAlignType==1){
            for(i=topQueryOffset; i<topQueryOffset+topAlignLength; i++){
                switch(getChar(queryF, i)){
                    case 0x00:query.append('$');break;
                    case 0x01:query.append('A');break;
                    case 0x02:query.append('C');break;
                    case 0x03:query.append('G');break;
                    case 0x04:query.append('T');break;
                    default:query.append('N');
                }
            }
            for(i=topSbjctOffset; i<topSbjctOffset+topAlignLength; i++){
                switch(getChar(refSeq, i)){
                    case 0x00:sbjct.append('$');break;
                    case 0x01:sbjct.append('A');break;
                    case 0x02:sbjct.append('C');break;
                    case 0x03:sbjct.append('G');break;
                    case 0x04:sbjct.append('T');break;
                    default:sbjct.append('N');
                }
            }

			chStart=topSbjctOffset-chStart+1;
			chEnd=chStart+topAlignLength-1;

			//�m�F�ς�
			quStart=topQueryOffset+1;
			quEnd=topQueryOffset+topAlignLength;

        }
        //G2A�ϊ������N�G���[�̑��⍽�𓖂Ă����ʁi������̂�C2T���j
        else if(topAlignType==2){
            for(i=topQueryOffset; i<topQueryOffset+topAlignLength; i++){
                switch(getChar(queryR, i)){
                    case 0x00:query.append('$');break;
                    case 0x01:query.append('A');break;
                    case 0x02:query.append('C');break;
                    case 0x03:query.append('G');break;
                    case 0x04:query.append('T');break;
                    default:query.append('N');
                }
            }
            for(i=topSbjctOffset; i<topSbjctOffset+topAlignLength; i++){
                switch(getChar(refSeq, i)){
                    case 0x00:sbjct.append('$');break;
                    case 0x01:sbjct.append('A');break;
                    case 0x02:sbjct.append('C');break;
                    case 0x03:sbjct.append('G');break;
                    case 0x04:sbjct.append('T');break;
                    default:sbjct.append('N');
                }
            }

			chStart=topSbjctOffset-chStart+1;
			chEnd=chStart+topAlignLength-1;

			//�m�F�ς�
			quStart=queryLen-topQueryOffset;
			quEnd=quStart-topAlignLength+1;

        }
        //C2T�ϊ������N�G���[�̑��⍽�𓖂Ă����ʁi������̂�G2A���j
        else if(topAlignType==3){
            for(i=topQueryOffset; i<topQueryOffset+topAlignLength; i++){
                switch(getChar(queryR, i)){
                    case 0x00:query.prepend('$');break;
                    case 0x01:query.prepend('T');break;
                    case 0x02:query.prepend('G');break;
                    case 0x03:query.prepend('C');break;
                    case 0x04:query.prepend('A');break;
                    default:query.prepend('N');
                }

            }
            for(i=topSbjctOffset; i<topSbjctOffset+topAlignLength; i++){
                switch(getChar(refSeq, i)){
                    case 0x00:sbjct.prepend('$');break;
                    case 0x01:sbjct.prepend('T');break;
                    case 0x02:sbjct.prepend('G');break;
                    case 0x03:sbjct.prepend('C');break;
                    case 0x04:sbjct.prepend('A');break;
                    default:sbjct.prepend('N');
                }
            }

			chEnd=topSbjctOffset-chStart+1;
			chStart=chEnd+topAlignLength-1;

			//�C���ς�
			quStart=queryLen-topQueryOffset-topAlignLength+1;
			quEnd=queryLen-topQueryOffset;

        }
        //G2A�ϊ������N�G���[�𓖂Ă����ʁi������̂�G2A���j
        else if(topAlignType==4){
            for(i=topQueryOffset; i<topQueryOffset+topAlignLength; i++){
                switch(getChar(queryF, i)){
                    case 0x00:query.prepend('$');break;
                    case 0x01:query.prepend('T');break;
                    case 0x02:query.prepend('G');break;
                    case 0x03:query.prepend('C');break;
                    case 0x04:query.prepend('A');break;
                    default:query.prepend('N');
                }

            }
            for(i=topSbjctOffset; i<topSbjctOffset+topAlignLength; i++){
                switch(getChar(refSeq, i)){
                    case 0x00:sbjct.prepend('$');break;
                    case 0x01:sbjct.prepend('T');break;
                    case 0x02:sbjct.prepend('G');break;
                    case 0x03:sbjct.prepend('C');break;
                    case 0x04:sbjct.prepend('A');break;
                    default:sbjct.prepend('N');
                }
            }

			chEnd=topSbjctOffset-chStart+1;
			chStart=chEnd+topAlignLength-1;

			//�C���ς�
			quStart=topQueryOffset+topAlignLength;
			quEnd=topQueryOffset+1;

        }
        for(pos=0; pos<(int)topAlignLength; pos++){
            if(sbjct[pos]=='C'){
                if(query[pos]=='C'){
                    call.append('M');
                }
                else if(query[pos]=='T'){
                    call.append('U');
                }
                else{
                    call.append(' ');
                }
            }
            else{
                if(query[pos]==sbjct[pos]){
                    call.append('|');
                }
                else{
                    call.append(' ');
                }
            }
        }

		//sum�̏o��
        buffer.setBuffer(&sumData);
        buffer.open(QIODevice::WriteOnly);
        out.setDevice(&buffer);
        out << cloneName << '\t'
            << topCount << '\t'
            << queryLen << '\t'
            << targetName << '\t'
            << chStart << '\t'
            << chEnd << '\t'
            << quStart << '\t'
            << quEnd << '\t'
            << topAlignType << '\t'
			<< topCount2 << '\t'
			<< queryLen2 << '\t'
			<< '\t'
			<< '\t'
			<< '\t'
			<< '\t'
			<< '\t'
			<< endl;
        buffer.close();

        //�A���C�����g�̏o��
        buffer.setBuffer(&alnData);
        buffer.open(QIODevice::WriteOnly);
        out.setDevice(&buffer);
        out << ">" << cloneName << " Read1" << endl
            << targetName << endl
            << quStart << endl
            << quEnd << endl
            << chStart << endl
            << chEnd << endl
            << topAlignType << endl
            << query << endl
            << call << endl
            << sbjct << endl
            << endl;
        buffer.close();

	}
	else if(topCount!=1&&topCount2==1){

        QByteArray query, sbjct, call;
        //C2T�ϊ������N�G���[�𓖂Ă����ʁi������̂�C2T���j
        if(topAlignType2==1){
            for(i=topQueryOffset2; i<topQueryOffset2+topAlignLength2; i++){
                switch(getChar(queryF2, i)){
                    case 0x00:query.append('$');break;
                    case 0x01:query.append('A');break;
                    case 0x02:query.append('C');break;
                    case 0x03:query.append('G');break;
                    case 0x04:query.append('T');break;
                    default:query.append('N');
                }
            }
            for(i=topSbjctOffset2; i<topSbjctOffset2+topAlignLength2; i++){
                switch(getChar(refSeq, i)){
                    case 0x00:sbjct.append('$');break;
                    case 0x01:sbjct.append('A');break;
                    case 0x02:sbjct.append('C');break;
                    case 0x03:sbjct.append('G');break;
                    case 0x04:sbjct.append('T');break;
                    default:sbjct.append('N');
                }
            }

			chStart2=topSbjctOffset2-chStart2+1;
			chEnd2=chStart2+topAlignLength2-1;

			//�C���ςݗv�m�F�iHISEQ:104:HGM5KADXX:1:1101:3225:1998�@���[�h�Q�j����
			quStart2=queryLen2-topQueryOffset2;
			quEnd2=queryLen2-topQueryOffset2-topAlignLength2+1;

			topAlignType2=2;

        }
        //G2A�ϊ������N�G���[�̑��⍽�𓖂Ă����ʁi������̂�C2T���j
        else if(topAlignType2==2){
            for(i=topQueryOffset2; i<topQueryOffset2+topAlignLength2; i++){
                switch(getChar(queryR2, i)){
                    case 0x00:query.append('$');break;
                    case 0x01:query.append('A');break;
                    case 0x02:query.append('C');break;
                    case 0x03:query.append('G');break;
                    case 0x04:query.append('T');break;
                    default:query.append('N');
                }
            }
            for(i=topSbjctOffset2; i<topSbjctOffset2+topAlignLength2; i++){
                switch(getChar(refSeq, i)){
                    case 0x00:sbjct.append('$');break;
                    case 0x01:sbjct.append('A');break;
                    case 0x02:sbjct.append('C');break;
                    case 0x03:sbjct.append('G');break;
                    case 0x04:sbjct.append('T');break;
                    default:sbjct.append('N');
                }
            }

			chStart2=topSbjctOffset2-chStart2+1;
			chEnd2=chStart2+topAlignLength2-1;

			//�C���ςݗv�m�F�iHISEQ:104:HGM5KADXX:1:1101:2006:1993�@���[�h�Q�j����
			quStart2=topQueryOffset2+1;
			quEnd2=topQueryOffset2+topAlignLength2;

			topAlignType2=1;

        }
        //C2T�ϊ������N�G���[�̑��⍽�𓖂Ă����ʁi������̂�G2A���j
        else if(topAlignType2==3){
            for(i=topQueryOffset2; i<topQueryOffset2+topAlignLength2; i++){
                switch(getChar(queryR2, i)){
                    case 0x00:query.prepend('$');break;
                    case 0x01:query.prepend('T');break;
                    case 0x02:query.prepend('G');break;
                    case 0x03:query.prepend('C');break;
                    case 0x04:query.prepend('A');break;
                    default:query.prepend('N');
                }

            }
            for(i=topSbjctOffset2; i<topSbjctOffset2+topAlignLength2; i++){
                switch(getChar(refSeq, i)){
                    case 0x00:sbjct.prepend('$');break;
                    case 0x01:sbjct.prepend('T');break;
                    case 0x02:sbjct.prepend('G');break;
                    case 0x03:sbjct.prepend('C');break;
                    case 0x04:sbjct.prepend('A');break;
                    default:sbjct.prepend('N');
                }
            }

			chEnd2=topSbjctOffset2-chStart2+1;
			chStart2=chEnd2+topAlignLength2-1;

			//�C���ςݗv�m�F�iHISEQ:104:HGM5KADXX:1:1101:9136:1954�@���[�h�Q�j����
			quStart2=topQueryOffset2+topAlignLength2;
			quEnd2=topQueryOffset2+1;

			topAlignType2=4;

        }
        //G2A�ϊ������N�G���[�𓖂Ă����ʁi������̂�G2A���j
        else if(topAlignType2==4){
            for(i=topQueryOffset2; i<topQueryOffset2+topAlignLength2; i++){
                switch(getChar(queryF2, i)){
                    case 0x00:query.prepend('$');break;
                    case 0x01:query.prepend('T');break;
                    case 0x02:query.prepend('G');break;
                    case 0x03:query.prepend('C');break;
                    case 0x04:query.prepend('A');break;
                    default:query.prepend('N');
                }

            }
            for(i=topSbjctOffset2; i<topSbjctOffset2+topAlignLength2; i++){
                switch(getChar(refSeq, i)){
                    case 0x00:sbjct.prepend('$');break;
                    case 0x01:sbjct.prepend('T');break;
                    case 0x02:sbjct.prepend('G');break;
                    case 0x03:sbjct.prepend('C');break;
                    case 0x04:sbjct.prepend('A');break;
                    default:sbjct.prepend('N');
                }
            }

			chEnd2=topSbjctOffset2-chStart2+1;
			chStart2=chEnd2+topAlignLength2-1;

			//�C���ςݗv�m�F�iHISEQ:104:HGM5KADXX:1:1101:6089:1957�@���[�h�Q�j����
			quStart2=queryLen2-topQueryOffset2-topAlignLength2+1;
			quEnd2=queryLen2-topQueryOffset2;

			topAlignType2=3;

        }
        for(pos=0; pos<(int)topAlignLength2; pos++){
            if(sbjct[pos]=='C'){
                if(query[pos]=='C'){
                    call.append('M');
                }
                else if(query[pos]=='T'){
                    call.append('U');
                }
                else{
                    call.append(' ');
                }
            }
            else{
                if(query[pos]==sbjct[pos]){
                    call.append('|');
                }
                else{
                    call.append(' ');
                }
            }
        }

		//sum�̏o��
        buffer.setBuffer(&sumData);
        buffer.open(QIODevice::WriteOnly);
        out.setDevice(&buffer);
        out << cloneName << '\t'
            << topCount << '\t'
            << queryLen << '\t'
            << '\t'
            << '\t'
            << '\t'
            << '\t'
            << '\t'
            << '\t'
			<< topCount2 << '\t'
			<< queryLen2 << '\t'
			<< targetName2 << '\t'
			<< chStart2 << '\t'
			<< chEnd2 << '\t'
			<< quStart2 << '\t'
			<< quEnd2 << '\t'
			<< topAlignType2 << endl;
        buffer.close();

        //�A���C�����g�̏o��
        buffer.setBuffer(&alnData);
        buffer.open(QIODevice::WriteOnly);
        out.setDevice(&buffer);
        out << ">" << cloneName << " Read2" << endl
            << targetName2 << endl
            << quStart2 << endl
            << quEnd2 << endl
            << chStart2 << endl
            << chEnd2 << endl
            << topAlignType2 << endl
            << query << endl
            << call << endl
            << sbjct << endl
            << endl;
        buffer.close();

	}
	else{
        buffer.setBuffer(&sumData);
        buffer.open(QIODevice::WriteOnly);
        out.setDevice(&buffer);
        out << cloneName << '\t'
            << topCount << '\t'
            << queryLen << '\t'
            << '\t'
            << '\t'
            << '\t'
            << '\t'
            << '\t'
            << '\t'
			<< topCount2 << '\t'
			<< queryLen2 << '\t'
			<< '\t'
			<< '\t'
			<< '\t'
			<< '\t'
			<< '\t'
			<< endl;
        buffer.close();
	}

    emit searchFinished(sumData, alnData);

}

void BMapThread::alignWithSA(void){

    topScore=0;
    topCount=0;

    quint64 i, j, k, l, m;
    quint64 lb, ub;
    qint64 maxScore=0;
    int pos;
    int maxPos;

    QHash<quint64, int> hash;
    QHash<quint64, int>::iterator itr;

    //C2T�ϊ������N�G���[�𓖂Ă�i�����ڂ��̂܂�C2T�jtopAlignType=1
    hash.clear();
    for(i=seedOffset, j=0; i<queryLen-seedLength&&j<seedIterate; i+=seedStep, j++){
        lb=0, ub=refLen-1;
        if(seedLength>=bIdxWordSize){
            quint64 id=getId(c2tF, queryLen, i, bIdxWordSize);
			if(id==maxValue){
					continue;
				}
            if(!searchBounds(c2tBIdx, id, lb, ub)){
                continue;
            }
        }
        if(maxValue==(lb=lowerBound(c2tSeq, c2tSA, refLen, lb, ub, c2tF, i, seedLength))){
            continue;
        }
        ub=upperBound(c2tSeq, c2tSA, refLen, lb, ub, c2tF, i, seedLength);
        //adaptive seed
        if(seedFreqMax>0&&ub-lb+1>seedFreqMax){
            for(l=seedLength+1; l<=seedLengthMax; l++){
                //query�͈̔̓`�F�b�N
                if(i+l>=queryLen){
                    break;
                }
                if(maxValue==(lb=lowerBoundE(c2tSeq, c2tSA, refLen, lb, ub, c2tF, i, l))){
                    break;
                }
                ub=upperBoundE(c2tSeq, c2tSA, refLen, lb, ub, c2tF, i, l);
                if((ub-lb+1<=seedFreqMax)){
                    break;
                }
            }
            if(lb==maxValue){
                continue;
            }
            else if(ub-lb+1>seedFreqMax){
                continue;
            }
        }

        for(k=lb; k<=ub; k++){
            quint64 seedHitOffset=getInt(c2tSA, k);
            if(seedHitOffset<i){
                //���������ꏊ�͋ɒ[�ɋ�����
                continue;
            }
            quint64 candidateOffset=seedHitOffset-i;
            hash[candidateOffset]++;
        }

    }

    for(itr=hash.begin(); itr!=hash.end(); itr++){
        if(itr.value()<(int)minSeedHit){
            continue;
        }
        //�A���C�����g���{
        maxScore=0;
        maxPos=0;
        scoringArray[0]=0;
        for(pos=1, l=0, m=itr.key(); l<queryLen&&m<refLen; pos++, l++, m++){
            quint8 sc=getChar(refSeq, m);
            quint8 qc=getChar(queryF, l);
            qint64 score=scoringArray[pos-1]+c2tMatrix[sc][qc];
            if(score>0){
                scoringArray[pos]=score;
            }
            else{
                scoringArray[pos]=0;
            }
            if(score>maxScore){
                maxScore=score;
                maxPos=pos;
            }
        }
        //�X�R�A�]��
        if(maxScore<minAlnScore){
            continue;
        }
        else if(topScore<maxScore){
            topScore=maxScore;
            topCount=1;
            pos=maxPos;
            while(scoringArray[pos-1]>0){
                pos--;
            }
            topAlignLength=maxPos-pos+1;
            topQueryOffset=pos-1;
            topSbjctOffset=itr.key()+pos-1;
            topAlignType=1;
        }
        else if(topScore==maxScore){
            topCount++;
        }
    }

    //G2A�ϊ������N�G���[�̑��⍽�𓖂Ă�i�����ڂ�C2T���jtopAlignType=2
    hash.clear();
    for(i=seedOffset, j=0; i<queryLen-seedLength&&j<seedIterate; i+=seedStep, j++){
        lb=0, ub=refLen-1;
        if(seedLength>=bIdxWordSize){
            quint64 id=getId(g2aR, queryLen, i, bIdxWordSize);
			if(id==maxValue){
				continue;
			}
            if(!searchBounds(c2tBIdx, id, lb, ub)){
                continue;
            }
        }
        if(maxValue==(lb=lowerBound(c2tSeq, c2tSA, refLen, lb, ub, g2aR, i, seedLength))){
            continue;
        }
        ub=upperBound(c2tSeq, c2tSA, refLen, lb, ub, g2aR, i, seedLength);

        //adaptive seed
        if(seedFreqMax>0&&ub-lb+1>seedFreqMax){
            for(l=seedLength+1; l<=seedLengthMax; l++){
                //query�͈̔̓`�F�b�N
                if(i+l>=queryLen){
                    break;
                }
                if(maxValue==(lb=lowerBoundE(c2tSeq, c2tSA, refLen, lb, ub, g2aR, i, l))){
                    break;
                }
                ub=upperBoundE(c2tSeq, c2tSA, refLen, lb, ub, g2aR, i, l);
                if((ub-lb+1<=seedFreqMax)){
                    break;
                }
            }
            if(lb==maxValue){
                continue;
            }
            else if(ub-lb+1>seedFreqMax){
                continue;
            }
        }

        for(k=lb; k<=ub; k++){
            quint64 seedHitOffset=getInt(c2tSA, k);
            if(seedHitOffset<i){
                //���������ꏊ�͋ɒ[�ɋ�����
                continue;
            }
            quint64 candidateOffset=seedHitOffset-i;
            hash[candidateOffset]++;
        }

    }

    for(itr=hash.begin(); itr!=hash.end(); itr++){
        if(itr.value()<(int)minSeedHit){
            continue;
        }
        //�A���C�����g���{
        maxScore=0;
        maxPos=0;
        scoringArray[0]=0;
        for(pos=1, l=0, m=itr.key(); l<queryLen&&m<refLen; pos++, l++, m++){
            quint8 sc=getChar(refSeq, m);
            quint8 qc=getChar(queryR, l);
            qint64 score=scoringArray[pos-1]+c2tMatrix[sc][qc];
            if(score>0){
                scoringArray[pos]=score;
            }
            else{
                scoringArray[pos]=0;
            }
            if(score>maxScore){
                maxScore=score;
                maxPos=pos;
            }
        }
        //�X�R�A�]��
        if(maxScore<minAlnScore){
            continue;
        }
        else if(topScore<maxScore){
            topScore=maxScore;
            topCount=1;
            pos=maxPos;
            while(scoringArray[pos-1]>0){
                pos--;
            }
            topAlignLength=maxPos-pos+1;
            topQueryOffset=pos-1;
            topSbjctOffset=itr.key()+pos-1;
            topAlignType=2;
        }
        else if(topScore==maxScore){
            topCount++;
        }
    }

    ////C2T�ϊ������N�G���[�̑��⍽�𓖂Ă�i�����ڂ�G2A���jtopAlignType=3
    hash.clear();
    for(i=seedOffset, j=0; i<queryLen-seedLength&&j<seedIterate; i+=seedStep, j++){
        lb=0, ub=refLen-1;
        if(seedLength>=bIdxWordSize){
            quint64 id=getId(c2tR, queryLen, i, bIdxWordSize);
			if(id==maxValue){
				continue;
			}
            if(!searchBounds(g2aBIdx, id, lb, ub)){
                continue;
            }
        }
        if(maxValue==(lb=lowerBound(g2aSeq, g2aSA, refLen, lb, ub, c2tR, i, seedLength))){
            continue;
        }
        ub=upperBound(g2aSeq, g2aSA, refLen, lb, ub, c2tR, i, seedLength);

        //adaptive seed
        if(seedFreqMax>0&&ub-lb+1>seedFreqMax){
            for(l=seedLength+1; l<=seedLengthMax; l++){
                //query�͈̔̓`�F�b�N
                if(i+l>=queryLen){
                    break;
                }
                if(maxValue==(lb=lowerBoundE(g2aSeq, g2aSA, refLen, lb, ub, c2tR, i, l))){
                    break;
                }
                ub=upperBoundE(g2aSeq, g2aSA, refLen, lb, ub, c2tR, i, l);
                if((ub-lb+1<=seedFreqMax)){
                    break;
                }
            }
            if(lb==maxValue){
                continue;
            }
            else if(ub-lb+1>seedFreqMax){
                continue;
            }
        }

        for(k=lb; k<=ub; k++){
            quint64 seedHitOffset=getInt(g2aSA, k);
            if(seedHitOffset<i){
                //���������ꏊ�͋ɒ[�ɋ�����
                continue;
            }
            quint64 candidateOffset=seedHitOffset-i;
            hash[candidateOffset]++;
        }

    }

    for(itr=hash.begin(); itr!=hash.end(); itr++){
        if(itr.value()<(int)minSeedHit){
            continue;
        }
        //�A���C�����g���{
        maxScore=0;
        maxPos=0;
        scoringArray[0]=0;
        for(pos=1, l=0, m=itr.key(); l<queryLen&&m<refLen; pos++, l++, m++){
            quint8 sc=getChar(refSeq, m);
            quint8 qc=getChar(queryR, l);
            qint64 score=scoringArray[pos-1]+g2aMatrix[sc][qc];
            if(score>0){
                scoringArray[pos]=score;
            }
            else{
                scoringArray[pos]=0;
            }
            if(score>maxScore){
                maxScore=score;
                maxPos=pos;
            }
        }
        //�X�R�A�]��
        if(maxScore<minAlnScore){
            continue;
        }
        else if(topScore<maxScore){
            topScore=maxScore;
            topCount=1;
            pos=maxPos;
            while(scoringArray[pos-1]>0){
                pos--;
            }
            topAlignLength=maxPos-pos+1;
            topQueryOffset=pos-1;
            topSbjctOffset=itr.key()+pos-1;
            topAlignType=3;
        }
        else if(topScore==maxScore){
            topCount++;
        }
    }

    //G2A�ϊ������N�G���[�𓖂Ă�i�����ڂ�G2A���jtopAlignType=4
    hash.clear();
    for(i=seedOffset, j=0; i<queryLen-seedLength&&j<seedIterate; i+=seedStep, j++){
        lb=0, ub=refLen-1;
        if(seedLength>=bIdxWordSize){
            quint64 id=getId(g2aF, queryLen, i, bIdxWordSize);
			if(id==maxValue){
				continue;
			}
            if(!searchBounds(g2aBIdx, id, lb, ub)){
                continue;
            }
        }
        if(maxValue==(lb=lowerBound(g2aSeq, g2aSA, refLen, lb, ub, g2aF, i, seedLength))){
            continue;
        }
        ub=upperBound(g2aSeq, g2aSA, refLen, lb, ub, g2aF, i, seedLength);

        //adaptive seed
        if(seedFreqMax>0&&ub-lb+1>seedFreqMax){
            for(l=seedLength+1; l<=seedLengthMax; l++){
                //query�͈̔̓`�F�b�N
                if(i+l>=queryLen){
                    break;
                }
                if(maxValue==(lb=lowerBoundE(g2aSeq, g2aSA, refLen, lb, ub, g2aF, i, l))){
                    break;
                }
                ub=upperBoundE(g2aSeq, g2aSA, refLen, lb, ub, g2aF, i, l);
                if((ub-lb+1<=seedFreqMax)){
                    break;
                }
            }
            if(lb==maxValue){
                continue;
            }
            else if(ub-lb+1>seedFreqMax){
                continue;
            }
        }

        for(k=lb; k<=ub; k++){
            quint64 seedHitOffset=getInt(g2aSA, k);
            if(seedHitOffset<i){
                //���������ꏊ�͋ɒ[�ɋ�����
                continue;
            }
            quint64 candidateOffset=seedHitOffset-i;
            hash[candidateOffset]++;
        }

    }

    for(itr=hash.begin(); itr!=hash.end(); itr++){
        if(itr.value()<(int)minSeedHit){
            continue;
        }
        //�A���C�����g���{
        maxScore=0;
        maxPos=0;
        scoringArray[0]=0;
        for(pos=1, l=0, m=itr.key(); l<queryLen&&m<refLen; pos++, l++, m++){
            quint8 sc=getChar(refSeq, m);
            quint8 qc=getChar(queryF, l);
            qint64 score=scoringArray[pos-1]+g2aMatrix[sc][qc];
            if(score>0){
                scoringArray[pos]=score;
            }
            else{
                scoringArray[pos]=0;
            }
            if(score>maxScore){
                maxScore=score;
                maxPos=pos;
            }
        }
        //�X�R�A�]��
        if(maxScore<minAlnScore){
            continue;
        }
        else if(topScore<maxScore){
            topScore=maxScore;
            topCount=1;
            pos=maxPos;
            while(scoringArray[pos-1]>0){
                pos--;
            }
            topAlignLength=maxPos-pos+1;
            topQueryOffset=pos-1;
            topSbjctOffset=itr.key()+pos-1;
            topAlignType=4;
        }
        else if(topScore==maxScore){
            topCount++;
        }
    }

}

void BMapThread::alignWithSA2(void){

    topScore2=0;
    topCount2=0;

    quint64 i, j, k, l, m;
    quint64 lb, ub;
    qint64 maxScore=0;
    int pos;
    int maxPos;

    QHash<quint64, int> hash;
    QHash<quint64, int>::iterator itr;

    //C2T�ϊ������N�G���[�𓖂Ă�i�����ڂ��̂܂�C2T�jtopAlignType=1
    hash.clear();
    for(i=seedOffset, j=0; i<queryLen2-seedLength&&j<seedIterate; i+=seedStep, j++){
        lb=0, ub=refLen-1;
        if(seedLength>=bIdxWordSize){
            quint64 id=getId(c2tF2, queryLen2, i, bIdxWordSize);
			if(id==maxValue){
				continue;
			}
            if(!searchBounds(c2tBIdx, id, lb, ub)){
                continue;
            }
        }
        if(maxValue==(lb=lowerBound(c2tSeq, c2tSA, refLen, lb, ub, c2tF2, i, seedLength))){
            continue;
        }
        ub=upperBound(c2tSeq, c2tSA, refLen, lb, ub, c2tF2, i, seedLength);
        //adaptive seed
        if(seedFreqMax>0&&ub-lb+1>seedFreqMax){
            for(l=seedLength+1; l<=seedLengthMax; l++){
                //query�͈̔̓`�F�b�N
                if(i+l>=queryLen2){
                    break;
                }
                if(maxValue==(lb=lowerBoundE(c2tSeq, c2tSA, refLen, lb, ub, c2tF2, i, l))){
                    break;
                }
                ub=upperBoundE(c2tSeq, c2tSA, refLen, lb, ub, c2tF2, i, l);
                if((ub-lb+1<=seedFreqMax)){
                    break;
                }
            }
            if(lb==maxValue){
                continue;
            }
            else if(ub-lb+1>seedFreqMax){
                continue;
            }
        }

        for(k=lb; k<=ub; k++){
            quint64 seedHitOffset=getInt(c2tSA, k);
            if(seedHitOffset<i){
                //���������ꏊ�͋ɒ[�ɋ�����
                continue;
            }
            quint64 candidateOffset=seedHitOffset-i;
            hash[candidateOffset]++;
        }

    }

    for(itr=hash.begin(); itr!=hash.end(); itr++){
        if(itr.value()<(int)minSeedHit){
            continue;
        }
        //�A���C�����g���{
        maxScore=0;
        maxPos=0;
        scoringArray[0]=0;
        for(pos=1, l=0, m=itr.key(); l<queryLen2&&m<refLen; pos++, l++, m++){
            quint8 sc=getChar(refSeq, m);
            quint8 qc=getChar(queryF2, l);
            qint64 score=scoringArray[pos-1]+c2tMatrix[sc][qc];
            if(score>0){
                scoringArray[pos]=score;
            }
            else{
                scoringArray[pos]=0;
            }
            if(score>maxScore){
                maxScore=score;
                maxPos=pos;
            }
        }
        //�X�R�A�]��
        if(maxScore<minAlnScore){
            continue;
        }
        else if(topScore2<maxScore){
            topScore2=maxScore;
            topCount2=1;
            pos=maxPos;
            while(scoringArray[pos-1]>0){
                pos--;
            }
            topAlignLength2=maxPos-pos+1;
            topQueryOffset2=pos-1;
            topSbjctOffset2=itr.key()+pos-1;
            topAlignType2=1;
        }
        else if(topScore2==maxScore){
            topCount2++;
        }
    }

    //G2A�ϊ������N�G���[�̑��⍽�𓖂Ă�i�����ڂ�C2T���jtopAlignType=2
    hash.clear();
    for(i=seedOffset, j=0; i<queryLen2-seedLength&&j<seedIterate; i+=seedStep, j++){
        lb=0, ub=refLen-1;
        if(seedLength>=bIdxWordSize){
            quint64 id=getId(g2aR2, queryLen2, i, bIdxWordSize);
			if(id==maxValue){
				continue;
			}
            if(!searchBounds(c2tBIdx, id, lb, ub)){
                continue;
            }
        }
        if(maxValue==(lb=lowerBound(c2tSeq, c2tSA, refLen, lb, ub, g2aR2, i, seedLength))){
            continue;
        }
        ub=upperBound(c2tSeq, c2tSA, refLen, lb, ub, g2aR2, i, seedLength);

        //adaptive seed
        if(seedFreqMax>0&&ub-lb+1>seedFreqMax){
            for(l=seedLength+1; l<=seedLengthMax; l++){
                //query�͈̔̓`�F�b�N
                if(i+l>=queryLen2){
                    break;
                }
                if(maxValue==(lb=lowerBoundE(c2tSeq, c2tSA, refLen, lb, ub, g2aR2, i, l))){
                    break;
                }
                ub=upperBoundE(c2tSeq, c2tSA, refLen, lb, ub, g2aR2, i, l);
                if((ub-lb+1<=seedFreqMax)){
                    break;
                }
            }
            if(lb==maxValue){
                continue;
            }
            else if(ub-lb+1>seedFreqMax){
                continue;
            }
        }

        for(k=lb; k<=ub; k++){
            quint64 seedHitOffset=getInt(c2tSA, k);
            if(seedHitOffset<i){
                //���������ꏊ�͋ɒ[�ɋ�����
                continue;
            }
            quint64 candidateOffset=seedHitOffset-i;
            hash[candidateOffset]++;
        }

    }

    for(itr=hash.begin(); itr!=hash.end(); itr++){
        if(itr.value()<(int)minSeedHit){
            continue;
        }
        //�A���C�����g���{
        maxScore=0;
        maxPos=0;
        scoringArray[0]=0;
        for(pos=1, l=0, m=itr.key(); l<queryLen2&&m<refLen; pos++, l++, m++){
            quint8 sc=getChar(refSeq, m);
            quint8 qc=getChar(queryR2, l);
            qint64 score=scoringArray[pos-1]+c2tMatrix[sc][qc];
            if(score>0){
                scoringArray[pos]=score;
            }
            else{
                scoringArray[pos]=0;
            }
            if(score>maxScore){
                maxScore=score;
                maxPos=pos;
            }
        }
        //�X�R�A�]��
        if(maxScore<minAlnScore){
            continue;
        }
        else if(topScore2<maxScore){
            topScore2=maxScore;
            topCount2=1;
            pos=maxPos;
            while(scoringArray[pos-1]>0){
                pos--;
            }
            topAlignLength2=maxPos-pos+1;
            topQueryOffset2=pos-1;
            topSbjctOffset2=itr.key()+pos-1;
            topAlignType2=2;
        }
        else if(topScore2==maxScore){
            topCount2++;
        }
    }

    ////C2T�ϊ������N�G���[�̑��⍽�𓖂Ă�i�����ڂ�G2A���jtopAlignType=3
    hash.clear();
    for(i=seedOffset, j=0; i<queryLen2-seedLength&&j<seedIterate; i+=seedStep, j++){
        lb=0, ub=refLen-1;
        if(seedLength>=bIdxWordSize){
            quint64 id=getId(c2tR2, queryLen2, i, bIdxWordSize);
			if(id==maxValue){
				continue;
			}
            if(!searchBounds(g2aBIdx, id, lb, ub)){
                continue;
            }
        }
        if(maxValue==(lb=lowerBound(g2aSeq, g2aSA, refLen, lb, ub, c2tR2, i, seedLength))){
            continue;
        }
        ub=upperBound(g2aSeq, g2aSA, refLen, lb, ub, c2tR2, i, seedLength);

        //adaptive seed
        if(seedFreqMax>0&&ub-lb+1>seedFreqMax){
            for(l=seedLength+1; l<=seedLengthMax; l++){
                //query�͈̔̓`�F�b�N
                if(i+l>=queryLen2){
                    break;
                }
                if(maxValue==(lb=lowerBoundE(g2aSeq, g2aSA, refLen, lb, ub, c2tR2, i, l))){
                    break;
                }
                ub=upperBoundE(g2aSeq, g2aSA, refLen, lb, ub, c2tR2, i, l);
                if((ub-lb+1<=seedFreqMax)){
                    break;
                }
            }
            if(lb==maxValue){
                continue;
            }
            else if(ub-lb+1>seedFreqMax){
                continue;
            }
        }

        for(k=lb; k<=ub; k++){
            quint64 seedHitOffset=getInt(g2aSA, k);
            if(seedHitOffset<i){
                //���������ꏊ�͋ɒ[�ɋ�����
                continue;
            }
            quint64 candidateOffset=seedHitOffset-i;
            hash[candidateOffset]++;
        }

    }

    for(itr=hash.begin(); itr!=hash.end(); itr++){
        if(itr.value()<(int)minSeedHit){
            continue;
        }
        //�A���C�����g���{
        maxScore=0;
        maxPos=0;
        scoringArray[0]=0;
        for(pos=1, l=0, m=itr.key(); l<queryLen2&&m<refLen; pos++, l++, m++){
            quint8 sc=getChar(refSeq, m);
            quint8 qc=getChar(queryR2, l);
            qint64 score=scoringArray[pos-1]+g2aMatrix[sc][qc];
            if(score>0){
                scoringArray[pos]=score;
            }
            else{
                scoringArray[pos]=0;
            }
            if(score>maxScore){
                maxScore=score;
                maxPos=pos;
            }
        }
        //�X�R�A�]��
        if(maxScore<minAlnScore){
            continue;
        }
        else if(topScore2<maxScore){
            topScore2=maxScore;
            topCount2=1;
            pos=maxPos;
            while(scoringArray[pos-1]>0){
                pos--;
            }
            topAlignLength2=maxPos-pos+1;
            topQueryOffset2=pos-1;
            topSbjctOffset2=itr.key()+pos-1;
            topAlignType2=3;
        }
        else if(topScore2==maxScore){
            topCount2++;
        }
    }

    //G2A�ϊ������N�G���[�𓖂Ă�i�����ڂ�G2A���jtopAlignType=4
    hash.clear();
    for(i=seedOffset, j=0; i<queryLen2-seedLength&&j<seedIterate; i+=seedStep, j++){
        lb=0, ub=refLen-1;
        if(seedLength>=bIdxWordSize){
            quint64 id=getId(g2aF2, queryLen2, i, bIdxWordSize);
			if(id==maxValue){
				continue;
			}
            if(!searchBounds(g2aBIdx, id, lb, ub)){
                continue;
            }
        }
        if(maxValue==(lb=lowerBound(g2aSeq, g2aSA, refLen, lb, ub, g2aF2, i, seedLength))){
            continue;
        }
        ub=upperBound(g2aSeq, g2aSA, refLen, lb, ub, g2aF2, i, seedLength);

        //adaptive seed
        if(seedFreqMax>0&&ub-lb+1>seedFreqMax){
            for(l=seedLength+1; l<=seedLengthMax; l++){
                //query�͈̔̓`�F�b�N
                if(i+l>=queryLen2){
                    break;
                }
                if(maxValue==(lb=lowerBoundE(g2aSeq, g2aSA, refLen, lb, ub, g2aF2, i, l))){
                    break;
                }
                ub=upperBoundE(g2aSeq, g2aSA, refLen, lb, ub, g2aF2, i, l);
                if((ub-lb+1<=seedFreqMax)){
                    break;
                }
            }
            if(lb==maxValue){
                continue;
            }
            else if(ub-lb+1>seedFreqMax){
                continue;
            }
        }

        for(k=lb; k<=ub; k++){
            quint64 seedHitOffset=getInt(g2aSA, k);
            if(seedHitOffset<i){
                //���������ꏊ�͋ɒ[�ɋ�����
                continue;
            }
            quint64 candidateOffset=seedHitOffset-i;
            hash[candidateOffset]++;
        }

    }

    for(itr=hash.begin(); itr!=hash.end(); itr++){
        if(itr.value()<(int)minSeedHit){
            continue;
        }
        //�A���C�����g���{
        maxScore=0;
        maxPos=0;
        scoringArray[0]=0;
        for(pos=1, l=0, m=itr.key(); l<queryLen2&&m<refLen; pos++, l++, m++){
            quint8 sc=getChar(refSeq, m);
            quint8 qc=getChar(queryF2, l);
            qint64 score=scoringArray[pos-1]+g2aMatrix[sc][qc];
            if(score>0){
                scoringArray[pos]=score;
            }
            else{
                scoringArray[pos]=0;
            }
            if(score>maxScore){
                maxScore=score;
                maxPos=pos;
            }
        }
        //�X�R�A�]��
        if(maxScore<minAlnScore){
            continue;
        }
        else if(topScore2<maxScore){
            topScore2=maxScore;
            topCount2=1;
            pos=maxPos;
            while(scoringArray[pos-1]>0){
                pos--;
            }
            topAlignLength2=maxPos-pos+1;
            topQueryOffset2=pos-1;
            topSbjctOffset2=itr.key()+pos-1;
            topAlignType2=4;
        }
        else if(topScore2==maxScore){
            topCount2++;
        }
    }

}


void BMapThread::limAlignWithSA1(void){

	//query2�̃}�b�v���ʂ𗘗p����query1���ēx�}�b�v���邽�߂̊֐�
    quint64 i, j, k, l, m;
    quint64 lb, ub;
    qint64 maxScore=0;
    int pos;
    int maxPos;

    QHash<quint64, int> hash;
    QHash<quint64, int>::iterator itr;

	//�O��Ƃ���query2��unique�Ƀ}�b�v����Ă���K�v������
	if(topCount2!=1){
		return;
	}

	if(topAlignType2==1){

		//�ړI��frequency�Œe���ꂽ�V�[�h��PE�ɂ��~�ςȂ̂ł����Ȃ�seedLengthMax�𗘗p
		for(i=seedOffset, j=0; i<queryLen-seedLengthMax&&j<seedIterate; i+=seedStep, j++){
			lb=0, ub=refLen-1;
			if(seedLengthMax>=bIdxWordSize){
				quint64 id=getId(c2tF, queryLen, i, bIdxWordSize);
				if(id==maxValue){
					continue;
				}
				if(!searchBounds(c2tBIdx, id, lb, ub)){
					continue;
				}
			}
			if(maxValue==(lb=lowerBound(c2tSeq, c2tSA, refLen, lb, ub, c2tF, i, seedLengthMax))){
				continue;
			}
			ub=upperBound(c2tSeq, c2tSA, refLen, lb, ub, c2tF, i, seedLengthMax);
			for(k=lb; k<=ub; k++){
				quint64 seedHitOffset=getInt(c2tSA, k);
				if(seedHitOffset<i){
					//���������ꏊ�͋ɒ[�ɋ�����
					continue;
				}
				quint64 candidateOffset=seedHitOffset-i;
				if(candidateOffset>topSbjctOffset2-maxPEPairLen
					&&candidateOffset<topSbjctOffset2+maxPEPairLen+topAlignLength2)
				{
					hash[candidateOffset]++;
				}
			}
		}
		for(itr=hash.begin(); itr!=hash.end(); itr++){
			if(itr.value()<(int)minSeedHit){
				continue;
			}
			//�A���C�����g���{
			maxScore=0;
			maxPos=0;
			scoringArray[0]=0;
			for(pos=1, l=0, m=itr.key(); l<queryLen&&m<refLen; pos++, l++, m++){
				quint8 sc=getChar(refSeq, m);
				quint8 qc=getChar(queryF, l);
				qint64 score=scoringArray[pos-1]+c2tMatrix[sc][qc];
				if(score>0){
					scoringArray[pos]=score;
				}
				else{
					scoringArray[pos]=0;
				}
				if(score>maxScore){
					maxScore=score;
					maxPos=pos;
				}
			}
			//�X�R�A�]��
			if(maxScore<minAlnScore){
				continue;
			}
			else if(topScore<maxScore){
				topScore=maxScore;
				topCount=1;
				pos=maxPos;
				while(scoringArray[pos-1]>0){
					pos--;
				}
				topAlignLength=maxPos-pos+1;
				topQueryOffset=pos-1;
				topSbjctOffset=itr.key()+pos-1;
				topAlignType=1;
			}
			else if(topScore==maxScore){
				topCount++;
			}
		}
	}


	else if(topAlignType2==2){

		//�ړI��frequency�Œe���ꂽ�V�[�h��PE�ɂ��~�ςȂ̂ł����Ȃ�seedLengthMax�𗘗p
		for(i=seedOffset, j=0; i<queryLen-seedLengthMax&&j<seedIterate; i+=seedStep, j++){
			lb=0, ub=refLen-1;
			if(seedLengthMax>=bIdxWordSize){
				quint64 id=getId(g2aR, queryLen, i, bIdxWordSize);
				if(id==maxValue){
					continue;
				}
				if(!searchBounds(c2tBIdx, id, lb, ub)){
					continue;
				}
			}
			if(maxValue==(lb=lowerBound(c2tSeq, c2tSA, refLen, lb, ub, g2aR, i, seedLengthMax))){
				continue;
			}
			ub=upperBound(c2tSeq, c2tSA, refLen, lb, ub, g2aR, i, seedLengthMax);
			for(k=lb; k<=ub; k++){
				quint64 seedHitOffset=getInt(c2tSA, k);
				if(seedHitOffset<i){
					//���������ꏊ�͋ɒ[�ɋ�����
					continue;
				}
				quint64 candidateOffset=seedHitOffset-i;
				if(candidateOffset>topSbjctOffset2-maxPEPairLen
					&&candidateOffset<topSbjctOffset2+maxPEPairLen+topAlignLength2)
				{
					hash[candidateOffset]++;
				}
			}
		}
		for(itr=hash.begin(); itr!=hash.end(); itr++){
			if(itr.value()<(int)minSeedHit){
				continue;
			}
			//�A���C�����g���{
			maxScore=0;
			maxPos=0;
			scoringArray[0]=0;
			for(pos=1, l=0, m=itr.key(); l<queryLen&&m<refLen; pos++, l++, m++){
				quint8 sc=getChar(refSeq, m);
				quint8 qc=getChar(queryR, l);
				qint64 score=scoringArray[pos-1]+c2tMatrix[sc][qc];
				if(score>0){
					scoringArray[pos]=score;
				}
				else{
					scoringArray[pos]=0;
				}
				if(score>maxScore){
					maxScore=score;
					maxPos=pos;
				}
			}
			//�X�R�A�]��
			if(maxScore<minAlnScore){
				continue;
			}
			else if(topScore<maxScore){
				topScore=maxScore;
				topCount=1;
				pos=maxPos;
				while(scoringArray[pos-1]>0){
					pos--;
				}
				topAlignLength=maxPos-pos+1;
				topQueryOffset=pos-1;
				topSbjctOffset=itr.key()+pos-1;
				topAlignType=2;
			}
			else if(topScore==maxScore){
				topCount++;
			}
		}
	}


	if(topAlignType2==3){

		//�ړI��frequency�Œe���ꂽ�V�[�h��PE�ɂ��~�ςȂ̂ł����Ȃ�seedLengthMax�𗘗p
		for(i=seedOffset, j=0; i<queryLen-seedLengthMax&&j<seedIterate; i+=seedStep, j++){
			lb=0, ub=refLen-1;
			if(seedLengthMax>=bIdxWordSize){
				quint64 id=getId(c2tR, queryLen, i, bIdxWordSize);
				if(id==maxValue){
					continue;
				}
				if(!searchBounds(g2aBIdx, id, lb, ub)){
					continue;
				}
			}
			if(maxValue==(lb=lowerBound(g2aSeq, g2aSA, refLen, lb, ub, c2tR, i, seedLengthMax))){
				continue;
			}
			ub=upperBound(g2aSeq, g2aSA, refLen, lb, ub, c2tR, i, seedLengthMax);
			for(k=lb; k<=ub; k++){
				quint64 seedHitOffset=getInt(g2aSA, k);
				if(seedHitOffset<i){
					//���������ꏊ�͋ɒ[�ɋ�����
					continue;
				}
				quint64 candidateOffset=seedHitOffset-i;
				if(candidateOffset>topSbjctOffset2-maxPEPairLen
					&&candidateOffset<topSbjctOffset2+maxPEPairLen+topAlignLength2)
				{
					hash[candidateOffset]++;
				}
			}
		}
		for(itr=hash.begin(); itr!=hash.end(); itr++){
			if(itr.value()<(int)minSeedHit){
				continue;
			}
			//�A���C�����g���{
			maxScore=0;
			maxPos=0;
			scoringArray[0]=0;
			for(pos=1, l=0, m=itr.key(); l<queryLen&&m<refLen; pos++, l++, m++){
				quint8 sc=getChar(refSeq, m);
				quint8 qc=getChar(queryR, l);
				qint64 score=scoringArray[pos-1]+g2aMatrix[sc][qc];
				if(score>0){
					scoringArray[pos]=score;
				}
				else{
					scoringArray[pos]=0;
				}
				if(score>maxScore){
					maxScore=score;
					maxPos=pos;
				}
			}
			//�X�R�A�]��
			if(maxScore<minAlnScore){
				continue;
			}
			else if(topScore<maxScore){
				topScore=maxScore;
				topCount=1;
				pos=maxPos;
				while(scoringArray[pos-1]>0){
					pos--;
				}
				topAlignLength=maxPos-pos+1;
				topQueryOffset=pos-1;
				topSbjctOffset=itr.key()+pos-1;
				topAlignType=3;
			}
			else if(topScore==maxScore){
				topCount++;
			}
		}
	}

	if(topAlignType2==4){

		//�ړI��frequency�Œe���ꂽ�V�[�h��PE�ɂ��~�ςȂ̂ł����Ȃ�seedLengthMax�𗘗p
		for(i=seedOffset, j=0; i<queryLen-seedLengthMax&&j<seedIterate; i+=seedStep, j++){
			lb=0, ub=refLen-1;
			if(seedLengthMax>=bIdxWordSize){
				quint64 id=getId(g2aF, queryLen, i, bIdxWordSize);
				if(id==maxValue){
					continue;
				}
				if(!searchBounds(g2aBIdx, id, lb, ub)){
					continue;
				}
			}
			if(maxValue==(lb=lowerBound(g2aSeq, g2aSA, refLen, lb, ub, g2aF, i, seedLengthMax))){
				continue;
			}
			ub=upperBound(g2aSeq, g2aSA, refLen, lb, ub, g2aF, i, seedLengthMax);
			for(k=lb; k<=ub; k++){
				quint64 seedHitOffset=getInt(g2aSA, k);
				if(seedHitOffset<i){
					//���������ꏊ�͋ɒ[�ɋ�����
					continue;
				}
				quint64 candidateOffset=seedHitOffset-i;
				if(candidateOffset>topSbjctOffset2-maxPEPairLen
					&&candidateOffset<topSbjctOffset2+maxPEPairLen+topAlignLength2)
				{
					hash[candidateOffset]++;
				}
			}
		}

		for(itr=hash.begin(); itr!=hash.end(); itr++){
			if(itr.value()<(int)minSeedHit){
				continue;
			}
			//�A���C�����g���{
			maxScore=0;
			maxPos=0;
			scoringArray[0]=0;
			for(pos=1, l=0, m=itr.key(); l<queryLen&&m<refLen; pos++, l++, m++){
				quint8 sc=getChar(refSeq, m);
				quint8 qc=getChar(queryF, l);
				qint64 score=scoringArray[pos-1]+g2aMatrix[sc][qc];
				if(score>0){
					scoringArray[pos]=score;
				}
				else{
					scoringArray[pos]=0;
				}
				if(score>maxScore){
					maxScore=score;
					maxPos=pos;
				}
			}
			//�X�R�A�]��
			if(maxScore<minAlnScore){
				continue;
			}
			else if(topScore<maxScore){
				topScore=maxScore;
				topCount=1;
				pos=maxPos;
				while(scoringArray[pos-1]>0){
					pos--;
				}
				topAlignLength=maxPos-pos+1;
				topQueryOffset=pos-1;
				topSbjctOffset=itr.key()+pos-1;
				topAlignType=4;
			}
			else if(topScore==maxScore){
				topCount++;
			}
		}
	}

}

void BMapThread::limAlignWithSA2(void){

	//query1�̃}�b�v���ʂ𗘗p����query2���ēx�}�b�v���邽�߂̊֐�
    quint64 i, j, k, l, m;
    quint64 lb, ub;
    qint64 maxScore=0;
    int pos;
    int maxPos;

    QHash<quint64, int> hash;
    QHash<quint64, int>::iterator itr;

	//�O��Ƃ���query1��unique�Ƀ}�b�v����Ă���K�v������
	if(topCount!=1){
		return;
	}

	if(topAlignType==1){

		//�ړI��frequency�Œe���ꂽ�V�[�h��PE�ɂ��~�ςȂ̂ł����Ȃ�seedLengthMax�𗘗p
		for(i=seedOffset, j=0; i<queryLen2-seedLengthMax&&j<seedIterate; i+=seedStep, j++){
			lb=0, ub=refLen-1;
			if(seedLengthMax>=bIdxWordSize){
				quint64 id=getId(c2tF2, queryLen2, i, bIdxWordSize);
				if(id==maxValue){
					continue;
				}
				if(!searchBounds(c2tBIdx, id, lb, ub)){
					continue;
				}
			}
			if(maxValue==(lb=lowerBound(c2tSeq, c2tSA, refLen, lb, ub, c2tF2, i, seedLengthMax))){
				continue;
			}
			ub=upperBound(c2tSeq, c2tSA, refLen, lb, ub, c2tF2, i, seedLengthMax);
			for(k=lb; k<=ub; k++){
				quint64 seedHitOffset=getInt(c2tSA, k);
				if(seedHitOffset<i){
					//���������ꏊ�͋ɒ[�ɋ�����
					continue;
				}
				quint64 candidateOffset=seedHitOffset-i;
				if(candidateOffset>topSbjctOffset-maxPEPairLen
					&&candidateOffset<topSbjctOffset+maxPEPairLen+topAlignLength)
				{
					hash[candidateOffset]++;
				}
			}
		}
		for(itr=hash.begin(); itr!=hash.end(); itr++){
			if(itr.value()<(int)minSeedHit){
				continue;
			}
			//�A���C�����g���{
			maxScore=0;
			maxPos=0;
			scoringArray[0]=0;
			for(pos=1, l=0, m=itr.key(); l<queryLen&&m<refLen; pos++, l++, m++){
				quint8 sc=getChar(refSeq, m);
				quint8 qc=getChar(queryF2, l);
				qint64 score=scoringArray[pos-1]+c2tMatrix[sc][qc];
				if(score>0){
					scoringArray[pos]=score;
				}
				else{
					scoringArray[pos]=0;
				}
				if(score>maxScore){
					maxScore=score;
					maxPos=pos;
				}
			}
			//�X�R�A�]��
			if(maxScore<minAlnScore){
				continue;
			}
			else if(topScore2<maxScore){
				topScore2=maxScore;
				topCount2=1;
				pos=maxPos;
				while(scoringArray[pos-1]>0){
					pos--;
				}
				topAlignLength2=maxPos-pos+1;
				topQueryOffset2=pos-1;
				topSbjctOffset2=itr.key()+pos-1;
				topAlignType2=1;
			}
			else if(topScore2==maxScore){
				topCount2++;
			}
		}
	}

	else if(topAlignType==2){

		//�ړI��frequency�Œe���ꂽ�V�[�h��PE�ɂ��~�ςȂ̂ł����Ȃ�seedLengthMax�𗘗p
		for(i=seedOffset, j=0; i<queryLen2-seedLengthMax&&j<seedIterate; i+=seedStep, j++){
			lb=0, ub=refLen-1;
			if(seedLengthMax>=bIdxWordSize){
				quint64 id=getId(g2aR2, queryLen2, i, bIdxWordSize);
				if(id==maxValue){
					continue;
				}
				if(!searchBounds(c2tBIdx, id, lb, ub)){
					continue;
				}
			}
			if(maxValue==(lb=lowerBound(c2tSeq, c2tSA, refLen, lb, ub, g2aR2, i, seedLengthMax))){
				continue;
			}
			ub=upperBound(c2tSeq, c2tSA, refLen, lb, ub, g2aR2, i, seedLengthMax);
			for(k=lb; k<=ub; k++){
				quint64 seedHitOffset=getInt(c2tSA, k);
				if(seedHitOffset<i){
					//���������ꏊ�͋ɒ[�ɋ�����
					continue;
				}
				quint64 candidateOffset=seedHitOffset-i;
				if(candidateOffset>topSbjctOffset-maxPEPairLen
					&&candidateOffset<topSbjctOffset+maxPEPairLen+topAlignLength)
				{
					hash[candidateOffset]++;
				}
			}
		}
		for(itr=hash.begin(); itr!=hash.end(); itr++){
			if(itr.value()<(int)minSeedHit){
				continue;
			}
			//�A���C�����g���{
			maxScore=0;
			maxPos=0;
			scoringArray[0]=0;
			for(pos=1, l=0, m=itr.key(); l<queryLen2&&m<refLen; pos++, l++, m++){
				quint8 sc=getChar(refSeq, m);
				quint8 qc=getChar(queryR2, l);
				qint64 score=scoringArray[pos-1]+c2tMatrix[sc][qc];
				if(score>0){
					scoringArray[pos]=score;
				}
				else{
					scoringArray[pos]=0;
				}
				if(score>maxScore){
					maxScore=score;
					maxPos=pos;
				}
			}
			//�X�R�A�]��
			if(maxScore<minAlnScore){
				continue;
			}
			else if(topScore2<maxScore){
				topScore2=maxScore;
				topCount2=1;
				pos=maxPos;
				while(scoringArray[pos-1]>0){
					pos--;
				}
				topAlignLength2=maxPos-pos+1;
				topQueryOffset2=pos-1;
				topSbjctOffset2=itr.key()+pos-1;
				topAlignType2=2;
			}
			else if(topScore2==maxScore){
				topCount2++;
			}
		}
	}

	if(topAlignType==3){

		//�ړI��frequency�Œe���ꂽ�V�[�h��PE�ɂ��~�ςȂ̂ł����Ȃ�seedLengthMax�𗘗p
		for(i=seedOffset, j=0; i<queryLen2-seedLengthMax&&j<seedIterate; i+=seedStep, j++){
			lb=0, ub=refLen-1;
			if(seedLengthMax>=bIdxWordSize){
				quint64 id=getId(c2tR2, queryLen2, i, bIdxWordSize);
				if(id==maxValue){
					continue;
				}
				if(!searchBounds(g2aBIdx, id, lb, ub)){
					continue;
				}
			}
			if(maxValue==(lb=lowerBound(g2aSeq, g2aSA, refLen, lb, ub, c2tR2, i, seedLengthMax))){
				continue;
			}
			ub=upperBound(g2aSeq, g2aSA, refLen, lb, ub, c2tR2, i, seedLengthMax);
			for(k=lb; k<=ub; k++){
				quint64 seedHitOffset=getInt(g2aSA, k);
				if(seedHitOffset<i){
					//���������ꏊ�͋ɒ[�ɋ�����
					continue;
				}
				quint64 candidateOffset=seedHitOffset-i;
				if(candidateOffset>topSbjctOffset-maxPEPairLen
					&&candidateOffset<topSbjctOffset+maxPEPairLen+topAlignLength)
				{
					hash[candidateOffset]++;
				}
			}
		}
		for(itr=hash.begin(); itr!=hash.end(); itr++){
			if(itr.value()<(int)minSeedHit){
				continue;
			}
			//�A���C�����g���{
			maxScore=0;
			maxPos=0;
			scoringArray[0]=0;
			for(pos=1, l=0, m=itr.key(); l<queryLen2&&m<refLen; pos++, l++, m++){
				quint8 sc=getChar(refSeq, m);
				quint8 qc=getChar(queryR2, l);
				qint64 score=scoringArray[pos-1]+g2aMatrix[sc][qc];
				if(score>0){
					scoringArray[pos]=score;
				}
				else{
					scoringArray[pos]=0;
				}
				if(score>maxScore){
					maxScore=score;
					maxPos=pos;
				}
			}
			//�X�R�A�]��
			if(maxScore<minAlnScore){
				continue;
			}
			else if(topScore2<maxScore){
				topScore2=maxScore;
				topCount2=1;
				pos=maxPos;
				while(scoringArray[pos-1]>0){
					pos--;
				}
				topAlignLength2=maxPos-pos+1;
				topQueryOffset2=pos-1;
				topSbjctOffset2=itr.key()+pos-1;
				topAlignType2=3;
			}
			else if(topScore2==maxScore){
				topCount2++;
			}
		}
	}

	if(topAlignType==4){

		//�ړI��frequency�Œe���ꂽ�V�[�h��PE�ɂ��~�ςȂ̂ł����Ȃ�seedLengthMax�𗘗p
		for(i=seedOffset, j=0; i<queryLen2-seedLengthMax&&j<seedIterate; i+=seedStep, j++){
			lb=0, ub=refLen-1;
			if(seedLengthMax>=bIdxWordSize){
				quint64 id=getId(g2aF2, queryLen2, i, bIdxWordSize);
				if(id==maxValue){
					continue;
				}
				if(!searchBounds(g2aBIdx, id, lb, ub)){
					continue;
				}
			}
			if(maxValue==(lb=lowerBound(g2aSeq, g2aSA, refLen, lb, ub, g2aF2, i, seedLengthMax))){
				continue;
			}
			ub=upperBound(g2aSeq, g2aSA, refLen, lb, ub, g2aF2, i, seedLengthMax);
			for(k=lb; k<=ub; k++){
				quint64 seedHitOffset=getInt(g2aSA, k);
				if(seedHitOffset<i){
					//���������ꏊ�͋ɒ[�ɋ�����
					continue;
				}
				quint64 candidateOffset=seedHitOffset-i;
				if(candidateOffset>topSbjctOffset-maxPEPairLen
					&&candidateOffset<topSbjctOffset+maxPEPairLen+topAlignLength)
				{
					hash[candidateOffset]++;
				}
			}
		}

		for(itr=hash.begin(); itr!=hash.end(); itr++){
			if(itr.value()<(int)minSeedHit){
				continue;
			}
			//�A���C�����g���{
			maxScore=0;
			maxPos=0;
			scoringArray[0]=0;
			for(pos=1, l=0, m=itr.key(); l<queryLen2&&m<refLen; pos++, l++, m++){
				quint8 sc=getChar(refSeq, m);
				quint8 qc=getChar(queryF2, l);
				qint64 score=scoringArray[pos-1]+g2aMatrix[sc][qc];
				if(score>0){
					scoringArray[pos]=score;
				}
				else{
					scoringArray[pos]=0;
				}
				if(score>maxScore){
					maxScore=score;
					maxPos=pos;
				}
			}
			//�X�R�A�]��
			if(maxScore<minAlnScore){
				continue;
			}
			else if(topScore2<maxScore){
				topScore2=maxScore;
				topCount2=1;
				pos=maxPos;
				while(scoringArray[pos-1]>0){
					pos--;
				}
				topAlignLength2=maxPos-pos+1;
				topQueryOffset2=pos-1;
				topSbjctOffset2=itr.key()+pos-1;
				topAlignType2=4;
			}
			else if(topScore2==maxScore){
				topCount2++;
			}
		}
	}

}

void BMapThread::limAlignWithBWT2(void){

	//query1�̃}�b�v���ʂ𗘗p����query2���ēx�}�b�v���邽�߂̊֐�
    quint64 i, j, k, l, m;
    quint64 lb, ub;
    qint64 maxScore=0;
    int pos;
    int maxPos;

    QHash<quint64, int> hash;
    QHash<quint64, int>::iterator itr;

	//�O��Ƃ���query1��unique�Ƀ}�b�v����Ă���K�v������
	if(topCount!=1){
		return;
	}

	if(topAlignType==1){

		//�ړI��frequency�Œe���ꂽ�V�[�h��PE�ɂ��~�ςȂ̂ł����Ȃ�seedLengthMax�𗘗p
		for(i=seedLength+seedOffset-1, j=0; i<queryLen2&&j<seedIterate; i+=seedStep, j++){
			if(i<seedLengthMax-1){
				continue;
			}
			if(seedLengthMax>bIdxWordSize){
				quint64 id=getId(c2tF2, queryLen2, i-bIdxWordSize+1, bIdxWordSize);
				if(id==maxValue){
					continue;
				}
				if(!searchBounds(c2tBIdx, id, lb, ub)){
					continue;
				}
				if(!BWTSearchA(c2tBKT, c2tBWT, c2tMCB, c2tF2, i-bIdxWordSize, seedLengthMax-bIdxWordSize, lb, ub)){
					continue;
				}
			}
			else if(seedLengthMax==bIdxWordSize){
				quint64 id=getId(c2tF2, queryLen2, i-bIdxWordSize+1, bIdxWordSize);
				if(id==maxValue){
					continue;
				}
				if(!searchBounds(c2tBIdx, id, lb, ub)){
					continue;
				}
			}
			else{
				if(!BWTSearch(c2tBKT, c2tBWT, c2tMCB, c2tF2, i, seedLengthMax, lb, ub)){
					continue;
				}
			}
			for(k=lb; k<=ub; k++){
				quint64 seedHitOffset=BWTPos(c2tSA, c2tBKT, c2tBWT, c2tMCB, k);
				if(seedHitOffset<i){
					//���������ꏊ�͋ɒ[�ɋ�����
					continue;
				}
				quint64 candidateOffset=seedHitOffset-i+seedLengthMax-1;
				if(candidateOffset>topSbjctOffset-maxPEPairLen
					&&candidateOffset<topSbjctOffset+maxPEPairLen+topAlignLength)
				{
					hash[candidateOffset]++;
				}
			}
		}

		for(itr=hash.begin(); itr!=hash.end(); itr++){
			if(itr.value()<(int)minSeedHit){
				continue;
			}
			//�A���C�����g���{
			qint64 maxScore=0;
			int maxPos=0;
			scoringArray[0]=0;
			for(pos=1, l=0, m=itr.key(); l<queryLen2&&m<refLen; pos++, l++, m++){
				quint8 sc=getChar(refSeq, m);
				quint8 qc=getChar(queryF2, l);
				qint64 score=scoringArray[pos-1]+c2tMatrix[sc][qc];
				if(score>0){
					scoringArray[pos]=score;
				}
				else{
					scoringArray[pos]=0;
				}
				if(score>maxScore){
					maxScore=score;
					maxPos=pos;
				}
			}
			//�X�R�A�]��
			if(maxScore<minAlnScore){
				continue;
			}
			else if(topScore2<maxScore){
				topScore2=maxScore;
				topCount2=1;
				pos=maxPos;
				while(scoringArray[pos-1]>0){
					pos--;
				}
				topAlignLength2=maxPos-pos+1;
				topQueryOffset2=pos-1;
				topSbjctOffset2=itr.key()+pos-1;
				topAlignType2=1;
			}
			else if(topScore2==maxScore){
				topCount2++;
			}
		}
	}

	else if(topAlignType==2){

		//�ړI��frequency�Œe���ꂽ�V�[�h��PE�ɂ��~�ςȂ̂ł����Ȃ�seedLengthMax�𗘗p
		for(i=seedLength+seedOffset-1, j=0; i<queryLen2&&j<seedIterate; i+=seedStep, j++){
			if(i<seedLengthMax-1){
				continue;
			}
			if(seedLengthMax>bIdxWordSize){
				quint64 id=getId(g2aR2, queryLen2, i-bIdxWordSize+1, bIdxWordSize);
				if(id==maxValue){
					continue;
				}
				if(!searchBounds(c2tBIdx, id, lb, ub)){
					continue;
				}
				if(!BWTSearchA(c2tBKT, c2tBWT, c2tMCB, g2aR2, i-bIdxWordSize, seedLengthMax-bIdxWordSize, lb, ub)){
					continue;
				}
			}
			else if(seedLengthMax==bIdxWordSize){
				quint64 id=getId(g2aR2, queryLen2, i-bIdxWordSize+1, bIdxWordSize);
				if(id==maxValue){
					continue;
				}
				if(!searchBounds(c2tBIdx, id, lb, ub)){
					continue;
				}
			}
			else{
				if(!BWTSearch(c2tBKT, c2tBWT, c2tMCB, g2aR2, i, seedLengthMax, lb, ub)){
					continue;
				}
			}
			for(k=lb; k<=ub; k++){
				quint64 seedHitOffset=BWTPos(c2tSA, c2tBKT, c2tBWT, c2tMCB, k);
				if(seedHitOffset<i){
					//���������ꏊ�͋ɒ[�ɋ�����
					continue;
				}
				quint64 candidateOffset=seedHitOffset-i+seedLengthMax-1;
				if(candidateOffset>topSbjctOffset-maxPEPairLen
					&&candidateOffset<topSbjctOffset+maxPEPairLen+topAlignLength)
				{
					hash[candidateOffset]++;
				}
			}
		}

		for(itr=hash.begin(); itr!=hash.end(); itr++){
			if(itr.value()<(int)minSeedHit){
				continue;
			}
			//�A���C�����g���{
			maxScore=0;
			maxPos=0;
			scoringArray[0]=0;
			for(pos=1, l=0, m=itr.key(); l<queryLen2&&m<refLen; pos++, l++, m++){
				quint8 sc=getChar(refSeq, m);
				quint8 qc=getChar(queryR2, l);
				qint64 score=scoringArray[pos-1]+c2tMatrix[sc][qc];
				if(score>0){
					scoringArray[pos]=score;
				}
				else{
					scoringArray[pos]=0;
				}
				if(score>maxScore){
					maxScore=score;
					maxPos=pos;
				}
			}
			//�X�R�A�]��
			if(maxScore<minAlnScore){
				continue;
			}
			else if(topScore2<maxScore){
				topScore2=maxScore;
				topCount2=1;
				pos=maxPos;
				while(scoringArray[pos-1]>0){
					pos--;
				}
				topAlignLength2=maxPos-pos+1;
				topQueryOffset2=pos-1;
				topSbjctOffset2=itr.key()+pos-1;
				topAlignType2=2;
			}
			else if(topScore2==maxScore){
				topCount2++;
			}
		}
	}

	if(topAlignType==3){

		//�ړI��frequency�Œe���ꂽ�V�[�h��PE�ɂ��~�ςȂ̂ł����Ȃ�seedLengthMax�𗘗p
		for(i=seedLength+seedOffset-1, j=0; i<queryLen2&&j<seedIterate; i+=seedStep, j++){
			if(i<seedLengthMax-1){
				continue;
			}
			if(seedLengthMax>bIdxWordSize){
				quint64 id=getId(c2tR2, queryLen2, i-bIdxWordSize+1, bIdxWordSize);
				if(id==maxValue){
					continue;
				}
				if(!searchBounds(g2aBIdx, id, lb, ub)){
					continue;
				}
				if(!BWTSearchA(g2aBKT, g2aBWT, g2aMCB, c2tR2, i-bIdxWordSize, seedLengthMax-bIdxWordSize, lb, ub)){
					continue;
				}
			}
			else if(seedLengthMax==bIdxWordSize){
				quint64 id=getId(c2tR2, queryLen2, i-bIdxWordSize+1, bIdxWordSize);
				if(id==maxValue){
					continue;
				}
				if(!searchBounds(g2aBIdx, id, lb, ub)){
					continue;
				}
			}
			else{
				if(!BWTSearch(g2aBKT, g2aBWT, g2aMCB, c2tR2, i, seedLengthMax, lb, ub)){
					continue;
				}
			}
			for(k=lb; k<=ub; k++){
				quint64 seedHitOffset=BWTPos(g2aSA, g2aBKT, g2aBWT, g2aMCB, k);
				if(seedHitOffset<i){
					//���������ꏊ�͋ɒ[�ɋ�����
					continue;
				}
				quint64 candidateOffset=seedHitOffset-i+seedLengthMax-1;
				if(candidateOffset>topSbjctOffset-maxPEPairLen
					&&candidateOffset<topSbjctOffset+maxPEPairLen+topAlignLength)
				{
					hash[candidateOffset]++;
				}
			}
		}

		for(itr=hash.begin(); itr!=hash.end(); itr++){
			if(itr.value()<(int)minSeedHit){
				continue;
			}
			//�A���C�����g���{
			maxScore=0;
			maxPos=0;
			scoringArray[0]=0;
			for(pos=1, l=0, m=itr.key(); l<queryLen2&&m<refLen; pos++, l++, m++){
				quint8 sc=getChar(refSeq, m);
				quint8 qc=getChar(queryR2, l);
				qint64 score=scoringArray[pos-1]+g2aMatrix[sc][qc];
				if(score>0){
					scoringArray[pos]=score;
				}
				else{
					scoringArray[pos]=0;
				}
				if(score>maxScore){
					maxScore=score;
					maxPos=pos;
				}
			}
			//�X�R�A�]��
			if(maxScore<minAlnScore){
				continue;
			}
			else if(topScore2<maxScore){
				topScore2=maxScore;
				topCount2=1;
				pos=maxPos;
				while(scoringArray[pos-1]>0){
					pos--;
				}
				topAlignLength2=maxPos-pos+1;
				topQueryOffset2=pos-1;
				topSbjctOffset2=itr.key()+pos-1;
				topAlignType2=3;
			}
			else if(topScore2==maxScore){
				topCount2++;
			}
		}
	}

	if(topAlignType==4){

		//�ړI��frequency�Œe���ꂽ�V�[�h��PE�ɂ��~�ςȂ̂ł����Ȃ�seedLengthMax�𗘗p
		for(i=seedLength+seedOffset-1, j=0; i<queryLen2&&j<seedIterate; i+=seedStep, j++){
			if(i<seedLengthMax-1){
				continue;
			}
			if(seedLengthMax>bIdxWordSize){
				quint64 id=getId(g2aF2, queryLen2, i-bIdxWordSize+1, bIdxWordSize);
				if(id==maxValue){
					continue;
				}
				if(!searchBounds(g2aBIdx, id, lb, ub)){
					continue;
				}
				if(!BWTSearchA(g2aBKT, g2aBWT, g2aMCB, g2aF2, i-bIdxWordSize, seedLengthMax-bIdxWordSize, lb, ub)){
					continue;
				}
			}
			else if(seedLengthMax==bIdxWordSize){
				quint64 id=getId(g2aF2, queryLen2, i-bIdxWordSize+1, bIdxWordSize);
				if(id==maxValue){
					continue;
				}
				if(!searchBounds(g2aBIdx, id, lb, ub)){
					continue;
				}
			}
			else{
				if(!BWTSearch(g2aBKT, g2aBWT, g2aMCB, g2aF2, i, seedLengthMax, lb, ub)){
					continue;
				}
			}
			for(k=lb; k<=ub; k++){
				quint64 seedHitOffset=BWTPos(g2aSA, g2aBKT, g2aBWT, g2aMCB, k);
				if(seedHitOffset<i){
					//���������ꏊ�͋ɒ[�ɋ�����
					continue;
				}
				quint64 candidateOffset=seedHitOffset-i+seedLengthMax-1;
				if(candidateOffset>topSbjctOffset-maxPEPairLen
					&&candidateOffset<topSbjctOffset+maxPEPairLen+topAlignLength)
				{
					hash[candidateOffset]++;
				}
			}
		}

		for(itr=hash.begin(); itr!=hash.end(); itr++){
			if(itr.value()<(int)minSeedHit){
				continue;
			}
			//�A���C�����g���{
			maxScore=0;
			maxPos=0;
			scoringArray[0]=0;
			for(pos=1, l=0, m=itr.key(); l<queryLen2&&m<refLen; pos++, l++, m++){
				quint8 sc=getChar(refSeq, m);
				quint8 qc=getChar(queryF2, l);
				qint64 score=scoringArray[pos-1]+g2aMatrix[sc][qc];
				if(score>0){
					scoringArray[pos]=score;
				}
				else{
					scoringArray[pos]=0;
				}
				if(score>maxScore){
					maxScore=score;
					maxPos=pos;
				}
			}
			//�X�R�A�]��
			if(maxScore<minAlnScore){
				continue;
			}
			else if(topScore2<maxScore){
				topScore2=maxScore;
				topCount2=1;
				pos=maxPos;
				while(scoringArray[pos-1]>0){
					pos--;
				}
				topAlignLength2=maxPos-pos+1;
				topQueryOffset2=pos-1;
				topSbjctOffset2=itr.key()+pos-1;
				topAlignType2=4;
			}
			else if(topScore2==maxScore){
				topCount2++;
			}
		}
	}

}

void BMapThread::alignWithBWT(void){

    topScore=0;
    topCount=0;

    quint64 i, j, k, l, m;
    quint64 lb, ub;
    qint64 maxScore=0;
    int pos;
    int maxPos;

    QHash<quint64, int> hash;
    QHash<quint64, int>::iterator itr;

    //C2T�ϊ������N�G���[�𓖂Ă�i�����ڂ��̂܂�C2T�jtopAlignType=1
    for(i=seedLength+seedOffset-1, j=0; i<queryLen&&j<seedIterate; i+=seedStep, j++){
        if(i<seedLength-1){
            continue;
        }
        if(seedLength>bIdxWordSize){
            quint64 id=getId(c2tF, queryLen, i-bIdxWordSize+1, bIdxWordSize);
			if(id==maxValue){
				continue;
			}
            if(!searchBounds(c2tBIdx, id, lb, ub)){
                continue;
            }
            if(!BWTSearchA(c2tBKT, c2tBWT, c2tMCB, c2tF, i-bIdxWordSize, seedLength-bIdxWordSize, lb, ub)){
                continue;
            }
        }
        else if(seedLength==bIdxWordSize){
            quint64 id=getId(c2tF, queryLen, i-bIdxWordSize+1, bIdxWordSize);
			if(id==maxValue){
				continue;
			}
            if(!searchBounds(c2tBIdx, id, lb, ub)){
                continue;
            }
        }
        else{
            if(!BWTSearch(c2tBKT, c2tBWT, c2tMCB, c2tF, i, seedLength, lb, ub)){
                continue;
            }
        }

        l=seedLength;
        //adaptive seed
        if(seedFreqMax>0&&ub-lb+1>seedFreqMax){
            l++;
            while(l<=seedLengthMax){
                //seed�͈̔̓`�F�b�N
                if(i+1<=l){
                    break;
                }
                if(!BWTSearchE(c2tBKT, c2tBWT, c2tMCB, c2tF, i, l, lb, ub)){
                    break;
                }

                if((ub-lb+1<=seedFreqMax)){
                    break;
                }

                l++;
            }

            if(ub-lb+1>seedFreqMax){
                continue;
            }
        }

        for(k=lb; k<=ub; k++){
            quint64 seedHitOffset=BWTPos(c2tSA, c2tBKT, c2tBWT, c2tMCB, k);
            if(seedHitOffset<i){
                //���������ꏊ�͋ɒ[�ɋ�����
                continue;
            }
            quint64 candidateOffset=seedHitOffset-i+l-1;
            hash[candidateOffset]++;
        }

    }

    for(itr=hash.begin(); itr!=hash.end(); itr++){
        if(itr.value()<(int)minSeedHit){
            continue;
        }
        //�A���C�����g���{
        qint64 maxScore=0;
        int maxPos=0;
        scoringArray[0]=0;
        for(pos=1, l=0, m=itr.key(); l<queryLen&&m<refLen; pos++, l++, m++){
            quint8 sc=getChar(refSeq, m);
            quint8 qc=getChar(queryF, l);
            qint64 score=scoringArray[pos-1]+c2tMatrix[sc][qc];
            if(score>0){
                scoringArray[pos]=score;
            }
            else{
                scoringArray[pos]=0;
            }
            if(score>maxScore){
                maxScore=score;
                maxPos=pos;
            }
        }
        //�X�R�A�]��
        if(maxScore<minAlnScore){
            continue;
        }
        else if(topScore<maxScore){
            topScore=maxScore;
            topCount=1;
            pos=maxPos;
            while(scoringArray[pos-1]>0){
                pos--;
            }
            topAlignLength=maxPos-pos+1;
            topQueryOffset=pos-1;
            topSbjctOffset=itr.key()+pos-1;
            topAlignType=1;
        }
        else if(topScore==maxScore){
            topCount++;
        }
    }

    //G2A�ϊ������N�G���[�̑��⍽�𓖂Ă�i�����ڂ�C2T���jtopAlignType=2
    hash.clear();
    for(i=seedLength+seedOffset-1, j=0; i<queryLen&&j<seedIterate; i+=seedStep, j++){
        if(i<seedLength-1){
            continue;
        }
        if(seedLength>bIdxWordSize){
            quint64 id=getId(g2aR, queryLen, i-bIdxWordSize+1, bIdxWordSize);
			if(id==maxValue){
				continue;
			}
            if(!searchBounds(c2tBIdx, id, lb, ub)){
                continue;
            }
            if(!BWTSearchA(c2tBKT, c2tBWT, c2tMCB, g2aR, i-bIdxWordSize, seedLength-bIdxWordSize, lb, ub)){
                continue;
            }
        }
        else if(seedLength==bIdxWordSize){
            quint64 id=getId(g2aR, queryLen, i-bIdxWordSize+1, bIdxWordSize);
			if(id==maxValue){
				continue;
			}
            if(!searchBounds(c2tBIdx, id, lb, ub)){
                continue;
            }
        }
        else{
            if(!BWTSearch(c2tBKT, c2tBWT, c2tMCB, g2aR, i, seedLength, lb, ub)){
                continue;
            }
        }

        l=seedLength;
        //adaptive seed
        if(seedFreqMax>0&&ub-lb+1>seedFreqMax){
            l++;
            while(l<=seedLengthMax){
                //seed�͈̔̓`�F�b�N
                if(i+1<=l){
                    break;
                }
                if(!BWTSearchE(c2tBKT, c2tBWT, c2tMCB, g2aR, i, l, lb, ub)){
                    break;
                }

                if((ub-lb+1<=seedFreqMax)){
                    break;
                }

                l++;
            }

            if(ub-lb+1>seedFreqMax){
                continue;
            }
        }

        for(k=lb; k<=ub; k++){
			quint64 seedHitOffset=BWTPos(c2tSA, c2tBKT, c2tBWT, c2tMCB, k);
            if(seedHitOffset<i){
                //���������ꏊ�͋ɒ[�ɋ�����
                continue;
            }
            quint64 candidateOffset=seedHitOffset-i+l-1;
            hash[candidateOffset]++;
        }

    }

    for(itr=hash.begin(); itr!=hash.end(); itr++){
        if(itr.value()<(int)minSeedHit){
            continue;
        }
        //�A���C�����g���{
        maxScore=0;
        maxPos=0;
        scoringArray[0]=0;
        for(pos=1, l=0, m=itr.key(); l<queryLen&&m<refLen; pos++, l++, m++){
            quint8 sc=getChar(refSeq, m);
            quint8 qc=getChar(queryR, l);
            qint64 score=scoringArray[pos-1]+c2tMatrix[sc][qc];
            if(score>0){
                scoringArray[pos]=score;
            }
            else{
                scoringArray[pos]=0;
            }
            if(score>maxScore){
                maxScore=score;
                maxPos=pos;
            }
        }
        //�X�R�A�]��
        if(maxScore<minAlnScore){
            continue;
        }
        else if(topScore<maxScore){
            topScore=maxScore;
            topCount=1;
            pos=maxPos;
            while(scoringArray[pos-1]>0){
                pos--;
            }
            topAlignLength=maxPos-pos+1;
            topQueryOffset=pos-1;
            topSbjctOffset=itr.key()+pos-1;
            topAlignType=2;
        }
        else if(topScore==maxScore){
            topCount++;
        }
    }

    //C2T�ϊ������N�G���[�̑��⍽�𓖂Ă�i�����ڂ�G2A���jtopAlignType=3
    hash.clear();
    for(i=seedLength+seedOffset-1, j=0; i<queryLen&&j<seedIterate; i+=seedStep, j++){
        if(i<seedLength-1){
            continue;
        }
        if(seedLength>bIdxWordSize){
            quint64 id=getId(c2tR, queryLen, i-bIdxWordSize+1, bIdxWordSize);
			if(id==maxValue){
				continue;
			}
            if(!searchBounds(g2aBIdx, id, lb, ub)){
                continue;
            }
            if(!BWTSearchA(g2aBKT, g2aBWT, g2aMCB, c2tR, i-bIdxWordSize, seedLength-bIdxWordSize, lb, ub)){
                continue;
            }
        }
        else if(seedLength==bIdxWordSize){
            quint64 id=getId(c2tR, queryLen, i-bIdxWordSize+1, bIdxWordSize);
			if(id==maxValue){
				continue;
			}
            if(!searchBounds(g2aBIdx, id, lb, ub)){
                continue;
            }
        }
        else{
            if(!BWTSearch(g2aBKT, g2aBWT, g2aMCB, c2tR, i, seedLength, lb, ub)){
                continue;
            }
        }

        l=seedLength;
        //adaptive seed
        if(seedFreqMax>0&&ub-lb+1>seedFreqMax){
            l++;
            while(l<=seedLengthMax){
                //seed�͈̔̓`�F�b�N
                if(i+1<=l){
                    break;
                }
                if(!BWTSearchE(g2aBKT, g2aBWT, g2aMCB, c2tR, i, l, lb, ub)){
                    break;
                }

                if((ub-lb+1<=seedFreqMax)){
                    break;
                }

                l++;
            }

            if(ub-lb+1>seedFreqMax){
                continue;
            }
        }

        for(k=lb; k<=ub; k++){
            quint64 seedHitOffset=BWTPos(g2aSA, g2aBKT, g2aBWT, g2aMCB, k);
            if(seedHitOffset<i){
                //���������ꏊ�͋ɒ[�ɋ�����
                continue;
            }
            quint64 candidateOffset=seedHitOffset-i+l-1;
            hash[candidateOffset]++;
        }

	}

    for(itr=hash.begin(); itr!=hash.end(); itr++){
        if(itr.value()<(int)minSeedHit){
            continue;
        }
        //�A���C�����g���{
        maxScore=0;
        maxPos=0;
        scoringArray[0]=0;
        for(pos=1, l=0, m=itr.key(); l<queryLen&&m<refLen; pos++, l++, m++){
            quint8 sc=getChar(refSeq, m);
            quint8 qc=getChar(queryR, l);
            qint64 score=scoringArray[pos-1]+g2aMatrix[sc][qc];
            if(score>0){
                scoringArray[pos]=score;
            }
            else{
                scoringArray[pos]=0;
            }
            if(score>maxScore){
                maxScore=score;
                maxPos=pos;
            }
        }
        //�X�R�A�]��
        if(maxScore<minAlnScore){
            continue;
        }
        else if(topScore<maxScore){
            topScore=maxScore;
            topCount=1;
            pos=maxPos;
            while(scoringArray[pos-1]>0){
                pos--;
            }
            topAlignLength=maxPos-pos+1;
            topQueryOffset=pos-1;
            topSbjctOffset=itr.key()+pos-1;
            topAlignType=3;
        }
        else if(topScore==maxScore){
            topCount++;
        }
    }

    //G2A�ϊ������N�G���[�𓖂Ă�i�����ڂ�G2A���jtopAlignType=4
    hash.clear();
    for(i=seedLength+seedOffset-1, j=0; i<queryLen&&j<seedIterate; i+=seedStep, j++){
        if(i<seedLength-1){
            continue;
        }
        if(seedLength>bIdxWordSize){
            quint64 id=getId(g2aF, queryLen, i-bIdxWordSize+1, bIdxWordSize);
			if(id==maxValue){
				continue;
			}
            if(!searchBounds(g2aBIdx, id, lb, ub)){
                continue;
            }
            if(!BWTSearchA(g2aBKT, g2aBWT, g2aMCB, g2aF, i-bIdxWordSize, seedLength-bIdxWordSize, lb, ub)){
                continue;
            }
        }
        else if(seedLength==bIdxWordSize){
            quint64 id=getId(g2aF, queryLen, i-bIdxWordSize+1, bIdxWordSize);
			if(id==maxValue){
				continue;
			}
            if(!searchBounds(g2aBIdx, id, lb, ub)){
                continue;
            }
        }
        else{
            if(!BWTSearch(g2aBKT, g2aBWT, g2aMCB, g2aF, i, seedLength, lb, ub)){
                continue;
            }
        }

        l=seedLength;
        //adaptive seed
        if(seedFreqMax>0&&ub-lb+1>seedFreqMax){
            l++;
            while(l<=seedLengthMax){
                //seed�͈̔̓`�F�b�N
                if(i+1<=l){
                    break;
                }
                if(!BWTSearchE(g2aBKT, g2aBWT, g2aMCB, g2aF, i, l, lb, ub)){
                    break;
                }

                if((ub-lb+1<=seedFreqMax)){
                    break;
                }

                l++;
            }

            if(ub-lb+1>seedFreqMax){
                continue;
            }
        }

        for(k=lb; k<=ub; k++){
            quint64 seedHitOffset=BWTPos(g2aSA, g2aBKT, g2aBWT, g2aMCB, k);
            if(seedHitOffset<i){
                //���������ꏊ�͋ɒ[�ɋ�����
                continue;
            }
            quint64 candidateOffset=seedHitOffset-i+l-1;
            hash[candidateOffset]++;
        }

    }

    for(itr=hash.begin(); itr!=hash.end(); itr++){
        if(itr.value()<(int)minSeedHit){
            continue;
        }
        //�A���C�����g���{
        maxScore=0;
        maxPos=0;
        scoringArray[0]=0;
        for(pos=1, l=0, m=itr.key(); l<queryLen&&m<refLen; pos++, l++, m++){
            quint8 sc=getChar(refSeq, m);
            quint8 qc=getChar(queryF, l);
            qint64 score=scoringArray[pos-1]+g2aMatrix[sc][qc];
            if(score>0){
                scoringArray[pos]=score;
            }
            else{
                scoringArray[pos]=0;
            }
            if(score>maxScore){
                maxScore=score;
                maxPos=pos;
            }
        }
        //�X�R�A�]��
        if(maxScore<minAlnScore){
            continue;
        }
        else if(topScore<maxScore){
            topScore=maxScore;
            topCount=1;
            pos=maxPos;
            while(scoringArray[pos-1]>0){
                pos--;
            }
            topAlignLength=maxPos-pos+1;
            topQueryOffset=pos-1;
            topSbjctOffset=itr.key()+pos-1;
            topAlignType=4;
        }
        else if(topScore==maxScore){
            topCount++;
        }
    }

}

void BMapThread::alignWithBWT2(void){

    topScore2=0;
    topCount2=0;

    quint64 i, j, k, l, m;
    quint64 lb, ub;
    qint64 maxScore=0;
    int pos;
    int maxPos;

    QHash<quint64, int> hash;
    QHash<quint64, int>::iterator itr;

    //C2T�ϊ������N�G���[�𓖂Ă�i�����ڂ��̂܂�C2T�jtopAlignType=1
    for(i=seedLength+seedOffset-1, j=0; i<queryLen2&&j<seedIterate; i+=seedStep, j++){
        if(i<seedLength-1){
            continue;
        }
        if(seedLength>bIdxWordSize){
            quint64 id=getId(c2tF2, queryLen2, i-bIdxWordSize+1, bIdxWordSize);
			if(id==maxValue){
				continue;
			}
            if(!searchBounds(c2tBIdx, id, lb, ub)){
                continue;
            }
            if(!BWTSearchA(c2tBKT, c2tBWT, c2tMCB, c2tF2, i-bIdxWordSize, seedLength-bIdxWordSize, lb, ub)){
                continue;
            }
        }
        else if(seedLength==bIdxWordSize){
            quint64 id=getId(c2tF2, queryLen2, i-bIdxWordSize+1, bIdxWordSize);
			if(id==maxValue){
				continue;
			}
            if(!searchBounds(c2tBIdx, id, lb, ub)){
                continue;
            }
        }
        else{
            if(!BWTSearch(c2tBKT, c2tBWT, c2tMCB, c2tF2, i, seedLength, lb, ub)){
                continue;
            }
        }
        l=seedLength;
        //adaptive seed
        if(seedFreqMax>0&&ub-lb+1>seedFreqMax){
            l++;
            while(l<=seedLengthMax){
                //seed�͈̔̓`�F�b�N
                if(i+1<=l){
                    break;
                }
                if(!BWTSearchE(c2tBKT, c2tBWT, c2tMCB, c2tF2, i, l, lb, ub)){
                    break;
                }
                if((ub-lb+1<=seedFreqMax)){
                    break;
                }
                l++;
            }
            if(ub-lb+1>seedFreqMax){
                continue;
            }
        }

        for(k=lb; k<=ub; k++){
            quint64 seedHitOffset=BWTPos(c2tSA, c2tBKT, c2tBWT, c2tMCB, k);
            if(seedHitOffset<i){
                //���������ꏊ�͋ɒ[�ɋ�����
                continue;
            }
            quint64 candidateOffset=seedHitOffset-i+l-1;
            hash[candidateOffset]++;
        }

    }

    for(itr=hash.begin(); itr!=hash.end(); itr++){
        if(itr.value()<(int)minSeedHit){
            continue;
        }
        //�A���C�����g���{
        qint64 maxScore=0;
        int maxPos=0;
        scoringArray[0]=0;
        for(pos=1, l=0, m=itr.key(); l<queryLen2&&m<refLen; pos++, l++, m++){
            quint8 sc=getChar(refSeq, m);
            quint8 qc=getChar(queryF2, l);
            qint64 score=scoringArray[pos-1]+c2tMatrix[sc][qc];
            if(score>0){
                scoringArray[pos]=score;
            }
            else{
                scoringArray[pos]=0;
            }
            if(score>maxScore){
                maxScore=score;
                maxPos=pos;
            }
        }
        //�X�R�A�]��
        if(maxScore<minAlnScore){
            continue;
        }
        else if(topScore2<maxScore){
            topScore2=maxScore;
            topCount2=1;
            pos=maxPos;
            while(scoringArray[pos-1]>0){
                pos--;
            }
            topAlignLength2=maxPos-pos+1;
            topQueryOffset2=pos-1;
            topSbjctOffset2=itr.key()+pos-1;
            topAlignType2=1;
        }
        else if(topScore2==maxScore){
            topCount2++;
        }
    }

    //G2A�ϊ������N�G���[�̑��⍽�𓖂Ă�i�����ڂ�C2T���jtopAlignType=2
    hash.clear();
    for(i=seedLength+seedOffset-1, j=0; i<queryLen2&&j<seedIterate; i+=seedStep, j++){
        if(i<seedLength-1){
            continue;
        }
        if(seedLength>bIdxWordSize){
            quint64 id=getId(g2aR2, queryLen2, i-bIdxWordSize+1, bIdxWordSize);
			if(id==maxValue){
				continue;
			}
            if(!searchBounds(c2tBIdx, id, lb, ub)){
                continue;
            }
            if(!BWTSearchA(c2tBKT, c2tBWT, c2tMCB, g2aR2, i-bIdxWordSize, seedLength-bIdxWordSize, lb, ub)){
                continue;
            }
        }
        else if(seedLength==bIdxWordSize){
            quint64 id=getId(g2aR2, queryLen2, i-bIdxWordSize+1, bIdxWordSize);
			if(id==maxValue){
				continue;
			}
            if(!searchBounds(c2tBIdx, id, lb, ub)){
                continue;
            }
        }
        else{
            if(!BWTSearch(c2tBKT, c2tBWT, c2tMCB, g2aR2, i, seedLength, lb, ub)){
                continue;
            }
        }
        l=seedLength;
        //adaptive seed
        if(seedFreqMax>0&&ub-lb+1>seedFreqMax){
            l++;
            while(l<=seedLengthMax){
                //seed�͈̔̓`�F�b�N
                if(i+1<=l){
                    break;
                }
                if(!BWTSearchE(c2tBKT, c2tBWT, c2tMCB, g2aR2, i, l, lb, ub)){
                    break;
                }
                if((ub-lb+1<=seedFreqMax)){
                    break;
                }
                l++;
            }
            if(ub-lb+1>seedFreqMax){
                continue;
            }
        }

        for(k=lb; k<=ub; k++){
            quint64 seedHitOffset=BWTPos(c2tSA, c2tBKT, c2tBWT, c2tMCB, k);
            if(seedHitOffset<i){
                //���������ꏊ�͋ɒ[�ɋ�����
                continue;
            }
            quint64 candidateOffset=seedHitOffset-i+l-1;
            hash[candidateOffset]++;
        }

    }

    for(itr=hash.begin(); itr!=hash.end(); itr++){
        if(itr.value()<(int)minSeedHit){
            continue;
        }
        //�A���C�����g���{
        maxScore=0;
        maxPos=0;
        scoringArray[0]=0;
        for(pos=1, l=0, m=itr.key(); l<queryLen2&&m<refLen; pos++, l++, m++){
            quint8 sc=getChar(refSeq, m);
            quint8 qc=getChar(queryR2, l);
            qint64 score=scoringArray[pos-1]+c2tMatrix[sc][qc];
            if(score>0){
                scoringArray[pos]=score;
            }
            else{
                scoringArray[pos]=0;
            }
            if(score>maxScore){
                maxScore=score;
                maxPos=pos;
            }
        }
        //�X�R�A�]��
        if(maxScore<minAlnScore){
            continue;
        }
        else if(topScore2<maxScore){
            topScore2=maxScore;
            topCount2=1;
            pos=maxPos;
            while(scoringArray[pos-1]>0){
                pos--;
            }
            topAlignLength2=maxPos-pos+1;
            topQueryOffset2=pos-1;
            topSbjctOffset2=itr.key()+pos-1;
            topAlignType2=2;
        }
        else if(topScore2==maxScore){
            topCount2++;
        }
    }

    ////C2T�ϊ������N�G���[�̑��⍽�𓖂Ă�i�����ڂ�G2A���jtopAlignType=3
    hash.clear();
    for(i=seedLength+seedOffset-1, j=0; i<queryLen2&&j<seedIterate; i+=seedStep, j++){
        if(i<seedLength-1){
            continue;
        }
        if(seedLength>bIdxWordSize){
            quint64 id=getId(c2tR2, queryLen2, i-bIdxWordSize+1, bIdxWordSize);
			if(id==maxValue){
				continue;
			}
            if(!searchBounds(g2aBIdx, id, lb, ub)){
                continue;
            }
            if(!BWTSearchA(g2aBKT, g2aBWT, g2aMCB, c2tR2, i-bIdxWordSize, seedLength-bIdxWordSize, lb, ub)){
                continue;
            }
        }
        else if(seedLength==bIdxWordSize){
            quint64 id=getId(c2tR2, queryLen2, i-bIdxWordSize+1, bIdxWordSize);
			if(id==maxValue){
				continue;
			}
            if(!searchBounds(g2aBIdx, id, lb, ub)){
                continue;
            }
        }
        else{
            if(!BWTSearch(g2aBKT, g2aBWT, g2aMCB, c2tR2, i, seedLength, lb, ub)){
                continue;
            }
        }
        l=seedLength;
        //adaptive seed
        if(seedFreqMax>0&&ub-lb+1>seedFreqMax){
            l++;
            while(l<=seedLengthMax){
                //seed�͈̔̓`�F�b�N
                if(i+1<=l){
                    break;
                }
                if(!BWTSearchE(g2aBKT, g2aBWT, g2aMCB, c2tR2, i, l, lb, ub)){
                    break;
                }
                if((ub-lb+1<=seedFreqMax)){
                    break;
                }
                l++;
            }
            if(ub-lb+1>seedFreqMax){
                continue;
            }
        }

        for(k=lb; k<=ub; k++){
            quint64 seedHitOffset=BWTPos(g2aSA, g2aBKT, g2aBWT, g2aMCB, k);
            if(seedHitOffset<i){
                //���������ꏊ�͋ɒ[�ɋ�����
                continue;
            }
            quint64 candidateOffset=seedHitOffset-i+l-1;
            hash[candidateOffset]++;
        }

    }

    for(itr=hash.begin(); itr!=hash.end(); itr++){
        if(itr.value()<(int)minSeedHit){
            continue;
        }
        //�A���C�����g���{
        maxScore=0;
        maxPos=0;
        scoringArray[0]=0;
        for(pos=1, l=0, m=itr.key(); l<queryLen2&&m<refLen; pos++, l++, m++){
            quint8 sc=getChar(refSeq, m);
            quint8 qc=getChar(queryR2, l);
            qint64 score=scoringArray[pos-1]+g2aMatrix[sc][qc];
            if(score>0){
                scoringArray[pos]=score;
            }
            else{
                scoringArray[pos]=0;
            }
            if(score>maxScore){
                maxScore=score;
                maxPos=pos;
            }
        }
        //�X�R�A�]��
        if(maxScore<minAlnScore){
            continue;
        }
        else if(topScore2<maxScore){
            topScore2=maxScore;
            topCount2=1;
            pos=maxPos;
            while(scoringArray[pos-1]>0){
                pos--;
            }
            topAlignLength2=maxPos-pos+1;
            topQueryOffset2=pos-1;
            topSbjctOffset2=itr.key()+pos-1;
            topAlignType2=3;
        }
        else if(topScore2==maxScore){
            topCount2++;
        }
    }

    //G2A�ϊ������N�G���[�𓖂Ă�i�����ڂ�G2A���jtopAlignType=4
    hash.clear();
    for(i=seedLength+seedOffset-1, j=0; i<queryLen2&&j<seedIterate; i+=seedStep, j++){
        if(i<seedLength-1){
            continue;
        }
        if(seedLength>bIdxWordSize){
            quint64 id=getId(g2aF2, queryLen2, i-bIdxWordSize+1, bIdxWordSize);
			if(id==maxValue){
				continue;
			}
            if(!searchBounds(g2aBIdx, id, lb, ub)){
                continue;
            }
            if(!BWTSearchA(g2aBKT, g2aBWT, g2aMCB, g2aF2, i-bIdxWordSize, seedLength-bIdxWordSize, lb, ub)){
                continue;
            }
        }
        else if(seedLength==bIdxWordSize){
            quint64 id=getId(g2aF2, queryLen2, i-bIdxWordSize+1, bIdxWordSize);
			if(id==maxValue){
				continue;
			}
            if(!searchBounds(g2aBIdx, id, lb, ub)){
                continue;
            }
        }
        else{
            if(!BWTSearch(g2aBKT, g2aBWT, g2aMCB, g2aF2, i, seedLength, lb, ub)){
                continue;
            }
        }
        l=seedLength;
        //adaptive seed
        if(seedFreqMax>0&&ub-lb+1>seedFreqMax){
            l++;
            while(l<=seedLengthMax){
                //seed�͈̔̓`�F�b�N
                if(i+1<=l){
                    break;
                }
                if(!BWTSearchE(g2aBKT, g2aBWT, g2aMCB, g2aF2, i, l, lb, ub)){
                    break;
                }
                if((ub-lb+1<=seedFreqMax)){
                    break;
                }
                l++;
            }
            if(ub-lb+1>seedFreqMax){
                continue;
            }
        }

        for(k=lb; k<=ub; k++){
            quint64 seedHitOffset=BWTPos(g2aSA, g2aBKT, g2aBWT, g2aMCB, k);
            if(seedHitOffset<i){
                //���������ꏊ�͋ɒ[�ɋ�����
                continue;
            }
            quint64 candidateOffset=seedHitOffset-i+l-1;
            hash[candidateOffset]++;
        }

	}

    for(itr=hash.begin(); itr!=hash.end(); itr++){
        if(itr.value()<(int)minSeedHit){
            continue;
        }
        //�A���C�����g���{
        maxScore=0;
        maxPos=0;
        scoringArray[0]=0;
        for(pos=1, l=0, m=itr.key(); l<queryLen2&&m<refLen; pos++, l++, m++){
            quint8 sc=getChar(refSeq, m);
            quint8 qc=getChar(queryF2, l);
            qint64 score=scoringArray[pos-1]+g2aMatrix[sc][qc];
            if(score>0){
                scoringArray[pos]=score;
            }
            else{
                scoringArray[pos]=0;
            }
            if(score>maxScore){
                maxScore=score;
                maxPos=pos;
            }
        }
        //�X�R�A�]��
        if(maxScore<minAlnScore){
            continue;
        }
        else if(topScore2<maxScore){
            topScore2=maxScore;
            topCount2=1;
            pos=maxPos;
            while(scoringArray[pos-1]>0){
                pos--;
            }
            topAlignLength2=maxPos-pos+1;
            topQueryOffset2=pos-1;
            topSbjctOffset2=itr.key()+pos-1;
            topAlignType2=4;
        }
        else if(topScore2==maxScore){
            topCount2++;
        }
    }

}

void BMapThread::limAlignWithBWT1(void){

	//query2�̃}�b�v���ʂ𗘗p����query1���ēx�}�b�v���邽�߂̊֐�
    quint64 i, j, k, l, m;
    quint64 lb, ub;
    qint64 maxScore=0;
    int pos;
    int maxPos;

    QHash<quint64, int> hash;
    QHash<quint64, int>::iterator itr;

	//�O��Ƃ���query2��unique�Ƀ}�b�v����Ă���K�v������
	if(topCount2!=1){
		return;
	}

	if(topAlignType2==1){

		//�ړI��frequency�Œe���ꂽ�V�[�h��PE�ɂ��~�ςȂ̂ł����Ȃ�seedLengthMax�𗘗p
		for(i=seedLength+seedOffset-1, j=0; i<queryLen&&j<seedIterate; i+=seedStep, j++){
			if(i<seedLengthMax-1){
				continue;
			}
			if(seedLengthMax>bIdxWordSize){
				quint64 id=getId(c2tF, queryLen, i-bIdxWordSize+1, bIdxWordSize);
				if(id==maxValue){
					continue;
				}
				if(!searchBounds(c2tBIdx, id, lb, ub)){
					continue;
				}
				if(!BWTSearchA(c2tBKT, c2tBWT, c2tMCB, c2tF, i-bIdxWordSize, seedLengthMax-bIdxWordSize, lb, ub)){
					continue;
				}
			}
			else if(seedLengthMax==bIdxWordSize){
				quint64 id=getId(c2tF, queryLen, i-bIdxWordSize+1, bIdxWordSize);
				if(id==maxValue){
					continue;
				}
				if(!searchBounds(c2tBIdx, id, lb, ub)){
					continue;
				}
			}
			else{
				if(!BWTSearch(c2tBKT, c2tBWT, c2tMCB, c2tF, i, seedLengthMax, lb, ub)){
					continue;
				}
			}
			for(k=lb; k<=ub; k++){
				quint64 seedHitOffset=BWTPos(c2tSA, c2tBKT, c2tBWT, c2tMCB, k);
				if(seedHitOffset<i){
					//���������ꏊ�͋ɒ[�ɋ�����
					continue;
				}
				quint64 candidateOffset=seedHitOffset-i+seedLengthMax-1;
				if(candidateOffset>topSbjctOffset2-maxPEPairLen
					&&candidateOffset<topSbjctOffset2+maxPEPairLen+topAlignLength2)
				{
					hash[candidateOffset]++;
				}
			}
		}

		for(itr=hash.begin(); itr!=hash.end(); itr++){
			if(itr.value()<(int)minSeedHit){
				continue;
			}
			//�A���C�����g���{
			qint64 maxScore=0;
			int maxPos=0;
			scoringArray[0]=0;
			for(pos=1, l=0, m=itr.key(); l<queryLen&&m<refLen; pos++, l++, m++){
				quint8 sc=getChar(refSeq, m);
				quint8 qc=getChar(queryF, l);
				qint64 score=scoringArray[pos-1]+c2tMatrix[sc][qc];
				if(score>0){
					scoringArray[pos]=score;
				}
				else{
					scoringArray[pos]=0;
				}
				if(score>maxScore){
					maxScore=score;
					maxPos=pos;
				}
			}
			//�X�R�A�]��
			if(maxScore<minAlnScore){
				continue;
			}
			else if(topScore<maxScore){
				topScore=maxScore;
				topCount=1;
				pos=maxPos;
				while(scoringArray[pos-1]>0){
					pos--;
				}
				topAlignLength=maxPos-pos+1;
				topQueryOffset=pos-1;
				topSbjctOffset=itr.key()+pos-1;
				topAlignType=1;
			}
			else if(topScore==maxScore){
				topCount++;
			}
		}
	}

	else if(topAlignType2==2){

		//�ړI��frequency�Œe���ꂽ�V�[�h��PE�ɂ��~�ςȂ̂ł����Ȃ�seedLengthMax�𗘗p
		for(i=seedLength+seedOffset-1, j=0; i<queryLen&&j<seedIterate; i+=seedStep, j++){
			if(i<seedLengthMax-1){
				continue;
			}
			if(seedLengthMax>bIdxWordSize){
				quint64 id=getId(g2aR, queryLen, i-bIdxWordSize+1, bIdxWordSize);
				if(id==maxValue){
					continue;
				}
				if(!searchBounds(c2tBIdx, id, lb, ub)){
					continue;
				}
				if(!BWTSearchA(c2tBKT, c2tBWT, c2tMCB, g2aR, i-bIdxWordSize, seedLengthMax-bIdxWordSize, lb, ub)){
					continue;
				}
			}
			else if(seedLengthMax==bIdxWordSize){
				quint64 id=getId(g2aR, queryLen, i-bIdxWordSize+1, bIdxWordSize);
				if(id==maxValue){
					continue;
				}
				if(!searchBounds(c2tBIdx, id, lb, ub)){
					continue;
				}
			}
			else{
				if(!BWTSearch(c2tBKT, c2tBWT, c2tMCB, g2aR, i, seedLengthMax, lb, ub)){
					continue;
				}
			}
			for(k=lb; k<=ub; k++){
				quint64 seedHitOffset=BWTPos(c2tSA, c2tBKT, c2tBWT, c2tMCB, k);
				if(seedHitOffset<i){
					//���������ꏊ�͋ɒ[�ɋ�����
					continue;
				}
				quint64 candidateOffset=seedHitOffset-i+seedLengthMax-1;
				if(candidateOffset>topSbjctOffset2-maxPEPairLen
					&&candidateOffset<topSbjctOffset2+maxPEPairLen+topAlignLength2)
				{
					hash[candidateOffset]++;
				}
			}
		}

		for(itr=hash.begin(); itr!=hash.end(); itr++){
			if(itr.value()<(int)minSeedHit){
				continue;
			}
			//�A���C�����g���{
			maxScore=0;
			maxPos=0;
			scoringArray[0]=0;
			for(pos=1, l=0, m=itr.key(); l<queryLen&&m<refLen; pos++, l++, m++){
				quint8 sc=getChar(refSeq, m);
				quint8 qc=getChar(queryR, l);
				qint64 score=scoringArray[pos-1]+c2tMatrix[sc][qc];
				if(score>0){
					scoringArray[pos]=score;
				}
				else{
					scoringArray[pos]=0;
				}
				if(score>maxScore){
					maxScore=score;
					maxPos=pos;
				}
			}
			//�X�R�A�]��
			if(maxScore<minAlnScore){
				continue;
			}
			else if(topScore<maxScore){
				topScore=maxScore;
				topCount=1;
				pos=maxPos;
				while(scoringArray[pos-1]>0){
					pos--;
				}
				topAlignLength=maxPos-pos+1;
				topQueryOffset=pos-1;
				topSbjctOffset=itr.key()+pos-1;
				topAlignType=2;
			}
			else if(topScore==maxScore){
				topCount++;
			}
		}
	}

	if(topAlignType2==3){

		//�ړI��frequency�Œe���ꂽ�V�[�h��PE�ɂ��~�ςȂ̂ł����Ȃ�seedLengthMax�𗘗p
		for(i=seedLength+seedOffset-1, j=0; i<queryLen&&j<seedIterate; i+=seedStep, j++){
			if(i<seedLengthMax-1){
				continue;
			}
			if(seedLengthMax>bIdxWordSize){
				quint64 id=getId(c2tR, queryLen, i-bIdxWordSize+1, bIdxWordSize);
				if(id==maxValue){
					continue;
				}
				if(!searchBounds(g2aBIdx, id, lb, ub)){
					continue;
				}
				if(!BWTSearchA(g2aBKT, g2aBWT, g2aMCB, c2tR, i-bIdxWordSize, seedLengthMax-bIdxWordSize, lb, ub)){
					continue;
				}
			}
			else if(seedLengthMax==bIdxWordSize){
				quint64 id=getId(c2tR, queryLen, i-bIdxWordSize+1, bIdxWordSize);
				if(id==maxValue){
					continue;
				}
				if(!searchBounds(g2aBIdx, id, lb, ub)){
					continue;
				}
			}
			else{
				if(!BWTSearch(g2aBKT, g2aBWT, g2aMCB, c2tR, i, seedLengthMax, lb, ub)){
					continue;
				}
			}
			for(k=lb; k<=ub; k++){
				quint64 seedHitOffset=BWTPos(g2aSA, g2aBKT, g2aBWT, g2aMCB, k);
				if(seedHitOffset<i){
					//���������ꏊ�͋ɒ[�ɋ�����
					continue;
				}
				quint64 candidateOffset=seedHitOffset-i+seedLengthMax-1;
				if(candidateOffset>topSbjctOffset2-maxPEPairLen
					&&candidateOffset<topSbjctOffset2+maxPEPairLen+topAlignLength2)
				{
					hash[candidateOffset]++;
				}
			}
		}

		for(itr=hash.begin(); itr!=hash.end(); itr++){
			if(itr.value()<(int)minSeedHit){
				continue;
			}
			//�A���C�����g���{
			maxScore=0;
			maxPos=0;
			scoringArray[0]=0;
			for(pos=1, l=0, m=itr.key(); l<queryLen&&m<refLen; pos++, l++, m++){
				quint8 sc=getChar(refSeq, m);
				quint8 qc=getChar(queryR, l);
				qint64 score=scoringArray[pos-1]+g2aMatrix[sc][qc];
				if(score>0){
					scoringArray[pos]=score;
				}
				else{
					scoringArray[pos]=0;
				}
				if(score>maxScore){
					maxScore=score;
					maxPos=pos;
				}
			}
			//�X�R�A�]��
			if(maxScore<minAlnScore){
				continue;
			}
			else if(topScore<maxScore){
				topScore=maxScore;
				topCount=1;
				pos=maxPos;
				while(scoringArray[pos-1]>0){
					pos--;
				}
				topAlignLength=maxPos-pos+1;
				topQueryOffset=pos-1;
				topSbjctOffset=itr.key()+pos-1;
				topAlignType=3;
			}
			else if(topScore==maxScore){
				topCount++;
			}
		}
	}

	if(topAlignType2==4){

		//�ړI��frequency�Œe���ꂽ�V�[�h��PE�ɂ��~�ςȂ̂ł����Ȃ�seedLengthMax�𗘗p
		for(i=seedLength+seedOffset-1, j=0; i<queryLen&&j<seedIterate; i+=seedStep, j++){
			if(i<seedLengthMax-1){
				continue;
			}
			if(seedLengthMax>bIdxWordSize){
				quint64 id=getId(g2aF, queryLen, i-bIdxWordSize+1, bIdxWordSize);
				if(id==maxValue){
					continue;
				}
				if(!searchBounds(g2aBIdx, id, lb, ub)){
					continue;
				}
				if(!BWTSearchA(g2aBKT, g2aBWT, g2aMCB, g2aF, i-bIdxWordSize, seedLengthMax-bIdxWordSize, lb, ub)){
					continue;
				}
			}
			else if(seedLengthMax==bIdxWordSize){
				quint64 id=getId(g2aF, queryLen, i-bIdxWordSize+1, bIdxWordSize);
				if(id==maxValue){
					continue;
				}
				if(!searchBounds(g2aBIdx, id, lb, ub)){
					continue;
				}
			}
			else{
				if(!BWTSearch(g2aBKT, g2aBWT, g2aMCB, g2aF, i, seedLengthMax, lb, ub)){
					continue;
				}
			}
			for(k=lb; k<=ub; k++){
				quint64 seedHitOffset=BWTPos(g2aSA, g2aBKT, g2aBWT, g2aMCB, k);
				if(seedHitOffset<i){
					//���������ꏊ�͋ɒ[�ɋ�����
					continue;
				}
				quint64 candidateOffset=seedHitOffset-i+seedLengthMax-1;
				if(candidateOffset>topSbjctOffset2-maxPEPairLen
					&&candidateOffset<topSbjctOffset2+maxPEPairLen+topAlignLength2)
				{
					hash[candidateOffset]++;
				}
			}
		}

		for(itr=hash.begin(); itr!=hash.end(); itr++){
			if(itr.value()<(int)minSeedHit){
				continue;
			}
			//�A���C�����g���{
			maxScore=0;
			maxPos=0;
			scoringArray[0]=0;
			for(pos=1, l=0, m=itr.key(); l<queryLen&&m<refLen; pos++, l++, m++){
				quint8 sc=getChar(refSeq, m);
				quint8 qc=getChar(queryF, l);
				qint64 score=scoringArray[pos-1]+g2aMatrix[sc][qc];
				if(score>0){
					scoringArray[pos]=score;
				}
				else{
					scoringArray[pos]=0;
				}
				if(score>maxScore){
					maxScore=score;
					maxPos=pos;
				}
			}
			//�X�R�A�]��
			if(maxScore<minAlnScore){
				continue;
			}
			else if(topScore<maxScore){
				topScore=maxScore;
				topCount=1;
				pos=maxPos;
				while(scoringArray[pos-1]>0){
					pos--;
				}
				topAlignLength=maxPos-pos+1;
				topQueryOffset=pos-1;
				topSbjctOffset=itr.key()+pos-1;
				topAlignType=4;
			}
			else if(topScore==maxScore){
				topCount++;
			}
		}
	}

}



void BMapThread::setQuery(const QByteArray& name, const QByteArray& query)
{
    int i;
    quint64 pf, pr;
    queryLen=query.size()<(int)maxQueryLength?(quint64)query.size():(quint64)maxQueryLength;
    for(i=0, pf=0, pr=queryLen-1; pf<queryLen; i++, pf++, pr--){
        switch(query[i]){
            case 'A':
            case 'a':
                setChar(queryF, pf, 0x01);	//A
                setChar(c2tF, pf, 0x01);	//A
                setChar(g2aF, pf, 0x01);	//A
                setChar(queryR, pr, 0x04);	//T
                setChar(c2tR, pr, 0x04);	//T
                setChar(g2aR, pr, 0x04);	//T
                break;
            case 'C':
            case 'c':
                setChar(queryF, pf, 0x02);	//C
                setChar(c2tF, pf, 0x04);	//T
                setChar(g2aF, pf, 0x02);	//C
                setChar(queryR, pr, 0x03);	//G
                setChar(c2tR, pr, 0x01);	//A
                setChar(g2aR, pr, 0x03);	//G
                break;
            case 'G':
            case 'g':
                setChar(queryF, pf, 0x03);	//G
                setChar(c2tF, pf, 0x03);	//G
                setChar(g2aF, pf, 0x01);	//A
                setChar(queryR, pr, 0x02);	//C
                setChar(c2tR, pr, 0x02);	//C
                setChar(g2aR, pr, 0x04);	//T
                break;
            case 'T':
            case 't':
                setChar(queryF, pf, 0x04);	//T
                setChar(c2tF, pf, 0x04);	//T
                setChar(g2aF, pf, 0x04);	//T
                setChar(queryR, pr, 0x01);	//A
                setChar(c2tR, pr, 0x01);	//A
                setChar(g2aR, pr, 0x01);	//A
                break;
            default:
                setChar(queryF, pf, 0x05);	//N
                setChar(c2tF, pf, 0x05);	//N
                setChar(g2aF, pf, 0x05);	//N
                setChar(queryR, pr, 0x05);	//N
                setChar(c2tR, pr, 0x05);	//N
                setChar(g2aR, pr, 0x05);	//N
        }
    }
    cloneName=name;

}

void BMapThread::setQuery2(const QByteArray& name, const QByteArray& query)
{
    int i;
    quint64 pf, pr;
    queryLen2=query.size()<(int)maxQueryLength?(quint64)query.size():(quint64)maxQueryLength;
    for(i=0, pf=0, pr=queryLen2-1; pf<queryLen2; i++, pf++, pr--){
        switch(query[i]){
            case 'A':
            case 'a':
                setChar(queryF2, pf, 0x01);	//A
                setChar(c2tF2, pf, 0x01);	//A
                setChar(g2aF2, pf, 0x01);	//A
                setChar(queryR2, pr, 0x04);	//T
                setChar(c2tR2, pr, 0x04);	//T
                setChar(g2aR2, pr, 0x04);	//T
                break;
            case 'C':
            case 'c':
                setChar(queryF2, pf, 0x02);	//C
                setChar(c2tF2, pf, 0x04);	//T
                setChar(g2aF2, pf, 0x02);	//C
                setChar(queryR2, pr, 0x03);	//G
                setChar(c2tR2, pr, 0x01);	//A
                setChar(g2aR2, pr, 0x03);	//G
                break;
            case 'G':
            case 'g':
                setChar(queryF2, pf, 0x03);	//G
                setChar(c2tF2, pf, 0x03);	//G
                setChar(g2aF2, pf, 0x01);	//A
                setChar(queryR2, pr, 0x02);	//C
                setChar(c2tR2, pr, 0x02);	//C
                setChar(g2aR2, pr, 0x04);	//T
                break;
            case 'T':
            case 't':
                setChar(queryF2, pf, 0x04);	//T
                setChar(c2tF2, pf, 0x04);	//T
                setChar(g2aF2, pf, 0x04);	//T
                setChar(queryR2, pr, 0x01);	//A
                setChar(c2tR2, pr, 0x01);	//A
                setChar(g2aR2, pr, 0x01);	//A
                break;
            default:
                setChar(queryF2, pf, 0x05);	//N
                setChar(c2tF2, pf, 0x05);	//N
                setChar(g2aF2, pf, 0x05);	//N
                setChar(queryR2, pr, 0x05);	//N
                setChar(c2tR2, pr, 0x05);	//N
                setChar(g2aR2, pr, 0x05);	//N
        }
    }
    cloneName2=name;

}
