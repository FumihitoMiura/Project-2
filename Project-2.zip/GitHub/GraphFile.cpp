#include "GraphFile.h"

using namespace DesktopTrack::GraphFile;

Header::Header(void):
magic(1234),
version(2),		//�ύX
dataType(Integer),
targetListOffset(0),
targetListDataSize(0),
targetListDataCount(0),
rowHeight(RowHeight),
fontSize(FontSize),
fgColor(FgColor),
bgColor(BgColor),
anColor(AnColor),
//markerColor(MkColor),
strandSpecificity(SeparateStrands),
maxValue(100),
minValue(0){}

Header::Header(const Header& original):
magic(original.magic),
version(original.version),
trackName(original.trackName),
species(original.species),
revision(original.revision),
dataType(original.dataType),
targetListOffset(original.targetListOffset),
targetListDataSize(original.targetListDataSize),
targetListDataCount(original.targetListDataCount),
rowHeight(original.rowHeight),
fontSize(original.fontSize),
fgColor(original.fgColor),
bgColor(original.bgColor),
anColor(original.anColor),
//markerColor(original.markerColor),
strandSpecificity(original.strandSpecificity),
maxValue(original.maxValue),
minValue(original.minValue){}

Header& Header::operator =(const Header& original)
{
	magic=original.magic;
	version=original.version;
	trackName=original.trackName;
	species=original.species;
	revision=original.revision;
	dataType=original.dataType;
	targetListOffset=original.targetListOffset;
	targetListDataSize=original.targetListDataSize;
	targetListDataCount=original.targetListDataCount;
	rowHeight=original.rowHeight;
	fontSize=original.fontSize;
	fgColor=original.fgColor;
	bgColor=original.bgColor;
	anColor=original.anColor;
	//markerColor=original.markerColor;
	strandSpecificity=original.strandSpecificity;
	maxValue=original.maxValue;
	minValue=original.minValue;
	return *this;
}

bool Header::isCorrectFile(void)
{
	if(magic==1234){
		if(version==1||version==2||version==3){
			return true;
		}
		else{
			return false;
		}
	}
	else{
		return false;
	}
}

void Header::putSerialized(QDataStream& out)
{
	out		<< magic
			<< version
			<< trackName
			<< species
			<< revision
			<< dataType
			<< targetListOffset
			<< targetListDataSize
			<< targetListDataCount
			<< rowHeight
			<< fontSize
			<< fgColor
			<< bgColor
            << anColor
			//<< markerColor
			<< strandSpecificity;
	if(version>=2){
		out << maxValue
			<< minValue;
	}
}

void Header::getSerialized(QDataStream& in)
{
	in		>> magic
			>> version
			>> trackName
			>> species
			>> revision
			>> dataType
			>> targetListOffset
			>> targetListDataSize
			>> targetListDataCount
			>> rowHeight
			>> fontSize
			>> fgColor
			>> bgColor
			>> anColor
			//>> markerColor
			>> strandSpecificity;
	if(version>=2){
		in	>> maxValue
			>> minValue;
	}
}

int Target::version=2;

void Target::setVersion(const int& v)
{
	version=v;
}

Target::Target(void):
targetLength(0),
fwDataOffset(0),
fwDataSize(0),
rvDataOffset(0),
rvDataSize(0){}

Target::Target(const QString& target_name,
			   const quint32& target_length):
targetName(target_name),
targetLength(target_length),
fwDataOffset(0),
fwDataSize(0),
rvDataOffset(0),
rvDataSize(0){}

Target::Target(const Target& original):
targetName(original.targetName),
targetLength(original.targetLength),
fwDataOffset(original.fwDataOffset),
fwDataSize(original.fwDataSize),
rvDataOffset(original.rvDataOffset),
rvDataSize(original.rvDataSize){}

Target& Target::operator =(const Target& original)
{
	targetName=original.targetName;
	targetLength=original.targetLength;
	fwDataOffset=original.fwDataOffset;
	fwDataSize=original.fwDataSize;
	rvDataOffset=original.rvDataOffset;
	rvDataSize=original.rvDataSize;
	return *this;
}

void Target::putSerialized(QDataStream& out)
{
	if(version==1){
		quint32 fwDataOffset32, rvDataOffset32;
		out	<< targetName
			<< targetLength
			<< (quint32)fwDataOffset
			<< fwDataSize
			<< (quint32)rvDataOffset
			<< rvDataSize;
	}
	else if(version>=2){
		out	<< targetName
			<< targetLength
			<< fwDataOffset
			<< fwDataSize
			<< rvDataOffset
			<< rvDataSize;
	}
}

void Target::getSerialized(QDataStream& in)
{
	if(version==1){
		quint32 fwDataOffset32, rvDataOffset32;
		in	>> targetName
			>> targetLength
			>> fwDataOffset32
			>> fwDataSize
			>> rvDataOffset32
			>> rvDataSize;
		fwDataOffset=fwDataOffset32;
		rvDataOffset=rvDataOffset32;
	}
	else if(version>=2){
		in	>> targetName
			>> targetLength
			>> fwDataOffset
			>> fwDataSize
			>> rvDataOffset
			>> rvDataSize;
	}
}

TargetLess::TargetLess(void){}

bool TargetLess::operator()(const Target& a, const Target& b)
{
	return a.targetName < b.targetName;
}


/*--------------------------------------------------------------

	class FileCreator

--------------------------------------------------------------*/

//�R���X�g���N�^
FileCreator::FileCreator(QObject* parent):
QThread(parent){}

/*-----�O���������֖��߂�������֐�(Thread Safe)-------*/
void FileCreator::
setOrder(bool proceed){
	mutex.lock();
	promoteProcess = proceed;
	mutex.unlock();
}

/*-----�O���������̏�Ԃ��󂯎��֐�(Thread Safe)-------*/
void FileCreator::
getProcessStatus(	Process& process_status,
					quint64& prosessed_data,
					quint64& total_data)
{
	mutex.lock();
	process_status = processStatus;
	prosessed_data = processedData;
	total_data = totalData;
	mutex.unlock();
}

/*-----�������O���̖��߂��󂯎��֐�(Thread Safe)-------*/
bool FileCreator::
getOrder(void)
{
	mutex.lock();
	bool order = promoteProcess;
	mutex.unlock();
	return order;
}

/*-----�������O���֏�Ԃ�񍐂���֐�(Thread Safe)-------*/
void FileCreator::
setProcessStatus(	const Process& process_status,
					const quint64& prosessed_data,
					const quint64& total_data)
{
	mutex.lock();
	processStatus = process_status;
	processedData = prosessed_data;
	totalData = total_data;
	mutex.unlock();
}

//�N���X��������������
void FileCreator::initialize(void)
{
	Header temp;
	header=temp;
	targetList.clear();
	targetMap.clear();
	renameMap.clear();
	featureTypesToBeIgnored.clear();
}

void FileCreator::setTrackConfig(const Header& config)
{

	header.trackName=config.trackName;
	header.species=config.species;
	header.revision=config.revision;
	header.dataType=config.dataType;
	header.targetListOffset=config.targetListOffset;
	header.targetListDataSize=config.targetListDataSize;
	header.targetListDataCount=config.targetListDataCount;
	header.rowHeight=config.rowHeight;
	header.fontSize=config.fontSize;
	header.fgColor=config.fgColor;
	header.bgColor=config.bgColor;
	header.anColor=config.anColor;
	//header.markerColor=config.markerColor;
	header.strandSpecificity=config.strandSpecificity;

}

void FileCreator::setTargetFilePath(const QString& target_file_path)
{
	targetFilePath=target_file_path;
}

void FileCreator::setIgnoredFeatureTypes(const QStringList& ignored_feature_types)
{
	featureTypesToBeIgnored=QSet<QString>::fromList(ignored_feature_types);
}

void FileCreator::setTargetList(const QList<QPair<QString, quint32> >& target_list)
{
	//QList<QPair<QString, quint32> > local_temporal_target_list(target_list);
	//���X�̃��X�g���N���A
	targetList.clear();
	targetMap.clear();
	//target_id��������
	quint32 target_id_counter=0;
	for(int i=0; i<target_list.size(); i++){
		QString target_name=target_list[i].first;
		if(targetMap.contains(target_list[i].first)){
			quint32 target_id=targetMap[target_list[i].first];
			if(targetList[target_id].targetLength<target_list[i].second){
				targetList[target_id].targetLength=target_list[i].second;
			}
		}
		else{
			targetMap[target_list[i].first]=target_id_counter++;
			Target newTarget(target_list[i].first, target_list[i].second);
			targetList.push_back(newTarget);
		}
	}
}

void FileCreator::setRenameMap(const QMap<QString, QString>& rename_map)
{
	renameMap=rename_map;
}

void FileCreator::setAnalysisResultFile(const QString& path_to_analysis_result_file)
{
	analysisResultFilePath=path_to_analysis_result_file;
}

void FileCreator::run(void)
{
	//�o�͐�t�@�C�����I�[�v��
	QFile outFile(targetFilePath);
	outFile.open(QIODevice::WriteOnly);
	if(!outFile.isOpen()){
		setProcessStatus(failed, 0, 0);
		return;
	}
	//���ߊm�F
	if(!getOrder()){
		setProcessStatus(stopped, 0, 0);
		return;
	}

	//���͐�t�@�C�����I�[�v��
	QFile inFile(analysisResultFilePath);
	inFile.open(QIODevice::ReadOnly);
	if(!inFile.isOpen()){
		//���s�����甲����
		setProcessStatus(failed, 0, 0);
		return;
	}
	quint64 fileSize=inFile.size();
	FileBuffer inputBuffer(&inFile);

	if(header.strandSpecificity==SeparateStrands&&header.dataType==Integer){

		int i, j;

		//�f�[�^�i�[�̈���m�ۂ�������
		QList<QVector<qint32> > fwGraphDataList, rvGraphDataList;
		for(i=0; i<targetList.size(); i++){
			QVector<qint32> temp;
			fwGraphDataList.push_back(temp);
			rvGraphDataList.push_back(temp);
			fwGraphDataList[i].resize(targetList[i].targetLength);
			fwGraphDataList[i].fill(0);
			rvGraphDataList[i].resize(targetList[i].targetLength);
			rvGraphDataList[i].fill(0);
		}

		//�S�Ẵf�[�^�����Z
		setProcessStatus(registering, 0, fileSize);
		QString line;
		i=0;
		while(inputBuffer.getLine(line)){

			QStringList cols=line.split("\t");
			/*--------------------------
				cols[0] target
				cols[1] start
				cols[2] end
				cols[3] strand 1 or 0 or -1
				cols[4] feature_type
				cols[5] value
			--------------------------*/
			QString& target=cols[0];
			quint32 start=cols[1].toUInt();
			quint32 end=cols[2].toUInt();
			qint32 strand=cols[3].toInt();
			QString& feature_type=cols[4];
			qint32 value=cols[5].toInt();


			//�o�^���Ȃ����X�g�Ɋ܂܂�Ă���feature_type�ł���Ζ�������
			if(featureTypesToBeIgnored.contains(feature_type)){
				continue;
			}

			//���O����
			if(renameMap.contains(target)){
				target=renameMap[target];
			}
			//target���������A������Δ�����
			if(!targetMap.contains(target)){
				continue;
			}
			quint32 target_id=targetMap[target];

			if(start>end){
				continue;
			}
			if(end>targetList[target_id].targetLength){
				continue;
			}

			//�X�g�����h���ɏ���
			if(strand==1){
				for(i=start-1; i<end; i++){
					fwGraphDataList[target_id][i]+=value;
				}
			}
			else if(strand==-1){
				for(i=start-1; i<end; i++){
					rvGraphDataList[target_id][i]+=value;
				}			
			}
			if(strand==0){
				for(i=start-1; i<end; i++){
					fwGraphDataList[target_id][i]+=value;
					rvGraphDataList[target_id][i]+=value;
				}			
			}

			i++;
			if(i%1000==0){
				if(!getOrder()){
					setProcessStatus(stopped, 0, 0);
					return;
				}
				setProcessStatus(registering, inputBuffer.processed(), fileSize);
			}

		}
		setProcessStatus(registering, fileSize, fileSize);

		//�o�͊J�n
		if(!getOrder()){
			setProcessStatus(stopped, 0, 0);
			return;
		}
		setProcessStatus(outputting, 0, 7);



		//�w�b�_�[�̉��o��
		QDataStream out;
		out.setDevice(&outFile);
		header.putSerialized(out);

		//�o�b�t�@�[����
		QByteArray data;
		QBuffer buffer;
		//�f�[�^�̏o��
		buffer.setBuffer(&data);
		buffer.open(QIODevice::WriteOnly);
		out.setDevice(&buffer);

		for(i=0; i<targetList.size(); i++){

			setProcessStatus(finished, i, targetList.size());

			Target& target=targetList[i];
			//fw
			QVector<qint32>& fwGraphData=fwGraphDataList[i];
			target.fwDataOffset=outFile.pos()+buffer.pos();
			for(j=0; j<target.targetLength; j++){
				out << fwGraphData[j];
			}
			target.rvDataOffset=outFile.pos()+buffer.pos();
			target.fwDataSize=target.rvDataOffset-target.fwDataOffset;
			QVector<qint32>& rvGraphData=rvGraphDataList[i];
			for(j=0; j<target.targetLength; j++){
				out << rvGraphData[j];
			}
			target.rvDataSize=outFile.pos()+buffer.pos()-target.rvDataOffset;
			if(data.size()>BufferSizeMax){
				buffer.close();
				outFile.write(data);
				data.clear();
				buffer.setBuffer(&data);
				buffer.open(QIODevice::WriteOnly);
				out.setDevice(&buffer);
			}
			
		}

		buffer.close();
		outFile.write(data);
		data.clear();
		buffer.setBuffer(&data);
		buffer.open(QIODevice::WriteOnly);
		out.setDevice(&buffer);

		for(i=0; i<targetList.size(); i++){
			targetList[i].putSerialized(out);
		}
		buffer.close();
		header.targetListOffset=outFile.pos();
		header.targetListDataSize=(quint32)data.size();
		header.targetListDataCount=targetList.size();
		outFile.write(data);
		data.clear();

		//�Ăуt�@�C���擪��
		outFile.seek(0);
		out.setDevice(&outFile);
		header.putSerialized(out);

		setProcessStatus(finished, 7, 7);

	}
	else if(header.strandSpecificity==UnifyStrands&&header.dataType==Integer){

		int i, j;

		//�f�[�^�i�[�̈���m�ۂ�������
		QList<QVector<qint32> > graphDataList;
		for(i=0; i<targetList.size(); i++){
			QVector<qint32> temp;
			graphDataList.push_back(temp);
			graphDataList[i].resize(targetList[i].targetLength);
			graphDataList[i].fill(0);
		}

		//�S�Ẵf�[�^�����Z
		setProcessStatus(registering, 0, fileSize);
		QString line;
		i=0;
		while(inputBuffer.getLine(line)){

			QStringList cols=line.split("\t");
			/*--------------------------
				cols[0] target
				cols[1] start
				cols[2] end
				cols[3] strand 1 or 0 or -1
				cols[4] feature_type
				cols[5] value
			--------------------------*/
			QString& target=cols[0];
			quint32 start=cols[1].toUInt();
			quint32 end=cols[2].toUInt();
			qint32 strand=cols[3].toInt();
			QString& feature_type=cols[4];
			qint32 value=cols[5].toInt();

			//�o�^���Ȃ����X�g�Ɋ܂܂�Ă���feature_type�ł���Ζ�������
			if(featureTypesToBeIgnored.contains(feature_type)){
				continue;
			}

			//���O����
			if(renameMap.contains(target)){
				target=renameMap[target];
			}
			//target���������A������Δ�����
			if(!targetMap.contains(target)){
				continue;
			}
			quint32 target_id=targetMap[target];

			if(start>end){
				continue;
			}
			if(end>targetList[target_id].targetLength){
				continue;
			}

			for(i=start-1; i<end; i++){
				graphDataList[target_id][i]+=value;
			}

			i++;
			if(i%1000==0){
				if(!getOrder()){
					setProcessStatus(stopped, 0, 0);
					return;
				}
				setProcessStatus(registering, inputBuffer.processed(), fileSize);
			}

		}
		setProcessStatus(registering, fileSize, fileSize);

		//�o�͊J�n
		if(!getOrder()){
			setProcessStatus(stopped, 0, 0);
			return;
		}
		setProcessStatus(outputting, 0, 7);



		//�w�b�_�[�̉��o��
		QDataStream out;
		out.setDevice(&outFile);
		header.putSerialized(out);

		//�o�b�t�@�[����
		QByteArray data;
		QBuffer buffer;
		//�f�[�^�̏o��
		buffer.setBuffer(&data);
		buffer.open(QIODevice::WriteOnly);
		out.setDevice(&buffer);

		for(i=0; i<targetList.size(); i++){

			setProcessStatus(finished, i, targetList.size());

			Target& target=targetList[i];
			QVector<qint32>& graphData=graphDataList[i];
			target.fwDataOffset=outFile.pos()+buffer.pos();
			for(j=0; j<target.targetLength; j++){
				out << graphData[j];
			}
			target.fwDataSize=outFile.pos()+buffer.pos()-target.fwDataOffset;
			target.rvDataOffset=0;
			target.rvDataSize=0;
			if(data.size()>BufferSizeMax){
				buffer.close();
				outFile.write(data);
				data.clear();
				buffer.setBuffer(&data);
				buffer.open(QIODevice::WriteOnly);
				out.setDevice(&buffer);
			}
			
		}

		buffer.close();
		outFile.write(data);
		data.clear();
		buffer.setBuffer(&data);
		buffer.open(QIODevice::WriteOnly);
		out.setDevice(&buffer);

		for(i=0; i<targetList.size(); i++){
			targetList[i].putSerialized(out);
		}
		buffer.close();
		header.targetListOffset=outFile.pos();
		header.targetListDataSize=(quint32)data.size();
		header.targetListDataCount=targetList.size();
		outFile.write(data);
		data.clear();

		//�Ăуt�@�C���擪��
		outFile.seek(0);
		out.setDevice(&outFile);
		header.putSerialized(out);

		setProcessStatus(finished, 7, 7);

	}
	if(header.strandSpecificity==SeparateStrands&&header.dataType==Float){

		int i, j;

		//�f�[�^�i�[�̈���m�ۂ�������
		QList<QVector<float> > fwGraphDataList, rvGraphDataList;
		for(i=0; i<targetList.size(); i++){
			QVector<float> temp;
			fwGraphDataList.push_back(temp);
			rvGraphDataList.push_back(temp);
			fwGraphDataList[i].resize(targetList[i].targetLength);
			fwGraphDataList[i].fill(0);
			rvGraphDataList[i].resize(targetList[i].targetLength);
			rvGraphDataList[i].fill(0);
		}

		//�S�Ẵf�[�^�����Z
		setProcessStatus(registering, 0, fileSize);
		QString line;
		i=0;
		while(inputBuffer.getLine(line)){

			QStringList cols=line.split("\t");
			/*--------------------------
				cols[0] target
				cols[1] start
				cols[2] end
				cols[3] strand 1 or 0 or -1
				cols[4] feature_type
				cols[5] value
			--------------------------*/
			QString& target=cols[0];
			quint32 start=cols[1].toUInt();
			quint32 end=cols[2].toUInt();
			qint32 strand=cols[3].toInt();
			QString& feature_type=cols[4];
			float value=cols[5].toFloat();

			//�o�^���Ȃ����X�g�Ɋ܂܂�Ă���feature_type�ł���Ζ�������
			if(featureTypesToBeIgnored.contains(feature_type)){
				continue;
			}

			//���O����
			if(renameMap.contains(target)){
				target=renameMap[target];
			}
			//target���������A������Δ�����
			if(!targetMap.contains(target)){
				continue;
			}
			quint32 target_id=targetMap[target];

			if(start>end){
				continue;
			}
			if(end>targetList[target_id].targetLength){
				continue;
			}

			//�X�g�����h���ɏ���
			if(strand==1){
				for(i=start-1; i<end; i++){
					fwGraphDataList[target_id][i]+=value;
				}
			}
			else if(strand==-1){
				for(i=start-1; i<end; i++){
					rvGraphDataList[target_id][i]+=value;
				}			
			}
			if(strand==0){
				for(i=start-1; i<end; i++){
					fwGraphDataList[target_id][i]+=value;
					rvGraphDataList[target_id][i]+=value;
				}			
			}

			i++;
			if(i%1000==0){
				if(!getOrder()){
					setProcessStatus(stopped, 0, 0);
					return;
				}
				setProcessStatus(registering, inputBuffer.processed(), fileSize);
			}

		}
		setProcessStatus(registering, fileSize, fileSize);

		//�o�͊J�n
		if(!getOrder()){
			setProcessStatus(stopped, 0, 0);
			return;
		}
		setProcessStatus(outputting, 0, 7);



		//�w�b�_�[�̉��o��
		QDataStream out;
		out.setDevice(&outFile);
		header.putSerialized(out);

		//�o�b�t�@�[����
		QByteArray data;
		QBuffer buffer;
		//�f�[�^�̏o��
		buffer.setBuffer(&data);
		buffer.open(QIODevice::WriteOnly);
		out.setDevice(&buffer);

		for(i=0; i<targetList.size(); i++){

			setProcessStatus(finished, i, targetList.size());

			Target& target=targetList[i];
			//fw
			QVector<float>& fwGraphData=fwGraphDataList[i];
			target.fwDataOffset=outFile.pos()+buffer.pos();
			for(j=0; j<target.targetLength; j++){
				out << fwGraphData[j];
			}
			target.rvDataOffset=outFile.pos()+buffer.pos();
			target.fwDataSize=target.rvDataOffset-target.fwDataOffset;
			QVector<float>& rvGraphData=rvGraphDataList[i];
			for(j=0; j<target.targetLength; j++){
				out << rvGraphData[j];
			}
			target.rvDataSize=outFile.pos()+buffer.pos()-target.rvDataOffset;
			if(data.size()>BufferSizeMax){
				buffer.close();
				outFile.write(data);
				data.clear();
				buffer.setBuffer(&data);
				buffer.open(QIODevice::WriteOnly);
				out.setDevice(&buffer);
			}
			
		}

		buffer.close();
		outFile.write(data);
		data.clear();
		buffer.setBuffer(&data);
		buffer.open(QIODevice::WriteOnly);
		out.setDevice(&buffer);

		for(i=0; i<targetList.size(); i++){
			targetList[i].putSerialized(out);
		}
		buffer.close();
		header.targetListOffset=outFile.pos();
		header.targetListDataSize=(quint32)data.size();
		header.targetListDataCount=targetList.size();
		outFile.write(data);
		data.clear();

		//�Ăуt�@�C���擪��
		outFile.seek(0);
		out.setDevice(&outFile);
		header.putSerialized(out);

		setProcessStatus(finished, 7, 7);

	}
	else if(header.strandSpecificity==UnifyStrands&&header.dataType==Float){

		int i, j;

		//�f�[�^�i�[�̈���m�ۂ�������
		QList<QVector<float> > graphDataList;
		for(i=0; i<targetList.size(); i++){
			QVector<float> temp;
			graphDataList.push_back(temp);
			graphDataList[i].resize(targetList[i].targetLength);
			graphDataList[i].fill(0);
		}

		//�S�Ẵf�[�^�����Z
		setProcessStatus(registering, 0, fileSize);
		QString line;
		i=0;
		while(inputBuffer.getLine(line)){

			QStringList cols=line.split("\t");
			/*--------------------------
				cols[0] target
				cols[1] start
				cols[2] end
				cols[3] strand 1 or 0 or -1
				cols[4] feature_type
				cols[5] value
			--------------------------*/
			QString& target=cols[0];
			quint32 start=cols[1].toUInt();
			quint32 end=cols[2].toUInt();
			qint32 strand=cols[3].toInt();
			QString& feature_type=cols[4];
			qint32 value=cols[5].toFloat();

			//�o�^���Ȃ����X�g�Ɋ܂܂�Ă���feature_type�ł���Ζ�������
			if(featureTypesToBeIgnored.contains(feature_type)){
				continue;
			}

			//���O����
			if(renameMap.contains(target)){
				target=renameMap[target];
			}
			//target���������A������Δ�����
			if(!targetMap.contains(target)){
				continue;
			}
			quint32 target_id=targetMap[target];

			if(start>end){
				continue;
			}
			if(end>targetList[target_id].targetLength){
				continue;
			}

			for(i=start-1; i<end; i++){
				graphDataList[target_id][i]+=value;
			}

			i++;
			if(i%1000==0){
				if(!getOrder()){
					setProcessStatus(stopped, 0, 0);
					return;
				}
				setProcessStatus(registering, inputBuffer.processed(), fileSize);
			}

		}
		setProcessStatus(registering, fileSize, fileSize);

		//�o�͊J�n
		if(!getOrder()){
			setProcessStatus(stopped, 0, 0);
			return;
		}
		setProcessStatus(outputting, 0, 7);



		//�w�b�_�[�̉��o��
		QDataStream out;
		out.setDevice(&outFile);
		header.putSerialized(out);

		//�o�b�t�@�[����
		QByteArray data;
		QBuffer buffer;
		//�f�[�^�̏o��
		buffer.setBuffer(&data);
		buffer.open(QIODevice::WriteOnly);
		out.setDevice(&buffer);

		for(i=0; i<targetList.size(); i++){

			setProcessStatus(finished, i, targetList.size());

			Target& target=targetList[i];
			QVector<float>& graphData=graphDataList[i];
			target.fwDataOffset=outFile.pos()+buffer.pos();
			for(j=0; j<target.targetLength; j++){
				out << graphData[j];
			}
			target.fwDataSize=outFile.pos()+buffer.pos()-target.fwDataOffset;
			target.rvDataOffset=0;
			target.rvDataSize=0;
			if(data.size()>BufferSizeMax){
				buffer.close();
				outFile.write(data);
				data.clear();
				buffer.setBuffer(&data);
				buffer.open(QIODevice::WriteOnly);
				out.setDevice(&buffer);
			}
			
		}

		buffer.close();
		outFile.write(data);
		data.clear();
		buffer.setBuffer(&data);
		buffer.open(QIODevice::WriteOnly);
		out.setDevice(&buffer);

		for(i=0; i<targetList.size(); i++){
			targetList[i].putSerialized(out);
		}
		buffer.close();
		header.targetListOffset=outFile.pos();
		header.targetListDataSize=(quint32)data.size();
		header.targetListDataCount=targetList.size();
		outFile.write(data);
		data.clear();

		//�Ăуt�@�C���擪��
		outFile.seek(0);
		out.setDevice(&outFile);
		header.putSerialized(out);

		setProcessStatus(finished, 7, 7);

	}
	else{
		return;
	}

	return;

}


/*--------------------------------------------------------------

	class FileReader

--------------------------------------------------------------*/


FileReader::FileReader(void){}

bool FileReader::setFile(const QString& file_path)
{
	targetList.clear();
	targetMap.clear();
	if(file.isOpen()){
		file.close();	
	}
	file.setFileName(file_path);
	file.open(QIODevice::ReadOnly);
	if(!file.isOpen()){
		return false;
	}
	QDataStream in(&file);

	//�w�b�_�[��ǂݍ����
	header.getSerialized(in);
	//�w�b�_�[����
	if(!header.isCorrectFile()){
		return false;
	}
	else{
		Target::setVersion(header.version);
	}
	QByteArray data;
	QBuffer buffer;
	int i;
	//target list���擾
	file.seek(header.targetListOffset);
	data=file.read(header.targetListDataSize);
	buffer.setBuffer(&data);
	buffer.open(QIODevice::ReadOnly);
	in.setDevice(&buffer);
	for(i=0; i<header.targetListDataCount; i++){
		Target temp;
		temp.getSerialized(in);
		targetList.push_back(temp);
	}
	for(i=0; i<targetList.size(); i++){
		QString targetName=targetList[i].targetName;
		targetMap[targetName]=i;
	}
	buffer.close();
	file.close();
	return true;
}

bool FileReader::releaseFile(void)
{
	if(file.isOpen()){
		file.close();
		return true;
	}
	else{
		return false;
	}
}

bool FileReader::unsetFile(void){
	Header header;
	this->header=header;
	targetList.clear();
	file.close();
	return true;
}

const Header& FileReader::getBasicTrackInfo(void) const
{
	return header; 
}

const QList<Target>& FileReader::getTargetList(void) const
{
	return targetList;
}

bool FileReader::targetContains(const QString& target_name)
{
	if(targetMap.contains(target_name)){
		return true;
	}
	else{
		return false;
	}
}

bool FileReader::setBasicTrackConf(const Header& conf)
{
	if(file.isOpen()){
		file.close();
	}
	file.open(QIODevice::Append);
	if(!file.isOpen()){
		return false;
	}

	header.rowHeight=conf.rowHeight;
	header.fontSize=conf.fontSize;
	header.fgColor=conf.fgColor;
	header.bgColor=conf.bgColor;
	header.anColor=conf.anColor;
	header.strandSpecificity=conf.strandSpecificity;
	file.seek(0);
	QDataStream out;
	out.setDevice(&file);
	header.putSerialized(out);
	file.close();
	return true;

}

bool FileReader::getData(	const QString& target_name,
							const qint32& strand,
							QVector<quint32>& data_to)
{
	if(header.dataType!=Integer){
		return false;
	}
	if(!targetMap.contains(target_name)){
		return false;
	}
	Target& target=targetList[targetMap[target_name]];

	//strand�𕪗����Ȃ��ꍇ
	if(header.strandSpecificity==UnifyStrands){

		if(file.isOpen()){
			file.close();	
		}
		file.open(QIODevice::ReadOnly);
		if(!file.isOpen()){
			return false;
		}
		file.seek(target.fwDataOffset);
		QByteArray data=file.read(target.fwDataSize);
		QBuffer buffer(&data);
		buffer.open(QIODevice::ReadOnly);
		QDataStream in(&buffer);
		data_to.resize(target.targetLength);
		for(int i=0; i<target.targetLength; i++){
			qint32 temp;
			in >> temp;
			if(header.version==3){
				data_to[i]=temp&0x7FFF;
			}
			else{
				data_to[i]=temp;
			}
		}
		return true;		

	}
	//�ȉ���strand�𕪗�����ꍇ
	else if(strand==1){
		if(file.isOpen()){
			file.close();	
		}
		file.open(QIODevice::ReadOnly);
		if(!file.isOpen()){
			return false;
		}
		file.seek(target.fwDataOffset);
		QByteArray data=file.read(target.fwDataSize);
		QBuffer buffer(&data);
		buffer.open(QIODevice::ReadOnly);
		QDataStream in(&buffer);
		data_to.resize(target.targetLength);
		for(int i=0; i<target.targetLength; i++){
			qint32 temp;
			in >> temp;
			if(header.version==3){
				data_to[i]=temp&0x7FFF;
			}
			else{
				data_to[i]=temp;
			}
		}
		return true;
	}
	else if(strand==-1){
		if(file.isOpen()){
			file.close();	
		}
		file.open(QIODevice::ReadOnly);
		if(!file.isOpen()){
			return false;
		}
		file.seek(target.rvDataOffset);
		QByteArray data=file.read(target.rvDataSize);
		QBuffer buffer(&data);
		buffer.open(QIODevice::ReadOnly);
		QDataStream in(&buffer);
		data_to.resize(target.targetLength);
		for(int i=0; i<target.targetLength; i++){
			qint32 temp;
			in >> temp;
			if(header.version==3){
				data_to[i]=temp&0x7FFF;
			}
			else{
				data_to[i]=temp;
			}
		}
		return true;
	}
	else{
		return false;
	}

}

bool FileReader::getData(	const QString& target_name,
							const qint32& strand,
							QVector<float>& data_to)
{
	if(header.dataType!=Float){
		return false;
	}
	if(!targetMap.contains(target_name)){
		return false;
	}
	Target& target=targetList[targetMap[target_name]];
	if(strand==1){
		if(file.isOpen()){
			file.close();	
		}
		file.open(QIODevice::ReadOnly);
		if(!file.isOpen()){
			return false;
		}
		file.seek(target.fwDataOffset);
		QByteArray data=file.read(target.fwDataSize);
		QBuffer buffer(&data);
		buffer.open(QIODevice::ReadOnly);
		QDataStream in(&buffer);

		#if QT_VERSION >= 0x040600
		in.setFloatingPointPrecision(QDataStream::SinglePrecision);
		#endif

		data_to.resize(target.targetLength);
		for(int i=0; i<target.targetLength; i++){
			float temp;
			in >> temp;
			data_to[i]=temp;
		}
		return true;
	}
	else if(strand==-1){
		if(file.isOpen()){
			file.close();	
		}
		file.open(QIODevice::ReadOnly);
		if(!file.isOpen()){
			return false;
		}
		file.seek(target.rvDataOffset);
		QByteArray data=file.read(target.rvDataSize);
		QBuffer buffer(&data);
		buffer.open(QIODevice::ReadOnly);
		QDataStream in(&buffer);

		#if QT_VERSION >= 0x040600
		in.setFloatingPointPrecision(QDataStream::SinglePrecision);
		#endif
		
		data_to.resize(target.targetLength);
		for(int i=0; i<target.targetLength; i++){
			float temp;
			in >> temp;
			data_to[i]=temp;
		}
		return true;
	}
	else{
		return false;
	}

}

bool FileReader::getData(	const QString& target_name,
							const quint32& start,
							const quint32& end,
							const qint32& strand,
							QVector<quint32>& data_to)
{
	if(header.dataType!=Integer){
		return false;
	}
	if(start>end){
		return false;
	}
	if(!targetMap.contains(target_name)){
		return false;
	}
	Target& target=targetList[targetMap[target_name]];
	if(end>target.targetLength){
		return false;
	}

	//�t�@�C�����̃f�[�^��strandspecific�������łȂ����ŕ���

	//strand�𕪗����Ȃ��ꍇ
	if(header.strandSpecificity==UnifyStrands){

		if(file.isOpen()){
			file.close();	
		}
		file.open(QIODevice::ReadOnly);
		if(!file.isOpen()){
			return false;
		}

		int sizeofint=target.fwDataSize/target.targetLength;
		int offset=sizeofint*(start-1);
		int datacount=end-start+1;
		int datasize=sizeofint*datacount;

		file.seek(target.fwDataOffset+offset);
		QByteArray data=file.read(datasize);
		QBuffer buffer(&data);
		buffer.open(QIODevice::ReadOnly);
		QDataStream in(&buffer);
		data_to.resize(datacount);
		for(int i=0; i<datacount; i++){
			qint32 temp;
			in >> temp;
			if(header.version==3){
				data_to[i]=temp&0x7FFF;
			}
			else{
				data_to[i]=temp;
			}
		}
		return true;		

	}
	//�ȉ���strand�𕪗�����ꍇ
	else if(strand==1){
		if(file.isOpen()){
			file.close();	
		}
		file.open(QIODevice::ReadOnly);
		if(!file.isOpen()){
			return false;
		}

		int sizeofint=target.fwDataSize/target.targetLength;
		int offset=sizeofint*(start-1);
		int datacount=end-start+1;
		int datasize=sizeofint*datacount;

		file.seek(target.fwDataOffset+offset);
		QByteArray data=file.read(datasize);
		QBuffer buffer(&data);
		buffer.open(QIODevice::ReadOnly);
		QDataStream in(&buffer);
		data_to.resize(datacount);
		for(int i=0; i<datacount; i++){
			qint32 temp;
			in >> temp;
			if(header.version==3){
				data_to[i]=temp&0x7FFF;
			}
			else{
				data_to[i]=temp;
			}
		}
		return true;
	}
	else if(strand==-1){
		if(file.isOpen()){
			file.close();	
		}
		file.open(QIODevice::ReadOnly);
		if(!file.isOpen()){
			return false;
		}

		int sizeofint=target.rvDataSize/target.targetLength;
		int offset=sizeofint*(start-1);
		int datacount=end-start+1;
		int datasize=sizeofint*datacount;

		file.seek(target.rvDataOffset+offset);
		QByteArray data=file.read(datasize);
		QBuffer buffer(&data);
		buffer.open(QIODevice::ReadOnly);
		QDataStream in(&buffer);
		data_to.resize(datacount);
		for(int i=0; i<datacount; i++){
			qint32 temp;
			in >> temp;
			if(header.version==3){
				data_to[i]=temp&0x7FFF;
			}
			else{
				data_to[i]=temp;
			}
		}
		return true;
	}
	else{
		return false;
	}

}



//strandspecific��seperate�̏ꍇ�̂ݗL��
bool FileReader::getData(	const QString& target_name,
							const quint32& start,
							const quint32& end,
							const qint32& strand,
							QVector<quint32>& data_to_1,
							QVector<quint32>& data_to_2)
{
	if(header.dataType!=Integer){
		return false;
	}
	if(start>end){
		return false;
	}
	if(!targetMap.contains(target_name)){
		return false;
	}
	Target& target=targetList[targetMap[target_name]];
	if(end>target.targetLength){
		return false;
	}

	if(strand==0||strand==-2){
		if(file.isOpen()){
			file.close();	
		}
		file.open(QIODevice::ReadOnly);
		if(!file.isOpen()){
			return false;
		}

		int sizeofint=target.fwDataSize/target.targetLength;
		int offset=sizeofint*(start-1);
		int datacount=end-start+1;
		int datasize=sizeofint*datacount;

		file.seek(target.fwDataOffset+offset);
		QByteArray data=file.read(datasize);
		QBuffer buffer(&data);
		buffer.open(QIODevice::ReadOnly);
		QDataStream in(&buffer);
		data_to_1.resize(datacount);


		for(int i=0; i<datacount; i++){
			qint32 temp;
			in >> temp;
			if(header.version==3){
				data_to_1[i]=temp&0x7FFF;
			}
			else{
				data_to_1[i]=temp;
			}
		}
	
	    int sizeofint2=target.rvDataSize/target.targetLength;
		int offset2=sizeofint2*(start-1);
		int datacount2=end-start+1;
		int datasize2=sizeofint2*datacount2;

		file.seek(target.rvDataOffset+offset);
		QByteArray data2=file.read(datasize2);
		QBuffer buffer2(&data2);
		buffer2.open(QIODevice::ReadOnly);
		QDataStream in2(&buffer2);
		data_to_2.resize(datacount2);
		
		for(int i=0; i<datacount2; i++){
			qint32 temp2;
			in2 >> temp2;
			if(header.version==3){
				data_to_2[i]=temp2&0x7FFF;
			}
			else{
				data_to_2[i]=temp2;
			}
		}
		return true;
	}

	else{
		return false;
	}

}





bool FileReader::getData(	const QString& target_name,
							const quint32& start,
							const quint32& end,
							const qint32& strand,
							QVector<float>& data_to)
{
	if(header.dataType!=Float){
		return false;
	}
	if(start>end){
		return false;
	}
	if(!targetMap.contains(target_name)){
		return false;
	}
	Target& target=targetList[targetMap[target_name]];
	if(end>target.targetLength){
		return false;
	}
	if(strand==1){
		if(file.isOpen()){
			file.close();	
		}
		file.open(QIODevice::ReadOnly);
		if(!file.isOpen()){
			return false;
		}

		qint64 sizeofint=target.fwDataSize/target.targetLength;
		qint64 offset=sizeofint*(start-1);
		qint64 datacount=end-start+1;
		qint64 datasize=sizeofint*datacount;

		file.seek(target.fwDataOffset+offset);
		QByteArray data=file.read(datasize);
		QBuffer buffer(&data);
		buffer.open(QIODevice::ReadOnly);
		QDataStream in(&buffer);

		#if QT_VERSION >= 0x040600
		in.setFloatingPointPrecision(QDataStream::SinglePrecision);
		#endif
		data_to.resize(datacount);
		for(int i=0; i<datacount; i++){
			float temp;
			in >> temp;
			data_to[i]=temp;
		}
		return true;
	}
	else if(strand==-1){
		if(file.isOpen()){
			file.close();	
		}
		file.open(QIODevice::ReadOnly);
		if(!file.isOpen()){
			return false;
		}

		qint64 sizeofint=target.rvDataSize/target.targetLength;
		qint64 offset=sizeofint*(start-1);
		qint64 datacount=end-start+1;
		qint64 datasize=sizeofint*datacount;

		file.seek(target.rvDataOffset+offset);
		QByteArray data=file.read(datasize);
		QBuffer buffer(&data);
		buffer.open(QIODevice::ReadOnly);
		QDataStream in(&buffer);
		
		#if QT_VERSION >= 0x040600
		in.setFloatingPointPrecision(QDataStream::SinglePrecision);
		#endif

		data_to.resize(datacount);
		for(int i=0; i<datacount; i++){
			float temp;
			in >> temp;
			data_to[i]=temp;
		}
		return true;
	}
	else{
		return false;
	}

}

//strandspecific��seperate�̏ꍇ�̂ݗL��
bool FileReader::getData(	const QString& target_name,
							const quint32& start,
							const quint32& end,
							const qint32& strand,
							QVector<float>& data_to_1,
							QVector<float>& data_to_2)
{
	if(header.dataType!=Float){
		return false;
	}
	if(start>end){
		return false;
	}
	if(!targetMap.contains(target_name)){
		return false;
	}
	Target& target=targetList[targetMap[target_name]];
	if(end>target.targetLength){
		return false;
	}

	if(strand==0||strand==-2){
		if(file.isOpen()){
			file.close();	
		}
		file.open(QIODevice::ReadOnly);
		if(!file.isOpen()){
			return false;
		}

		int sizeofint=target.fwDataSize/target.targetLength;
		int offset=sizeofint*(start-1);
		int datacount=end-start+1;
		int datasize=sizeofint*datacount;

		file.seek(target.fwDataOffset+offset);
		QByteArray data=file.read(datasize);
		QBuffer buffer(&data);
		buffer.open(QIODevice::ReadOnly);
		QDataStream in(&buffer);
		data_to_1.resize(datacount);


		for(int i=0; i<datacount; i++){
			qint32 temp;
			in >> temp;
			if(header.version==3){
				data_to_1[i]=temp&0x7FFF;
			}
			else{
				data_to_1[i]=temp;
			}
		}
	
	    int sizeofint2=target.rvDataSize/target.targetLength;
		int offset2=sizeofint2*(start-1);
		int datacount2=end-start+1;
		int datasize2=sizeofint2*datacount2;

		file.seek(target.rvDataOffset+offset);
		QByteArray data2=file.read(datasize2);
		QBuffer buffer2(&data2);
		buffer2.open(QIODevice::ReadOnly);
		QDataStream in2(&buffer2);
		data_to_2.resize(datacount2);
		
		for(int i=0; i<datacount2; i++){
			qint32 temp2;
			in2 >> temp2;
			if(header.version==3){
				data_to_2[i]=temp2&0x7FFF;
			}
			else{
				data_to_2[i]=temp2;
			}
		}
		return true;
	}

	else{
		return false;
	}

}


bool FileReader::getAnnotation(
		const QString& target_name,
		const qint32& strand,
		QBitArray& annotation_to)
{
	if(header.dataType!=Integer||header.version!=3){
		return false;
	}
	if(!targetMap.contains(target_name)){
		return false;
	}
	Target& target=targetList[targetMap[target_name]];

	//�t�@�C�����̃f�[�^��strandspecific�������łȂ����ŕ���

	//strand�𕪗����Ȃ��ꍇ
	if(header.strandSpecificity==UnifyStrands){

		if(file.isOpen()){
			file.close();	
		}
		file.open(QIODevice::ReadOnly);
		if(!file.isOpen()){
			return false;
		}

		file.seek(target.fwDataOffset);
		QByteArray data=file.read(target.fwDataSize);
		QBuffer buffer(&data);
		buffer.open(QIODevice::ReadOnly);
		QDataStream in(&buffer);
		annotation_to.resize(target.targetLength);
		for(int i=0; i<target.targetLength; i++){
			quint32 temp;
			in >> temp;
			if(temp&0x80000000){
				annotation_to[i]=true;
			}
			else{
				annotation_to[i]=false;
			}
		}
		return true;		

	}
	//�ȉ���strand�𕪗�����ꍇ
	else if(strand==1){
		if(file.isOpen()){
			file.close();	
		}
		file.open(QIODevice::ReadOnly);
		if(!file.isOpen()){
			return false;
		}

		file.seek(target.fwDataOffset);
		QByteArray data=file.read(target.fwDataSize);
		QBuffer buffer(&data);
		buffer.open(QIODevice::ReadOnly);
		QDataStream in(&buffer);
		annotation_to.resize(target.targetLength);
		for(int i=0; i<target.targetLength; i++){
			quint32 temp;
			in >> temp;
			if(temp&0x80000000){
				annotation_to[i]=true;
			}
			else{
				annotation_to[i]=false;
			}
		}
		return true;
	}
	else if(strand==-1){
		if(file.isOpen()){
			file.close();	
		}
		file.open(QIODevice::ReadOnly);
		if(!file.isOpen()){
			return false;
		}

		file.seek(target.rvDataOffset);
		QByteArray data=file.read(target.rvDataSize);
		QBuffer buffer(&data);
		buffer.open(QIODevice::ReadOnly);
		QDataStream in(&buffer);
		annotation_to.resize(target.targetLength);
		for(int i=0; i<target.targetLength; i++){
			quint32 temp;
			in >> temp;
			if(temp&0x80000000){
				annotation_to[i]=true;
			}
			else{
				annotation_to[i]=false;
			}
		}
		return true;
	}
	else{
		return false;
	}

}


bool FileReader::getAnnotation(
		const QString& target_name,
		const quint32& start,
		const quint32& end,
		const qint32& strand,
		QBitArray& annotation_to)
{
	if(header.dataType!=Integer||header.version!=3){
		return false;
	}
	if(start>end){
		return false;
	}
	if(!targetMap.contains(target_name)){
		return false;
	}
	Target& target=targetList[targetMap[target_name]];
	if(end>target.targetLength){
		return false;
	}

	//�t�@�C�����̃f�[�^��strandspecific�������łȂ����ŕ���

	//strand�𕪗����Ȃ��ꍇ
	if(header.strandSpecificity==UnifyStrands){

		if(file.isOpen()){
			file.close();	
		}
		file.open(QIODevice::ReadOnly);
		if(!file.isOpen()){
			return false;
		}

		int sizeofint=target.fwDataSize/target.targetLength;
		int offset=sizeofint*(start-1);
		int datacount=end-start+1;
		int datasize=sizeofint*datacount;

		file.seek(target.fwDataOffset+offset);
		QByteArray data=file.read(datasize);
		QBuffer buffer(&data);
		buffer.open(QIODevice::ReadOnly);
		QDataStream in(&buffer);
		annotation_to.resize(datacount);
		for(int i=0; i<datacount; i++){
			quint32 temp;
			in >> temp;
			if(temp&0x80000000){
				annotation_to[i]=true;
			}
			else{
				annotation_to[i]=false;
			}
		}
		return true;		

	}
	//�ȉ���strand�𕪗�����ꍇ
	else if(strand==1){
		if(file.isOpen()){
			file.close();	
		}
		file.open(QIODevice::ReadOnly);
		if(!file.isOpen()){
			return false;
		}

		int sizeofint=target.fwDataSize/target.targetLength;
		int offset=sizeofint*(start-1);
		int datacount=end-start+1;
		int datasize=sizeofint*datacount;

		file.seek(target.fwDataOffset+offset);
		QByteArray data=file.read(datasize);
		QBuffer buffer(&data);
		buffer.open(QIODevice::ReadOnly);
		QDataStream in(&buffer);
		annotation_to.resize(datacount);
		for(int i=0; i<datacount; i++){
			quint32 temp;
			in >> temp;
			if(temp&0x80000000){
				annotation_to[i]=true;
			}
			else{
				annotation_to[i]=false;
			}
		}
		return true;
	}
	else if(strand==-1){
		if(file.isOpen()){
			file.close();	
		}
		file.open(QIODevice::ReadOnly);
		if(!file.isOpen()){
			return false;
		}

		int sizeofint=target.rvDataSize/target.targetLength;
		int offset=sizeofint*(start-1);
		int datacount=end-start+1;
		int datasize=sizeofint*datacount;

		file.seek(target.rvDataOffset+offset);
		QByteArray data=file.read(datasize);
		QBuffer buffer(&data);
		buffer.open(QIODevice::ReadOnly);
		QDataStream in(&buffer);
		annotation_to.resize(datacount);
		for(int i=0; i<datacount; i++){
			quint32 temp;
			in >> temp;
			if(temp&0x80000000){
				annotation_to[i]=true;
			}
			else{
				annotation_to[i]=false;
			}
		}
		return true;
	}
	else{
		return false;
	}

}