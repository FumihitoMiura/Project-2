#include "EncoderBasic.h"

using namespace DesktopTrack;

const quint8 EncoderBasic::onMask[8]={0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01};
const quint8 EncoderBasic::offMask[8]={0x7F, 0xBF, 0xDF, 0xEF, 0xF7, 0xFB, 0xFD, 0xFE};
quint64 EncoderBasic::sizeofInt=4;
quint64 EncoderBasic::maxValue=0x00000000FFFFFFFF;

EncoderBasic::EncoderBasic(void){}

EncoderBasic::~EncoderBasic(void){}

#ifndef INLINE

bool EncoderBasic::getBit(const quint8* s, quint64 pos)
{
	quint64 array_offset=pos/8;
	quint64 bit_offset=pos%8;	
	if(s[array_offset]&onMask[bit_offset]){
		return true;
	}
	else{
		return false;
	}
}

void EncoderBasic::setBit(quint8* s, quint64 pos, bool flag)
{
	quint64 array_offset=pos/8;
	quint64 bit_offset=pos%8;
	if(flag){
		s[array_offset]=s[array_offset]|onMask[bit_offset];
	}
	else{
		s[array_offset]=s[array_offset]&offMask[bit_offset];
	}
}

quint8 EncoderBasic::getChar(const quint8* s, quint64 pos)
{
	if(pos%2==0){
		return s[pos/2]>>4;
	}
	else{
		return s[pos/2]&0x0f;
	}
}

void EncoderBasic::setChar(quint8* s, quint64 pos, quint8 value)
{
	quint64 offset=pos/2;
	if(pos%2==0){
		s[offset]=(s[offset]&0x0f)|(value<<4);
	}
	else{
		s[offset]=(s[offset]&0xf0)|(value&0x0f);
	}
}


quint64 EncoderBasic::getInt(const quint8* s, quint64 pos)
{
	quint64 value=0;
	const quint8* c=s+pos*sizeofInt;
	int i=0;
	int j=sizeofInt-1;
	while(true){
		quint64 temp=(quint64)(c[i]);
		value=value|temp<<j*8;
		i++;
		j--;
		if(i>=sizeofInt){
			break;
		}
	}
	return value;
}

void EncoderBasic::setInt(quint8* s, quint64 pos, quint64 value)
{
	quint8 i=0;
	quint8 j=sizeofInt-1;
	quint8* c=s+pos*sizeofInt;
	while(true){
		c[i]=quint8(value>>j*8);
		i++;
		j--;
		if(i>=sizeofInt){
			break;
		}
	}
}

#endif

void EncoderBasic::setSizeofInt(quint64 byte_num)
{
	if(byte_num>8){
		return;
	}
	else{
		sizeofInt=byte_num;
		quint64 value[8]={	0x00000000000000FFULL,
							0x000000000000FFFFULL,
							0x0000000000FFFFFFULL,
							0x00000000FFFFFFFFULL,
							0x000000FFFFFFFFFFULL,
							0x0000FFFFFFFFFFFFULL,
							0x00FFFFFFFFFFFFFFULL,
							0xFFFFFFFFFFFFFFFFULL};
		maxValue=value[sizeofInt-1];
	}
}

quint64 EncoderBasic::getId(quint8* s, quint64 sl,
							quint64 pos, quint64 idLen)
{
    quint64 value=0;
    for(quint64 i=0; i<idLen; i++){
        if(pos+i>=sl){
            return maxValue;
        }
        quint64 temp=getChar(s, pos+i);
		if(temp==0||temp==5){
			return maxValue;
		}
        for(quint64 j=1; j<idLen-i; j++){
            temp*=6;
        }
        value+=temp;
    }
    return value;
}



