#ifndef SUFFIX_ARRAY_BASIC_H
#define SUFFIX_ARRAY_BASIC_H

#include <QtCore>
#include "DesktopTrackCommon.h"
#include "EncoderBasic.h"

namespace DesktopTrack{

    class SuffixArrayBasic:public EncoderBasic{
	public:
        SuffixArrayBasic(void);
        ~SuffixArrayBasic(void);

		void debugC(quint8* s, quint64 n, quint64 o);
		void debugC(quint8* s, quint8* SA, quint8* type, quint64 n);
		void debugI(quint8* s, quint8* SA, quint8* type, quint64 n);

		//SuffixArray�쐬�p
        bool SAISC(quint8* s, quint8* SA, quint64 n, quint64 k);
        bool SAISI(quint8* s, quint8* SA, quint64 n, quint64 k);

		//SuffixArray�����p�i��{�͂���j
		// quint8* s -> 4-bit encoded reference sequence
		// quint8* SA -> suffix array
		// quint64 sl -> length of reference
		// quint64 lb -> lower bound to start (equal or more than 0)
		// quint64 ub -> upper bound to start (less than length of sequence)
		// quint8* q -> 4-bit encoded query sequence
		// quint64 qo -> query offset
		// quint64 ql -> query length
		quint64	lowerBound(	quint8* s, quint8* SA, quint64 sl, 
							quint64 lb, quint64 ub, 
							quint8* q, quint64 qo, quint64 ql);
		quint64	upperBound(	quint8* s, quint8* SA, quint64 sl, 
							quint64 lb, quint64 ub, 
							quint8* q, quint64 qo, quint64 ql);

		//SuffixArray��v�z�񂩂�1�����L�΂��Ă���Ɍ���
		// quint8* s -> 4-bit encoded reference sequence
		// quint8* SA -> suffix array
		// quint64 sl -> length of reference
		// quint64 lb -> lower bound to start (equal or more than 0)
		// quint64 ub -> upper bound to start (less than length of sequence)
		// quint8* q -> 4-bit encoded query sequence
		// quint64 qo -> query offset
		// quint64 ql -> query length
		quint64	lowerBoundE(quint8* s, quint8* SA, quint64 sl, 
							quint64 lb, quint64 ub, 
							quint8* q, quint64 qo, quint64 ql);
		quint64	upperBoundE(quint8* s, quint8* SA, quint64 sl, 
							quint64 lb, quint64 ub, 
							quint8* q, quint64 qo, quint64 ql);

		quint64 calcBoosterIndexSize(quint64 ws);

		// quint8* s -> 4-bit encoded reference sequence
		// quint8* SA -> suffix array
		// quint64 sl -> length of reference
		// quint64 ws -> word size
		// quint8* BIdx -> booster index to be created
		// quint64 bl -> size of booster index (in bytes)
        bool createBoosterIndex(quint8* s, quint8* SA, quint64 sl,
                                quint64 ws, quint8* BIdx, quint64 bl);

        //
        bool searchBounds(quint8* BIdx, quint64 id,
                          quint64& lb, quint64& ub);

		// quint8* BIdxOrig -> booster index original
		// quint8* BIdxTo -> place store for created index
		// quint64 wsBefore -> word size before shrinking
		// quint64 wsAfter -> word size after shrinking
		bool shrinkBoosterIndex(quint8* BIdxOrig, quint8* BIdxTo,
								quint64 wsBefore, quint64 wsAfter); 


	};

};

#endif
