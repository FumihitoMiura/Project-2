#ifndef BMAP_FILE_H
#define BMAP_FILE_H

#include <QtCore>
#include <istream>
#include <new>
#include <vector>

#include "DesktopTrackCommon.h"
#include "SeqInfo.h"
#include "BinSeq.h"
#include "BWTBasic.h"
#include "QueryDispatcher.h"

namespace DesktopTrack{

	namespace BMapCore{

		struct Header{
			//magic
			qint32			magic;
			qint32			version;
			//basic
			QString			species;
			QString			revision;
			//target info
			quint64			targetListOffset;
			quint32			targetListDataSize;
			quint32			targetListDataCount;
			//basic info
			quint64			seqLength;		//include 0-termination
			quint64			sizeofInt;

			/*--- suffix array ---*/
			//genomic seq
			quint64			seqOffset;
			quint64			seqDataSize;
			//c2t seq and suffixarray
			quint64			c2tSeqOffset;
			quint64			c2tSeqDataSize;
			quint64			c2tSAOffset;
			quint64			c2tSADataSize;
			//g2a seq and suffixarray
			quint64			g2aSeqOffset;
			quint64			g2aSeqDataSize;
			quint64			g2aSAOffset;
			quint64			g2aSADataSize;

			/*--- BWT ---*/
			quint64			c2tBWTOffset;
			quint64			c2tBWTDataSize;
			quint64			g2aBWTOffset;
			quint64			g2aBWTDataSize;

            /*--- BoosterIndex ---*/
            quint64         bIdxWordSize;
            quint64         c2tBIdxOffset;
            quint64         c2tBIdxDataSize;
            quint64         g2aBIdxOffset;
            quint64         g2aBIdxDataSize;

			//
			Header(void);
			Header(const Header& original);
			Header& operator=(const Header& original);
			void putSerialized(QDataStream& out);
			void getSerialized(QDataStream& in);
		};

		struct Target{

			static quint64 sizeofInt;
			static void setSizeofInt(quint64 byte_num);

			QString		targetName;
			quint64		targetOffset;
			quint64		targetLength;

			Target(void);
			Target(	const QString& target_name, 
					const quint64& target_offset, 
					const quint64& target_length);
            Target(const Target& original);
			Target& operator=(const Target& original);
			void putSerialized(QDataStream& out);
			void getSerialized(QDataStream& in);
		};

	};

};

#endif
