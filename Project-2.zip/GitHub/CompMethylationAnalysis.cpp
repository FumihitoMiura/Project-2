#include "CompMethylationAnalysis.h"

using namespace DesktopTrack;

CompMethylationAnalysis::CompMethylationAnalysis(void):
    windowSize(1),
    stepSize(1),
    readThreshold(10),
    averageThreshold(1),
    minRateD1(0),
    maxRateD1(1),
    minRateD2(0),
    maxRateD2(1),
    imageScale(10),
    maxDepth(300),
	matrixSize(300){}

bool CompMethylationAnalysis::
setSpecies(const QString& pathToBinSeq){

    //BinSeqをセットする
    if(!binReader.setFile(pathToBinSeq)){
        return false;
    }
    //染色体の基本情報を取得
    targetList = binReader.getTargetList();
    probeMap.clear();
    for (int i = 0; i < targetList.size(); i++){
        //初期化は全部true
        probeMap[targetList[i].targetName] = QBitArray((int)targetList[i].targetLength, true);
    }
    return true;

}

bool CompMethylationAnalysis::
setProbeMap(const QString& pathToBam){

    //ファイルオープン
    QFile bedFile(pathToBam);
    bedFile.open(QIODevice::WriteOnly);
    if (!bedFile.isOpen()){
        return false;
    }

    //前提としてSpeciesの初期化がされている必要がある
    for (int i = 0; i < targetList.size(); i++){
        //初期化は全部false
        probeMap[targetList[i].targetName] = QBitArray((int)targetList[i].targetLength, false);
    }

    while (!bedFile.atEnd()){
        QStringList cols = QString(bedFile.readLine().trimmed()).split('\t');
        if (cols.size() >= 3){
            continue;
        }
        QBitArray& targetArray=probeMap[cols[0]];
        int begin = cols[1].toInt();
        int end = cols[2].toInt();
        if (begin < 1){
            continue;
        }
        if (begin > end){
            int temp = begin;
            begin = end;
            end = temp;
        }
        for (int i = begin-1; i < end; i++){
            targetArray.setBit(i, true);
        }
    }
    return true;
}

void CompMethylationAnalysis::
setReadnumberThreshold(const int num)
{
    readThreshold=num;
}

bool CompMethylationAnalysis::
setGraphFiles(
        const QString& pathToGraph1,
        const QString& pathToGraph2)
{

    if(!graphReader1.setFile(pathToGraph1)){
        return false;
    }
    if(!graphReader2.setFile(pathToGraph2)){
        return false;
    }
    return true;

}

void CompMethylationAnalysis::
setMatrixSize(int size){
    methyMatrix.clear();
    methyMatrix.resize(size);
    matrixSize=size;
}

void CompMethylationAnalysis::
setImageScale(int scale) {
	if (scale < 1) {
		return;
	}
	imageScale = scale;
}

void CompMethylationAnalysis::
setMaxDepth(int depth) {
	if (depth < 1) {
		return;
	}
	maxDepth = depth;
}

const QByteArray CompMethylationAnalysis::
reverseComplement(const QByteArray& seq)
{
    QByteArray result(seq);
    for(int i=0, j=seq.size()-1; i<seq.size(); i++, j--){
        if(seq[i]=='A'){
            result[j]='T';
        }
        else if(seq[i]=='C'){
            result[j]='G';
        }
        else if(seq[i]=='G'){
            result[j]='C';
        }
        else if(seq[i]=='T'){
            result[j]='A';
        }
        else if(seq[i]=='R'){
            result[j]='Y';
        }
        else if(seq[i]=='Y'){
            result[j]='R';
        }
        else if(seq[i]=='S'){
            result[j]='S';
        }
        else if(seq[i]=='W'){
            result[j]='W';
        }
        else if(seq[i]=='K'){
            result[j]='M';
        }
        else if(seq[i]=='M'){
            result[j]='K';
        }
        else if(seq[i]=='B'){
            result[j]='V';
        }
        else if(seq[i]=='D'){
            result[j]='H';
        }
        else if(seq[i]=='H'){
            result[j]='D';
        }
        else if(seq[i]=='V'){
            result[j]='B';
        }
        else if(seq[i]=='N'){
            result[j]='N';
        }
    }
    return result;
}

bool CompMethylationAnalysis::
patternMatch(
        const QByteArray& pattern,
        const QByteArray& sample)
{
    if(pattern.size()>sample.size()){
        return false;
    }
    for(int i=0; i<pattern.size(); i++){
         if(pattern[i]=='A'){
             if(sample[i]!='A'){
                 return false;
             }
         }
         else if(pattern[i]=='C'){
             if(sample[i]!='C'){
                 return false;
             }
         }
         else if(pattern[i]=='G'){
             if(sample[i]!='G'){
                 return false;
             }
         }
         else if(pattern[i]=='T'){
             if(sample[i]!='T'){
                 return false;
             }
         }
         else if(pattern[i]=='R'){
             if(sample[i]!='A'&&sample[i]!='G'){
                 return false;
             }
         }
         else if(pattern[i]=='Y'){
             if(sample[i]!='C'&&sample[i]!='T'){
                 return false;
             }
         }
         else if(pattern[i]=='S'){
             if(sample[i]!='G'&&sample[i]!='C'){
                 return false;
             }
         }
         else if(pattern[i]=='W'){
             if(sample[i]!='A'&&sample[i]!='T'){
                 return false;
             }
         }
         else if(pattern[i]=='K'){
             if(sample[i]!='G'&&sample[i]!='T'){
                 return false;
             }
         }
         else if(pattern[i]=='M'){
             if(sample[i]!='A'&&sample[i]!='C'){
                 return false;
             }
         }
         else if(pattern[i]=='B'){
             if(sample[i]!='C'&&sample[i]!='G'&&sample[i]!='T'){
                 return false;
             }
         }
         else if(pattern[i]=='D'){
             if(sample[i]!='A'&&sample[i]!='G'&&sample[i]!='T'){
                 return false;
             };
         }
         else if(pattern[i]=='H'){
             if(sample[i]!='A'&&sample[i]!='C'&&sample[i]!='T'){
                 return false;
             }
         }
         else if(pattern[i]=='V'){
             if(sample[i]!='A'&&sample[i]!='C'&&sample[i]!='G'){
                 return false;
             }
         }
         else if(pattern[i]=='N'){
             if(sample[i]!='A'&&sample[i]!='C'&&sample[i]!='G'&&sample[i]!='T'){
                 return false;
             }
         }
     }

    return true;
}

bool CompMethylationAnalysis::
patternMatch(
	const QByteArray& pattern, int posPattern,
	const QByteArray& sample, int posSample)
{
	
	for (int i = posPattern, j=posSample; i<pattern.size()&&j<sample.size(); i++, j++) {
		if (pattern[i] == 'A') {
			if (sample[j] != 'A') {
				return false;
			}
		}
		else if (pattern[i] == 'C') {
			if (sample[j] != 'C') {
				return false;
			}
		}
		else if (pattern[i] == 'G') {
			if (sample[j] != 'G') {
				return false;
			}
		}
		else if (pattern[i] == 'T') {
			if (sample[j] != 'T') {
				return false;
			}
		}
		else if (pattern[i] == 'R') {
			if (sample[j] != 'A'&&sample[j] != 'G') {
				return false;
			}
		}
		else if (pattern[i] == 'Y') {
			if (sample[j] != 'C'&&sample[j] != 'T') {
				return false;
			}
		}
		else if (pattern[i] == 'S') {
			if (sample[j] != 'G'&&sample[j] != 'C') {
				return false;
			}
		}
		else if (pattern[i] == 'W') {
			if (sample[j] != 'A'&&sample[j] != 'T') {
				return false;
			}
		}
		else if (pattern[i] == 'K') {
			if (sample[j] != 'G'&&sample[j] != 'T') {
				return false;
			}
		}
		else if (pattern[i] == 'M') {
			if (sample[j] != 'A'&&sample[j] != 'C') {
				return false;
			}
		}
		else if (pattern[i] == 'B') {
			if (sample[j] != 'C'&&sample[j] != 'G'&&sample[j] != 'T') {
				return false;
			}
		}
		else if (pattern[i] == 'D') {
			if (sample[j] != 'A'&&sample[j] != 'G'&&sample[j] != 'T') {
				return false;
			};
		}
		else if (pattern[i] == 'H') {
			if (sample[j] != 'A'&&sample[j] != 'C'&&sample[j] != 'T') {
				return false;
			}
		}
		else if (pattern[i] == 'V') {
			if (sample[j] != 'A'&&sample[j] != 'C'&&sample[j] != 'G') {
				return false;
			}
		}
		else if (pattern[i] == 'N') {
			if (sample[j] != 'A'&&sample[j] != 'C'&&sample[j] != 'G'&&sample[j] != 'T') {
				return false;
			}
		}
	}

	return true;

}

void CompMethylationAnalysis::
AnalyzeAll(
        const QByteArray& context,
        const int windowSize,
        const int stepSize)
{

    const QByteArray fwContext(context);
    const QByteArray rvContext(reverseComplement(context));
    const int contextSize=context.size();
	contextAnalyzed = context;

	methyMatrix.clear();
	methyMatrix.resize(matrixSize);
	methyMatrix.fill(QVector<int>(matrixSize, 0));

	depthMatrix.clear();
	depthMatrix.resize(matrixSize);
	depthMatrix.fill(QVector<int>(matrixSize, 0));

	//カバレッジの相関を計算するためのデータ保存領域
	QList<QPair<double, double> > pairData1;
	QTemporaryFile tempFile1;
	if (!tempFile1.open()) {
		cerr << "Couldn't open temporary file" << endl;
	}
	QDataStream temp1(&tempFile1);
	qint64 pCount1 = 0, eCount1 = 0;

	//メチル化率の相関を計算するためのデータ保存領域
    QList<QPair<double, double> > pairData2;
    QTemporaryFile tempFile2;
    if(!tempFile2.open()){
        cerr << "Couldn't open temporary file" << endl;
    }
    QDataStream temp2(&tempFile2);
    qint64 pCount2=0, eCount2=0;

    if(windowSize==1){

        //全てのtargetに対して計算
        for(int i=0; i<targetList.size(); i++){

            QString targetName=targetList[i].targetName;
            cout << targetName.toStdString() << endl;

            QByteArray seq;
            vector<quint16> CD1F, CD1R, CD2F, CD2R, MD1F, MD1R, MD2F, MD2R;

            if(!binReader.getSeq(targetName, seq)){
                cerr << "Couldn't obtain sequence data for \"" << targetName.toStdString() << "\"." << endl;
                continue;
            }
            if(!graphReader1.getData(targetName, 1, seq.size(), 1, MD1F, CD1F)){
                cerr << "Couldn't obtain data for \"" << targetName.toStdString() << "\"." << endl;
                continue;
            }
            if(!graphReader1.getData(targetName, 1, seq.size(), -1, MD1R, CD1R)){
                cerr << "Couldn't obtain data for \"" << targetName.toStdString() << "\"." << endl;
                continue;
            }
            if(!graphReader2.getData(targetName, 1, seq.size(), 1, MD2F, CD2F)){
                cerr << "Couldn't obtain data for \"" << targetName.toStdString() << "\"." << endl;
                continue;
            }
            if(!graphReader2.getData(targetName, 1, seq.size(), -1, MD2R, CD2R)){
                cerr << "Couldn't obtain data for \"" << targetName.toStdString() << "\"." << endl;
                continue;
            }
            if (!probeMap.contains(targetName)){
                cerr << "Couldn't obtain data for \"" << targetName.toStdString() << "\"." << endl;
                continue;
            }
            QBitArray& targetArray = probeMap[targetName];

            int limitPos=seq.size()-contextSize-1;
            for(int j=0; j<limitPos; j++){

                if (!targetArray[j]){
                    continue;
                }

                if(patternMatch(fwContext, 0, seq, j)){

                    qint32 dataCount1=CD1F[j];
                    qint32 methylCount1=MD1F[j];
                    qint32 dataCount2=CD2F[j];
                    qint32 methylCount2=MD2F[j];

					pairData1.append(qMakePair((double)dataCount1, (double)dataCount2));
					pCount1++;
					if (pairData1.size() >= 65536) {
						temp1 << pairData1;
						pairData1.clear();
						eCount1++;
					}

					int depth1 = (matrixSize - 1)*(dataCount1 < maxDepth ? dataCount1 : maxDepth) / maxDepth;
					int depth2 = (matrixSize - 1)*(dataCount2 < maxDepth ? dataCount2 : maxDepth) / maxDepth;
					depthMatrix[depth1][depth2]++;

                    if(dataCount1<readThreshold||dataCount2<readThreshold){
                        continue;
                    }

                    double m1=(double)methylCount1/(double)dataCount1;
                    double m2=(double)methylCount2/(double)dataCount2;

                    if (m1 < minRateD1){
                        continue;
                    }
                    if (m1 > maxRateD1){
                        continue;
                    }
                    if (m2 < minRateD2){
                        continue;
                    }
                    if (m2 > maxRateD2){
                        continue;
                    }

                    pairData2.append(qMakePair(m1, m2));
                    pCount2++;
                    if(pairData2.size()>=65536){
                        temp2 << pairData2;
                        pairData2.clear();
                        eCount2++;
                    }

					int rate1 = (int)floor((double)(matrixSize - 1)*m1);
					int rate2 = (int)floor((double)(matrixSize - 1)*m2);
					methyMatrix[rate1][rate2]++;

                }
                if(patternMatch(rvContext, 0, seq, j)){

                    int pos=j+contextSize-1;
                    qint32 dataCount1=CD1R[pos];
                    qint32 methylCount1=MD1R[pos];
                    qint32 dataCount2=CD2R[pos];
                    qint32 methylCount2=MD2R[pos];

					pairData1.append(qMakePair((double)dataCount1, (double)dataCount2));
					pCount1++;
					if (pairData1.size() >= 65536) {
						temp1 << pairData1;
						pairData1.clear();
						eCount1++;
					}

					int depth1 = (matrixSize - 1)*(dataCount1 < maxDepth ? dataCount1 : maxDepth) / maxDepth;
					int depth2 = (matrixSize - 1)*(dataCount2 < maxDepth ? dataCount2 : maxDepth) / maxDepth;
					depthMatrix[depth1][depth2]++;

                    if(dataCount1<readThreshold||dataCount2<readThreshold){
                        continue;
                    }

                    double m1=(double)methylCount1/(double)dataCount1;
                    double m2=(double)methylCount2/(double)dataCount2;

                    if (m1 < minRateD1){
                        continue;
                    }
                    if (m1 > maxRateD1){
                        continue;
                    }
                    if (m2 < minRateD2){
                        continue;
                    }
                    if (m2 > maxRateD2){
                        continue;
                    }

                    pairData2.append(qMakePair(m1, m2));
                    pCount2++;
                    if(pairData2.size()>=65536){
                        temp2 << pairData2;
                        pairData2.clear();
                        eCount2++;
                    }

					int rate1 = (int)floor((double)(matrixSize - 1)*m1);
					int rate2 = (int)floor((double)(matrixSize - 1)*m2);
                    methyMatrix[rate1][rate2]++;

                }

            }

        }

        //ペアデータを一旦TempFileにフラッシュ
        if(pairData2.size()>0){
            temp2 << pairData2;
            pairData2.clear();
            eCount2++;
        }

    }
    else if(windowSize>1){

        //全てのtargetに対して計算
        for(int i=0; i<targetList.size(); i++){

            QString targetName=targetList[i].targetName;
            cout << targetName.toStdString() << endl;

            QByteArray seq;
            QVector<quint16> CD1F, CD1R, CD2F, CD2R, MD1F, MD1R, MD2F, MD2R;

            if(!binReader.getSeq(targetName, seq)){
                cerr << "Couldn't obtain sequence data for \"" << targetName.toStdString() << "\"." << endl;
                continue;
            }
            if(!graphReader1.getData(targetName, 1, seq.size(), 1, MD1F, CD1F)){
                cerr << "Couldn't obtain data for \"" << targetName.toStdString() << "\"." << endl;
                continue;
            }
            if(!graphReader1.getData(targetName, 1, seq.size(), -1, MD1R, CD1R)){
                cerr << "Couldn't obtain data for \"" << targetName.toStdString() << "\"." << endl;
                continue;
            }
            if(!graphReader2.getData(targetName, 1, seq.size(), 1, MD2F, CD2F)){
                cerr << "Couldn't obtain data for \"" << targetName.toStdString() << "\"." << endl;
                continue;
            }
            if(!graphReader2.getData(targetName, 1, seq.size(), -1, MD2R, CD2R)){
                cerr << "Couldn't obtain data for \"" << targetName.toStdString() << "\"." << endl;
                continue;
            }

            if (!probeMap.contains(targetName)){
                cerr << "Couldn't obtain data for \"" << targetName.toStdString() << "\"." << endl;
                continue;
            }
            QBitArray& targetArray = probeMap[targetName];

            int limitPos=seq.size()-windowSize-contextSize-1;
            for(int w=0; w<limitPos; w+=stepSize){

                double m1(0), m2(0);
				qint64 r1(0), r2(0);
				qint64 dcount = 0;
				qint64 mcount=0;

				for (int j = w; j < w + windowSize; j++) {

					if (!targetArray[j]) {
						continue;
					}

					if (patternMatch(fwContext, 0, seq, j)) {

						qint32 dataCount1 = CD1F[j];
						qint32 methylCount1 = MD1F[j];
						qint32 dataCount2 = CD2F[j];
						qint32 methylCount2 = MD2F[j];

						r1 += dataCount1;
						r2 += dataCount2;
						dcount++;

						if (dataCount1 < readThreshold || dataCount2 < readThreshold) {
							continue;
						}

						m1 += (double)methylCount1 / (double)dataCount1;
						m2 += (double)methylCount2 / (double)dataCount2;
						mcount++;

					}
					if (patternMatch(rvContext, 0, seq, j)) {

						int pos = j + contextSize - 1;

						qint32 dataCount1 = CD1R[pos];
						qint32 methylCount1 = MD1R[pos];
						qint32 dataCount2 = CD2R[pos];
						qint32 methylCount2 = MD2R[pos];

						r1 += dataCount1;
						r2 += dataCount2;
						dcount++;

						if (dataCount1 < readThreshold || dataCount2 < readThreshold) {
							continue;
						}

						m1 += (double)methylCount1 / (double)dataCount1;
						m2 += (double)methylCount2 / (double)dataCount2;
						mcount++;

					}

				}

				if (dcount > 0) {
					r1 /= dcount;
					r2 /= dcount;
				}

				pairData1.append(qMakePair((double)r1, (double)r2));
				pCount1++;
				if (pairData1.size() >= 65536) {
					temp1 << pairData1;
					pairData1.clear();
					eCount1++;
				}

				int depth1 = (matrixSize - 1)*(r1 < maxDepth ? r1 : maxDepth) / maxDepth;
				int depth2 = (matrixSize - 1)*(r2 < maxDepth ? r2 : maxDepth) / maxDepth;
				depthMatrix[depth1][depth2]++;

                if(mcount>averageThreshold){
                    m1/=(double)mcount;
                    m2/=(double)mcount;


                    if (m1 < minRateD1){
                        continue;
                    }
                    if (m1 > maxRateD1){
                        continue;
                    }
                    if (m2 < minRateD2){
                        continue;
                    }
                    if (m2 > maxRateD2){
                        continue;
                    }

                    pairData2.append(qMakePair(m1, m2));
                    pCount2++;
                    if(pairData2.size()>=65536){
                        temp2 << pairData2;
                        pairData2.clear();
                        eCount2++;
                    }
                    int rate1=(int)floor((double)(matrixSize-1)*m1);
                    int rate2=(int)floor((double)(matrixSize-1)*m2);
                    methyMatrix[rate1][rate2]++;
					
                }
            }
        }

        //ペアデータを一旦フラッシュ
		if (pairData1.size()>0) {
			temp1 << pairData1;
			pairData1.clear();
			eCount1++;
		}
        if(pairData2.size()>0){
            temp2 << pairData2;
            pairData2.clear();
            eCount2++;
        }

    }

	//カバレッジの直線回帰
	//まずは平均値の計算
	tempFile1.seek(0);
	double avex1 = 0;
	double avey1 = 0;
	for (int c = 0; c<eCount1; c++) {
		temp1 >> pairData1;
		for (int i = 0; i<pairData1.size(); i++) {
			avex1 += (double)pairData1[i].first;
			avey1 += (double)pairData1[i].second;
		}
	}
	avex1 /= (double)pCount1;
	avey1 /= (double)pCount1;
	//次いでブレの計算
	double sxx1 = 0;
	double syy1 = 0;
	double sxy1 = 0;
	tempFile1.seek(0);
	for (int c = 0; c<eCount1; c++) {
		temp1 >> pairData1;
		for (int i = 0; i<pairData1.size(); i++) {
			sxx1 += ((double)pairData1[i].first - avex1)*((double)pairData1[i].first - avex1);
			syy1 += ((double)pairData1[i].second - avey1)*((double)pairData1[i].second - avey1);
			sxy1 += ((double)pairData1[i].first - avex1)*((double)pairData1[i].second - avey1);
		}
	}
	pairData1.clear();

	//計算されたパラメータをオブジェクト内に保存
	cSlope = sxy1 / sxx1;
	cIntercept = -cSlope*avex1 + avey1;
	cCorrel = sxy1*sxy1 / sxx1 / syy1;

    //メチル化率の直線回帰
    //まずは平均値の計算
    tempFile2.seek(0);
    double avex2=0;
    double avey2=0;
    for(int c=0; c<eCount2; c++){
        temp2 >> pairData2;
        for(int i=0; i<pairData2.size(); i++){
            avex2+= (double)pairData2[i].first;
            avey2+= (double)pairData2[i].second;
        }
    }
    avex2/=(double)pCount2;
    avey2/=(double)pCount2;
    //次いでブレの計算
    double sxx2=0;
    double syy2=0;
    double sxy2=0;
    tempFile2.seek(0);
    for(int c=0; c<eCount2; c++){
        temp2 >> pairData2;
        for(int i=0; i<pairData2.size(); i++){
            sxx2+=((double)pairData2[i].first-avex2)*((double)pairData2[i].first-avex2);
            syy2+=((double)pairData2[i].second-avey2)*((double)pairData2[i].second-avey2);
            sxy2+=((double)pairData2[i].first-avex2)*((double)pairData2[i].second-avey2);
        }
    }
	pairData2.clear();

    //計算されたパラメータをオブジェクト内に保存
    mSlope=sxy2/sxx2;
    mIntercept=-mSlope*avex2+avey2;
    mCorrel=sxy2*sxy2/sxx2/syy2;

}

void CompMethylationAnalysis::
DrawChart(
        const QString& filePath)
{

    //Imageの準備
    QImage image(matrixSize, matrixSize, QImage::Format_ARGB32);

    for(int i=0; i<matrixSize; i++){

        for(int j=0; j<matrixSize; j++){

            int intensity=methyMatrix[i][j];
            if(intensity>imageScale){
                intensity=imageScale;
            }
            intensity=255-intensity*255/imageScale;
            image.setPixel(i, j, QColor(intensity, intensity, intensity).rgb());

        }

    }
    //ファイルの準備
    QFile out(filePath);
    out.open(QIODevice::WriteOnly);
    if(!out.isOpen()){
        return;
    }
    //ファイルへの書込
    QImageWriter writer(&out, "png");
    if(writer.canWrite()){
        writer.write(image.mirrored(false, true));
    }
    else{
        return;
    }

}

void CompMethylationAnalysis::
DrawThermoChart(
        const QString& filePath)
{

    //データ確認
    //x軸
    int size_x = methyMatrix.size();
    if (size_x == 0){
        return;
    }
    int size_y = methyMatrix[0].size();
    if (size_y == 0){
        return;
    }

    //プロット準備
    QCustomPlot* customPlot = new QCustomPlot;
    customPlot->axisRect()->setupFullAxesBox(true);
    customPlot->xAxis->setLabel(QString(QString("Methylation Rate (") + graphReader1.getBasicTrackInfo().trackName + QString(") [%]")));
    customPlot->yAxis->setLabel(QString(QString("Methylation Rate (") + graphReader2.getBasicTrackInfo().trackName + QString(") [%]")));

    //QVector<double> data_list;
    QCPColorMap *colorMap = new QCPColorMap(customPlot->xAxis, customPlot->yAxis);
    customPlot->addPlottable(colorMap);
    colorMap->data()->setSize(size_x, size_y);
    colorMap->data()->setRange(QCPRange(0, 100), QCPRange(0, 100));
    for (int x = 0; x < size_x; ++x)
    {
        for (int y = 0; y < size_y; ++y)
        {
            colorMap->data()->setCell(x, y, (double)methyMatrix[x][y]);
        }
    }

    //カラースケール
    QCPColorScale *colorScale = new QCPColorScale(customPlot);
    colorScale->axis()->setLabel(QString("Comparison of methylome data"));
    colorScale->setDataRange(QCPRange(0, (double)imageScale));
    colorScale->setType(QCPAxis::atRight); // scale shall be vertical bar with tick/axis labels right (actually atRight is already the default)
    colorMap->setColorScale(colorScale); // associate the color map with the color scale
    customPlot->plotLayout()->addElement(0, 1, colorScale); // add it to the right of the main axis rect

    //グラジエントタイプ
    colorMap->setGradient(QCPColorGradient::gpPolar);

    QCPMarginGroup *marginGroup = new QCPMarginGroup(customPlot);
    customPlot->axisRect()->setMarginGroup(QCP::msBottom | QCP::msTop, marginGroup);
    colorScale->setMarginGroup(QCP::msBottom | QCP::msTop, marginGroup);
    customPlot->rescaleAxes();
    customPlot->savePng(filePath, 600, 500, 1);

}

void CompMethylationAnalysis::
DrawCoverageChart(
        const QString& filePath)
{
	//Imageの準備
	QImage image(matrixSize, matrixSize, QImage::Format_ARGB32);

	for (int i = 0; i<matrixSize; i++) {

		for (int j = 0; j<matrixSize; j++) {

			int intensity = depthMatrix[i][j];
			if (intensity>imageScale) {
				intensity = imageScale;
			}
			intensity = 255 - intensity * 255 / imageScale;
			image.setPixel(i, j, QColor(intensity, intensity, intensity).rgb());

		}

	}
	//ファイルの準備
	QFile out(filePath);
	out.open(QIODevice::WriteOnly);
	if (!out.isOpen()) {
		return;
	}
	//ファイルへの書込
	QImageWriter writer(&out, "png");
	if (writer.canWrite()) {
		writer.write(image.mirrored(false, true));
	}
	else {
		return;
	}
}

void CompMethylationAnalysis::
OutputParameters(
	const QString& filePath)
{
	//ファイルの準備
	QFile out(filePath);
	out.open(QIODevice::WriteOnly);
	if (!out.isOpen()) {
		return;
	}
	QTextStream outstream(&out);

	outstream
		<< "Dataset 1  :" << graphReader1.getBasicTrackInfo().trackName << endl
		<< "Dataset 2  :" << graphReader2.getBasicTrackInfo().trackName << endl
		<< "Context    :" << contextAnalyzed << endl
		<< "Window     :" << windowSize << endl
		<< "Step       :" << stepSize << endl
		<< "Coverage" << endl
		<< "  Slope    :" << (double)cSlope << endl
		<< "  Intercept:" << (double)cIntercept << endl
		<< "  Coeff.   :" << (double)cCorrel << endl
		<< "Methylation Level" << endl
		<< "  Slope    :" << (double)mSlope << endl
		<< "  Intercept:" << (double)mIntercept << endl
		<< "  Coeff.   :" << (double)mCorrel << endl;
	
}

