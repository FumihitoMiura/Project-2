#ifndef GRAPH_TRACK_H
#define GRAPH_TRACK_H

#include <QtCore>
#include <QtXml>
#if QT_VERSION >= 0x050000
#include <QtWidgets>
#else
#include <QtGui>
#endif

#include "GraphTrackCGIParam.h"
#include "GraphFile.h"
#include "DesktopTrackCommon.h"

namespace DesktopTrack{

	class GraphTrack{
	public:
		GraphTrack(void);
		bool							printTrackLayer(void);

	protected:

		GraphTrackCGIParam				CGIParam;

		//
		bool	printTrackList(void);
		bool	printTrackDescription(void);

		//�X�P�[���`��i�œK�ȃX�P�[����`�悵�A�X�P�[���̍ő�l��Ԃ��j
		bool	drawGrad(
					const quint32& highest,
					QImage& image,
					QPainter& painter,
					quint32& strand,
					quint32& dataType,
					bool showLine);

		bool	drawIndexGrad(
					const quint32& highest,
					QImage& image,
					QFont& font,
					QPainter& painter,
					bool changeScale,
					quint32& strand,
					quint32& dataType,
					bool showLine);

		//�u���E�U�[���C���[
		bool	printImage(void);
		bool	printIndexImage(void);
		bool	printOperation(void);
		bool	printIndexOperation(void);

		//�⏕�֐�
		int		getMinimumLargerGrad(int value);
		void	printBackground(QImage* imagePtr, const QColor& color);

	};

};

#endif

