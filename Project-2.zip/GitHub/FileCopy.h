#ifndef FILECOPY_H
#define FILECOPY_H

#include <QtCore>
#if QT_VERSION >= 0x050000
#include <QtWidgets>
#else
#include <QtGui>
#endif
#include "DesktopTrackCommon.h"

namespace DesktopTrack{

    class FileCopy: public QThread{
        Q_OBJECT
    public:
        enum Process{processing, stopped, finished};

        FileCopy(QObject* parent=0);
        bool setFiles(
                const QStringList& origFiles,
                const QStringList& destFiles);
        //Thread Safe
        void setOrder(bool proceed);
        //Thread Safe
        void getProcessStatus(
                Process& process_status,
                quint64& prosessed_data,
                quint64& total_data);

    private:
        //-----thread�ԒʐM�p�ϐ���������-----
        QMutex	mutex;
        bool	promoteProcess;
        Process processStatus;
        quint64	processedData;
        quint64	totalData;
        //-----thread�ԒʐM�p�ϐ������܂�-----

        QStringList origFiles;
        QStringList destFiles;


        void run(void);

        //Thread Safe
        void setProcessStatus(	const Process& process_status,
                                const quint64& prosessed_data,
                                const quint64& total_data);
        //Thread Safe
        bool getOrder(void);


    };

};

#endif // FILECOPY_H
