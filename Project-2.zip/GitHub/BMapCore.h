#ifndef BMAP_CORE_H
#define BMAP_CORE_H


#include <QtCore>
#include <QString>
#include <QThread>
#include <istream>
#include <new>
#include <vector>
#include <iostream>
#include <cstring>

#include "DesktopTrackCommon.h"
#include "SeqInfo.h"
#include "BinSeq.h"
#include "BWTBasic.h"
#include "QueryDispatcher.h"
#include "BMapThread.h"
#include "BMapFile.h"

#include "zlib/zlib.h"

namespace DesktopTrack{

	namespace BMapCore{


        class BMapPrep:public QThread, BWTBasic{
            Q_OBJECT
		private:

			QString	pathToBinseq;
			QString targetFilePath;
		public:

            void run(void);
            BMapPrep(QObject* parent=0);
			bool setBinSeq(const QString& path_to_binseq);
			bool setTargetFilePath(const QString& path_to_target_file);

		};

        struct SeedInfo:public EncoderBasic{
            //properties
            quint32 queryOffset;
            quint16 queryLength;
            quint64 seedHitOffset;
            quint8  seedHitType;    //type=1, 2, 3 or 4

            //functions
            SeedInfo(void);
            SeedInfo(
                    const SeedInfo& original);
            SeedInfo(
                    const quint32& queryOffset,
                    const quint16& queryLength,
                    const quint64& seedHitOffset,
                    const quint8& seedHitType);
            SeedInfo& operator=(const SeedInfo& original);
            void pushSerialized(QByteArray& to);
        };

        class BMapCore: public QObject, BWTBasic{
			Q_OBJECT
		public:

		private:
			const static quint64				readAmountMax=0x000000003FFFFFFF;
			quint64								stepSize;
			quint64								unitNumber;
			quint64								unitNumberMax;
            quint64								bufferSizeMax;
			bool								useSuffixArray;
			Header								header;
			QList<Target>						targetList;


			//seed finding
			quint64								seedOffset;
			quint64								seedLength;
			quint64								seedLengthMax;
			quint64								seedFreqMax;
			quint64								seedStep;
			quint64								seedIterate;
			quint64								minSeedHit;
			qint64								minAlnScore;

			//reference
			quint64								refLen;
			quint8*								refSeq;
            quint64                             bIdxWordSize;
			quint8*								c2tSeq;
            quint8*         					c2tSA;
            quint8*                             c2tBIdx;
            quint64*							c2tBKT;
			quint8*								c2tBWT;
            quint8* 							c2tMCB[6];
			quint8*								g2aSeq;
			quint8*								g2aSA;
            quint8*                             g2aBIdx;
            quint64*							g2aBKT;
			quint8*								g2aBWT;
            quint8* 							g2aMCB[6];

			QTime								time;
			
			//query
			QStringList							pathsToQueryFiles;
			QList<QueryDispatcher::FileFormat>	queryFileFormats;
			int									currentQueryFileIndex;
			QueryDispatcher						queryDispatcher;
			quint64								processed;
			//thread
			QList<BMapThread*>					bmapThreads;
			//IO
			QMutex								mutex;
	
			QByteArray							bsAlnBuff;
			QFile								bsAlnFile;
			bool								alnOutCompressed;
			z_stream							alnStream;

			QByteArray							bsSumBuff;
			QFile								bsSumFile;
			bool								sumOutCompressed;
			z_stream							sumStream;

		public slots:
			void exportSearchResult(
				const QByteArray& sumData,
				const QByteArray& alnData
			);
            void flushOut(void);

			void onSearchFinished(void);
		signals:
			void finished(void);
		public:
			BMapCore(int num_of_thread=1, QObject* parent=0);
			~BMapCore(void);

			bool setBMapFile(const QString& pathToBMapFile);

            bool setBMapFileAsBWT(
				const QString& pathToBMapFile,
				const quint64& scf,
				const quint64& scl);

			void setAlignmentParameters(
				quint64 seedoffset, 
				quint64 seedlength, 
				quint64 seedstep, 
				quint64 seediterate,
				quint64 minseedhit,
				quint64 seedlengthmax,
				quint64 maxhitcount,
				qint64 minalnscore);

			bool setQueryFile(
				const QString& pathToQueryFile,
				const QueryDispatcher::FileFormat& format=QueryDispatcher::unknown);

			bool setQueryFiles(
				const QStringList& pathsToQueryFiles,
				const QList<QueryDispatcher::FileFormat> formats);

			bool setIO(
				const QString& pathToBisulSumFile, 
				const QString& pathToBisulAlignFile);

            bool start(void);

		};

	};

};

#endif
