#ifndef GRAPH_TRACK_CGI_PARAM_H
#define GRAPH_TRACK_CGI_PARAM_H

#include <QtCore>
#if QT_VERSION >= 0x050000
#include <QtWidgets>
#else
#include <QtGui>
#endif
#include <cstdlib>
#include <cstring>

namespace DesktopTrack{

	struct GraphTrackCGIParam{
		bool		is_cgi;
		//basic
		QString		track_name;		//
		QString		species;		//
		QString		revision;
		
		QString		layer;	//image, index_image, operation, index_operation, query
		//browser
		QString		target;
		quint32		start;
		quint32		end;
		quint32		width;

		QString		address;

		QString				foreground_color;
		QString				background_color;
		quint32				row_height;
		
		QList<QPair<QString, QString> > anotherParam;

		//methods
		GraphTrackCGIParam(void);

	};

};

#endif

