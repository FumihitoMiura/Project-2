#include <QtCore>
#include <QtGui>
#include <vector>
#include <iostream>
#include <limits>

#include "DesktopTrackCommon.h"
#include "BinSeq.h"
#include "GraphFile.h"
#include "MethylationPerspectiveTrack.h"

//custom plot
#include "qcustomplot/qcustomplot.h"

//alglib
#include "alglib/stdafx.h"
#include "alglib/statistics.h"


using namespace DesktopTrack;
using namespace std;
using namespace alglib;


QString binseqPath;
QString graphPath;
QString outFilePath;
int windowSize=1000;
int stepSize=200;
QString targetName;
quint32 targetFrom(0);
quint32 targetTo(0);
bool bothStrand=false;
quint32 minDepth=5;

struct ThousandSeparator: public QString{

	ThousandSeparator(void): QString(){};

	ThousandSeparator(const QString& original):
		QString(original){};

	QString& putSeparator(void){
		if(size()<3){
			return *this;
		}
		int pos=QString::indexOf('.');
		if(pos==-1){
			pos=size();
		}
		pos=pos-3;
		while(pos>0){
			insert(pos, QChar(','));
			pos=pos-3;
		}
		return *this;
	};

};

bool ProcessArguments(int argc, char* argv[]){

	int i=1;
	while(i<argc){
		QString option(argv[i]);
		if(option==QString("-binseq")){
			i++;
			if(i==argc){
				break;
			}
			binseqPath=argv[i];
		} 
		else if(option==QString("-graph")){
			i++;
			if(i==argc){
				break;
			}
			graphPath=argv[i];
		}
  		else if(option==QString("-window")){
			i++;
			if(i==argc){
				break;
			}
			windowSize=QString(argv[i]).toInt();
			if(windowSize<1){
				cout << "window size must be larger than 1." << endl;
				return false;
			}
		}
		else if(option==QString("-step")){
			i++;
			if(i==argc){
				break;
			}
			stepSize=QString(argv[i]).toInt();
			if(stepSize<1){
				cout << "window size must be larger than 1." << endl;
				return false;
			}
		}
		else if(option==QString("-minread")){
			i++;
			if(i==argc){
				break;
			}
			minDepth=QString(argv[i]).toUInt();
			if(minDepth<1){
				cout << "limit value should be more than 1." << endl;
				return false;
			}
		}
		else if(option==QString("-out")){
			i++;
			if(i==argc){
				break;
			}
			outFilePath=argv[i];
		}
     
		i++;
	}
    return true;
}

bool ProcessSpecies(const QString& species, const QString& revision)
{
	//���s�t�@�C���̑��݂���f�B���N�g�����m�F
	QDir RevisionDir(QApplication::applicationDirPath());
	//Revision�f�B���N�g��
	if(!RevisionDir.exists(RevisionsDirName)){
		cerr << "Coundn't find revision directory.";
		return false;
	}
	if(!RevisionDir.cd(RevisionsDirName)){
		cerr << "Coundn't find revision directory.";
		return false;
	}
	//species�̊m�F
	if(!RevisionDir.exists(species)){
		cerr << "Couldn't find species \"" << species.toStdString() << "\".";
		return false;
	}
	if(!RevisionDir.cd(species)){
		cerr << "Couldn't find species \"" << species.toStdString() << "\".";
		return false;
	}
	//revision�̊m�F
	if(!RevisionDir.exists(revision)){
		cerr << "Couldn't find revision \"" << revision.toStdString() << "\".";
		return false;
	}
	if(!RevisionDir.cd(revision)){
		cerr << "Couldn't find revision \"" << revision.toStdString() << "\".";
		return false;
	}
	//BinSeq�t�@�C���̊m�F
	QString binseqFileName(BinSeqFileTemp.arg(species).arg(revision));
	if(RevisionDir.exists(binseqFileName)){
		binseqPath=RevisionDir.absoluteFilePath(binseqFileName);
		return true;
	}
	return false;
}

bool ProcessTargetOrder(QString& species, QString& revision, QList<BinSeq::Target>& targets)
{
	QFile Resource(QString(":/template/TargetOrders.txt"));
	Resource.open(QIODevice::ReadOnly);
	QByteArray orderText=Resource.readAll();
	QBuffer buffer(&orderText);
	buffer.open(QIODevice::ReadOnly);
	while(!buffer.atEnd()){
		QStringList cols=QString(buffer.readLine()).split('\t');
		if(cols.size()<3){
			break;
		}
		if(cols[0]==species&&cols[1]==revision){
			QList<BinSeq::Target> temp;
			for(int i=2; i<cols.size(); i++){
				for(int j=0; j<targets.size(); j++){
					if(targets[j].targetName==cols[i]){
						temp.push_back(targets[j]);
						break;
					}
				}
			}
			targets=temp;
			return true;
		}
	}
	return false;
}

void ShowMessage(void){

	cout	<< "options: " << endl
			<< " -binseq  [string]     : binseq file path" << endl
			<< " -graph   [string]      : graph file path" << endl
			<< " -window  [integer]     : window size to calculate GC contents(default value is 1000)." << endl
			<< " -step    [integer]     : step size to calcuclate GC contents(default value is 200)." << endl
			<< " -minread [integer]     : minimum read for calculation of methylation rates (Default value is 5)." << endl
			<< " -out     [string]      : out file path" << endl;

}

int main(int argc, char* argv[]){

	QApplication app(argc, argv);

	//�t�H���g�����ݒ�
	int font_id=QFontDatabase::addApplicationFont(":/font/ArenaCondensed.ttf");
	QStringList fontFamilies=QFontDatabase::applicationFontFamilies(font_id);
	QFontDatabase fontDatabase;
	QApplication::setFont(fontDatabase.font(fontFamilies[0], "normal", 12));

	ProcessArguments(argc, argv);

	//MethylationPerspectiveTrack��graph file���I�[�v��
	MethylationPerspectiveFileReader graphReader;
	if(!graphReader.setFile(graphPath)){
		cout	<< "Couldn't open file \"" << graphPath.toStdString() << "." << endl
				<< "Please specify correct graph file path." << endl;
		ShowMessage();
		return 0;
	}
	GraphFile::Header graphHeader=graphReader.getBasicTrackInfo();

	QString sampleName=graphHeader.trackName;

	BinSeq::FileReader binseqReader;

	if(binseqPath.size()==0){
		if(!ProcessSpecies(graphHeader.species, graphHeader.revision)){
			cerr << "Couldn't find binseq file." << endl
				 << "Please specify correct binseq file with option -binseq" << endl;
			return 0;
		}
	}
	
	if(!binseqReader.setFile(binseqPath, BinSeq::FileReader::batch)){
		cout	<< "Couldn't open file \"" << binseqPath.toStdString() << "." << endl
				<< "Please specify correct binseq file path." << endl;
		ShowMessage();
		return 0;
	}
	BinSeq::Header binseqHeader=binseqReader.getTrackConfig();

	if(binseqHeader.species!=graphHeader.species){
		cout	<< "Species between graph file and binseq file don't match." << endl;
		return 0;
	}
	if(binseqHeader.revision!=graphHeader.revision){
		cout	<< "Revisions between graph file and binseq file don't match." << endl;
		return 0;
	}

	QList<BinSeq::Target> targetList=binseqReader.getTargetList();

	if(!ProcessTargetOrder(binseqHeader.species, binseqHeader.revision, targetList)){
		BinSeq::TargetLarge targetLarge;
		qSort(targetList.begin(), targetList.end(), targetLarge);
	}
	
	const int NumGrade=20;
	const quint16 M16=numeric_limits<quint16>::max();
	const quint32 M32=numeric_limits<quint32>::max();


	//GC�ˑ��I�}�b�s���O�p�x�i�E�C���h�E�x�[�X�j
	QVector<QList<qreal> > FDCG(NumGrade+1);
	vector<double> GCList, DepthList;

	//�����ٓI�A�������킹�����[�h�[�x�A�R���e�N�X�g���̃��[�h�[�x��
	QMap<quint16, quint32> ssMapF, ssMapR, ssMap, cMap, cgMap, chgMap, chhMap;
	QMap<quint32, quint32> dsMap;
	quint64 totalReadF(0), totalReadR(0), totalReadD(0), targetSize(0);
	QVector<QString> targets;
	QVector<quint64> targetSizes;
	QVector<quint64> totalReadsF, totalReadsR, totalReadsD;
	QVector<quint16> firstQsF, mediansF, thirdQsF;
	QVector<quint16> firstQsR, mediansR, thirdQsR;
	QVector<quint32> firstQsD, mediansD, thirdQsD;
	QVector<qreal> averagesF, averagesR, averagesD;
	QVector<qreal> cMethyls, cgMethyls, chgMethyls, chhMethyls;
	QVector<quint32> cCounts, cgCounts, chgCounts, chhCounts;
	qreal totalCMethyl(0), totalCgMethyl(0), totalChgMethyl(0), totalChhMethyl(0);
	quint64 totalCRead(0), totalCgRead(0), totalChgRead(0), totalChhRead(0);
	quint32 totalCCount(0), totalCgCount(0), totalChgCount(0), totalChhCount(0);
	qreal windowDepth(0);
	quint64 windowCount(0);
	for(int i=0; i<targetList.size(); i++){

		//���F�̃f�[�^�̎擾
		QByteArray seq;
		QVector<quint16> mf, mr, rf, rr;
		QString& target=targetList[i].targetName;
		if(!binseqReader.getSeq(target, seq)){
			cout << "Failed to retrieve sequence for " << target.toStdString() << "." << endl;
			continue;
		}
		if(!graphReader.getData(target, 1, mf, rf)){
			cout << "Failed to retrieve data for forward strand of " << target.toStdString() << "." << endl;
			continue;
		}
		if(!graphReader.getData(target, -1, mr, rr)){
			cout << "Failed to retrieve data for forward strand of " << target.toStdString() << "." << endl;
			continue;
		}
		if(seq.size()!=rf.size()){
			cout << "Data size not match between binseq and graph for " << target.toStdString() << "." << endl;
			continue;
		}
		if(seq.size()!=rr.size()){
			cout << "Data size not match between binseq and graph for " << target.toStdString() << "." << endl;
			continue;
		}
		int seqLen=seq.size();

		//�E�C���h�E�ɂ��W�v�@GC�R���e���g�ƃ��[�h�[�x�̊֌W
		for(int j=0, k=windowSize; k<=seqLen; j+=stepSize, k+=stepSize){

			int a(0), c(0), g(0), t(0);
			int read(0);
			for(int l=j; l<k; l++){
				if(seq[l]=='A'){
					a++;
				}
				else if(seq[l]=='C'){
					c++;
				}
				else if(seq[l]=='G'){
					g++;
				}
				else if(seq[l]=='T'){
					t++;
				}
				read+=rf[l];
				read+=rr[l];
			}
			double depth=(double)read/(double)windowSize;
			windowDepth+=depth;
			windowCount++;
			int cg=c+g;
			int acgt=a+c+g+t;
			if(acgt==0){
				continue;
			}
			double gcc = (double)cg / (double)acgt;

			//GC bias�v�Z�p�Ƀf�[�^�����u��
			DepthList.push_back(depth);
			GCList.push_back(gcc);
			
			//bias�O���t�\���p
			int grade=NumGrade*(cg)/(acgt);
			FDCG[grade].append(depth);

		}

		//�����ٓI�A���������킹�����F�̖��̃��[�h�[�x
		//�S���F�̃f�[�^���v�Z
		QMap<quint16, quint32> ssmapf, ssmapr;
		QMap<quint32, quint32> dsmap;
		quint64 target_size(seq.size()), total_read_f(0), total_read_r(0), total_read_d(0);
		quint64 c_mread(0), cg_mread(0), chg_mread(0), chh_mread(0);
		quint64 c_tread(0), cg_tread(0), chg_tread(0), chh_tread(0);
		qreal c_methyl(0), cg_methyl(0), chg_methyl(0), chh_methyl(0);
		quint32 c_count(0), cg_count(0), chg_count(0), chh_count(0);

		for(int j=0; j<target_size; j++){

			quint16 f=rf[j];
			quint16 r=rr[j];
			quint16 m=mf[j];
			quint16 n=mr[j];

			ssmapf[f]++;
			ssmapr[r]++;
			dsmap[(quint32)f+(quint32)r]++;

			ssMapF[f]++;
			ssMapR[r]++;
			dsMap[(quint32)f+(quint32)r]++;

			total_read_f+=(quint64)f;
			total_read_r+=(quint64)r;
			total_read_d+=(quint64)f+(quint64)r;

			ssMap[f]++;
			ssMap[r]++;

			if(seq[j]=='C'){
				cMap[f]++;
				c_mread+=(quint64)m;
				c_tread+=(quint64)f;
				if(f>=minDepth){
					c_methyl+=((qreal)m/(qreal)f)*100;
					c_count++;
				}
				if(j<target_size-1){
					if(seq[j+1]=='G'){
						cgMap[f]++;
						cg_mread+=(quint64)m;
						cg_tread+=(quint64)f;
						if(f>=minDepth){
							cg_methyl+=((qreal)m/(qreal)f)*100;
							cg_count++;
						}
					}
					else{
						if(j<target_size-2){
							if(seq[j+2]=='G'){
								chgMap[f]++;
								chg_mread+=(quint64)m;
								chg_tread+=(quint64)f;
								if(f>=minDepth){
									chg_methyl+=((qreal)m/(qreal)f)*100;
									chg_count++;
								}
							}
							else{
								chhMap[f]++;
								chh_mread+=(quint64)m;
								chh_tread+=(quint64)f;
								if(f>=minDepth){
									chh_methyl+=((qreal)m/(qreal)f)*100;
									chh_count++;
								}
							}
						}
					}
				}
			}
			else if(seq[j]=='G'){
				cMap[r]++;
				c_mread+=(quint64)n;
				c_tread+=(quint64)r;
				if(r>=minDepth){
					c_methyl+=((qreal)n/(qreal)r)*100;
					c_count++;
				}
				if(j>0){
					if(seq[j-1]=='C'){
						cgMap[r]++;
						cg_mread+=(quint64)n;
						cg_tread+=(quint64)r;
						if(r>=minDepth){
							cg_methyl+=((qreal)n/(qreal)r)*100;
							cg_count++;
						}
					}
					else{
						if(j>1){
							if(seq[j-2]=='C'){
								chgMap[r]++;
								chg_mread+=(quint64)n;
								chg_tread+=(quint64)r;
								if(r>=minDepth){
									chg_methyl+=((qreal)n/(qreal)r)*100;
									chg_count++;
								}
							}
							else{
								chgMap[r]++;
								chh_mread+=(quint64)n;
								chh_tread+=(quint64)r;
								if(r>=minDepth){
									chh_methyl+=((qreal)n/(qreal)r)*100;
									chh_count++;
								}
							}
						}
					}
				}
			}
		}

		//���`�������ݐ�
		totalCMethyl+=c_methyl; 
		totalCgMethyl+=cg_methyl; 
		totalChgMethyl+=chg_methyl; 
		totalChhMethyl+=chh_methyl;
		//�R���e�N�X�g�o���p�x��ݐ�
		totalCCount+=c_count; 
		totalCgCount+=cg_count; 
		totalChgCount+=chg_count; 
		totalChhCount+=chh_count;
		totalCRead+=c_tread;
		//�S�̂̃��[�h���A���F�̒���ݐ�
		targetSize+=target_size;
		totalReadF+=total_read_f;
		totalReadR+=total_read_r;
		totalReadD+=total_read_d;
		//�R���e�N�X�g���̃��[�h�p�x��ݐ�
		totalCgRead+=cg_tread;
		totalChgRead+=chg_tread;
		totalChhRead+=chh_tread;


		//���F�̖��̃}�b�v���ꂽ���[�h���A�}�b�v�[�x�̕��ρA�����l�A����O�l���l�v�Z
		//mean
		qreal mean_f=(qreal)total_read_f/(qreal)target_size;
		qreal mean_r=(qreal)total_read_r/(qreal)target_size;
		qreal mean_d=(qreal)total_read_d/(qreal)target_size;
		//median, first_q, third_q�v�Z����
		QList<quint16> keysf=ssmapf.keys();
		QList<quint16> keysr=ssmapr.keys();
		QList<quint32> keysd=dsmap.keys();
		qSort(keysf.begin(), keysf.end());
		qSort(keysr.begin(), keysr.end());
		qSort(keysd.begin(), keysd.end());
		quint64 median_pos=target_size/2;
		quint64 firstq_pos=target_size/4;
		quint64 thirdq_pos=target_size*3/4;
		quint16 firstq_f(M16), firstq_r(M16);
		quint16 median_f(M16), median_r(M16);
		quint16 thirdq_f(M16), thirdq_r(M16);
		quint32 median_d(M32), firstq_d(M32), thirdq_d(M32);
		quint32 pos;
		pos=0;
		for(int k=0; k<keysf.size(); k++){
			if(firstq_f==M16&&pos>firstq_pos){
				firstq_f=keysf[k];
			}
			if(median_f==M16&&pos>=median_pos){
				median_f=keysf[k];
			}
			if(thirdq_f==M16&&pos>thirdq_pos){
				thirdq_f=keysf[k];
			}
			pos+=ssmapf[keysf[k]];
		}
		pos=0;
		for(int k=0; k<keysr.size(); k++){
			if(firstq_r==M16&&pos>firstq_pos){
				firstq_r=keysr[k];
			}
			if(median_r==M16&&pos>=median_pos){
				median_r=keysr[k];
			}
			if(thirdq_r==M16&&pos>thirdq_pos){
				thirdq_r=keysr[k];
			}
			pos+=ssmapr[keysr[k]];
		}
		pos=0;
		for(int k=0; k<keysd.size(); k++){
			if(firstq_d==M32&&pos>firstq_pos){
				firstq_d=keysd[k];
			}
			if(median_d==M32&&pos>=median_pos){
				median_d=keysd[k];
			}
			if(thirdq_d==M32&&pos>thirdq_pos){
				thirdq_d=keysd[k];
			}
			pos+=dsmap[keysd[k]];
		}
			
		//���σ��`�������Z�o
		if(c_count>0){
			c_methyl/=(qreal)c_count;
		}
		if(cg_count>0){
			cg_methyl/=(qreal)cg_count;
		}
		if(chg_count>0){
			chg_methyl/=(qreal)chg_count; 
		}
		if(chh_count>0){
			chh_methyl/=(qreal)chh_count;
		}

		//���F�̖��̏����L�^
		targets << target;
		targetSizes << target_size;
		totalReadsF << total_read_f;
		totalReadsR << total_read_r;
		totalReadsD << total_read_d;
		firstQsF << firstq_f;
		firstQsR << firstq_r;
		firstQsD << firstq_d;
		mediansF << median_f;
		mediansR << median_r;
		mediansD << median_d;
		thirdQsF << thirdq_f;
		thirdQsR << thirdq_r;
		thirdQsD << thirdq_d;
		averagesF << mean_f;
		averagesR << mean_r;
		averagesD << mean_d;
		cMethyls << c_methyl;
		cgMethyls << cg_methyl;
		chgMethyls << chg_methyl;
		chhMethyls << chh_methyl;
		cCounts << c_count;
		cgCounts << cg_count;
		chgCounts << chg_count;
		chhCounts << chh_count;

	}

	//���F�̑S�̂̃��[�h�[�x
	qreal totalAverageF=(qreal)totalReadF/(qreal)targetSize;
	qreal totalAverageR=(qreal)totalReadR/(qreal)targetSize;
	qreal totalAverage=(qreal)totalReadD/(qreal)targetSize;
	quint32 medianPos=targetSize/2;
	quint32 firstqPos=targetSize/4;
	quint32 thirdqPos=targetSize*3/4;
	quint16 medianValueF(M16), medianValueR(M16);
	quint16 firstQValueF(M16), firstQValueR(M16);
	quint16 thirdQValueF(M16), thirdQValueR(M16);
	quint32 medianValueD(M32), firstQValueD(M32), thirdQValueD(M32);
	quint32 Pos;
	Pos=0;
	QList<quint16> KeysF=ssMapF.keys();
	qSort(KeysF.begin(), KeysF.end());
	for(int i=0; i<KeysF.size(); i++){
		if(firstQValueF==M16&&Pos>=firstqPos){
			firstQValueF=KeysF[i];
		}
		if(medianValueF==M16&&Pos>=medianPos){
			medianValueF=KeysF[i];
		}
		if(thirdQValueF==M16&&Pos>=thirdqPos){
			thirdQValueF=KeysF[i];
		}
		Pos+=ssMapF[KeysF[i]];
	}
	Pos=0;
	QList<quint16> KeysR=ssMapR.keys();
	qSort(KeysR.begin(), KeysR.end());
	for(int i=0; i<KeysR.size(); i++){
		if(firstQValueR==M16&&Pos>=firstqPos){
			firstQValueR=KeysR[i];
		}
		if(medianValueR==M16&&Pos>=medianPos){
			medianValueR=KeysR[i];
		}
		if(thirdQValueR==M16&&Pos>=thirdqPos){
			thirdQValueR=KeysR[i];
		}
		Pos+=ssMapR[KeysR[i]];
	}
	Pos=0;
	QList<quint32> KeysD=dsMap.keys();
	qSort(KeysD.begin(), KeysD.end());
	for(int i=0; i<KeysD.size(); i++){
		if(firstQValueD==M32&&Pos>=firstqPos){
			firstQValueD=KeysD[i];
		}
		if(medianValueD==M32&&Pos>=medianPos){
			medianValueD=KeysD[i];
		}
		if(thirdQValueD==M32&&Pos>=thirdqPos){
			thirdQValueD=KeysD[i];
		}
		Pos+=dsMap[KeysD[i]];
	}

	//���F�̑S�̂̃��`������
	if(totalCCount>0){
		totalCMethyl/=(qreal)totalCCount;
	}
	else{
		totalCMethyl=0;
	}
	if(totalCgCount>0){
		totalCgMethyl/=(qreal)totalCgCount;
	}
	else{
		totalCgMethyl=0;
	}
	if(totalChgCount>0){
		totalChgMethyl/=(qreal)totalChgCount;
	}
	else{
		totalChgMethyl=0;
	}
	if(totalChhCount>0){
		totalChhMethyl/=(qreal)totalChhCount;
	}
	else{
		totalChhMethyl=0;
	}


	//���[�h�[�x�ƃJ�o���[�W
	//QMap<quint16, quint32> ssMap, cMap, cgMap, chgMap, chhMap;
	QList<quint16> depthKeys=ssMap.keys();
	quint16 maxKey=0;
	for(int i=0; i<depthKeys.size(); i++){
		maxKey=qMax(maxKey, depthKeys[i]);
	}
	QVector<QString> depthStringList;
	QVector<quint64> depthListI, aDepthListI, cDepthListI, cgDepthListI, chgDepthListI, chhDepthListI;
	QVector<qreal> depthListF, aDepthListF, cDepthListF, cgDepthListF, chgDepthListF, chhDepthListF;
	QVector<quint64> cumAListI, cumCListI, cumCpgListI, cumChgListI, cumChhListI;
	QVector<qreal> cumAListF, cumCListF, cumCpgListF, cumChgListF, cumChhListF;
	quint64 aCount(0), cCount(0), cgCount(0), chgCount(0), chhCount(0);
	quint64 aDepthI(0), cDepthI(0), cgDepthI(0), chgDepthI(0), chhDepthI(0); 
	qreal aDepthF(0), cDepthF(0), cgDepthF(0), chgDepthF(0), chhDepthF(0);
	quint16 aFirstQValue(M16), aMedianValue(M16), aThirdQValue(M16);
	quint16 cFirstQValue(M16), cMedianValue(M16), cThirdQValue(M16);
	quint16 cgFirstQValue(M16), cgMedianValue(M16), cgThirdQValue(M16);
	quint16 chgFirstQValue(M16), chgMedianValue(M16), chgThirdQValue(M16);
	quint16 chhFirstQValue(M16), chhMedianValue(M16), chhThirdQValue(M16);
	for(int i=0; i<maxKey+1; i++){
		depthStringList << QString().setNum(i);
		depthListF << (qreal)(i);
		quint64 key=i;
		if(ssMap.contains(i)){
			quint64 value=(quint64)ssMap[i];
			aDepthListF << (qreal)value;
			aDepthListI << value;
			aCount+=value;
			aDepthI+=(value*key);
		}
		else{
			aDepthListF << 0;
			aDepthListI << 0;
		}
		if(cMap.contains(i)){
			quint64 value=(quint64)cMap[i];
			cDepthListF << (qreal)value;
			cDepthListI << value;
			cCount+=value;
			cDepthI+=(value*key);
		}
		else{
			cDepthListF << 0;
			cDepthListI << 0;
		}
		if(cgMap.contains(i)){
			quint64 value=(quint64)cgMap[i];
			cgDepthListF << (qreal)value;
			cgDepthListI << value;
			cgCount+=value;
			cgDepthI+=(value*key);
		}
		else{
			cgDepthListF << 0;
			cgDepthListI << 0;
		}
		if(chgMap.contains(i)){
			quint64 value=(quint64)chgMap[i];
			chgDepthListF << (qreal)value;
			chgDepthListI << value;
			chgCount+=value;
			chgDepthI+=(value*key);
		}
		else{
			chgDepthListF << 0;
			chgDepthListI << 0;
		}
		if(chhMap.contains(i)){
			quint64 value=(quint64)chhMap[i];
			chhDepthListF << (qreal)value;
			chhDepthListI << value;
			chhCount+=value;
			chhDepthI+=(value*key);
		}
		else{
			chhDepthListF << 0;
			chhDepthListI << 0;
		}
	}

	//�ݐς��v�Z
	for(int i=0; i<maxKey+1; i++){
		cumAListI<<aDepthListI[i];
		cumCListI<<cDepthListI[i];
		cumCpgListI<<cgDepthListI[i];
		cumChgListI<<chgDepthListI[i];
		cumChhListI<<chhDepthListI[i];
	}

	for(int i=maxKey; i>0; i--){
		cumAListI[i-1]+=cumAListI[i];
		cumCListI[i-1]+=cumCListI[i];
		cumCpgListI[i-1]+=cumCpgListI[i];
		cumChgListI[i-1]+=cumChgListI[i];
		cumChhListI[i-1]+=cumChhListI[i];
	}

	if(aCount>0){
		for(int i=0; i<maxKey+1; i++){
			aDepthListF[i]=aDepthListF[i]/(qreal)aCount*100;
			cumAListF<<(qreal)cumAListI[i]/(qreal)aCount*100;
		}
		aDepthF=(qreal)aDepthI/(qreal)aCount;

		//firstq, median, thirdq
		//median, first_q, third_q�v�Z����
		QList<quint16> keys=ssMap.keys();
		qSort(keys.begin(), keys.end());
		quint64 firstq_pos=aCount/4;
		quint64 median_pos=aCount/2;
		quint64 thirdq_pos=aCount*3/4;
		quint64 pos=0;
		for(int k=0; k<keys.size(); k++){

			if(aFirstQValue==M16&&pos>=firstq_pos){
				aFirstQValue=keys[k];
			}
			if(aMedianValue==M16&&pos>=median_pos){
				aMedianValue=keys[k];
			}
			if(aThirdQValue==M16&&pos>=thirdq_pos){
				aThirdQValue=keys[k];
			}
			pos+=(quint64)ssMap[keys[k]];
		}

	}

	if(aFirstQValue==M16){
		aFirstQValue=0;
	}
	if(aFirstQValue==M16){
		aFirstQValue=0;
	}
	if(aMedianValue==M16){
		aMedianValue=0;
	}
	if(aThirdQValue==M16){
		aThirdQValue=0;
	}

	if(cCount>0){
		for(int i=0; i<maxKey+1; i++){
			cDepthListF[i]=cDepthListF[i]/(qreal)cCount*100;
			cumCListF<<(qreal)cumCListI[i]/(qreal)cCount*100;
		}
		cDepthF=(qreal)cDepthI/(qreal)cCount;

		//firstq, median, thirdq
		//median, first_q, third_q�v�Z����
		QList<quint16> keys=cMap.keys();
		qSort(keys.begin(), keys.end());
		quint64 firstq_pos=cCount/4;
		quint64 median_pos=cCount/2;
		quint64 thirdq_pos=cCount*3/4;
		quint64 pos=0;
		for(int k=0; k<keys.size(); k++){
			if(cFirstQValue==M16&&pos>=firstq_pos){
				cFirstQValue=keys[k];
			}
			if(cMedianValue==M16&&pos>=median_pos){
				cMedianValue=keys[k];
			}
			if(cThirdQValue==M16&&pos>=thirdq_pos){
				cThirdQValue=keys[k];
			}
			pos+=(quint64)cMap[keys[k]];
		}

	}

	if(cFirstQValue==M16){
		cFirstQValue=0;
	}
	if(cFirstQValue==M16){
		cFirstQValue=0;
	}
	if(cMedianValue==M16){
		cMedianValue=0;
	}
	if(cThirdQValue==M16){
		cThirdQValue=0;
	}

	if(cgCount>0){
		for(int i=0; i<maxKey+1; i++){
			cgDepthListF[i]=cgDepthListF[i]/(qreal)cgCount*100;
			cumCpgListF<<(qreal)cumCpgListI[i]/(qreal)cgCount*100;
		}
		cgDepthF=(qreal)cgDepthI/(qreal)cgCount;

		//firstq, median, thirdq
		//median, first_q, third_q�v�Z����
		QList<quint16> keys=cgMap.keys();
		qSort(keys.begin(), keys.end());
		quint64 firstq_pos=cgCount/4;
		quint64 median_pos=cgCount/2;
		quint64 thirdq_pos=cgCount*3/4;
		quint64 pos=0;
		for(int k=0; k<keys.size(); k++){
			if(cgFirstQValue==M16&&pos>=firstq_pos){
				cgFirstQValue=keys[k];
			}
			if(cgMedianValue==M16&&pos>=median_pos){
				cgMedianValue=keys[k];
			}
			if(cgThirdQValue==M16&&pos>=thirdq_pos){
				cgThirdQValue=keys[k];
			}
			pos+=(quint64)cgMap[keys[k]];
		}

	}

	if(cgFirstQValue==M16){
		cgFirstQValue=0;
	}
	if(cgFirstQValue==M16){
		cgFirstQValue=0;
	}
	if(cgMedianValue==M16){
		cgMedianValue=0;
	}
	if(cgThirdQValue==M16){
		cgThirdQValue=0;
	}

	if(chgCount>0){
		for(int i=0; i<maxKey+1; i++){
			chgDepthListF[i]=chgDepthListF[i]/(qreal)chgCount*100;
			cumChgListF<<(qreal)cumChgListI[i]/(qreal)chgCount*100;
		}
		chgDepthF=(qreal)chgDepthI/(qreal)chgCount;

		//firstq, median, thirdq
		//median, first_q, third_q�v�Z����
		QList<quint16> keys=chgMap.keys();
		qSort(keys.begin(), keys.end());
		quint64 firstq_pos=chgCount/4;
		quint64 median_pos=chgCount/2;
		quint64 thirdq_pos=chgCount*3/4;
		quint64 pos=0;
		for(int k=0; k<keys.size(); k++){
			if(chgFirstQValue==M16&&pos>=firstq_pos){
				chgFirstQValue=keys[k];
			}
			if(chgMedianValue==M16&&pos>=median_pos){
				chgMedianValue=keys[k];
			}
			if(chgThirdQValue==M16&&pos>=thirdq_pos){
				chgThirdQValue=keys[k];
			}
			pos+=(quint64)chgMap[keys[k]];
		}

	}

	if(chgFirstQValue==M16){
		chgFirstQValue=0;
	}
	if(chgFirstQValue==M16){
		chgFirstQValue=0;
	}
	if(chgMedianValue==M16){
		chgMedianValue=0;
	}
	if(chgThirdQValue==M16){
		chgThirdQValue=0;
	}

	if(chhCount>0){
		for(int i=0; i<maxKey+1; i++){
			chhDepthListF[i]=chhDepthListF[i]/(qreal)chhCount*100;
			cumChhListF<<(qreal)cumChhListI[i]/(qreal)chhCount*100;
		}
		chhDepthF=(qreal)chhDepthI/(qreal)chhCount;

		//firstq, median, thirdq
		//median, first_q, third_q�v�Z����
		QList<quint16> keys=chhMap.keys();
		qSort(keys.begin(), keys.end());
		quint64 firstq_pos=chhCount/4;
		quint64 median_pos=chhCount/2;
		quint64 thirdq_pos=chhCount*3/4;
		quint64 pos=0;
		for(int k=0; k<keys.size(); k++){
			if(chhFirstQValue==M16&&pos>=firstq_pos){
				chhFirstQValue=keys[k];
			}
			if(chhMedianValue==M16&&pos>=median_pos){
				chhMedianValue=keys[k];
			}
			if(chhThirdQValue==M16&&pos>=thirdq_pos){
				chhThirdQValue=keys[k];
			}
			pos+=(quint64)chhMap[keys[k]];
		}

	}

	if(chhFirstQValue==M16){
		chhFirstQValue=0;
	}
	if(chhFirstQValue==M16){
		chhFirstQValue=0;
	}
	if(chhMedianValue==M16){
		chhMedianValue=0;
	}
	if(chhThirdQValue==M16){
		chhThirdQValue=0;
	}




	//GC�ˑ��I�}�b�s���O��
	real_1d_array x, y;
	x.setcontent(GCList.size(), GCList.data());
	GCList.clear();
	y.setcontent(DepthList.size(), DepthList.data());
	DepthList.clear();
	//�s�A�\���ƃX�y���}���v�Z
	double pearson = pearsoncorr2(x, y);
	double spearman = spearmancorr2(x, y);

	QVector<QString> gcContentsLabel;
	QVector<qreal> windowNums, windowTicks;
	QVector<quint32> windowNumsI;
	QVector<qreal> windowFirstqs, windowAverages, windowMedians, windowThirdqs;
	for(int i=0; i<NumGrade+1; i++){

		QList<qreal>& data=FDCG[i];

		gcContentsLabel << QString(QString().setNum(i*100/NumGrade)+"%");
		windowNums << (qreal)(data.size());
		windowNumsI << data.size();
		windowTicks << (qreal)(i+1);

		if(data.size()>0){
			QMap<qreal, quint32> map;
			qreal cumlDepth(0);
			for(int j=0; j<data.size(); j++){
				map[data[j]]++;
				cumlDepth+=data[j];
			}
			QList<qreal> keys=map.keys();
			qSort(keys.begin(), keys.end());
			quint64 firstq_pos=data.size()/4;
			quint64 median_pos=data.size()/2;
			quint64 thirdq_pos=data.size()*3/4;
			qreal firstq_value(-1), median_value(-1), thirdq_value(-1);
			quint64 pos=0;
			for(int j=0; j<keys.size(); j++){
				if(firstq_value==-1&&pos>=firstq_pos){
					firstq_value=keys[j];
				}
				if(median_value==-1&&pos>=median_pos){
					median_value=keys[j];
				}
				if(thirdq_value==-1&&pos>=thirdq_pos){
					thirdq_value=keys[j];
				}
				pos+=map[keys[j]];
			}
			qreal average=cumlDepth/(qreal)data.size();
			
			windowFirstqs << firstq_value;
			windowAverages << average;
			windowMedians << median_value;
			windowThirdqs << thirdq_value;

		}
		else{
			windowFirstqs << 0;
			windowAverages << 0;
			windowMedians << 0;
			windowThirdqs << 0;
		}
	}
	if(windowDepth>0){
		windowDepth/=(qreal)windowCount;
	}

	QFileInfo info(outFilePath);
	if(info.suffix()=="html"){

		QFile Resource(QString(":/template/CalcCoverageTemplate.html"));
		Resource.open(QIODevice::ReadOnly);
		QString htmlTemplate=Resource.readAll();
		
		QString ImageFilePath1 = info.dir().relativeFilePath(info.completeBaseName() + QString(".depths.png"));
		QString ImageFilePath2 = info.dir().relativeFilePath(info.completeBaseName() + QString(".depthd.png"));
		QString ImageFilePath3 = info.dir().relativeFilePath(info.completeBaseName() + QString(".methyl.png"));
		QString ImageFilePath4 = info.dir().relativeFilePath(info.completeBaseName() + QString(".gcbias.png"));
		QString ImageFilePath5 = info.dir().relativeFilePath(info.completeBaseName() + QString(".cover.png"));
		QString ImageFilePath6 = info.dir().relativeFilePath(info.completeBaseName() + QString(".cumul.png"));

		//���F�̖��̃��[�h�f�v�X
		QByteArray TableTextData;
		QBuffer TableTextStreamBuffer(&TableTextData);
		TableTextStreamBuffer.open(QIODevice::WriteOnly);
		QTextStream TableTextStream(&TableTextStreamBuffer);

		for(int i=0; i<targets.size(); i++){

			TableTextStream << "\t\t\t<tr>" << endl;
			
			TableTextStream << "\t\t\t\t<td>" << targets[i] << "</td>" << endl;
			TableTextStream << "\t\t\t\t<td align=\"right\">" << ThousandSeparator(QString().setNum(targetSizes[i])).putSeparator() << "</td>" << endl;
			
			if(totalReadsF[i]>0){
				TableTextStream << "\t\t\t\t<td align=\"right\">" << ThousandSeparator(QString().setNum(totalReadsF[i])).putSeparator() << "</td>" << endl;
				TableTextStream << "\t\t\t\t<td align=\"right\">" << QString().setNum(averagesF[i], 'f', 1) << "</td>" << endl;
				TableTextStream << "\t\t\t\t<td align=\"right\">" << firstQsF[i] << "</td>" << endl;
				TableTextStream << "\t\t\t\t<td align=\"right\">" << mediansF[i] << "</td>" << endl;
				TableTextStream << "\t\t\t\t<td align=\"right\">" << thirdQsF[i] << "</td>" << endl;
			}
			else{
				TableTextStream << "\t\t\t\t<td align=\"right\">" << 0 << "</td>" << endl;
				TableTextStream << "\t\t\t\t<td align=\"right\">" << "-" << "</td>" << endl;
				TableTextStream << "\t\t\t\t<td align=\"right\">" << "-" << "</td>" << endl;
				TableTextStream << "\t\t\t\t<td align=\"right\">" << "-" << "</td>" << endl;
				TableTextStream << "\t\t\t\t<td align=\"right\">" << "-" << "</td>" << endl;
			}

			if(totalReadsR[i]>0){
				TableTextStream << "\t\t\t\t<td align=\"right\">" << ThousandSeparator(QString().setNum(totalReadsR[i])).putSeparator() << "</td>" << endl;
				TableTextStream << "\t\t\t\t<td align=\"right\">" << QString().setNum(averagesR[i], 'f', 1) << "</td>" << endl;
				TableTextStream << "\t\t\t\t<td align=\"right\">" << firstQsR[i] << "</td>" << endl;
				TableTextStream << "\t\t\t\t<td align=\"right\">" << mediansR[i] << "</td>" << endl;
				TableTextStream << "\t\t\t\t<td align=\"right\">" << thirdQsR[i] << "</td>" << endl;
			}
			else{
				TableTextStream << "\t\t\t\t<td align=\"right\">" << 0 << "</td>" << endl;
				TableTextStream << "\t\t\t\t<td align=\"right\">" << "-" << "</td>" << endl;
				TableTextStream << "\t\t\t\t<td align=\"right\">" << "-" << "</td>" << endl;
				TableTextStream << "\t\t\t\t<td align=\"right\">" << "-" << "</td>" << endl;
				TableTextStream << "\t\t\t\t<td align=\"right\">" << "-" << "</td>" << endl;
			}

			if(totalReadsD[i]>0){
				TableTextStream << "\t\t\t\t<td align=\"right\">" << ThousandSeparator(QString().setNum(totalReadsD[i])).putSeparator() << "</td>" << endl;
				TableTextStream << "\t\t\t\t<td align=\"right\">" << QString().setNum(averagesD[i], 'f', 1) << "</td>" << endl;
				TableTextStream << "\t\t\t\t<td align=\"right\">" << firstQsD[i] << "</td>" << endl;
				TableTextStream << "\t\t\t\t<td align=\"right\">" << mediansD[i] << "</td>" << endl;
				TableTextStream << "\t\t\t\t<td align=\"right\">" << thirdQsD[i] << "</td>" << endl;
			}
			else{
				TableTextStream << "\t\t\t\t<td align=\"right\">" << 0 << "</td>" << endl;
				TableTextStream << "\t\t\t\t<td align=\"right\">" << "-" << "</td>" << endl;
				TableTextStream << "\t\t\t\t<td align=\"right\">" << "-" << "</td>" << endl;
				TableTextStream << "\t\t\t\t<td align=\"right\">" << "-" << "</td>" << endl;
				TableTextStream << "\t\t\t\t<td align=\"right\">" << "-" << "</td>" << endl;
			}

			if(cCounts[i]>0){
				TableTextStream << "\t\t\t\t<td align=\"right\">" << QString().setNum(cMethyls[i], 'f', 1) << "</td>" << endl;
			}
			else{
				TableTextStream << "\t\t\t\t<td align=\"right\">" << "-" << "</td>" << endl;
			}

			if(cgCounts[i]>0){
				TableTextStream << "\t\t\t\t<td align=\"right\">" << QString().setNum(cgMethyls[i], 'f', 1) << "</td>" << endl;
			}
			else{
				TableTextStream << "\t\t\t\t<td align=\"right\">" << "-" << "</td>" << endl;
			}

			if(chgCounts[i]>0){
				TableTextStream << "\t\t\t\t<td align=\"right\">" << QString().setNum(chgMethyls[i], 'f', 1) << "</td>" << endl;
			}
			else{
				TableTextStream << "\t\t\t\t<td align=\"right\">" << "-" << "</td>" << endl;
			}

			if(chhCounts[i]>0){
				TableTextStream << "\t\t\t\t<td align=\"right\">" << QString().setNum(chhMethyls[i], 'f', 1) << "</td>" << endl;
			}
			else{				
				TableTextStream << "\t\t\t\t<td align=\"right\">" << "-" << "</td>" << endl;
			}

			TableTextStream << "\t\t\t</tr>" << endl;

		}


		//�S���F�̂̃��[�h�f�v�X�W�v
		TableTextStreamBuffer.close();
	
		QByteArray TableFooterData;
		QBuffer TableFooterStreamBuffer(&TableFooterData);
		TableFooterStreamBuffer.open(QIODevice::WriteOnly);
		QTextStream TableFooterStream(&TableFooterStreamBuffer);

		TableFooterStream << "\t\t\t<tr>" << endl;

		TableFooterStream << "\t\t\t\t<td>" << "all" << "</td>" << endl;
		TableFooterStream << "\t\t\t\t<td align=\"right\">" << ThousandSeparator(QString().setNum(targetSize)).putSeparator() << "</td>" << endl;
			
		TableFooterStream << "\t\t\t\t<td align=\"right\">" << ThousandSeparator(QString().setNum(totalReadF)).putSeparator() << "</td>" << endl;
		TableFooterStream << "\t\t\t\t<td align=\"right\">" << QString().setNum(totalAverageF, 'f', 1) << "</td>" << endl;
		TableFooterStream << "\t\t\t\t<td align=\"right\">" << firstQValueF << "</td>" << endl;
		TableFooterStream << "\t\t\t\t<td align=\"right\">" << medianValueF << "</td>" << endl;
		TableFooterStream << "\t\t\t\t<td align=\"right\">" << thirdQValueF << "</td>" << endl;

		TableFooterStream << "\t\t\t\t<td align=\"right\">" << ThousandSeparator(QString().setNum(totalReadR)).putSeparator() << "</td>" << endl;
		TableFooterStream << "\t\t\t\t<td align=\"right\">" << QString().setNum(totalAverageR, 'f', 1) << "</td>" << endl;
		TableFooterStream << "\t\t\t\t<td align=\"right\">" << firstQValueR << "</td>" << endl;
		TableFooterStream << "\t\t\t\t<td align=\"right\">" << medianValueR << "</td>" << endl;
		TableFooterStream << "\t\t\t\t<td align=\"right\">" << thirdQValueR << "</td>" << endl;

		TableFooterStream << "\t\t\t\t<td align=\"right\">" << ThousandSeparator(QString().setNum(totalReadD)).putSeparator() << "</td>" << endl;
		TableFooterStream << "\t\t\t\t<td align=\"right\">" << QString().setNum(totalAverage, 'f', 1) << "</td>" << endl;
		TableFooterStream << "\t\t\t\t<td align=\"right\">" << firstQValueD << "</td>" << endl;
		TableFooterStream << "\t\t\t\t<td align=\"right\">" << medianValueD << "</td>" << endl;
		TableFooterStream << "\t\t\t\t<td align=\"right\">" << thirdQValueD << "</td>" << endl;

		TableFooterStream << "\t\t\t\t<td align=\"right\">" << QString().setNum(totalCMethyl, 'f', 1) << "</td>" << endl;
		TableFooterStream << "\t\t\t\t<td align=\"right\">" << QString().setNum(totalCgMethyl, 'f', 1) << "</td>" << endl;
		TableFooterStream << "\t\t\t\t<td align=\"right\">" << QString().setNum(totalChgMethyl, 'f', 1) << "</td>" << endl;
		TableFooterStream << "\t\t\t\t<td align=\"right\">" << QString().setNum(totalChhMethyl, 'f', 1) << "</td>" << endl;

		TableFooterStream << "\t\t\t</tr>" << endl;

		TableFooterStreamBuffer.close();

		//GC�ˑ��}�b�s���O�o�C�A�X
		QByteArray GCTableTextData;
		QBuffer GCTableTextStreamBuffer(&GCTableTextData);
		GCTableTextStreamBuffer.open(QIODevice::WriteOnly);
		QTextStream GCTableTextStream(&GCTableTextStreamBuffer);

		for(int i=0; i<NumGrade+1; i++){
			GCTableTextStream << "\t\t\t<tr>" << endl;
			GCTableTextStream << "\t\t\t\t<td align=\"right\">" << gcContentsLabel[i] << "</td>" << endl;
			GCTableTextStream << "\t\t\t\t<td align=\"right\">" << ThousandSeparator(QString().setNum(windowNumsI[i])).putSeparator() << "</td>" << endl;
			GCTableTextStream << "\t\t\t\t<td align=\"right\">" << QString().setNum(windowAverages[i], 'f', 1) << "</td>" << endl;
			GCTableTextStream << "\t\t\t\t<td align=\"right\">" << QString().setNum(windowFirstqs[i], 'f', 1) << "</td>" << endl;
			GCTableTextStream << "\t\t\t\t<td align=\"right\">" << QString().setNum(windowMedians[i], 'f', 1) << "</td>" << endl;
			GCTableTextStream << "\t\t\t\t<td align=\"right\">" << QString().setNum(windowThirdqs[i], 'f', 1) << "</td>" << endl;
			GCTableTextStream << "\t\t\t</tr>" << endl;
		}

		GCTableTextStreamBuffer.close();

		//�J�o���[�WVS���[�h�f�v�X
		//QVector<QString> depthStringList;
		//QVector<qreal> depthList, allDepths, cDepths, cgDepths, chgDepths, chhDepths;
		QByteArray DepthCoverageTableData;
		QBuffer DepthCoverageTableBuffer(&DepthCoverageTableData);
		DepthCoverageTableBuffer.open(QIODevice::WriteOnly);
		QTextStream DepthCoverageTableStream(&DepthCoverageTableBuffer);

		int limit=(int)(ceil((totalAverageF+totalAverageR)*2));
		limit=qMin(limit, (int)maxKey+1);

		for(int i=0; i<limit; i++){

			DepthCoverageTableStream << "\t\t\t<tr>" << endl;

			DepthCoverageTableStream << "\t\t\t\t<td align=\"right\">" << depthStringList[i] << "</td>" << endl;

			DepthCoverageTableStream << "\t\t\t\t<td align=\"right\">" << ThousandSeparator(QString().setNum(aDepthListI[i])).putSeparator() << " (";
			DepthCoverageTableStream << QString().setNum(aDepthListF[i], 'f', 1) << "%)" << "</td>" << endl;
			
			DepthCoverageTableStream << "\t\t\t\t<td align=\"right\">" << ThousandSeparator(QString().setNum(cDepthListI[i])).putSeparator() << " (";
			DepthCoverageTableStream << QString().setNum(cDepthListF[i], 'f', 1) << "%)" << "</td>" << endl;

			DepthCoverageTableStream << "\t\t\t\t<td align=\"right\">" << ThousandSeparator(QString().setNum(cgDepthListI[i])).putSeparator() << " (";
			DepthCoverageTableStream << QString().setNum(cgDepthListF[i], 'f', 1) << "%)" << "</td>" << endl;

			DepthCoverageTableStream << "\t\t\t\t<td align=\"right\">" << ThousandSeparator(QString().setNum(chgDepthListI[i])).putSeparator() << " (";
			DepthCoverageTableStream << QString().setNum(chgDepthListF[i], 'f', 1) << "%)" << "</td>" << endl;

			DepthCoverageTableStream << "\t\t\t\t<td align=\"right\">" << ThousandSeparator(QString().setNum(chhDepthListI[i])).putSeparator() << " (";
			DepthCoverageTableStream << QString().setNum(chhDepthListF[i], 'f', 1) << "%)" << "</td>" << endl;


			//cuml

			DepthCoverageTableStream << "\t\t\t\t<td align=\"right\">" << ThousandSeparator(QString().setNum(cumAListI[i])).putSeparator() << " (";
			DepthCoverageTableStream << QString().setNum(cumAListF[i], 'f', 1) << "%)" << "</td>" << endl;

			DepthCoverageTableStream << "\t\t\t\t<td align=\"right\">" << ThousandSeparator(QString().setNum(cumCListI[i])).putSeparator() << " (";
			DepthCoverageTableStream << QString().setNum(cumCListF[i], 'f', 1) << "%)" << "</td>" << endl;

			DepthCoverageTableStream << "\t\t\t\t<td align=\"right\">" << ThousandSeparator(QString().setNum(cumCpgListI[i])).putSeparator() << " (";
			DepthCoverageTableStream << QString().setNum(cumCpgListF[i], 'f', 1) << "%)" << "</td>" << endl;

			DepthCoverageTableStream << "\t\t\t\t<td align=\"right\">" << ThousandSeparator(QString().setNum(cumChgListI[i])).putSeparator() << " (";
			DepthCoverageTableStream << QString().setNum(cumChgListF[i], 'f', 1) << "%)" << "</td>" << endl;

			DepthCoverageTableStream << "\t\t\t\t<td align=\"right\">" << ThousandSeparator(QString().setNum(cumChhListI[i])).putSeparator() << " (";
			DepthCoverageTableStream << QString().setNum(cumChhListF[i], 'f', 1) << "%)" << "</td>" << endl;

			DepthCoverageTableStream << "\t\t\t</tr>" << endl;

		}

		quint64 aDepthMTLimitI(0), cDepthMTLimitI(0), cgDepthMTLimitI(0), chgDepthMTLimitI(0), chhDepthMTLimitI(0);
		qreal aDepthMTLimitF(0), cDepthMTLimitF(0), cgDepthMTLimitF(0), chgDepthMTLimitF(0), chhDepthMTLimitF(0);
		for(int i=limit; i<maxKey+1; i++){
			aDepthMTLimitI+=aDepthListI[i];
			cDepthMTLimitI+=cDepthListI[i];
			cgDepthMTLimitI+=cgDepthListI[i];
			chgDepthMTLimitI+=chgDepthListI[i];
			chhDepthMTLimitI+=chhDepthListI[i];
			aDepthMTLimitF+=aDepthListF[i];
			cDepthMTLimitF+=cDepthListF[i];
			cgDepthMTLimitF+=cgDepthListF[i];
			chgDepthMTLimitF+=chgDepthListF[i];
			chhDepthMTLimitF+=chhDepthListF[i];
		}
		if(limit<maxKey){

			DepthCoverageTableStream << "\t\t\t<tr>" << endl;

			DepthCoverageTableStream << "\t\t\t\t<td align=\"right\">&gt;=" << limit << "</td>" << endl;

			DepthCoverageTableStream << "\t\t\t\t<td align=\"right\">" << ThousandSeparator(QString().setNum(aDepthMTLimitI)).putSeparator() << " (";
			DepthCoverageTableStream << QString().setNum(aDepthMTLimitF, 'f', 1) << "%)" << "</td>" << endl;
			
			DepthCoverageTableStream << "\t\t\t\t<td align=\"right\">" << ThousandSeparator(QString().setNum(cDepthMTLimitI)).putSeparator() << " (";
			DepthCoverageTableStream << QString().setNum(cDepthMTLimitF, 'f', 1) << "%)" << "</td>" << endl;

			DepthCoverageTableStream << "\t\t\t\t<td align=\"right\">" << ThousandSeparator(QString().setNum(cgDepthMTLimitI)).putSeparator() << " (";
			DepthCoverageTableStream << QString().setNum(cgDepthMTLimitF, 'f', 1) << "%)" << "</td>" << endl;

			DepthCoverageTableStream << "\t\t\t\t<td align=\"right\">" << ThousandSeparator(QString().setNum(chgDepthMTLimitI)).putSeparator() << " (";
			DepthCoverageTableStream << QString().setNum(chgDepthMTLimitF, 'f', 1) << "%)" << "</td>" << endl;

			DepthCoverageTableStream << "\t\t\t\t<td align=\"right\">" << ThousandSeparator(QString().setNum(chhDepthMTLimitI)).putSeparator() << " (";
			DepthCoverageTableStream << QString().setNum(chhDepthMTLimitF, 'f', 1) << "%)" << "</td>" << endl;


			//cuml

			DepthCoverageTableStream << "\t\t\t\t<td align=\"right\">-</td>" << endl;

			DepthCoverageTableStream << "\t\t\t\t<td align=\"right\">-</td>" << endl;

			DepthCoverageTableStream << "\t\t\t\t<td align=\"right\">-</td>" << endl;

			DepthCoverageTableStream << "\t\t\t\t<td align=\"right\">-</td>" << endl;

			DepthCoverageTableStream << "\t\t\t\t<td align=\"right\">-</td>" << endl;

			DepthCoverageTableStream << "\t\t\t</tr>" << endl;

		}


		DepthCoverageTableBuffer.close();

		//�o�̓t�@�C���̃I�[�v��
		QFile outFile(outFilePath);
		outFile.open(QIODevice::WriteOnly);
		if(!outFile.isOpen()){
			cout	<< "Couldn't open file \"" << outFilePath.toStdString() << "." << endl;
			ShowMessage();
			return 0;
		}
		//QTextStream out(&outFile);

		//�o��
		outFile.write(htmlTemplate
			.replace(QString("SAMPLENAME"), sampleName)
			.replace(QString("IMAGEPATH_1"), ImageFilePath1)
			.replace(QString("IMAGEPATH_2"), ImageFilePath2)
			.replace(QString("IMAGEPATH_3"), ImageFilePath3)
			.replace(QString("IMAGEPATH_4"), ImageFilePath4)
			.replace(QString("IMAGEPATH_5"), ImageFilePath5)
			.replace(QString("IMAGEPATH_6"), ImageFilePath6)
			.replace(QString("TABLEBODY_1"), QString(TableTextData))
			.replace(QString("TABLEFOOT_1"), QString(TableFooterData))
			.replace(QString("TABLEBODY_2"), QString(GCTableTextData))
			.replace(QString("TABLEBODY_3"), QString(DepthCoverageTableData))
			.replace(QString("ALL_NUCLEOTIDE_AV"), QString().setNum(aDepthF, 'f', 1))
			.replace(QString("ALL_CYTOSINES_AV"), QString().setNum(cDepthF, 'f', 1))
			.replace(QString("CS_IN_CPG_AV"), QString().setNum(cgDepthF,'f', 1))
			.replace(QString("CS_IN_CHG_AV"), QString().setNum(chgDepthF,'f', 1))
			.replace(QString("CS_IN_CHH_AV"), QString().setNum(chhDepthF,'f', 1))
			.replace(QString("ALL_NUCLEOTIDE_Q1"), QString().setNum(aFirstQValue))
			.replace(QString("ALL_CYTOSINES_Q1"), QString().setNum(cFirstQValue))
			.replace(QString("CS_IN_CPG_Q1"), QString().setNum(cgFirstQValue))
			.replace(QString("CS_IN_CHG_Q1"), QString().setNum(chgFirstQValue))
			.replace(QString("CS_IN_CHH_Q1"), QString().setNum(chhFirstQValue))
			.replace(QString("ALL_NUCLEOTIDE_Q2"), QString().setNum(aMedianValue))
			.replace(QString("ALL_CYTOSINES_Q2"), QString().setNum(cMedianValue))
			.replace(QString("CS_IN_CPG_Q2"), QString().setNum(cgMedianValue))
			.replace(QString("CS_IN_CHG_Q2"), QString().setNum(chgMedianValue))
			.replace(QString("CS_IN_CHH_Q2"), QString().setNum(chhMedianValue))
			.replace(QString("ALL_NUCLEOTIDE_Q3"), QString().setNum(aThirdQValue))
			.replace(QString("ALL_CYTOSINES_Q3"), QString().setNum(cThirdQValue))
			.replace(QString("CS_IN_CPG_Q3"), QString().setNum(cgThirdQValue))
			.replace(QString("CS_IN_CHG_Q3"), QString().setNum(chgThirdQValue))
			.replace(QString("CS_IN_CHH_Q3"), QString().setNum(chhThirdQValue))
			.replace(QString("SPEARMAN"), QString().setNum(spearman, 'f', 3))
			.replace(QString("PEARSON"), QString().setNum(pearson, 'f', 3))
			.toLatin1()
			);

		// �O���b�h�p���ʃX�^�C��
		QPen gridPen;
		gridPen.setStyle(Qt::SolidLine);
		gridPen.setColor(QColor(0, 0, 0, 25));
		QPen subGridPen;
		subGridPen.setStyle(Qt::DotLine);
		subGridPen.setColor(QColor(0, 0, 0, 25));

		//���[�h�[�x�\���̂��߂̃v���b�g�쐬
		QCustomPlot* customPlot1=new QCustomPlot;
		QVector<qreal> tickVector;
		QVector<QString> labelVector;

		tickVector << -0.5;
		labelVector << QString();

		//Foward and Reverse Strand
		int numData = targets.size() > 200 ? 200 : targets.size();
		//for(int i=0; i<targets.size(); i++){
		for (int i = 0; i<numData; i++){

			QCPStatisticalBox *statBox1 = new QCPStatisticalBox(customPlot1->xAxis, customPlot1->yAxis);
			statBox1->setPen(QColor(247, 171, 108, 255));
			statBox1->setBrush(QColor(255, 232, 214, 255));
			statBox1->setName(QString("Top Strand"));
			customPlot1->addPlottable(statBox1);
			if(i!=0){
				customPlot1->legend->removeItem(customPlot1->legend->itemCount()-1);
			}
			// set data:
			statBox1->setKey((double)(i*2+1));
			if(totalReadsF[i]>0){
				statBox1->setLowerQuartile((double)(firstQsF[i]));
				statBox1->setMedian((double)(mediansF[i]));
				statBox1->setUpperQuartile((double)(thirdQsF[i]));
			}
			else{
				statBox1->setLowerQuartile(0);
				statBox1->setMedian(0);
				statBox1->setUpperQuartile(0);
			}

			tickVector << (double)(i*2)+1.5;
			labelVector << targets[i];

			QCPStatisticalBox *statBox2 = new QCPStatisticalBox(customPlot1->xAxis, customPlot1->yAxis);
			statBox2->setPen(QColor(164, 194, 104, 255));
			statBox2->setBrush(QColor(233, 254, 204, 255));
			statBox2->setName(QString("Bottom Strand"));
			customPlot1->addPlottable(statBox2);
			if(i!=0){
				customPlot1->legend->removeItem(customPlot1->legend->itemCount()-1);
			}
			// set data:
			statBox2->setKey((double)(i*2+2));
			if(totalReadsR[i]>0){
				statBox2->setLowerQuartile((double)(firstQsR[i]));
				statBox2->setMedian((double)(mediansR[i]));
				statBox2->setUpperQuartile((double)(thirdQsR[i]));
			}
			else{
				statBox2->setLowerQuartile(0);
				statBox2->setMedian(0);
				statBox2->setUpperQuartile(0);
			}

		}

		//tickVector << (double)(targets.size()*2)+1.5;
		tickVector << (double)(numData * 2) + 1.5;
		labelVector << QString();

		//Legends
		customPlot1->legend->setVisible(true);

		// x���̏���
		customPlot1->xAxis->setPadding(10); // a bit more space to the left border
		customPlot1->xAxis->setAutoTicks(false);
		customPlot1->xAxis->setAutoTickLabels(false);
		customPlot1->xAxis->setTickVector(tickVector);
		customPlot1->xAxis->setTickVectorLabels(labelVector);
		customPlot1->xAxis->setTickLabelRotation(270);
		customPlot1->xAxis->setSubTickCount(1);
		customPlot1->xAxis->setTickLength(0, 0);
		customPlot1->xAxis->setSubTickLength(4, 4);
		customPlot1->xAxis->grid()->setVisible(true);
		customPlot1->xAxis->setPadding(10);
		customPlot1->xAxis->setLabel(QString("Target"));
		//customPlot1->xAxis->setRange(0, double(targets.size()*2+1));
		customPlot1->xAxis->setRange(0, double(numData * 2 + 1));

		// y���̏���
		customPlot1->yAxis->setRange(0, 100);
		customPlot1->yAxis->setPadding(10); // a bit more space to the left border
		customPlot1->yAxis->grid()->setSubGridVisible(true);
		customPlot1->yAxis->setLabel(QString("Read Depth"));
		customPlot1->yAxis->setRange(0, ((qreal)(thirdQValueF+thirdQValueR)));

		//�������낦�Č����ڗǂ�����
		customPlot1->axisRect()->setupFullAxesBox();
		
		//�O���b�h���w��
		customPlot1->yAxis->grid()->setPen(gridPen);
		customPlot1->yAxis->grid()->setSubGridPen(subGridPen);

		//�`�� �o�[�̉𑜓x�����Ƃ�����
		const int idealPixPerCoord1=20;	// 20px x F, R D
		const int imageHeight=400;
		//int imageWidth=(targets.size()*2)*idealPixPerCoord1;
		int imageWidth = (numData * 2)*idealPixPerCoord1;
		customPlot1->setViewport(QRect(0, 0, imageWidth, imageHeight));
		customPlot1->replot();
		while(true){

			qreal pixcelPerCoord=customPlot1->xAxis->coordToPixel(2)-customPlot1->xAxis->coordToPixel(1);
			if(pixcelPerCoord>=(qreal)idealPixPerCoord1){
				break;
			}
			imageWidth++;
			customPlot1->setViewport(QRect(0, 0, imageWidth, imageHeight));
			customPlot1->replot();

		}

		customPlot1->savePng(ImageFilePath1, imageWidth, imageHeight, 1);

		//���[�h�[�x�\���̂��߂̃v���b�g�쐬
		QCustomPlot* customPlot2=new QCustomPlot;
		//�f�[�^����
		tickVector.clear();
		labelVector.clear();

		tickVector << 0;
		labelVector << QString();
		//Foward and Reverse Strand
		//for(int i=0; i<targets.size(); i++){
		for (int i = 0; i<numData; i++){

			tickVector << (double)(i+1);
			labelVector << targets[i];

			QCPStatisticalBox *statBox3 = new QCPStatisticalBox(customPlot2->xAxis, customPlot2->yAxis);
			statBox3->setPen(QColor(205, 116, 114, 255));
			statBox3->setBrush(QColor(255, 210, 210, 255));
			statBox3->setName(QString("Both Strands"));
			customPlot2->addPlottable(statBox3);
			if(i!=0){
				customPlot2->legend->removeItem(customPlot2->legend->itemCount()-1);
			}
			// set data:
			statBox3->setKey((double)(i+1));
			if(totalReadsD[i]>0){
				statBox3->setLowerQuartile((double)(firstQsD[i]));
				statBox3->setMedian((double)(mediansD[i]));
				statBox3->setUpperQuartile((double)(thirdQsD[i]));
			}
			else{
				statBox3->setLowerQuartile(0);
				statBox3->setMedian(0);
				statBox3->setUpperQuartile(0);
			}

		}
		//tickVector << qreal(targets.size()+1);
		tickVector << qreal(numData + 1);
		
		labelVector << QString();

		//Legends
		customPlot2->legend->setVisible(true);

		// x���̏���
		customPlot2->xAxis->setPadding(10); // a bit more space to the left border
		customPlot2->xAxis->setAutoTicks(false);
		customPlot2->xAxis->setAutoTickLabels(false);
		customPlot2->xAxis->setTickVector(tickVector);
		customPlot2->xAxis->setTickVectorLabels(labelVector);
		customPlot2->xAxis->setTickLabelRotation(270);
		customPlot2->xAxis->setSubTickCount(1);
		customPlot2->xAxis->setTickLength(0, 0);
		customPlot2->xAxis->setSubTickLength(4, 4);
		customPlot2->xAxis->grid()->setVisible(true);
		customPlot2->xAxis->setPadding(10);
		customPlot2->xAxis->setLabel(QString("Target"));
		//customPlot2->xAxis->setRange(0, double(targets.size()+1));
		customPlot2->xAxis->setRange(0, double(numData + 1));

		// y���̏���
		customPlot2->yAxis->setRange(0, 100);
		customPlot2->yAxis->setPadding(10); // a bit more space to the left border
		customPlot2->yAxis->grid()->setSubGridVisible(true);
		customPlot2->yAxis->setLabel(QString("Read Depth"));
		customPlot2->yAxis->setRange(0, ((qreal)thirdQValueD)*2);

		//�������낦�Č����ڗǂ�����
		customPlot2->axisRect()->setupFullAxesBox();
		
		//�O���b�h���w��
		customPlot2->yAxis->grid()->setPen(gridPen);
		customPlot2->yAxis->grid()->setSubGridPen(subGridPen);

		//�`�� �o�[�̉𑜓x�����Ƃ�����
		//const int imageHeight=400;
		//imageWidth=targets.size()*idealPixPerCoord1;
		imageWidth = numData*idealPixPerCoord1;
		customPlot2->setViewport(QRect(0, 0, imageWidth, imageHeight));
		customPlot2->replot();
		while(true){

			qreal pixcelPerCoord=customPlot2->xAxis->coordToPixel(2)-customPlot2->xAxis->coordToPixel(1);
			if(pixcelPerCoord>=(qreal)idealPixPerCoord1){
				break;
			}
			imageWidth++;
			customPlot2->setViewport(QRect(0, 0, imageWidth, imageHeight));
			customPlot2->replot();

		}

		customPlot2->savePng(ImageFilePath2, imageWidth, imageHeight, 1);


		//���F�̖��̃��`�������\���̂��߂̃v���b�g�쐬
		QCustomPlot* customPlot3=new QCustomPlot;
		//�f�[�^����
		tickVector.clear();
		labelVector.clear();
		//for(int i=0; i<targets.size(); i++){
		for (int i = 0; i<numData; i++){
			tickVector << (qreal)(i+1);
			labelVector << targets[i];
		}
		//tickVector << (qreal)targets.size();
		tickVector << (qreal)numData;
		labelVector << QString("all");
		cMethyls<<totalCMethyl;
		cgMethyls<<totalCgMethyl;
		chgMethyls<<totalChgMethyl;
		chhMethyls<<totalChhMethyl;


		//Legends
		customPlot3->legend->setVisible(true);

		customPlot3->addGraph();
		customPlot3->graph(0)->setLineStyle(QCPGraph::lsLine);
		customPlot3->graph(0)->setScatterStyle(QCPScatterStyle::ssCircle);
		customPlot3->graph(0)->setPen(QColor(247, 171, 108, 255));
		customPlot3->graph(0)->setData(tickVector, cMethyls);
		customPlot3->graph(0)->setName(QString("All C"));

		customPlot3->addGraph();
		customPlot3->graph(1)->setLineStyle(QCPGraph::lsLine);
		customPlot3->graph(1)->setScatterStyle(QCPScatterStyle::ssSquare);
		customPlot3->graph(1)->setPen(QColor(164, 194, 104, 255));
		customPlot3->graph(1)->setData(tickVector, cgMethyls);
		customPlot3->graph(1)->setName(QString("CpG"));

		customPlot3->addGraph();
		customPlot3->graph(2)->setLineStyle(QCPGraph::lsLine);
		customPlot3->graph(2)->setScatterStyle(QCPScatterStyle::ssDiamond);
		customPlot3->graph(2)->setPen(QColor(205, 116, 114, 255));
		customPlot3->graph(2)->setData(tickVector, chgMethyls);
		customPlot3->graph(2)->setName(QString("CHG"));

		customPlot3->addGraph();
		customPlot3->graph(3)->setLineStyle(QCPGraph::lsLine);
		customPlot3->graph(3)->setScatterStyle(QCPScatterStyle::ssTriangle);
		customPlot3->graph(3)->setPen(QColor(116, 156, 202, 255));
		customPlot3->graph(3)->setData(tickVector, chhMethyls);
		customPlot3->graph(3)->setName(QString("CHH"));
		

		// x���̏���
		customPlot3->xAxis->setPadding(10); // a bit more space to the left border
		customPlot3->xAxis->setAutoTicks(false);
		customPlot3->xAxis->setAutoTickLabels(false);
		customPlot3->xAxis->setTickVector(tickVector);
		customPlot3->xAxis->setTickVectorLabels(labelVector);
		customPlot3->xAxis->setTickLabelRotation(270);
		customPlot3->xAxis->setSubTickCount(0);
		customPlot3->xAxis->setTickLength(0, 4);
		customPlot3->xAxis->grid()->setVisible(true);
		//customPlot3->xAxis->setRange(0, (qreal)(targets.size()+1));
		customPlot3->xAxis->setRange(0, (qreal)(numData + 1));
		customPlot3->xAxis->setLabel(QString("Target"));

		// y���̏���
		customPlot3->yAxis->setRange(0, 100);
		customPlot3->yAxis->setPadding(10); // a bit more space to the left border
		customPlot3->yAxis->grid()->setSubGridVisible(true);
		customPlot3->yAxis->setLabel(QString("Average Methylation Level (%)"));
		customPlot3->yAxis->rescale();

		//�������낦�Č����ڗǂ�����
		customPlot3->axisRect()->setupFullAxesBox();
		
		//�O���b�h���w��
		customPlot3->yAxis->grid()->setPen(gridPen);
		customPlot3->yAxis->grid()->setSubGridPen(subGridPen);

		const int idealPixPerCoord2=20;	// 20px x F, R D
		//const int imageHeight=400;
		//imageWidth=targets.size()*idealPixPerCoord2;
		imageWidth = numData*idealPixPerCoord2;
		customPlot3->setViewport(QRect(0, 0, imageWidth, imageHeight));
		customPlot3->replot();
		while(true){

			qreal pixcelPerCoord=customPlot3->xAxis->coordToPixel(2)-customPlot3->xAxis->coordToPixel(1);
			if(pixcelPerCoord>=(qreal)idealPixPerCoord2){
				break;
			}
			imageWidth++;
			customPlot3->setViewport(QRect(0, 0, imageWidth, imageHeight));
			customPlot3->replot();

		}

		//�`��
		customPlot3->replot();
		customPlot3->savePng(ImageFilePath3, imageWidth, imageHeight, 1);

		//���[�h�[�x��GC�R���e���g�ˑ����m�F�̂��߂̃v���b�g�쐬
		QCustomPlot* customPlot4=new QCustomPlot;
		//Legends
		customPlot4->legend->setVisible(true);

		//�E�C���h�E���̃o�[�v���b�g
		QCPBars *barPlot = new QCPBars(customPlot4->xAxis, customPlot4->yAxis2);
		customPlot4->addPlottable(barPlot);
		barPlot->setName(QString("Number of Windows(Size=%1bp, Step=%2bp)").arg(windowSize).arg(stepSize));
		QPen BoxStyle;
		BoxStyle.setWidthF(1.2);
		BoxStyle.setColor(QColor(164, 194, 104, 255));
		barPlot->setPen(BoxStyle);
		barPlot->setBrush(QColor(233, 254, 204, 255));
		barPlot->setData(windowTicks, windowNums);

		//���[�h�[�x�̔��Ђ�
		for(int i=0; i<NumGrade+1; i++){

			QCPStatisticalBox *statBox = new QCPStatisticalBox(customPlot4->xAxis, customPlot4->yAxis);
			statBox->setPen(QColor(247, 171, 108, 150));
			statBox->setBrush(QColor(255, 232, 214, 150));
			statBox->setName(QString("Average Read Depth"));
			customPlot4->addPlottable(statBox);
			if(i!=0){
				customPlot4->legend->removeItem(customPlot4->legend->itemCount()-1);
			}
			// set data:
			statBox->setKey(windowTicks[i]);
			statBox->setLowerQuartile(windowFirstqs[i]);
			statBox->setMedian(windowMedians[i]);
			statBox->setUpperQuartile(windowThirdqs[i]);

		}

		// x���̏���
		customPlot4->xAxis->setPadding(10); // a bit more space to the left border
		customPlot4->xAxis->setAutoTicks(false);
		customPlot4->xAxis->setAutoTickLabels(false);
		customPlot4->xAxis->setTickVector(windowTicks);
		customPlot4->xAxis->setTickVectorLabels(gcContentsLabel);
		customPlot4->xAxis->setTickLabelRotation(0);
		customPlot4->xAxis->setSubTickCount(0);
		customPlot4->xAxis->setTickLength(0, 4);
		customPlot4->xAxis->grid()->setVisible(true);
		customPlot4->xAxis->setRange(0, (double)(windowTicks.size()+1));
		customPlot4->xAxis->setLabel(QString("GC Content"));

		// y���̏���
		customPlot4->yAxis->setPadding(10); // a bit more space to the left border
		customPlot4->yAxis->setLabel(QString("Average Read Depth"));
		customPlot4->yAxis->setRange(0, ceil(windowDepth)*2);
		customPlot4->yAxis->grid()->setSubGridVisible(true);

		// y2���̏���
		customPlot4->yAxis2->setPadding(10);
		customPlot4->yAxis2->setLabel(QString("Number of Windows"));
		customPlot4->yAxis2->rescale();
		customPlot4->yAxis2->setVisible(true);

		//�O���b�h���w��
		customPlot4->yAxis->grid()->setPen(gridPen);
		customPlot4->yAxis->grid()->setSubGridPen(subGridPen);

		//�`��
		customPlot4->replot();
		customPlot4->savePng(ImageFilePath4, 1200, 400, 1);

		//���[�h�[�x�ƃJ�o���[�W
		QCustomPlot* customPlot5=new QCustomPlot;
		//Legends
		customPlot5->legend->setVisible(true);

		customPlot5->addGraph();
		customPlot5->graph(0)->setLineStyle(QCPGraph::lsLine);
		customPlot5->graph(0)->setScatterStyle(QCPScatterStyle::ssCrossSquare);
		customPlot5->graph(0)->setPen(QColor(106, 188, 210, 255));
		customPlot5->graph(0)->setData(depthListF, aDepthListF);
		customPlot5->graph(0)->setName(QString("All Nucleotids"));

		customPlot5->addGraph();
		customPlot5->graph(1)->setLineStyle(QCPGraph::lsLine);
		customPlot5->graph(1)->setScatterStyle(QCPScatterStyle::ssCircle);
		customPlot5->graph(1)->setPen(QColor(247, 171, 108, 255));
		customPlot5->graph(1)->setData(depthListF, cDepthListF);
		customPlot5->graph(1)->setName(QString("All Cytosines"));

		customPlot5->addGraph();
		customPlot5->graph(2)->setLineStyle(QCPGraph::lsLine);
		customPlot5->graph(2)->setScatterStyle(QCPScatterStyle::ssSquare);
		customPlot5->graph(2)->setPen(QColor(164, 194, 104, 255));
		customPlot5->graph(2)->setData(depthListF, cgDepthListF);
		customPlot5->graph(2)->setName(QString("CpGs"));

		customPlot5->addGraph();
		customPlot5->graph(3)->setLineStyle(QCPGraph::lsLine);
		customPlot5->graph(3)->setScatterStyle(QCPScatterStyle::ssDiamond);
		customPlot5->graph(3)->setPen(QColor(205, 116, 114, 255));
		customPlot5->graph(3)->setData(depthListF, chgDepthListF);
		customPlot5->graph(3)->setName(QString("CHGs"));

		customPlot5->addGraph();
		customPlot5->graph(4)->setLineStyle(QCPGraph::lsLine);
		customPlot5->graph(4)->setScatterStyle(QCPScatterStyle::ssTriangle);
		customPlot5->graph(4)->setPen(QColor(116, 156, 202, 255));
		customPlot5->graph(4)->setData(depthListF, chhDepthListF);
		customPlot5->graph(4)->setName(QString("CHHs"));
		

		// x���̏���
		customPlot5->xAxis->setPadding(10); // a bit more space to the left border
		customPlot5->xAxis->setAutoTicks(true);
		customPlot5->xAxis->setAutoTickLabels(true);
		//customPlot5->xAxis->setTickVector(depthList);
		//customPlot5->xAxis->setTickVectorLabels(depthStringList);
		customPlot5->xAxis->setTickLabelRotation(0);
		customPlot5->xAxis->setSubTickCount(0);
		customPlot5->xAxis->setTickLength(0, 4);
		customPlot5->xAxis->grid()->setVisible(true);
		customPlot5->xAxis->setRange(0, ceil((totalAverageF+totalAverageR)*2));
		customPlot5->xAxis->setLabel(QString("Read Depth"));

		// y���̏���
		customPlot5->yAxis->setPadding(10); // a bit more space to the left border
		customPlot5->yAxis->grid()->setSubGridVisible(true);
		customPlot5->yAxis->setLabel(QString("Genomic Region Covered with \nthe Indicated Read Depth [%]"));
		customPlot5->yAxis->rescale();

		//�������낦�Č����ڗǂ�����
		customPlot5->axisRect()->setupFullAxesBox();
		
		//�O���b�h���w��
		customPlot5->yAxis->grid()->setPen(gridPen);
		customPlot5->yAxis->grid()->setSubGridPen(subGridPen);

		//�`��
		customPlot5->replot();
		customPlot5->savePng(ImageFilePath5, 1200, 400, 1);

		//�ݐσ��[�h�[�x�ƃJ�o���[�W
		QCustomPlot* customPlot6=new QCustomPlot;
		//Legends
		customPlot6->legend->setVisible(true);

		customPlot6->addGraph();
		customPlot6->graph(0)->setLineStyle(QCPGraph::lsLine);
		customPlot6->graph(0)->setScatterStyle(QCPScatterStyle::ssCrossSquare);
		customPlot6->graph(0)->setPen(QColor(106, 188, 210, 255));
		customPlot6->graph(0)->setData(depthListF, cumAListF);
		customPlot6->graph(0)->setName(QString("All Nucleotids"));

		customPlot6->addGraph();
		customPlot6->graph(1)->setLineStyle(QCPGraph::lsLine);
		customPlot6->graph(1)->setScatterStyle(QCPScatterStyle::ssCircle);
		customPlot6->graph(1)->setPen(QColor(247, 171, 108, 255));
		customPlot6->graph(1)->setData(depthListF, cumCListF);
		customPlot6->graph(1)->setName(QString("All Cytosines"));

		customPlot6->addGraph();
		customPlot6->graph(2)->setLineStyle(QCPGraph::lsLine);
		customPlot6->graph(2)->setScatterStyle(QCPScatterStyle::ssSquare);
		customPlot6->graph(2)->setPen(QColor(164, 194, 104, 255));
		customPlot6->graph(2)->setData(depthListF, cumCpgListF);
		customPlot6->graph(2)->setName(QString("CpGs"));

		customPlot6->addGraph();
		customPlot6->graph(3)->setLineStyle(QCPGraph::lsLine);
		customPlot6->graph(3)->setScatterStyle(QCPScatterStyle::ssDiamond);
		customPlot6->graph(3)->setPen(QColor(205, 116, 114, 255));
		customPlot6->graph(3)->setData(depthListF, cumChgListF);
		customPlot6->graph(3)->setName(QString("CHGs"));

		customPlot6->addGraph();
		customPlot6->graph(4)->setLineStyle(QCPGraph::lsLine);
		customPlot6->graph(4)->setScatterStyle(QCPScatterStyle::ssTriangle);
		customPlot6->graph(4)->setPen(QColor(116, 156, 202, 255));
		customPlot6->graph(4)->setData(depthListF, cumChhListF);
		customPlot6->graph(4)->setName(QString("CHHs"));
		

		// x���̏���
		customPlot6->xAxis->setPadding(10); // a bit more space to the left border
		customPlot6->xAxis->setAutoTicks(true);
		customPlot6->xAxis->setAutoTickLabels(true);
		customPlot6->xAxis->setTickLabelRotation(0);
		customPlot6->xAxis->setSubTickCount(0);
		customPlot6->xAxis->setTickLength(0, 4);
		customPlot6->xAxis->grid()->setVisible(true);
		customPlot6->xAxis->setRange(0, ceil((totalAverageF+totalAverageR)*2));
		customPlot6->xAxis->setLabel(QString("Read Depth"));

		// y���̏���
		customPlot6->yAxis->setRange(0, 100);
		customPlot6->yAxis->setPadding(10); // a bit more space to the left border
		customPlot6->yAxis->grid()->setSubGridVisible(true);
		customPlot6->yAxis->setLabel(QString("Genomic Region Covered with\nthe Indicated Read Depth\n and More [%]"));

		//�������낦�Č����ڗǂ�����
		customPlot6->axisRect()->setupFullAxesBox();
		
		//�O���b�h���w��
		customPlot6->yAxis->grid()->setPen(gridPen);
		customPlot6->yAxis->grid()->setSubGridPen(subGridPen);

		//�`��
		customPlot6->replot();
		customPlot6->savePng(ImageFilePath6, 1200, 400, 1);

	}
	else{

		//���[�h�̐[�x
		//���F�̖��̃��[�h�f�v�X
		QByteArray TableTextData;
		QBuffer TableTextStreamBuffer(&TableTextData);
		TableTextStreamBuffer.open(QIODevice::WriteOnly);
		QTextStream TableTextStream(&TableTextStreamBuffer);

		for(int i=0; i<targets.size(); i++){
			
			TableTextStream << targets[i] << '\t';
			TableTextStream << ThousandSeparator(QString().setNum(targetSizes[i])).putSeparator() << '\t';
			
			if(totalReadsF[i]>0){
				TableTextStream << ThousandSeparator(QString().setNum(totalReadsF[i])).putSeparator() << '\t';
				TableTextStream << QString().setNum(averagesF[i], 'f', 1) << '\t';
				TableTextStream << firstQsF[i] << '\t';
				TableTextStream << mediansF[i] << '\t';
				TableTextStream << thirdQsF[i] << '\t';
			}
			else{
				TableTextStream << "0\t";
				TableTextStream << "-\t";
				TableTextStream << "-\t";
				TableTextStream << "-\t";
				TableTextStream << "-\t";
			}

			if(totalReadsR[i]>0){
				TableTextStream << ThousandSeparator(QString().setNum(totalReadsR[i])).putSeparator() << '\t';
				TableTextStream << QString().setNum(averagesR[i], 'f', 1) << '\t';
				TableTextStream << firstQsR[i] << '\t';
				TableTextStream << mediansR[i] << '\t';
				TableTextStream << thirdQsR[i] << '\t';
			}
			else{
				TableTextStream << "0\t";
				TableTextStream << "-\t";
				TableTextStream << "-\t";
				TableTextStream << "-\t";
				TableTextStream << "-\t";
			}

			if(totalReadsD[i]>0){
				TableTextStream << ThousandSeparator(QString().setNum(totalReadsD[i])).putSeparator() << '\t';
				TableTextStream << QString().setNum(averagesD[i], 'f', 1) << '\t';
				TableTextStream << firstQsD[i] << '\t';
				TableTextStream << mediansD[i] << '\t';
				TableTextStream << thirdQsD[i] << '\t';
			}
			else{
				TableTextStream << "0\t";
				TableTextStream << "-\t";
				TableTextStream << "-\t";
				TableTextStream << "-\t";
				TableTextStream << "-\t";
			}

			if(cCounts[i]>0){
				TableTextStream << QString().setNum(cMethyls[i], 'f', 1) << '\t';
			}
			else{
				TableTextStream << "-\t";
			}

			if(cgCounts[i]>0){
				TableTextStream << QString().setNum(cgMethyls[i], 'f', 1) << '\t';
			}
			else{
				TableTextStream << "-\t";
			}

			if(chgCounts[i]>0){
				TableTextStream << QString().setNum(chgMethyls[i], 'f', 1) << '\t';
			}
			else{
				TableTextStream << "-\t";
			}

			if(chhCounts[i]>0){
				TableTextStream << QString().setNum(chhMethyls[i], 'f', 1) << '\t';
			}
			else{				
				TableTextStream << '\t';
			}

			TableTextStream << endl;

		}

		//�S���F��
		TableTextStream << "all\t";
		TableTextStream << ThousandSeparator(QString().setNum(targetSize)).putSeparator() << '\t';
			
		TableTextStream << ThousandSeparator(QString().setNum(totalReadF)).putSeparator() << '\t';
		TableTextStream << QString().setNum(totalAverageF, 'f', 1) << '\t';
		TableTextStream << firstQValueF << '\t';
		TableTextStream << medianValueF << '\t';
		TableTextStream << thirdQValueF << '\t';

		TableTextStream << ThousandSeparator(QString().setNum(totalReadR)).putSeparator() << '\t';
		TableTextStream << QString().setNum(totalAverageR, 'f', 1) << '\t';
		TableTextStream << firstQValueR << '\t';
		TableTextStream << medianValueR << '\t';
		TableTextStream << thirdQValueR << '\t';

		TableTextStream << ThousandSeparator(QString().setNum(totalReadD)).putSeparator() << '\t';
		TableTextStream << QString().setNum(totalAverage, 'f', 1) << '\t';
		TableTextStream << firstQValueD << '\t';
		TableTextStream << medianValueD << '\t';
		TableTextStream << thirdQValueD << '\t';

		TableTextStream << QString().setNum(totalCMethyl, 'f', 1) << '\t';
		TableTextStream << QString().setNum(totalCgMethyl, 'f', 1) << '\t';
		TableTextStream << QString().setNum(totalChgMethyl, 'f', 1) << '\t';
		TableTextStream << QString().setNum(totalChhMethyl, 'f', 1) << '\t';

		TableTextStream << endl;
		TableTextStreamBuffer.close();



		//GC�ˑ��}�b�s���O�o�C�A�X
		QByteArray GCTableTextData;
		QBuffer GCTableTextStreamBuffer(&GCTableTextData);
		GCTableTextStreamBuffer.open(QIODevice::WriteOnly);
		QTextStream GCTableTextStream(&GCTableTextStreamBuffer);

		for(int i=0; i<NumGrade+1; i++){
			GCTableTextStream << gcContentsLabel[i] << '\t';
			GCTableTextStream << ThousandSeparator(QString().setNum(windowNumsI[i])).putSeparator() << '\t';
			GCTableTextStream << QString().setNum(windowAverages[i], 'f', 1) << '\t';
			GCTableTextStream << QString().setNum(windowFirstqs[i], 'f', 1) << '\t';
			GCTableTextStream << QString().setNum(windowMedians[i], 'f', 1) << '\t';
			GCTableTextStream << QString().setNum(windowThirdqs[i], 'f', 1) << '\t';
			GCTableTextStream << endl;
		}

		GCTableTextStreamBuffer.close();


		//���[�h�[�x�����J�o���[�W



	}


	return 0;

}
