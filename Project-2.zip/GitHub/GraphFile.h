#ifndef GENOMIC_GRAPH_DATA_H
#define GENOMIC_GRAPH_DATA_H

#include <QtCore>
#if QT_VERSION >= 0x050000
#include <QtWidgets>
#else
#include <QtGui>
#endif

#include <cmath>
#include <iostream>

#include "DesktopTrackCommon.h"
#include "FileBuffer.h"

namespace DesktopTrack{

	namespace GraphFile{

		struct Header{
			//for version 2, unsigned integer and float value is allowed
			//for version 3, only unsigned integer is allowed
			quint32			magic;		//1234
			quint32			version;	//1 or 2 or 3 (with annotation)

			//basic info
			QString			trackName;
			QString			species;
			QString			revision;

			//
			quint32			dataType;				//0=int, 1=float

			//target info
			quint64			targetListOffset;		//
			quint32			targetListDataSize;
			quint32			targetListDataCount;

			//track configuration
			quint32			rowHeight;
			quint32			fontSize;
			QColor			fgColor;
            QColor			bgColor;
            QColor			anColor;
			//QColor			markerColor;
			qint32			strandSpecificity;	//0:separate, 1:unify

			quint32			maxValue;
			quint32			minValue;

			Header(void);
			Header(const Header& original);
			Header&	operator=(const Header& original);

			bool			isCorrectFile(void);
			void			getSerialized(QDataStream& in);
			void			putSerialized(QDataStream& out);
		};

		struct Target{
			static int	version;			//default 2
			static void setVersion(const int& version);
			QString		targetName;
			quint32		targetLength;
			quint64		fwDataOffset;		//ver1->32, ver2->64
			quint32		fwDataSize;
			quint64		rvDataOffset;		//ver1->32, ver2->64
			quint32		rvDataSize;
			Target(void);
			Target(const QString& target_name, const quint32& target_length);
			Target(const Target& original);
			Target& operator=(const Target& original);
			void putSerialized(QDataStream& out);
			void getSerialized(QDataStream& in);
		};

		struct TargetLess{
			TargetLess(void);
			bool operator()(const Target& a, const Target& b);
		};

		class FileCreator: public QThread{
		public:
			enum Process{registering, outputting, stopped, failed, finished};

		private:
			
			/*-----thread�ԒʐM�p�̕ϐ�-----*/
			QMutex	mutex;
			bool	promoteProcess;
			Process processStatus;
			quint64	processedData;
			quint64	totalData;
			int	processedFile;
			int	totalFile;

		public:

			/*-----�O���������֖��߂�������֐�(Thread Safe)-------*/
			void setOrder(bool proceed);

			/*-----�O���������̏�Ԃ��󂯎��֐�(Thread Safe)-------*/
			void getProcessStatus(	Process& process_status,
									quint64& prosessed_data,
									quint64& total_data);

		private:
			/*-----�������O���̖��߂��󂯎��֐�(Thread Safe)-------*/
			bool getOrder(void);


			/*-----�������O���֏�Ԃ�񍐂���֐�(Thread Safe)-------*/
			void setProcessStatus(	const Process& process_status,
									const quint64& prosessed_data,
									const quint64& total_data);

			//�w�b�_�[�Q
			Header						header;

			QList<Target>				targetList;
			QMap<QString, quint32>		targetMap;
			QMap<QString, QString>		renameMap;
			QSet<QString>				featureTypesToBeIgnored;

			QString						targetFilePath;
			QString						analysisResultFilePath;

		public:
			
			/*------------�R���X�g���N�^-----------*/
			FileCreator(QObject* parent=0);

			/*------------������-------------------*/
			void					initialize(void);

			//�ȉ��̏��Ԃɏ��̓o�^�͍s����
			void					setTrackConfig(const Header& config);
			void					setTargetFilePath(const QString& target_file_name);
			void					setAnalysisResultFile(const QString& path_to_analysis_result_file);
			void					setIgnoredFeatureTypes(const QStringList& ignored_feature_types);
			void					setTargetList(const QList<QPair<QString, quint32> >& target_list);
			void					setRenameMap(const QMap<QString, QString>& rename_map);
			

			void					run(void);

		private:

		};

		class FileReader{
		protected:
			Header					header;
			QList<Target>			targetList;
			QMap<QString, int>		targetMap;
			QFile					file;

		public:
			FileReader(void);

			bool					setFile(const QString& filePath);
			bool					releaseFile(void);

			bool					unsetFile(void);

			const Header&			getBasicTrackInfo(void) const;

			const QList<Target>&	getTargetList(void) const;

			bool					targetContains(const QString& target_name);

			bool					setBasicTrackConf(const Header& conf);


			bool					getData(const QString& target_name, 
											const qint32& strand,
											QVector<quint32>& data_to);
											
			bool					getData(const QString& target_name, 
											const qint32& strand,
											QVector<float>& data_to);

			bool					getData(const QString& target_name,
											const quint32& start,
											const quint32& end,
											const qint32& strand,
											QVector<quint32>& data_to);
											
			bool					getData(const QString& target_name,
											const quint32& start,
											const quint32& end,
											const qint32& strand,
											QVector<quint32>& data_to_1,
											QVector<quint32>& data_to_2);

			bool					getData(const QString& target_name,
											const quint32& start,
											const quint32& end,
											const qint32& strand,
											QVector<float>& data_to);

			bool					getData(const QString& target_name,
											const quint32& start,
											const quint32& end,
											const qint32& strand,
											QVector<float>& data_to_1,
											QVector<float>& data_to_2);

			//only for version 3
			bool					getAnnotation(
											const QString& target_name,
											const qint32& strand,
											QBitArray& annotation_to);

			bool					getAnnotation(
											const QString& target_name,
											const quint32& start,
											const quint32& end,
											const qint32& strand,
											QBitArray& annotation_to);


		};
	};
};

#endif
